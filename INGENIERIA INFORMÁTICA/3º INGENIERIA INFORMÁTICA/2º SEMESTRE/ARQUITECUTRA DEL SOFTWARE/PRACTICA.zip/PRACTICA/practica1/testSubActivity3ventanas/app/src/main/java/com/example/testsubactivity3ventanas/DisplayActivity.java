package com.example.testsubactivity3ventanas;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class DisplayActivity extends AppCompatActivity {

    String name="no_name";
    private static final int SHOW_SUBACTIVITY = 1;

    public void displayMessage(View view) {
        Bundle bundle = new Bundle();
        bundle.putString("name", name);
        Intent intent = new Intent(getApplicationContext(), DisplayActivity2.class);
        intent.putExtras(bundle);
        startActivityForResult(intent, SHOW_SUBACTIVITY);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {//crear el boton de vuelta
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        name= bundle.getString("name");
        TextView textView =((TextView) findViewById(R.id.textViewDisplay));
        textView.setTextSize(40);
        textView.setText(name);
    }

    public void saveName(View view) {//Para volver a la anterior
        Bundle bundle = new Bundle();
        EditText editText = (EditText) findViewById(R.id.edit_name);
        String name = editText.getText().toString();
        bundle.putString("name", name);
        Intent intent = new Intent();
        intent.putExtras(bundle);
        setResult(RESULT_OK, intent);
        finish();
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {//PARA QUE SALGA LA VENTANA
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            Bundle bundle = data.getExtras();
            String name= bundle.getString("name");
            TextView textView =((TextView) findViewById(R.id.textViewDisplay));
            textView.setTextSize(40);
            textView.setText(name);
        }
    }

}