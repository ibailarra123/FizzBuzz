package com.example.testlistsubactivity3ventanas;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class DisplayActivity extends AppCompatActivity {

    private static final int SHOW_SUBACTIVITY = 1;

    ListView listView;
    ArrayAdapter<String> todoItemsAdapter;
    public List<String> nameList = new ArrayList<>();
    String name;
    int position;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        name= bundle.getString("name");
        TextView textView =((TextView) findViewById(R.id.textViewDisplay));
        textView.setTextSize(40);
        textView.setText(name);

        position= bundle.getInt("position");
        TextView textView1 =((TextView) findViewById(R.id.textViewPosition));
        textView1.setTextSize(40);
        textView1.setText(Integer.toString(position));
    }

    public void saveName(View view) {
        Bundle bundle = new Bundle();
        EditText editText = (EditText) findViewById(R.id.edit_name);
        String name = editText.getText().toString();
        bundle.putString("name", name);
        Intent intent = new Intent();
        intent.putExtras(bundle);
        setResult(RESULT_OK, intent);

        bundle.putInt("position", position);

        finish();
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            Bundle bundle = data.getExtras();
            String name= bundle.getString("name");
            int position = bundle.getInt("position");
            nameList.set(position, name);
            todoItemsAdapter.notifyDataSetChanged();
        }
    }
}