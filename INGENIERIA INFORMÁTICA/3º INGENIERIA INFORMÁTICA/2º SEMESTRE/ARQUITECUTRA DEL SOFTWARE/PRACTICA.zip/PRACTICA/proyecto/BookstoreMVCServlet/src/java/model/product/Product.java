
package model.product;
import java.io.Serializable;

public class Product implements Serializable, Comparable {
    private int id;
    private String title = null;
    private String firstName = null;
    private String surname = null;
    private float price = 0.0F;
    private int year = 0;
    private String description = null;
    
    public Product(int bookId, String surname, String firstName, 
                       String title, float price, int year,
                       String description) {
        this.id = bookId;
        this.title = title;
        this.firstName =  firstName;
        this.surname = surname;
        this.price = price;
        this.year = year;
        this.description = description;
    }

    public String getTitle() {
        return title;
    }
    
    public float getPrice() {
       return price;
    }

    public int getYear() {
        return year;
    }

    public String getDescription() {
        return description;
    }

    public int getId() {
        return this.id;
    }

    public int getProductId() {
        return this.id;
    }
    
    public String getFirstName() {
        return this.firstName;
    }

    public String getSurname() {
        return this.surname;
    }
    public int compareTo(Object o) {
			Product n = (Product)o;
			int lastCmp = title.compareTo(n.title);
				return (lastCmp);
    }		
}

