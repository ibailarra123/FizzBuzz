/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.order;

import java.util.*;

/**
 *
 * @author usuario
 */
public class CustomerOrderDB {

    List<CustomerOrder> items;
    private static CustomerOrderDB onlyInstance = null;
    private int customerOrderId;
   

     public CustomerOrderDB() {
        items = new ArrayList<CustomerOrder>();
        customerOrderId = -1;
        
     }
     
    public static CustomerOrderDB instance() {
        if (onlyInstance == null)
        onlyInstance = new CustomerOrderDB();
       return onlyInstance; 
    }
    
    public synchronized void add(CustomerOrder order) {
       ++customerOrderId;
       order.setId(customerOrderId);
       items.add(order);
    }

    public CustomerOrder find(int orderId) {
        return items.get(orderId); 
    }
    
}
