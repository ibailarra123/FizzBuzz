/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.order;

import java.util.*;


/**
 *
 * @author usuario
 */
public class CustomerDB {

    private static CustomerDB onlyInstance = null;
    List<Customer> items;
    private int customerId;
        
    public CustomerDB() {
        items = new ArrayList<Customer>();
        customerId = -1;
        
     }
    public static CustomerDB instance() {
        if (onlyInstance == null)
        onlyInstance = new CustomerDB();
       return onlyInstance; 
    }
     
    public void add(Customer customer) {
        
       ++customerId;
       customer.setId(customerId);
       items.add(customer);
    }
    
}
