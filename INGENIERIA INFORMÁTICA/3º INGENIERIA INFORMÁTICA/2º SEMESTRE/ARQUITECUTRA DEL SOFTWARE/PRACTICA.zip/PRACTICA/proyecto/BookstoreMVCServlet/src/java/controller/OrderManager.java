package controller;

import model.product.Product;
import model.product.ProductDB;
import model.cart.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import model.order.Customer;
import model.order.CustomerDB;
import model.order.CustomerOrder;
import model.order.CustomerOrderDB;
import model.order.OrderedProduct;
import model.order.OrderedProductDB;

public class OrderManager {
  
    private ProductDB productDB;
   
    private CustomerDB customerDB;
     
    private CustomerOrderDB customerOrderDB;
    
    private OrderedProductDB orderedProductDB;
    
    private static OrderManager onlyInstance = null;

    public OrderManager () {
        this.customerDB = CustomerDB.instance();
        this.customerOrderDB = CustomerOrderDB.instance();
        this.orderedProductDB = OrderedProductDB.instance();
        
    }
    
    public void setProductDB(ProductDB productDB){
        this.productDB = productDB;
    }
    
    public static OrderManager instance () {
      if (onlyInstance == null)
        onlyInstance = new OrderManager();
      return onlyInstance;
   }
    
    public int placeOrder(String name, String address, String ccNumber, ShoppingCart cart) {

        try {
            Customer customer = addCustomer(name, address, ccNumber);
            CustomerOrder order = addOrder(customer, cart);
            addOrderedItems(order, cart);
            return order.getId();
        } catch (Exception e) {
            return 0;
        }
    }

    private Customer addCustomer(String name, String address, String ccNumber) {

        Customer customer = new Customer();
        customer.setName(name);     
        customer.setAddress(address);
        customer.setCcNumber(ccNumber);

        customerDB.add(customer);
        return customer;
    }

    private CustomerOrder addOrder(Customer customer, ShoppingCart cart) {

        // set up customer order
        CustomerOrder order = new CustomerOrder();
        order.setCustomer(customer);
        order.setAmount(BigDecimal.valueOf(cart.getTotal()));

        // create confirmation number
        Random random = new Random();
        int i = random.nextInt(999999999);
        order.setConfirmationNumber(i);

        customerOrderDB.add(order);
        return order;
    }

    private void addOrderedItems(CustomerOrder order, ShoppingCart cart) {

        List<ShoppingCartItem> items = cart.getItems();

        // iterate through shopping cart and create OrderedProducts
        for (ShoppingCartItem scItem : items) {

            int productId = scItem.getProduct().getId();
      
            // create ordered item
            OrderedProduct orderedItem = new OrderedProduct(order.getCustomer().getId(),productId);

            // set quantity
            orderedItem.setQuantity(scItem.getQuantity());
            orderedProductDB.add(orderedItem);
        }
    }

    public Map getOrderDetails(int orderId) {

        Map orderMap = new HashMap();

        CustomerOrder order = customerOrderDB.find(orderId);

        Customer customer = order.getCustomer();

        List<OrderedProduct> orderedProducts = orderedProductDB.findByOrderId(orderId);

        List<Product> products = new ArrayList<Product>();

        for (OrderedProduct op : orderedProducts) {
            Product p = (Product) productDB.find(op.getProductId());
            products.add(p);
        }

        // add each item to orderMap
        orderMap.put("orderRecord", order);
        orderMap.put("customer", customer);
        orderMap.put("products", products);

        return orderMap;
    }

}