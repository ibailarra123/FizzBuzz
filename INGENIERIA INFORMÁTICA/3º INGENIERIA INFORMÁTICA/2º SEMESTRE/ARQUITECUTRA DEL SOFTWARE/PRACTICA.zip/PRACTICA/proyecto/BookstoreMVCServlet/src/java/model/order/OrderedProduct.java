/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.order;

import java.io.Serializable;
import model.product.Product;


public class OrderedProduct implements Serializable{

    private int customerOrderId;
    private int productId;
    private int quantity;
    
   public OrderedProduct(int customerOrderId, int productId) {
          this.customerOrderId = customerOrderId;
          this.productId = productId;
    }

    public void setQuantity(short quantity) {
        this.quantity = quantity;
        }
    
    public int getProductId() {
        return productId;
    }

    public int getOrderId() {
    return   customerOrderId;
    }
    
}
