package controller;

import java.io.IOException;
import java.util.Collection;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.cart.ShoppingCart;
import model.product.ProductDB;
import model.product.Product;

public class ControlServlet extends HttpServlet {

    private ProductDB bookDB;
    private OrderManager orderManager;
   
    public void init() throws ServletException {
        bookDB =
            (ProductDB)getServletContext().getAttribute("database");

        if (bookDB == null) {
        		bookDB = ProductDB.instance();
                  getServletContext().setAttribute("database", bookDB);
        }	
        orderManager =
            (OrderManager)getServletContext().getAttribute("ordermanager");

        if (orderManager == null) {
        		orderManager = OrderManager.instance();
                        orderManager.setProductDB(bookDB);
                  getServletContext().setAttribute("ordermanager", orderManager);
        }	
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String userPath = request.getServletPath();
        HttpSession session = request.getSession();
        //Category selectedCategory;
        Collection<Product> books;

        System.out.println("GET, userpath: "+userPath);

         // if category page is requested
         switch (userPath) {
             case "/catalog":              
                 getCatalog(bookDB,session);
                 break;
             case "/bookdetails":       
                String bookId = request.getParameter("bookId");
                 if (bookId != null) {
                     getBookDetails(bookId,session);  
                 }
                  // if cart page is requested
                 break;
             case "/viewCart":
                 String clear = request.getParameter("clear");
                 getViewCart(clear, session);
                 userPath = "/cart";
                 break;
             case "/checkout":
                 getCheckout(session);
                 userPath = "/checkout";
                 break;  
         }
        // use RequestDispatcher to forward request internally
        String url = "/WEB-INF/view" + userPath + ".jsp";

        try {
            request.getRequestDispatcher(url).forward(request, response);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
 protected void getCatalog(ProductDB bookDB,HttpSession session){
       // get all books        
                 Collection<Product> books = bookDB.getBooks();
                  // place books in session scope
                 
                 session.setAttribute("catalogBooks", books); 
            
 }
 
  protected void getBookDetails(String bookId,HttpSession session){      
              
                 Product bd = bookDB.getBookDetails(bookId);
               // place book in session scope
                 session.setAttribute("bookdetail", bd);
            
 }
  
  protected void getViewCart(String clear, HttpSession session){      
              
                if ((clear != null) && clear.equals("true")) {                     
                     ShoppingCart cart = (ShoppingCart) session.getAttribute("cart");
                     cart.clear();
                 }   
                       
 }  
  
 protected void getCheckout(HttpSession session){      
              
                 ShoppingCart cart = (ShoppingCart) session.getAttribute("cart");
                 // calculate total
                 cart.calculateTotal("10");
           
 }  

  
    @Override
   protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8"); 
        String userPath = request.getServletPath();
        HttpSession session = request.getSession();
        ShoppingCart cart = (ShoppingCart) session.getAttribute("cart");

        //System.out.println("POST, userpath: "+userPath);
        switch (userPath) {
             case "/addToCart":
                {
                 // if user is adding item to cart for first time
                 // create cart object and attach it to user session
                 if (cart == null) {                
                     cart = new ShoppingCart();
                     session.setAttribute("cart", cart);
                    }        // get user input from request
                 String productId = request.getParameter("productId");
                 postAddtoCart(productId, cart, session);
                 userPath = "/cart";
                break;
                }
             case "/updateCart":
                {
                 // get input from request
                 String productId = request.getParameter("productId");
                 String quantity = request.getParameter("quantity");
                 postUpdateCart(productId, quantity, cart, session);
                 userPath = "/cart";
                 break;
                }
             case "/payment":
                 
                 String cardName = request.getParameter("cardname");
                 String cardNumber = request.getParameter("cardnumber");
                 String address = request.getParameter("address");
                 // TODO: contact bank server to validate card
                 // if bank validates then save order
                 
      
                 int orderId = orderManager.placeOrder(cardName, address,  cardNumber, cart);

                     // if order processed successfully send user to confirmation page
                 if (orderId > -1) {

                        // dissociate shopping cart from session
                         cart = null;
                         // end session
                         session.invalidate();

                         // get order details
                         Map orderMap = orderManager.getOrderDetails(orderId);

                         // place order details in request scope
                         request.setAttribute("customer", orderMap.get("customer"));
                         request.setAttribute("products",  orderMap.get("products"));
                         request.setAttribute("orderRecord", orderMap.get("orderRecord"));
                         
                         userPath = "/confirmation";

                     // otherwise, send back to checkout page and display error
                     } else {
                         userPath = "/checkout";
                         request.setAttribute("orderFailureFlag", true);
                     }
               
                 break;
         }

        // use RequestDispatcher to forward request internally
        String url = "/WEB-INF/view" + userPath + ".jsp";

        try {
            request.getRequestDispatcher(url).forward(request, response);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

protected void postAddtoCart(String productId, ShoppingCart cart, HttpSession session){      
              
             if (!productId.isEmpty()) {
                     Product book = bookDB.getBookDetails(productId);
                     cart.add(book);
                    }               
 }

protected void postUpdateCart(String productId, String quantity, ShoppingCart cart, HttpSession session){      
              
             Product book = bookDB.getBookDetails(productId);
                 cart.update(book,quantity);              
 }


/**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    
     @Override
      public void destroy() {
            bookDB = null;
         }
}
