/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.order;

import java.io.Serializable;

/**
 *
 * @author usuario
 */
public class Customer implements Serializable {
    
    private int id;
    private String name;
    private String address;
    private String ccNumber;

    
    public void setId(int id) {
       this.id = id;
     }

    public void setName(String name) {
       this.name = name;
     }
    
    public void setAddress(String address) {
     this.address = address;
     }

    public void setCcNumber(String ccNumber) {
      this.ccNumber = ccNumber;
     }

    public int getId() {
        return id;
    }
 
    public String getName() {
       return name;
     }
    
    public String getAddress() {
     return address;
     }
}
