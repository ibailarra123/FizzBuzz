/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.order;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 *
 * @author usuario
 */
public class OrderedProductDB {

        
    List<OrderedProduct> items;
    private static OrderedProductDB onlyInstance = null;
   

    public OrderedProductDB() {
        items = new ArrayList<OrderedProduct>();
        
     }
    
     public static OrderedProductDB instance() {
        if (onlyInstance == null)
        onlyInstance = new OrderedProductDB();
       return onlyInstance; 
    }
    
    
    public List<OrderedProduct> findByOrderId(int orderId) {
         
       List<OrderedProduct> products = new ArrayList<OrderedProduct>();

       for (OrderedProduct op : items) {

             if (op.getOrderId() == orderId) {
                 products.add(op);
            }
        }
        return products;
    }

    public void add(OrderedProduct orderedItem) {
    
        items.add(orderedItem); 
    }
    
}
