package com.example.testListMVCSubActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import com.example.testListMVCSubActivity.Modelos.InterestPoint;

import java.util.List;

public class Ventana2 extends AppCompatActivity {
    int position;
    TravelPointsApplication tpa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ventana2);
        position= bundle.getInt("position");
    }

    public void saveName(View view) {
        EditText editText = (EditText) findViewById(R.id.edit_name2);
        EditText editText2 = (EditText) findViewById(R.id.edit_name3);
        EditText editText3 = (EditText) findViewById(R.id.edit_name);

        String name = editText.getText().toString();
        String latitud = editText2.getText().toString();
        Double latitud2 = Double.valueOf(latitud);
        String longitud = editText3.getText().toString();
        Double longitud2 = Double.valueOf(longitud);

        tpa = (TravelPointsApplication)getApplicationContext();
        List<InterestPoint> lista = tpa.getPoints();

        lista.get(position).setLatitud(latitud2);
        lista.get(position).setLongitud(longitud2);
        lista.get(position).setNombre(name);

        Intent intent = new Intent();
        setResult(RESULT_OK, intent);
        finish();
    }
}