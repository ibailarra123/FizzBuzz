package com.example.back4appmvcsubactivity.Model;

import com.google.android.gms.maps.model.LatLng;
import com.parse.ParseClassName;
import com.parse.ParseGeoPoint;
import com.parse.ParseObject;

//@ParseClassName("InterestPoint")
@ParseClassName("Lavadero")
public class Lavadero extends ParseObject{

    public Lavadero() {
    }

    public double getLatitud() {
        return  getDouble("latitud");
    }

    public void setLatitud(double latitud) {
        put("latitud",latitud);
    }

    public double getLongitud() {
       return getDouble("longitud");
    }

    public void setLongitud(double longitud) {
        put("longitud",longitud);
    }

    public String getIdLavadero() {return getString("idLavadero");}

    public void setIdLavadero(String nombre) {
        put("idLavadero",nombre);
    }

    public ParseGeoPoint getLatLong(){return (ParseGeoPoint) get("latlong");}

    public void setLatLong(ParseGeoPoint latLong){put("latlong",latLong);}

    @Override
    public String toString() {
        return "Lavadero: " + this.getIdLavadero()+" Localización: "+this.getLatitud()+", "+this.getLongitud();
    }
}
