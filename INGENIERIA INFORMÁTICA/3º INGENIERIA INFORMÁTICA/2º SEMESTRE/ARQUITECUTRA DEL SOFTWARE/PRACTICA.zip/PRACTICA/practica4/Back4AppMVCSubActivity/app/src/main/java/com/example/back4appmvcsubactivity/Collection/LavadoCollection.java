package com.example.back4appmvcsubactivity.Collection;

import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.annotation.NonNull;

import com.example.back4appmvcsubactivity.Model.Lavado;
import com.example.back4appmvcsubactivity.Model.Lavadero;
import com.example.back4appmvcsubactivity.R;
import com.parse.ParseQuery;

import java.util.ArrayList;
import java.util.List;

public class LavadoCollection {
    private List<Lavado> local_commentlist = new ArrayList<>();


    public LavadoCollection()
    {
        // ParseObject.registerSubclass(InterestPoint.class); // podría estar aqui
    }

    public void getServerCommentsUpdate(Lavadero aInterestPoint, ListView listView) {
        //Pillamos todos los comentarios
        ParseQuery<Lavado> query = ParseQuery.getQuery("Lavado");
        //Filtramos de entre todos los comentarios lo que referencian al punto que queremos
        query.whereEqualTo("Lavadero",aInterestPoint);

        query.findInBackground((objects, e) -> {
            if (e == null) {
                local_commentlist = objects;
                ArrayAdapter<Lavado> pointItemsAdapter =
                        new ArrayAdapter<Lavado>(listView.getContext(), R.layout.row_layout,
                                R.id.listText,local_commentlist);
                listView.setAdapter(pointItemsAdapter);
                pointItemsAdapter.notifyDataSetChanged();

                Log.d("object query server OK:", "getServerCommentsUpdate()");
            } else {
                Log.d("error query, reason: " + e.getMessage(), "getServerCommentsUpdate()");
            }
        });
    }

    public void addCommentUpdate(@NonNull Lavado aComment, Lavadero aInterestPoint, ListView listView) {

        aComment.saveInBackground(e -> {
            if (e == null) {
                //Ponemos la referencia al punto que pertenece el comment
                aComment.setLavadero(aInterestPoint);
                //metemos el comment a la lista
                local_commentlist.add(aComment);
                ArrayAdapter<Lavado> pointItemsAdapter;
                pointItemsAdapter = (ArrayAdapter<Lavado>) listView.getAdapter();
                pointItemsAdapter.notifyDataSetChanged();
                Log.d("object saved in server:", "addCommentUpdate()");
            } else {
                Log.d("save failed, reason: "+ e.getMessage(), "addCommentUpdate()");
            }
        });
    }
}
