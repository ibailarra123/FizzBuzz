package com.example.back4appmvcsubactivity;

import android.app.Application;

import com.example.back4appmvcsubactivity.Collection.LavadoCollection;
import com.example.back4appmvcsubactivity.Collection.LavaderoCollection;
import com.example.back4appmvcsubactivity.Model.Lavado;
import com.example.back4appmvcsubactivity.Model.Lavadero;
import com.google.android.gms.maps.model.LatLng;
import com.parse.Parse;
import com.parse.ParseObject;

public class TravelPointsApplication extends Application {

    private LavaderoCollection pointsCollection;
    private LavadoCollection commentsCollection;

    @Override
    public void onCreate() {
        super.onCreate();

        ParseObject.registerSubclass(Lavadero.class);
        ParseObject.registerSubclass(Lavado.class);

        pointsCollection = new LavaderoCollection();
        commentsCollection = new LavadoCollection();

		Parse.initialize(new Parse.Configuration.Builder(getApplicationContext())
                .applicationId(getString(R.string.back4app_app_id))
                .clientKey(getString(R.string.back4app_client_key))
                .server(getString(R.string.back4app_server_url))
                .build());
    }

    public LavaderoCollection getCollection()
    {
        return pointsCollection;
    }

    public LavadoCollection getCommentsCollection() {
        return commentsCollection;
    }
}
