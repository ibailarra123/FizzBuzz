package com.example.back4appmvcsubactivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.example.back4appmvcsubactivity.Model.Lavado;
import com.example.back4appmvcsubactivity.Model.Lavadero;

import org.w3c.dom.Comment;

public class DisplayActivity extends Activity {

    Double lon,lat;
    int position;

	TravelPointsApplication tpa;
	Lavadero aPoint;

	private ListView listView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_display);
		Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        lon= bundle.getDouble("longitud");
		lat= bundle.getDouble("latitud");
        position= bundle.getInt("position");
        TextView textView =((TextView) findViewById(R.id.text_longitud));
		textView.setTextSize(40);
		textView.setText(lon.toString());
		TextView textView2 =((TextView) findViewById(R.id.text_latitud));
		textView2.setTextSize(40);
		textView2.setText(lat.toString());


		listView = (ListView) findViewById(R.id.list_comment);
		tpa = (TravelPointsApplication)getApplicationContext();
		aPoint = tpa.getCollection().getPoint(position);

		tpa.getCommentsCollection().getServerCommentsUpdate(aPoint,listView);


		listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				Lavado lavado = (Lavado) listView.getItemAtPosition(position);
				Bundle bundle = new Bundle();

				bundle.putInt("position", position);
				bundle.putString("idLavado",lavado.getIdLavado());
				bundle.putLong("fecha",lavado.getFecha().getTime());
				bundle.putString("tipoMotor",lavado.getTipoMotor());
				bundle.putBoolean("ahorroEnergia",lavado.getAhorroEnergia());

				bundle.putInt("temperaturaAgua", lavado.getTemperaturaAgua());
				bundle.putInt("cargaAgua", lavado.getCargaAgua());

				bundle.putString("tipoJabon", lavado.getTipoJabon());
				bundle.putInt("cargaJabon", lavado.getCargaJabon());

				Intent intent = new Intent(tpa, VComment.class);
				intent.putExtras(bundle);
				startActivityForResult(intent, 2);

			}


		});

	}

	public void saveLocationName(View view) {
		Bundle bundle = new Bundle();
		bundle.putInt("position", position);
        EditText editText = (EditText) findViewById(R.id.edit_point_name);
        String point_name = editText.getText().toString();
		System.out.println(point_name);
        bundle.putString("idLavadero", point_name);
        Intent intent = new Intent();
		intent.putExtras(bundle);

		setResult(RESULT_OK, intent);
		finish();
	}

	public void eliminarLavadero(View view){
		Bundle bundle = new Bundle();
		bundle.putInt("posicion",position);
		Intent intent = new Intent();
		intent.putExtras(bundle);
		setResult(4,intent);
		finish();
	}

	public void showMaps(View view){
		Intent intent = new Intent(tpa, MapsActivity.class);
		Bundle bundle = new Bundle();
		bundle.putInt("position",position);
		intent.putExtras(bundle);
		startActivityForResult(intent,1);
	}



	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == Activity.RESULT_OK){
			if (requestCode == 2) {
				Bundle bundle = data.getExtras();
				String name = bundle.getString("idLavado");
				int position = bundle.getInt("posicion");
				System.out.println(position);
				Lavado aComment = (Lavado) listView.getItemAtPosition(position);
				/*
				aComment.setIdLavado(name);
				tpa.getCommentsCollection().addCommentUpdate(aComment, aPoint, listView);
				tpa.getCommentsCollection().getServerCommentsUpdate(aPoint,listView);

				 */
			}
		}
	}


}
