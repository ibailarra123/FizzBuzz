package com.example.back4appmvcsubactivity.Collection;

import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.annotation.NonNull;
import com.example.back4appmvcsubactivity.Model.Lavadero;
import com.example.back4appmvcsubactivity.R;
import com.parse.ParseQuery;
import java.util.ArrayList;
import java.util.List;

public class LavaderoCollection {

    private List<Lavadero> local_pointList = new ArrayList<>();

    public LavaderoCollection()
    {
       // ParseObject.registerSubclass(InterestPoint.class); // podría estar aqui
    }

    public void getServerPointsUpdate(ListView listView) {

        ParseQuery<Lavadero> query = ParseQuery.getQuery("Lavadero");
        query.findInBackground((objects, e) -> {
            if (e == null) {
                local_pointList = objects;
                ArrayAdapter<Lavadero> pointItemsAdapter =
                        new ArrayAdapter<Lavadero>(listView.getContext(),R.layout.row_layout2,
                                R.id.listText,local_pointList);
                listView.setAdapter(pointItemsAdapter);
                pointItemsAdapter.notifyDataSetChanged();

                Log.d("object query server OK:", "getServerPointsUpdate()");
            } else {
                Log.d("error query, reason: " + e.getMessage(), "getServerPointsUpdate()");
            }
        });
    }

    public void addObjectUpdate(@NonNull Lavadero aInterestPoint, ListView listView) {

        aInterestPoint.saveInBackground(e -> {
            if (e == null) {
                local_pointList.add(aInterestPoint);
                ArrayAdapter<Lavadero> pointItemsAdapter;
                pointItemsAdapter = (ArrayAdapter<Lavadero>) listView.getAdapter();
                pointItemsAdapter.notifyDataSetChanged();
                Log.d("object saved in server:", "addObjectUpdate()");
            } else {
                Log.d("save failed, reason: "+ e.getMessage(), "addObjectUpdate()");
           }
        });
    }


    public void deleteObjectUpdate(@NonNull Lavadero aLavadero, ListView listView) {

        aLavadero.deleteInBackground(e -> {
            if (e == null) {
                local_pointList.remove(aLavadero);
                ArrayAdapter<Lavadero> pointItemsAdapter;
                pointItemsAdapter = (ArrayAdapter<Lavadero>) listView.getAdapter();
                pointItemsAdapter.notifyDataSetChanged();
                Log.d("object deleted", "deleteObjectUpdate()");
            } else {
                Log.d("delete failed, reason: "+ e.getMessage(), "deleteObjectUpdate()");}
        });
    }

    public Lavadero getPoint(int posicion){
        return local_pointList.get(posicion);
    }

}
