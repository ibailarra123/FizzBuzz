package com.example.back4appmvcsubactivity.Model;

import static java.lang.Integer.getInteger;

import androidx.annotation.NonNull;

import com.parse.ParseClassName;
import com.parse.ParseObject;

import java.util.Date;

@ParseClassName("Lavado")
public class Lavado extends ParseObject {

    public Lavado() {
    }


    public String getIdLavado() {return getString("idLavado");}

    public void setIdLavado(String idLavado) {put("idLavado",idLavado);}

    public Date getFecha() {return getDate("fecha");}

    public void setFecha(Date fecha) {put("fecha",fecha);}


    //CARACTERISTICAS
    public String getTipoMotor() {return getString("tipoMotor");}

    public void setTipoMotor(String tipoMotor) {put("tipoMotor",tipoMotor);}

    public Boolean getAhorroEnergia() {return getBoolean("ahorroEnergia");}

    public void setAhorroEnergia(Boolean ahorroEnergia) {put("ahorroEnergia",ahorroEnergia);}

    public int getTemperaturaAgua() {return getInt("temperaturaAgua");}

    public void setTemperaturaAgua(int temperaturaAgua) {put("temperaturaAgua",temperaturaAgua);}

    public int getCargaAgua() {return  getInt("cargaAgua");}

    public void setCargaAgua(int cargaAgua) {put("cargaAgua",cargaAgua);}

    public String getTipoJabon() {return  getString("tipoJabon");}

    public void setTipoJabon(String tipoJabon) {put("tipoJabon",tipoJabon);}

    public int getCargaJabon() {return  getInt("cargaJabon");}

    public void setCargaJabon(int cargaJabon) {put("cargaAgua",cargaJabon);}


    public Lavadero lavadero(){return lavadero();}

    public void setLavadero(Lavadero aLavadero){ put("Lavadero",aLavadero);}

    @NonNull
    @Override
    public String toString() {
        return getIdLavado()+getFecha();
    }
}
