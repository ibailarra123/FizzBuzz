package com.example.back4appmvcsubactivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Date;

public class VComment extends AppCompatActivity {
    int position;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vcomment);
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        position = bundle.getInt("position");

        // OBTENEMOS EL NOMBRE DEL LAVADO Y FECHA
        String nombre = bundle.getString("idLavado");
        Date fecha  = new Date (bundle.getLong("fecha"));
        TextView textViewNombre =((TextView) findViewById(R.id.textViewNombre));
        TextView textViewFecha =((TextView) findViewById(R.id.textViewFecha));
        textViewNombre.setText("NOMBRE: "+ nombre.toString());
        textViewFecha.setText("FECHA: "+ fecha.toString());

        // OBTENEMOS LOS DISTINTOS OBJETOS DE LA PARTE DE ELECTRICIDAD
        String tipoMotor =bundle.getString("tipoMotor");
        Boolean booleanAhorro = bundle.getBoolean("ahorroEnergia");
        TextView textViewTipoMotor =((TextView) findViewById(R.id.textViewTipoMotor));
        TextView textViewAhorroEnergia =((TextView) findViewById(R.id.textViewAhorroEnergía));
        textViewTipoMotor.setText("TIPO MOTOR: "+tipoMotor.toString());
        textViewAhorroEnergia.setText("AHORRO DE ENERGÍA: "+booleanAhorro.toString());

        // OBTENEMOS LOS DISTINTOS OBJETOS DE LA PARTE DE AGUA
        Integer temperaturaAgua = bundle.getInt("temperaturaAgua");
        Integer cargaAgua = bundle.getInt("cargaAgua");
        TextView textViewTemperaturaAgua =((TextView) findViewById(R.id.textViewTemperaturaAgua));
        TextView textViewCargaAgua =((TextView) findViewById(R.id.textViewCargaAgua));
        textViewTemperaturaAgua.setText("TEMPERATURA DEL AGUA: "+temperaturaAgua.toString()+"º");
        textViewCargaAgua.setText("CARGA DE AGUA: "+cargaAgua.toString());

        // OBTENEMOS LOS DISTINTOS OBJETOS DE LA PARTE DE JABON
        String tipoJabon =bundle.getString("tipoJabon");
        Integer cargaJabon = bundle.getInt("cargaJabon");
        TextView textViewTipoJabon =((TextView) findViewById(R.id.textViewTipoJabon));
        TextView textViewCargaJabon =((TextView) findViewById(R.id.textViewCargaJabon));
        textViewTipoJabon.setText("TIPO DE JABÓN: "+tipoJabon.toString());
        textViewCargaJabon.setText("CARGA DE JABÓN: "+cargaJabon.toString());
    }
    public void deleteLavado(View view){
        Bundle bundle = new Bundle();
        bundle.putInt("posicion",position);
        Intent intent = new Intent();
        intent.putExtras(bundle);
        setResult(RESULT_OK, intent);
        finish();
    }

}
