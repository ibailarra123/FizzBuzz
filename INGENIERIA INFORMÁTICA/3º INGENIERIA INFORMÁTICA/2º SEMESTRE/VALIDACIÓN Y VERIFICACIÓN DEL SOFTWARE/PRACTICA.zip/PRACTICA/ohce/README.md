PHP 8 testing base

Run: composer install