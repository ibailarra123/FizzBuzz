<?php

namespace Deg540\StringCalculatorPHP;

interface NumberProvider
{
    public function getNumber(): int;
}
