<?php

namespace Deg540\StringCalculatorPHP;

use phpDocumentor\Reflection\Types\Boolean;

class PrimeFactorsCalculator
{
    private NumberProvider $numberProvider;

    public function __construct(NumberProvider $numberProvider)
    {
        $this->numberProvider = $numberProvider;
    }
    public function calculate()
    {
        $primeNumbers = array();
        $firstNum = 2;
        $number = $this->numberProvider->getNumber();
        while ($firstNum <= $number) {
            while ($number % $firstNum == 0) {
                array_push($primeNumbers, $firstNum);
                $number = $number / $firstNum;
            }
            $firstNum = $firstNum + 1;
        }
        return $primeNumbers;
    }
}
