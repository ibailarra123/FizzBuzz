<?php

namespace Deg540\StringCalculatorPHP\Test;

use Deg540\StringCalculatorPHP\NumberProvider;
use Deg540\StringCalculatorPHP\PrimeFactorsCalculator;
use PHPUnit\Framework\TestCase;

/**
 * @SuppressWarnings(PHPMD.StaticAccess)
 */
class PrimeFactorsCalculatorTest extends TestCase
{
    protected $numberProvider;
    protected $calculator;

    public function setUp(): void
    {
        $this->numberProvider = \Mockery::mock(NumberProvider::class);
        $this->calculator = new PrimeFactorsCalculator($this->numberProvider);
    }

    /**
     * @test
     */
    public function returnEmptyIfNumberIs0()
    {
        $this->numberProvider
            ->allows()
            ->getNumber()
            ->andReturn(0);

        $primNumbers = $this->calculator->calculate();

        $this->assertEquals([], $primNumbers);
    }
    /**
     * @test
     */
    public function returnEmptyIfNumberIs1()
    {
        $this->numberProvider
            ->allows()
            ->getNumber()
            ->andReturn(1);

        $primNumbers = $this->calculator->calculate();

        $this->assertEquals([], $primNumbers);
    }
    /**
     * @test
     */
    public function returnHimselfIfIsPrimNumber()
    {
        $this->numberProvider
            ->allows()
            ->getNumber()
            ->andReturn(11);

        $primNumbers = $this->calculator->calculate();

        $this->assertEquals([11], $primNumbers);
    }
    /**
     * @test
     */
    public function returnsTheSameNumberRepeatIfIsPowerhouseOfThatNumber()
    {
        $this->numberProvider
            ->allows()
            ->getNumber()
            ->andReturn(16);

        $primNumbers = $this->calculator->calculate();

        $this->assertEquals([2,2,2,2], $primNumbers);
    }
    /**
     * @test
     */
    public function returnDifferentNumbersInOtherCase()
    {
        $this->numberProvider
            ->allows()
            ->getNumber()
            ->andReturn(18);

        $primNumbers = $this->calculator->calculate();

        $this->assertEquals([2,3,3], $primNumbers);
    }
}
