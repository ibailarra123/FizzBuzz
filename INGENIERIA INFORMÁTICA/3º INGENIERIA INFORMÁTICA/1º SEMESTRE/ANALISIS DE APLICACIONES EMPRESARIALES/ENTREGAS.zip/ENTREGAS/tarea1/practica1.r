ecomm.df <- read.csv("https://goo.gl/hzRyFd")

table(ecomm.df$profile[ecomm.df$country=="United States"])
#Se puede observar que entre los posibles clientes de estados unidos, la mayor�a son padres, seguidos de profesionales sanitarios y profesores.

table(ecomm.df$profile[ecomm.df$country!="United States"])
#Al igual que en Estados Unidos, en el resto del mundo, la mayor�a son son padres, seguidos de profesionales sanitarios y profesores.
#Lo que nos lleva a deducir que el perfil mayoritario es el de padre.

proportions(table(ecomm.df$age[ecomm.df$country=="United States"]))
#En cuanto a los intervalos de edades, en Estados Unidos, la mayoria de los encuestados tienen entre 25 y 34 a�os.

proportions(table(ecomm.df$age[ecomm.df$country=="United States" & ecomm.df$gender=="Male"]))
proportions(table(ecomm.df$age[ecomm.df$country=="United States" & ecomm.df$gender=="Female"]))
proportions(table(ecomm.df$age[ecomm.df$country=="United States" & ecomm.df$gender=="Prefer not to answer"]))
#Si embargo, cuando distinguimos por generos, la mayor�a de las mujeres siguen teniendo entre 25 y 34 a�os pero los hombres son menores de edad y los que prefieren no decir el sexo, prefieren no decir su edad tampoco.
#Por lo que en Estados Unidos la edad que predomina es entre 25 y 34 a�os.


filtered<-subset(ecomm.df,ecomm.df$age=="Less than 18")
table(filtered$country)
#Hablando ahora de los menores de edad, podemos observar, que por much�sima diferencia la mayor�a vive en Estados Unidos, mientras que en otros paises casi ninguno.



round(proportions(table(ecomm.df$purchasedBefore, ecomm.df$profile), margin = 1)*100, 1)
#En cuanto a la relaci�n entre tipos de perfiles y productos comprados antes de la encuesta, podemos observar que los perfiles que m�s compraron fueron los padres y los profesionales mientras que los que menos amigos o amigos de la familia.

round(proportions(table(ecomm.df$purchasedWhen, ecomm.df$profile), margin = 1)*100, 1)
#Se puede observar tambi�n que la mayoria de esos productos han sido comprados hace menos de un a�o.


state.tab <- table(ecomm.df$age[ecomm.df$behavAnySale>0])
ecomm.df$age[which.max(state.tab)]
ecomm.df$profile[which.max(state.tab)]
#Observamos tambi�n el mayor n�mero de ventas ha sido a padres de entre 25 y 34 a�os.


pageViewInt <- rep(NA, length(ecomm.df$behavPageviews))
pageViewInt[ecomm.df$behavPageviews=="0"]      <- 0
pageViewInt[ecomm.df$behavPageviews=="1"]      <- 1
pageViewInt[ecomm.df$behavPageviews=="2 to 3"] <- 2
pageViewInt[ecomm.df$behavPageviews=="4 to 6"] <- 4
pageViewInt[ecomm.df$behavPageviews=="7 to 9"] <- 7
pageViewInt[ecomm.df$behavPageviews=="10+"]    <- 10
ecomm.df$pageViewInt <- pageViewInt
rm(pageViewInt)

myfont<-"serif" 
xtick <- seq(0,9)

hnumv<-hist(ecomm.df$pageViewInt[ecomm.df$gender == "Male"], xlim=c(0,10), xlab="",ylab="",col="lightblue", main = "N�mero de visitas a la p�gina web siendo hombre",axes=F, family=myfont)
text(x=hnumv$mids,y=-1, labels = xtick, pos = 1, xpd = t, family = myfont)
text(x=hnumv$mids,y=hnumv$counts, labels = hnumv$counts, pos = 3, xpd = T, col = "darkblue", cex=0.8, family = myfont)

mtext("N�mero de personas", side = 2, family=myfont)
mtext("N�mero de visitas", side = 1, line = 2, family=myfont)
#En cuanto al n�mero de visitas a la p�gina web siendo hombre, vemos que la mayor�a de los que la han visitado, la han visitado varias veces.


hnumv2<-hist(ecomm.df$pageViewInt[ecomm.df$gender == "Female"], xlim=c(0,10),xlab="",ylab="", col="lightblue", main = "N�mero de visitas a la p�gina web siendo mujer",axes=F, family=myfont)
text(x=hnumv2$mids,y=-1, labels = xtick, pos = 1, xpd = t, family = myfont)
text(x=hnumv2$mids,y=hnumv2$counts, labels = hnumv2$counts, pos = 3, xpd = T, col = "darkblue", cex=0.8, family = myfont)

mtext("N�mero de personas", side = 2, family=myfont)
mtext("N�mero de visitas", side = 1, line = 2, family=myfont)
#En cuanto al n�mero de visitas a la p�gina web siendo mujer, vemos que la mayor�a de los que la han visitado, la han visitado varias veces.


hnumv3<-hist(ecomm.df$pageViewInt[ecomm.df$gender == "Prefer not to answer"], xlim=c(0,10), xlab="",ylab="", col="lightblue", main = "N�mero de visitas a la p�gina web sin expecificar genero",axes=F, family=myfont)
text(x=hnumv3$mids,y=-1, labels = xtick, pos = 1, xpd = t, family = myfont)
text(x=hnumv3$mids,y=hnumv3$counts, labels = hnumv3$counts, pos = 3, xpd = T, col = "darkblue", cex=0.8, family = myfont)

mtext("N�mero de personas", side = 2, family=myfont)
mtext("N�mero de visitas", side = 1, line = 2, family=myfont)
#En cuanto al n�mero de visitas a la p�gina web de personas sin decir su sexo, vemos que la mayor�a de los que la han visitado, la han visitado varias veces tambi�n.
#Por lo cual deducimos, que la gente que visita la p�gina web, la visita varias veces.



par(mar=c(3, 12, 2, 2), mgp=c(1,2,0))
boxplot(ecomm.df$behavNumVisits[ecomm.df$behavNumVisits<11] ~ ecomm.df$age[ecomm.df$behavNumVisits<11], las=1, horizontal = TRUE, main="Number of visits per profile", xlab = "Number of visits", ylab = "")
#Vemos tambi�n que la gente de entre 35 y 44 a�os son los que m�s visitan la p�gina web.



aggregate(pageViewInt ~ age, data = ecomm.df, summary)
for (i in unique(ecomm.df$age)) {
  print(i)
  print(summary(ecomm.df$pageViewInt[ecomm.df$age==i]))
}
#Se puede observar, que la media de veces m�s alta en vistar la p�gina es por parte de personas de entre 25 y 34 a�os y la que menos de mayores de 65 a�os


data_subset_gender <- subset(ecomm.df,ecomm.df$gender=="Female"|ecomm.df$gender=="Male")
barplot_data <-aggregate(behavAnySale ~ age + gender, data=data_subset_gender, sum)
barplot_data <-barplot_data[order(barplot_data$behavAnySale, decreasing = FALSE), ]
barplot_data$names <- paste(barplot_data$age, " - ", barplot_data$gender)
par(mar=c(5, 12, 2, 2), mgp=c(3, 1, 0), las=1) 
with(barplot_data, barplot(behavAnySale, las = 1, names.arg = names, cex.names = 0.5, horiz = TRUE))
with(subset(barplot_data, barplot_data$behavAnySale>0), barplot(behavAnySale, las = 1, names.arg = names, col = "lightblue",cex.names = 0.8, horiz = TRUE))
#Por �ltimo, vemos que las personas a las que m�s se les ha vendido es a las mujeres de entre 35 y 44 a�os seguidas de las de 45 a las 54 a�os, siendo en general a las muejeres, las mayores compradoras.

