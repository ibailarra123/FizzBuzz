#hist boxplot barplot table proportions by aggregate


ecomm.df<-read.csv("https://goo.gl/hzRyFd");
dim(ecomm.df);
names(ecomm.df);
summary(ecomm.df);

gender<-ecomm.df$gender;
age<-ecomm.df$age;
profile<-ecomm.df$profile  #with(ecomm.df,table(profile))
region<-ecomm.df$region
country<-ecomm.df$country
behavAnySale<-ecomm.df$behavAnySale;

table(gender);
table(age);
table(profile);
table(region);
table(country); #frequency table for the country of origin


table(profile[country == "United States"]);
hist(behavAnySale);
boxplot(behavAnySale, horizontal = TRUE, color="red");

install.packages('plotrix');
library(plotrix);
library(dplyr);

#################################################################################################################################################ANALISIS
gender[gender =="Male"] <- 1;
gender[gender =="Female"] <- 2;
pyramid(age = age, sex = gender, binwidth = 5, cex.axis = 1, bar.label = TRUE, cex.bar.value = 1, col.gender = c("#0F69B4","#EB3C46"), main=NULL);
