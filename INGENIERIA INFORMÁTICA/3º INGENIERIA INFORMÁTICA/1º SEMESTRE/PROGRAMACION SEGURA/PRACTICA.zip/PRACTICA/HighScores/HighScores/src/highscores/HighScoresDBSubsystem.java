package highscores;
/**
 *
 * @author MAZ
 */
import java.io.File;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLTimeoutException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.PreparedStatement;
//
public final class HighScoresDBSubsystem implements AutoCloseable {

    static private final Logger LOGGER = Logger.getLogger(HighScoresDBSubsystem.class.getName());

    static private final String DB_USER = "labops";
    static private final String DB_PASSWORD = "trustnoone";

    private final MessageDigest md;
    private final Connection connection;

    public HighScoresDBSubsystem () throws SQLException, NoSuchAlgorithmException {

        // Servicio de resumen digital; se emplea para obtener una clave
        // única a partir del nombre del jugador o del nombre del juego.
        try {
          md = MessageDigest.getInstance("MD5");
        } catch (final NoSuchAlgorithmException ex) {
          LOGGER.info("algoritmo de resumen no provisto en la plataforma");
          LOGGER.severe(ex.getMessage());
          throw new NoSuchAlgorithmException();
        }

        // Conexión con la BBDD; se mantiene abierta durante toda la ejecución;
        // por esa razón no se emplea try-con-recursos.
        try {

          final String db_URL = "jdbc:h2:file:" + System.getProperty("user.dir") +
                                                         File.separator + "data" +
                                                         File.separator + "database" +
                                                         File.separator + "highscoresDB";
          connection = DriverManager.getConnection(db_URL, DB_USER, DB_PASSWORD);
          LOGGER.info("Conexión con la base de datos establecida");
        } catch (final SQLTimeoutException ex) {
          LOGGER.info("timeout al intentar establecer la conexión.");
          LOGGER.severe(ex.getMessage());
          throw new SQLException();
        } catch (final SQLException ex) {
          LOGGER.severe("error al abrir la conexión.");
          LOGGER.log(Level.SEVERE, "Código de error: " + ex.getErrorCode(),ex);
          LOGGER.log(Level.SEVERE, ex.getMessage());
          throw new SQLException();
        }

    }

    
    @Override
    public void close () {
        try {
          connection.close();
        } catch (final SQLException ex) {
          LOGGER.severe("error al cerrar la conexion");
          LOGGER.log(Level.SEVERE, "Código de error: " + ex.getErrorCode(),ex);
          LOGGER.log(Level.SEVERE, ex.getMessage());
        }
    }

    
    private String getID (final String data) {
        // Generación de una clave única a partir del string recibido.
        // La clave generada es una secuencia de 16 octetos. Para poder
        // emplear la clave generada en los strings de las sentencias,
        // hay que convertir esa secuencia de octetos en un string que codifique
        // la misma información. Con ese fin se emplea la codificación Base64.
        final byte[] _Id = md.digest(data.getBytes(Charset.forName("UTF-8")));
        final String  Id = Base64.getEncoder().encodeToString(_Id);
        return Id;
    }
    
    
    //Nueva puntuación de un jugador en un juego
    public boolean newHighScore (final String[] data) throws SQLException {
        
        //Se obtienen el nombre de jugador, el nombre del juego y la puntuación pasados como argumento
        final String player = data[0];
        final String game = data[1];
        final int score = Integer.parseInt(data[2]);
        
        //Se obtienen el ID del jugador y el ID del juego
        final String playerId = getPlayerId(player);
        final String gameId = getGameId(game);

        // Jugador y juego deben estar registrados
        if ((!registeredPlayer(player)) || (!registeredGame(game)))
            return false;

        // Se ha verificado que jugador y juego están registrados
        //Se prepara una sentencia
        try (final PreparedStatement statement = connection.prepareStatement(
                "INSERT INTO scores(playerID, gameID, score) VALUES (?,?,?)")){

            //Se introducen el ID del jugadro, el ID del juego y la puntuacion en la sentencia
            statement.setString(1, playerId);
            statement.setString(2, gameId);
            statement.setInt(3,score);
            
            //Se ejecuta la sentencia
            return statement.executeUpdate() == 1;

        } catch (final SQLException ex) {
            LOGGER.warning("Error al almacenar la puntuacion");
            LOGGER.log(Level.WARNING, "jugador {0}, juego {1} y puntuación {2}", data);
            LOGGER.log(Level.WARNING, ex.getMessage());
        }

        return false;
    }
    
    
    //Consultar puntuaciones por jugador
    public Map<String, Long> highScoresByPlayer (final String player) throws SQLException {
        
        //Se declara e inicializa un map
        final Map<String, Long> scores = new LinkedHashMap<>();
        
        //Se ontiene el ID del jugador cuyo nombre se ha pasado como argumento
        final String playerId = getPlayerId(player);
        
        //Se comprueba que el jugador esta registrado
        if(!registeredPlayer(player))
            return scores;
        
        //Se ha verificado que el jugador esta registrado
        //Se prepara una sentencia
        try (final PreparedStatement statement = connection.prepareStatement(
                "SELECT Games.name, Scores.score " +
                "FROM Scores " +
                "INNER JOIN Games ON Scores.GameID = Games.GameID " + 
                "WHERE Scores.PlayerId = ? " +
                "ORDER BY Scores.score DESC")){
            
            //Se introduce el ID del jugador en la sentencia
            statement.setString(1,playerId);
            
            //Se ejecuta la secuencia 
            final ResultSet rs = statement.executeQuery();
            
            //Se recorren todas las líneas del resultado de la ejecucion
            while (rs.next()) {
                
                //Introducir en el mapa cada juego con su puntuacion
                scores.put(rs.getString("Games.name"), rs.getLong("Scores.score"));
            }
        } catch (final SQLException ex) {
            LOGGER.warning("Error al obtener puntuaciones por jugador");
            LOGGER.log(Level.WARNING, "problema al consultar puntuaciones de jugador {0}",player);
            LOGGER.log(Level.WARNING, ex.getMessage());
        }
        return scores;
    }
    
    
    //Puntuaciones por juego
    public Map<String, Long> highScoresByGame (final String game) throws SQLException {
        
        //Se declara e inicializa un map
        final Map<String, Long> scores = new LinkedHashMap<>();
        
        //Se obtiene el id del juego cuyo nombre se ha pasado como argumento
        final String gameId = getGameId(game);
        
        //Se comprueba que el juego esta registrado
        if(!registeredGame(game))
            return scores;
        
        //Se ha verificado que el juego esta registrado
        //Se prepara una sentencia
        try (final PreparedStatement statement = connection.prepareStatement(
                "SELECT Players.name, Scores.score " +
                "FROM Scores " +
                "INNER JOIN Players ON Scores.PlayerID = Players.PlayerID " + 
                "WHERE Scores.GameID = ? " +
                "ORDER BY Scores.score DESC")) {
            
            //Se introduce el ID del jugador en la sentencia
            statement.setString(1,gameId);
            
            //Se ejecuta la sentencia
            final ResultSet rs = statement.executeQuery();
            
            //Se recorren todas las líneas del resultado de la ejecucion
            while (rs.next()) {
                
                //Introducir en el mapa cada jugador con su puntuacion
                scores.put(rs.getString("Players.name"), rs.getLong("Scores.score"));
            }
        } catch (final SQLException ex) {
            LOGGER.warning("Error al obtener puntuaciones por juego");
            LOGGER.log(Level.WARNING, "problema al consultar puntuaciones de juego {0}",game);
            LOGGER.log(Level.WARNING, ex.getMessage());
        }
        return scores;
    }
    
    
    //Obtener listado de jugadores
    public List<String> getPlayers () {
        
        //Se declara e inicializa una lista de String
        final List<String> players = new ArrayList<>();
        
        //Se prepara una sentencia
        try (final PreparedStatement statement = connection.prepareStatement("SELECT name FROM players")) {
            
            //Se ejecuta la sentencia
            final ResultSet rs = statement.executeQuery();
            
            //Se recorren todas las lineas del resutado de la ejecucion
            while (rs.next()) {
                
                //Se añade a al lista el nombre del jugador
                players.add(rs.getString("name"));
            }
        } catch (final SQLException ex) {
            LOGGER.warning("Problema al obtener listado de jugadores");
            LOGGER.log(Level.WARNING, "problema al consultar listado de jugadores");
            LOGGER.log(Level.WARNING, ex.getMessage());
        }
        return players;
    }
    
    
    //Obtener listado de juegos
    public List<String> getGames () {
        
        //Se declara e inicializa una lista de String
        final List<String> games = new ArrayList<>();
        
        //Se prepara una sentencia
        try (final PreparedStatement statement = connection.prepareStatement("SELECT name FROM games")) {
            
            //Se ejecuta la sentencia
            final ResultSet rs = statement.executeQuery();
            
            //Se recorren todas las lineas del resutado de la ejecucion
            while (rs.next()) {
                
                //Se añade a al lista el nombre del juego
                games.add(rs.getString("name"));
            }
        } catch (final SQLException ex) {
            LOGGER.warning("Problema al obtener listado de juegos");
            LOGGER.log(Level.WARNING, "problema al consultar listado de juegos");
            LOGGER.log(Level.WARNING, ex.getMessage());
        }
        return games;
    }
    
    
    //Insertar nuevo jugador
    private boolean insertPlayer(final String player) throws SQLException{
        
        //Se prepara una sentencia
        try (final PreparedStatement statement = connection.prepareStatement("INSERT INTO players (playerID, name) VALUES (?, ?)")) {
            
            //Se obtiene el id del jugador cuyo nombre se ha pasado por argumento
            final String playerId = getID(player);
            
            //Se introducen  el ID DEL jugador y el nombre del jugador en la sentencia
            statement.setString(1, playerId);
            statement.setString(2, player);
            
            //Se ejecuta la sentencia
            statement.executeUpdate();

            return true;

        } catch (final SQLException ex) {
            LOGGER.warning("Problema para insertar jugador");
            LOGGER.log(Level.WARNING, "problema al intentar inserción en tabla PLAYERS con jugador {0}", player);
            LOGGER.log(Level.WARNING, ex.getMessage());
            throw new SQLException();
        }
    }
    
    
    //Crear nuevo jugador
    public boolean newPlayer (final String player) throws SQLException {
        
        // Jugador ya está registrado
        if (registeredPlayer(player))
            return false;

        // Jugador no registrado
        return insertPlayer(player);
    }
  
    
    //Insertar nuevo juego
    private boolean insertGame(final String game) throws SQLException{
        
        //Se prepara una sentencia
        try (final PreparedStatement statement = connection.prepareStatement("INSERT INTO games (gameID, name) VALUES (?, ?)")) {
            
            //Se obtiene el ID del juego cuyo nombre se ha pasado como argumento
            final String gameId = getID(game);
            
            //Se introducen el ID del juego y el nombre del juego en la sentencia
            statement.setString(1, gameId);
            statement.setString(2, game);
            
            //Se ejecuta la sentencia
            statement.executeUpdate();

            return true;

        } catch (final SQLException ex) {
            LOGGER.warning("Problema para insertar juego");
            LOGGER.log(Level.WARNING, "problema al intentar inserción en tabla GAMES con juego {0}", game);
            LOGGER.log(Level.WARNING, ex.getMessage());
            throw new SQLException();
        }
    }
    
    
    //Crear nuevo juego
    public boolean newGame (final String game) throws SQLException {
        
        // Juego ya está registrado
        if (registeredGame(game))
            return false;

        // Juego no registrado
        return insertGame(game);
    }

    
    //Ontener el ID de un juego
    private String getGameId(final String game) throws SQLException{
        
        //Se prepara una sentencia
        try(final PreparedStatement statement = connection.prepareStatement(
            "SELECT gameID " +
            "FROM games " + 
            "WHERE name = ?")){
            
            //Se introduce el nombre del juego pasado como argumento en la sentencia
            statement.setString(1, game);
            
            //Se ejecuta la sentencia
            final ResultSet rs = statement.executeQuery();
            
            // Método next() devuelve true si y solo si rs no está vacío.
            if(rs.next())
                return rs.getString("gameID");

        } catch  (final SQLException ex) {
            LOGGER.warning("Problema para obtener juego");
            LOGGER.log(Level.WARNING, "problema al realizar consulta en tabla GAMES con juego {0}", game);
            LOGGER.log(Level.WARNING, ex.getMessage());
            throw new SQLException();
        }
        return "";

    }
    
    //Obtener ID de un jugador
    private String getPlayerId(final String player) throws SQLException{
        
        //Se prepara una sentencia
        try(final PreparedStatement statement = connection.prepareStatement(
            "SELECT playerID " +
            "FROM players " + 
            "WHERE name = ?")){
            
            //Se introduce el nombre del jugador pasado como argumento en la sentencia
            statement.setString(1, player);
            
            //Se ejecuta la sentencia
            final ResultSet rs = statement.executeQuery();
            
            // Método next() devuelve true si y solo si rs no está vacío.
            if(rs.next())
                return rs.getString("playerID");

        } catch  (final SQLException ex) {
            LOGGER.warning("Problema para obtener jugador");
            LOGGER.log(Level.WARNING, "problema al realizar consulta en tabla PLAYERS con jugador {0}", player);
            LOGGER.log(Level.WARNING, ex.getMessage());
            throw new SQLException();
        }
        return "";

    }
  
    //Comprobar si un jugador esta registrado
    private boolean registeredPlayer(final String player) throws SQLException{
        
        //Se obtiene el ID del jugador cuyo nombre se ha pasado como argumento
        final String playerId = getPlayerId(player);
        
        //Se comprueba que existe ese ID
        if(playerId.isEmpty())
            
            //El ID no existe
            return false;
        
        //El ID existe
        return true;
    }
    
    //Comprobar si un juego esta registrado
    private boolean registeredGame(final String game) throws SQLException{
        
        //Se obtiene el ID del juego cuyo nombre se ha pasado por argumento
        final String playerGame = getGameId(game);
        
        //Se comprueba que existe ese ID
        if(playerGame.isEmpty())
            
            //El ID no existe
            return false;
        
        //El ID existe
        return true;
    }
}
