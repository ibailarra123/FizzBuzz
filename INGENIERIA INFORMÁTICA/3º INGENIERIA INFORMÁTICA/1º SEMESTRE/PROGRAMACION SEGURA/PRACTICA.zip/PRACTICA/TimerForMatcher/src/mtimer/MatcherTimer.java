package mtimer;
/**
 *
 * @author MAZ
 */
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import static java.util.concurrent.TimeUnit.MILLISECONDS;
import java.util.concurrent.TimeoutException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
//
public final class MatcherTimer {
  
  // Implementa el método timeoutWorker() como una alternativa
  // basada en los valores de la enumeración OPS, de posibles
  // operaciones.
    private static enum OPS {MATCHES, LOOKINGAT, FIND}
    
    private final long startTime;
    private long endTime;
    private long executionTime;
  
    private static final Logger LOGGER = Logger.getLogger(MatcherTimer.class.getName());

  // Servicio ejecutor empleado en el método timeoutWorker().
    private final ExecutorService executor;

  
    public MatcherTimer () {
        this.executor = Executors.newSingleThreadExecutor();
        startTime = System.currentTimeMillis();
    }
  
  
    public boolean matches (final Matcher matcher,
                          final long timeout,
                          final TimeUnit units) throws TimeoutException {

        return timeoutWorker(matcher, timeout, units, OPS.MATCHES);
        
    }
  
    public boolean lookingAt (final Matcher matcher,
                            final long timeout,
                            final TimeUnit units) throws TimeoutException {
    
        return timeoutWorker(matcher, timeout, units, OPS.LOOKINGAT);
    
    }
  
    public boolean find (final Matcher matcher,
                       final long timeout,
                       final TimeUnit units) throws TimeoutException {
    
        return timeoutWorker(matcher, timeout, units, OPS.FIND);
    
    }   
  
    private boolean timeoutWorker (final Matcher matcher,
                                 final long timeout,
                                 final TimeUnit units,
                                 final OPS method) throws TimeoutException {
        try{
            Future<Boolean> future = executor.submit(new Callable<Boolean>() {
                @Override
                public Boolean call()throws Exception{
                        boolean result = false;
                        switch (method) {
                            case MATCHES:
                                result = matcher.matches();
                                break;
                            case FIND:
                                result = matcher.find();
                                break;
                            case LOOKINGAT:
                                result = matcher.lookingAt();
                                break;
                        }
                        return result;
                }
            });
            return future.get(timeout, units);
        }catch(InterruptedException | ExecutionException e){
            LOGGER.log(Level.SEVERE, null, e);
            return false;
        }catch(TimeoutException e){
            matcher.reset();
            throw new TimeoutException("Cantidad de tiempo superada");
        }
              
  }
  
  public void close () {
    // Detener el ejecutor
    // Esperar hasta que terminen las tareas en curso y pendientes.
    executor.shutdownNow();
    do {
        try {
          // Consulta cada 1.5 segundos si todavía quedan tareas activas.
          final boolean x = executor.awaitTermination(1500, MILLISECONDS);
        } catch (final InterruptedException ex) {
          return;
        }
      } while (!executor.isTerminated());
    endTime = System.currentTimeMillis();
    executionTime = endTime - startTime;
    System.out.println("La ejecución ha durado "+ executionTime/1000 + " segundos");
    
  }
}
