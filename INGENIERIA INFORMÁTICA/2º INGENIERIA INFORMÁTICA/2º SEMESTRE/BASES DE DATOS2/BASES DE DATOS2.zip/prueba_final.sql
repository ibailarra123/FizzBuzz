1)
Muestra el c�digo de la comunidad y el nombre en castellano de las comunidades que tengan
alg�n biker nacido desp�es del 02/03/82, a�adiendo a este primer conjunto las comunidades
resultantes de quitar las que tengan alguna sede con longitud menor a 6400 metros,
a las que tengan alg�n equipo dentro de las categor�as ('MA-30','ELITE','F-M30').
Ordena el resultado por el c�digo de la comunidad descendentemente y por el nombre en castellano ascendentemente

select comunidades.cod_comu, comunidades.nombre_esp
from comunidades
join bikers on(comunidades.cod_comu = bikers.cod_comu)
where bikers.fecha_nacimiento > '02/03/82'

union

(select comunidades.cod_comu, comunidades.nombre_esp
from comunidades
join equipos on(equipos.cod_comu = comunidades.cod_comu)
where equipos.categoria = 'MA-30' or equipos.categoria = 'ELITE' or equipos.categoria = 'F-M30'

minus

select comunidades.cod_comu, comunidades.nombre_esp
from comunidades
join sedes on(sedes.cod_comu = comunidades.cod_comu)
where sedes.longitud < 6400)
order by cod_comu desc, nombre_esp asc;

2)
Obt�n un listado en el que aparezcan todas las comunidades de la base de datos, mostrando para cada una de ellas
el c�digo de comunidad, el nombre en castellano y el n�mero de las pertenencias con rol gregario
a equipos de cada comunidad como PERTENENCIAS_EQUIPOS.
Ordenado por PERTENENCIAS_EQUIPOS descendentemente.
Nota: Si alguna de las comunidades no tuviera pertenencias que cumplan esos criterios debe aparecer en el listado con 0.

select comunidades.cod_comu, comunidades.nombre_esp,count(pertenencias.rol)"PERTENENCIAS_EQUIPOS"
from comunidades 
left join equipos on (comunidades.cod_comu=equipos.cod_comu)
left join pertenencias on(equipos.codigo_eq=pertenencias.codigo_eq) AND pertenencias.rol = 'GR'
group by comunidades.cod_comu, comunidades.nombre_esp
order by PERTENENCIAS_EQUIPOS desc;


3)
a) Primero crea una vista BIKERS_MAYOR_TIEMPO que para cada biker muestre su nombre y el mayor de los tiempos
de llegadas en una carrera de 5 vueltas como MAYOR_TIEMPO.

b) a continuaci�n utiliza la vista BIKERS_MAYOR_TIEMPO para mostrar los datos que nos devuelve la vista del
biker o bikers con el mayor MAYOR_TIEMPO

create or replace view BIKERS_MAYOR_TIEMPO
as
select bikers.nombre, participaciones.tiempo_llegada
from bikers 
join participaciones on(participaciones.cod_biker = bikers.cod_biker)
where participaciones.tiempo_llegada 


4)Puebla las tablas con prefijo BTT_MTT_ que tenemos vac�as en nuestra BBDD insertando en ellas los datos
que est�n disponibles en las tablas sin prefijo. Por ejemplo puebla BTT_MTT_BIKERS insertando los
datos de la tabla BIKERS y as� con el resto. (Para evitar problemas accediendo a esquemas se incorporan
estas tablas vac�as con prefijo BTT_MTT_ que simulan el esquema BTT_MTT.)

a) primero deber�s proporcionar un alias m�s corto y manejable para las tablas que comienzan por BTT_MTT
creando sin�nimos que incluyan el prefijo 'z', para utilizarlos para realizar las inserciones.
Por ejemplo, zBIKERS ser� el sin�nimo de BTT_MTT_BIKERS. Crea sin�nimos para todas y cada una de
las tablas que comienzan por BTT_MTT_.

b) luego deber�s crear varias secuencias que vamos a necesitar para poder insertar datos en las tablas vac�as,
ya que hay 3 tablas de las vac�as que cuentan con una clave sustituta o artifical que rellenaremos usando la
correspondiente secuencia:
- Crea una secuencia sin a�adir cl�usulas, con todos sus valores por defecto, para generar los COD_TEMP,
que usaremos al insertar las TEMPORADAS.
- Crea otra secuencia que se inicie en -1 sea descendente y no tenga l�mite inferior para generar los COD_PARTICIPA,
que usaremos al insertar las PARTICIPACIONES.
- Y crea otra secuencia que comience en 700, se incremente de 80 en 80, con valor m�ximo 8700 y que
continue generando valores cuando alcance el m�ximo para generar los COD_PERTENEN, que usaremos al insertar
las PERTENENCIAS.

c) finalmente puebla las tablas vac�as BTT_MTT_ usando sus sin�nimos, insertando los datos que tenemos en las
tablas sin prefijos. En los casos de las tablas que no tengas los correspondientes nuevos c�digos a insertar
usa las secuencias creadas generando los c�digos correspondientes.
Nota : Sigue el orden adecuado a la hora de rellenar las tablas para no violar las restricciones de
integridad referencial.

CREATE OR REPLACE SYNONYM zBIKERS FOR BTT_MTT_BIKERS;
CREATE OR REPLACE SYNONYM zCARRERAS FOR BTT_MTT_CARRERAS;
CREATE OR REPLACE SYNONYM zCOMUNIDADES FOR BTT_MTT_COMUNIDADES;
CREATE OR REPLACE SYNONYM zEQUIPOS FOR BTT_MTT_EQUIPOS;
CREATE OR REPLACE SYNONYM zPARTICIPACIONES FOR BTT_MTT_PARTICIPACIONES;
CREATE OR REPLACE SYNONYM zPERTENENCIAS FOR BTT_MTT_PERTENENCIAS;
CREATE OR REPLACE SYNONYM zSEDES FOR BTT_MTT_SEDES;
CREATE OR REPLACE SYNONYM zTEMPORADAS FOR BTT_MTT_TEMPORADAS;


CREATE SEQUENCE COD_TEMP_SEQ;

CREATE SEQUENCE COD_PARTICIPA_SEQ
START WITH -1
INCREMENT BY -1;

CREATE SEQUENCE COD_PERTENEN_SEQ
START WITH 700
INCREMENT BY 80
MAXVALUE 8700
CYCLE;


INSERT INTO ZCOMUNIDADES SELECT * FROM COMUNIDADES;
INSERT INTO ZSEDES SELECT * FROM SEDES;
INSERT INTO ZEQUIPOS SELECT * FROM EQUIPOS;
INSERT INTO ZBIKERS SELECT * FROM BIKERS;
INSERT INTO ZTEMPORADAS SELECT COD_TEMP_SEQ.NEXTVAL,ANO,SISTEMA_PUNTOS FROM TEMPORADAS;
INSERT INTO ZPERTENENCIAS SELECT COD_PERTENEN_SEQ.NEXTVAL,ANO,COD_BIKER,CODIGO_EQ,ROL FROM PERTENENCIAS;
INSERT INTO ZCARRERAS SELECT * FROM CARRERAS;
INSERT INTO ZPARTICIPACIONES SELECT COD_PARTICIPA_SEQ.NEXTVAL,COD_CARRERA,COD_BIKER,POSICION_LLEGADA,TIEMPO_LLEGADA FROM PARTICIPACIONES;


5)Queremos almacenar el n�mero de carreras de cada temporada. Para ello, ejecuta la siguiente sentencia
ALTER TABLE TEMPORADAS ADD (num_carreras NUMBER DEFAULT 6 NOT NULL); para crear un campo num_carreras en la
tabla TEMPORADAS que sea obligatorio y con el valor 6 por defecto.
a) Actualiza con una s�la sentencia de actualizaci�n el n�mero de carreras de cada temporada con los datos que
hay en este momento en la base de datos.
b) Aplica una soluci�n para que el n�mero de carreras se actualice autom�ticamente para cualquier manipulaci�n
de carreras (ya sea una inserci�n, una eliminaci�n o una actualizaci�n).
c) Inserta una nueva carrera y comprueba que el n�mero de carreras de temporada se incrementa.
Cambia esa misma carrera de temporada y comprueba c�mo el n�mero de carreras de cada respectiva temporada se actualiza.
Elimina esa misma carrera a continuaci�n y comprueba c�mo el n�mero de carreras de temporada se reduce.


Nota 1: Si no consigues actualizar los datos, trabaja el resto del ejercicio con
los valores por defecto obtenidos.
Nota 2: Tambi�n se evaluan los SQLs indicados para realizar las comprobaciones.
Nota 3: Si consigues emplear un �nico disparador obtendr�s 0,20 ptos extra para la nota final de la prueba,
estos enlaces pueden ser de ayuda en caso de intentarlo:
https://oracle-base.com/articles/misc/database-triggers-overview
https://stackoverflow.com/questions/2965521/oracle-and-triggers-inserted-updated-deleted


ALTER TABLE TEMPORADAS ADD (num_carreras NUMBER DEFAULT 6 NOT NULL);                      

UPDATE TEMPORADAS
SET num_carreras
WHERE CODEQU = 3




CREATE OR REPLACE TRIGGER INSERCION_NUM_CARRERAS
AFTER INSERT ON CARRERAS
FOR EACH ROW
BEGIN
UPDATE TEMPORADAS SET NUM_CARRERAS = NUM_CARRERAS+1
WHERE ANO = :new.ANO  ;
END;


CREATE OR REPLACE TRIGGER ELIMINACION_NUM_CARRERAS
BEFORE DELETE ON CARRERAS
FOR EACH ROW
BEGIN
UPDATE TEMPORADAS SET NUM_CARRERAS = NUM_CARRERAS-1
WHERE ANO = :old.ANO;
END;

CREATE OR REPLACE TRIGGER ACTUALIZACION_NUM_CARRERAS
BEFORE UPDATE ON CARRERAS
FOR EACH ROW
BEGIN
UPDATE TEMPORADAS SET NUM_CARRERAS = NUM_CARRERAS+1
WHERE ANO = :new.ANO;  
UPDATE TEMPORADAS SET NUM_CARRERAS = NUM_CARRERAS-1
WHERE ANO = :old.ANO;
END;


INSERT INTO CARRERAS VALUES(78,2020,'20/10/20','CARRERA1',6,3);

DELETE FROM CARRERAS
WHERE NOMBRE_CARRERA='Open Villa de Peralta';

UPDATE CARRERAS
SET ANO = 2021
WHERE NOMBRE_CARRERA ='Open Villa de Peralta';


6)Para una integraci�n entre dos aplicaciones se requiere cacheo, alta disponibilidad y externalizaci�n de la
l�gica de negocio y se opta por compartir una tabla replic�ndola entre las bases de datos de forma s�ncrona.

A modo de entorno de pruebas prepararemos la replicaci�n de una tabla en nuestra base de datos local, de
tal forma que cuando funcione se trasladar� la soluci�n para replicarla en la base de datos de la aplicaci�n.

En concreto vamos a replicar la tabla COMUNIDADES, manteniendo sincronizada dicha r�plica siguiendo estos pasos:

a) Crea la tabla de r�plica COMUNIDADES_REPLICA a partir de la consulta de la tabla origen COMUNIDADES, a�adiendo un
atributo FECHA_REPLICA usando la funci�n SYSDATE y as� comenzar con los datos inciales replicados, tal como
quede la tabla r�plica (no es necesario a�adir ninguna restricci�n de las que tiene la tabla origen).

En caso de no conseguir crea la r�plica anterior del modo planteado, crea al memos la tabla
vac�a ejecutando la siguiente sentencia, para poder crear el replicador:

CREATE TABLE COMUNIDADES_REPLICA (
COD_COMU CHAR(2),
NOMBRE_ESP VARCHAR2(100) NOT NULL,
NOMBRE_EUS VARCHAR2(100) NOT NULL,
NOMBRE_ENG VARCHAR2(100) NOT NULL,
FECHA_REPLICA DATE
);

b) Crea el replicador para que al manipular (insertar, actualizar o borrar) alg�n dato de la tabla origen
COMUNIDADES se produzca la misma manipulaci�n en la tabla r�plica COMUNIDADES_REPLICA, es decir:
En caso de inserci�n en la tabla origen COMUNIDADES: realizar la misma inserci�n incluyendo la fecha de la
r�plica en la tabla r�plica COMUNIDADES_REPLICA.
En caso de actualizaci�n en la tabla origen COMUNIDADES: realizar la misma actualizaci�n incluyendo la fecha de
la r�plica en la tabla r�plica COMUNIDADES_REPLICA.
En caso de eliminaci�n en la tabla origen COMUNIDADES: realizar la misma eliminaci�n en la tabla r�plica COMUNIDADES_REPLICA.

c) Comprueba que el replicador funciona correctamente con las 3 manipulaciones(insertando, actualizando y
eliminando) sobre la tabla origen COMUNIDADES. Y comprobando que se producen las mismas manipulaciones en la
tabla r�plica COMUNIDADES_REPLICA.
Escribe el c�digo que utilizas para realizar las manipulaciones y comprobaciones ya que tambi�n se evalua.