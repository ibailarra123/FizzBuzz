#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <time.h>

#define N 500

double a[N][N];
double b[N][N];
double c[N][N];


int main(void) {
    int i,k,j;
    for (j=0;j<500;j++){
        for (k=0;k<500;k++){
            a[j][k]=drand48();
            b[j][k]=drand48();
        }
    }
    clock_t start =clock();
    for (i=0;i<25000;i++){
        for (j=0;j<500;j++){
            for (k=0;k<500;k++){
                c[j][k]=a[j][k]+b[j][k];
            }
        }
    }
    clock_t finish=clock();
    printf("%ld\n",(finish-start));
    return 0;
}
