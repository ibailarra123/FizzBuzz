
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

double A[64][64*1024];

void main () {
	int i, j, k;
	double cte1=2.0, cte2;
	printf ("Tamaño en bytes de una variable tipo \"double\": %ld\n", sizeof(double));

	for (i=0; i<64; i++)
		for (j=0; j<64*1024; j++)
			A[i][j]=drand48();

	clock_t start = clock();
	for (k=0; k<1500; k++)	
		for (i=0; i<64*1024; i++)
			for (j=0; j<64; j++) {
				cte2=A[j][i]+cte1;
			}
	clock_t finish = clock();

  	printf("It took %lf seconds to execute the loop.\n", (float)(finish - start) / CLOCKS_PER_SEC);
}

