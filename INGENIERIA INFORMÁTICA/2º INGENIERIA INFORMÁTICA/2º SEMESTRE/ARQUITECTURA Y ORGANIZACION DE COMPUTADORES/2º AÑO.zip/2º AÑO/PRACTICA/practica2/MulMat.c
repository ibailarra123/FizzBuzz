#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define N 1024
double A[N][N], B[N][N], C[N][N];
void main (){
    int i, j, k;
    for (i=0; i<N; i++) 
        for (j=0; j<N; j++){
            A[i][j]= drand48();
            B[i][j]= drand48();
            C[i][j]=0.0;
            }
    clock_t start = clock();
    
    for (i=0; i<N; i++)
        for (k=0; k<N; k++)
            for (j=0; j<N; j++)
                C[i][j] = C[i][j] + A[i][k] * B[k][j];
            
    clock_t finish = clock();
    printf("It took %lf seconds to execute the loop.\n", (float)(finish - start) / CLOCKS_PER_SEC);
}
