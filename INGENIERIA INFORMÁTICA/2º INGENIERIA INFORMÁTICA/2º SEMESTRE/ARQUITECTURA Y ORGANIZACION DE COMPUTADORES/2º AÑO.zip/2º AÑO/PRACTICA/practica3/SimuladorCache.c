#include <stdio.h>
#include <stdlib.h>
#include <math.h>

//DECLARACIÓN DE TIPOS

//CONJUNTO:
typedef struct conjunto{          //Representa un conjunto
    unsigned long int indice;     //Vía en la que se encuentra
    int viasCompletas;            //Número de vías del conjunto que ya están completas
    unsigned long int nVias[32];  //Número de vías por conjunto. Máximo 32
}conjunto;

//CACHE:
typedef struct cache{             //Simula una caché
    int longi;                    //Longitud de la caché
    conjunto cach[2048];          //Número de conjuntos por caché. Máximo 2048
}cache;

//DECLARACIÓN DE ACCIONES
unsigned long int rangobits (int bitmenor, int bitmayor, unsigned long int n);                                                                          //Función que calcula el valor entre dos bits (menor y mayor) ambos inclusive.
void intercambiar(unsigned long int *l, unsigned long int *l2);                                                                                         //Acción que intercambia los valores de dos variables.
void cacheVacia(cache *ca, unsigned long int aQueNLinea, unsigned long int aQueNConjunto);                                                              //La caché está vacía y esta acción la inicializa con la primera dirección.
void aumentarLongitudCache(cache *ca, unsigned long int aQueNLinea, unsigned long int aQueNConjunto);                                                   //acción para aumentar la longitud de la caché e inicializar la nueva longitud.
void lecturaFicheroConfiguracion(long *nlinea, long *tlinea, long *asoc, long *vc);                                                                     //Acción que lee los parametros para la configuración de la caché.
void lineaNoEstaEnConjunto(cache *ca, long asoc, unsigned long int aQueNLinea,int i);                                                                   //Acción para actualizar la caché en el caso de que la línea de la dirección no está en el                                                                                  
                                                                                                                                                        //conjunto actual.
void cacheNoVaciaSinVictimCache(cache *ca, unsigned long int aQueNLinea, unsigned long int aQueNConjunto,long asoc,int *numeroErrores,int *cont);       //Acción que modifica la caché y el número de errores cuando no hay Victim Caché y la caché 
                                                                                                                                                        //normal no está vacía.

//COMIENZA EL PROGRAMA
int main(){
    
    //DECLARACIÓN DE VARIABLES
    long nlinea,tlinea,asoc,vc,bitMenor,bitMayorConj;
    unsigned long int aQueNLinea,aQueNConjunto,n;
    FILE *fd;
    int numeroErrores,cont,numeroAccesos,i,v,j,z,w,pos;
    cache ca;

    //LECTURA DE FICHERO DE CONFIGURACIÓN
    lecturaFicheroConfiguracion(&nlinea,&tlinea,&asoc,&vc);

    //CALCULO DE BITS
    bitMenor=log(tlinea)/log(2);                                //Se calcula el bit menor de las direcciones para saber la linea
    bitMayorConj = bitMenor + (log(nlinea/asoc) / log(2));      //Se calcula el mayor bit de las direcciones para saber el conjunto
    
    //INICIALIZACIÓN VICTIM CACHÉ
    long VC[vc];           //Se declara la Victim Caché 
    for (i=0;i < vc; i++){
        VC[i] = -1;
    }
    
    //INICIALIZACIÓN DE VARIABLE Y FICHERO DE TRAZAS 
    fd=fopen("traza.txt","r+");   //Contiene las direcciones creadas por el código
    numeroErrores = 0;
    numeroAccesos = 0;
    ca.longi=0;
    
    //CASO SIN VICTIM CACHÉ:
    if(vc==0){                          //Cuando no hay Victim Caché
        while(!feof(fd)){
            cont=0;
            fscanf(fd, "%lx", &n);      //Se lee una direccion n
            
            //CALCULO DE LÍNEA Y CONJUNTO DE LA DIRECCIÓN
            aQueNLinea = rangobits(bitMenor,47,n);                          //Se calcula a que linea de la caché va la direccion n
            aQueNConjunto=rangobits(bitMenor,bitMayorConj-1,n);             //Se calcula a que conjunto de la caché va la direccion n
            
            //PRIMER CASO(CACHÉ VACÍA)
            if(ca.longi==0){                                                //Primer caso en el que la caché está vacía
                cacheVacia(&ca,aQueNLinea,aQueNConjunto);                   //Se inicializa con la primera dirección
                numeroErrores=numeroErrores+1;                              //Al estar la caché vacía, se produce el primer error
            }
            
            //RESTO DE DIRECCIONES
            else{                                                           //La caché no está vacía
                cacheNoVaciaSinVictimCache(&ca, aQueNLinea,aQueNConjunto,asoc, &numeroErrores,&cont);
            }
            numeroAccesos++;
        }
    }
    
    //CASO SIN VICTIM CACHÉ:
    else{                               //Cuando hay victim Caché
        while(!feof(fd)){
            cont=0;
            fscanf(fd, "%lx", &n);      //Se lee una direccion n

            //CALCULO DE LÍNEA Y CONJUNTO DE LA DIRECCIÓN
            aQueNLinea = rangobits(bitMenor,47,n);                        //Se calcula a que linea de la caché va la direccion n
            aQueNConjunto=rangobits(bitMenor,bitMayorConj-1,n);           //Se calcula a que conjunto de la caché va la direccion n

            //PRIMER CASO(CACHÉ VACÍA)
            if(ca.longi==0){                                              //Primer caso en el que la caché está vacía
                cacheVacia(&ca,aQueNLinea,aQueNConjunto);                 //Se inicializa con la primera dirección
                numeroErrores=numeroErrores+1;                            //Al estar la caché vacía, se produce el primer error
            }
            
            //RESTO DE DIRECCIONES
            else{                                                         //La caché no esta vacía
                i=0;
                while(i < ca.longi){                                      //Mientras haya espacio en la caché
                    
                    //CASO PARA SI EL CONJUNTO AL QUE VA LA DIRECCIÓN ES EL MISMO QUE EL CONJUNTO ACTUAL
                    if(ca.cach[i].indice == aQueNConjunto){               //Si el conjunto al que va la dirección es la misma que la que toca en el conjunto actual
                        j=0;
                        while(j < ca.cach[i].viasCompletas){              //Recorrido de las vías completas
                            if(aQueNLinea == ca.cach[i].nVias[j]){        //Si la línea a la que va la dirección coincide con la vía del conjunto
                                //REORDENAR LAS VÍAS
                                while(j != ca.cach[i].viasCompletas -1){ // While para actualizar el contenido de las vías, con respecto a la línea de la nueva dirección mediante el intercambio
                                    intercambiar(&ca.cach[i].nVias[j],&ca.cach[i].nVias[j+1]);
                                    j++;
                                }
                                break;
                            }
                            j=j+1;
                        }
                        if (aQueNLinea == ca.cach[i].nVias[ca.cach[i].viasCompletas-1]){     //Al acabarse el recorrido, si la linea a la que va la direccion es la última vía del conjunto, se sale
                            break;
                        }
                        if(aQueNLinea != ca.cach[i].nVias[j]){                               //Si la linea a la que va la direccion no está en el conjunto, se produce un fallo
                            pos= -1;
                            v=0;
                            
                            //COMPROBAR SI SE PRODUCE ERROR EN LA VICTIM CACHÉ
                            while(v < vc){                              //Recorrido de la Victim Cache
                                if(VC[v]== aQueNLinea){                 //Si la línea coincide con la vía actual de la Victim Cache, se produce un error
                                    numeroErrores=numeroErrores-1;
                                    pos = v;                            //Se guarda la posición en la Victim Cache
                                }
                                v=v+1;
                            }
                            
                            //ACTUALIZAR LA VICTIM CACHÉ
                            if (pos > -1){                              //Si la posición es mayor que -1, es decir si al línea ha coincidido con alguna vía de la Victim Cache pero no con la caché normal
                                w = pos;
                                while(w < vc-1){                        //Todas las vías a partir de la posición de la vía que coincide con al linea, se mueven una vía hacia delante
                                    VC[w]=VC[w+1];
                                    w = w+1;
                                }
                            }
                            else{                                       //Si la línea no ha coincidido con ninguna vía de la Victim Caché ni con la Caché normal
                                z = 0;
                                while(z < vc-1){                        //Todas las vías desde el principio, se mueven una vía hacia delante
                                    VC[z] = VC[z+1];
                                    z = z+1;
                                }
                                VC[vc-1]= ca.cach[i].nVias[0];          //Se inserta en la última posición de la Victim caché la primera vía del conjunto
                            }
                            
                            numeroErrores=numeroErrores+1;
                            lineaNoEstaEnConjunto(&ca, asoc, aQueNLinea,i);
                            break;
                        }
                    }
                    
                    //EL CONJUNTO AL QUE VA LA DIRECCIÓN NO ES EL MISMO QUE EL CONJUNTO ACTUAL
                    else{
                        cont=cont+1;
                    }
                    i = i+1;
                }
                if(cont==ca.longi){                         //Si ya no queda suficinte es espacio en la caché aumentar la longitud
                    aumentarLongitudCache(&ca,aQueNLinea,aQueNConjunto);
                    numeroErrores=numeroErrores+1;          //Por tanto se produce un error
                }
            }
            
            numeroAccesos++;                                //Se lleva la cuenta de todos los accesos
        }
    }

    printf("El número de accesos es: %d\n",numeroAccesos-1);
    printf("El número de errores es: %d\n",numeroErrores);
    printf("La tasa de fallos es del %f porciento\n",((float)numeroErrores/(numeroAccesos-1)*100));    //Tasa de fallos
}




//ACCIONES NECESARIAS
void lecturaFicheroConfiguracion(long *nlinea, long *tlinea, long *asoc, long *vc){
    FILE *f;
    f=fopen("config.txt","r+");                //Fichero que contiene la configuración de la caché
    fscanf(f, "Nlin: %ld\n", &(*nlinea));      //Número de lineas de la caché
    fscanf(f, "Tlin: %ld\n", &(*tlinea));      //Tamaño de la línea en bytes/linea
    fscanf(f, "Asoc: %ld\n", &(*asoc));        //Número de vias por conjunto
    fscanf(f, "VC: %ld\n", &(*vc));            //número de líneas de esta caché, totalmente asociativa con algoritmo de reemplazo LRU
    fclose(f);
}

void intercambiar(unsigned long int *l,unsigned long int *l2){
    unsigned long int aux;
    aux = *l;
    *l = *l2;
    *l2 = aux;
}

unsigned long int rangobits (int bitmenor, int bitmayor, unsigned long int n){
    unsigned long int bit2=1, bit1=1;
    if (bitmenor<0 || bitmenor>47) {
        printf("Error en Bitmenor: %d\n", bitmenor);
        exit(0);
    }
    else if (bitmayor<0 || bitmayor>47) {
        printf("Error en Bitmayor: %d\n", bitmayor);
        exit(0);
    }
    else if (bitmenor>bitmayor) {
        printf("Error en Orden\n");
        exit(0);
    }
    else if(bitmayor-bitmenor+1<48 ) {
        /** calcula valor 2 elevado a bitmenor **/
        bit1= bit1 << bitmenor;
        /** calcula valor 2 elevado a (bitmayor-bitmenor + 1) **/
        bit2 =bit2 << (bitmayor-bitmenor + 1);
        n=n / bit1;
        n=n % bit2;
    }
    return n;
}

void cacheVacia(cache *ca, unsigned long int aQueNLinea, unsigned long int aQueNConjunto){
    ca->cach[0].nVias[0]= aQueNLinea;   //Se introduce la primera línea
    ca->cach[0].indice = aQueNConjunto; //Se inntroduce el primer conjunto
    ca->cach[0].viasCompletas = 1;      //Se incrementa el número de vias completas en 1
    ca->longi = 1;                      //Al estar la caché vacía, ahora la longitud es 1
}

void aumentarLongitudCache(cache *ca, unsigned long int aQueNLinea, unsigned long int aQueNConjunto){
    ca->cach[ca->longi].nVias[0]= aQueNLinea;
    ca->cach[ca->longi].indice = aQueNConjunto;
    ca->cach[ca->longi].viasCompletas = ca->cach[ca->longi].viasCompletas + 1;
    ca->longi = ca->longi + 1;
}

void lineaNoEstaEnConjunto(cache *ca, long asoc, unsigned long int aQueNLinea,int i){
    int v;
    if(ca->cach[i].viasCompletas < asoc){                           //Si aún queda sitio en el conjunto
        ca->cach[i].nVias[ca->cach[i].viasCompletas]=aQueNLinea;    //Se inserta la dirección
        ca->cach[i].viasCompletas = ca->cach[i].viasCompletas+1;    //Se ha completado una nueva vía más
    }
    else if(ca->cach[i].viasCompletas == asoc){                     //Si ya están todas las vias del conjunto completas
        v = 0;                                                      
        while(v < asoc-1){                                          //Se mueven todas las direcciones a la vía anterior, dejando libre la última vía
            ca->cach[i].nVias[v] = ca->cach[i].nVias[v+1];
            v=v+1;
        }
        ca->cach[i].nVias[asoc-1] = aQueNLinea;                     //Se inserta la línea en la última vía
    }
}

void cacheNoVaciaSinVictimCache(cache *ca, unsigned long int aQueNLinea, unsigned long int aQueNConjunto,long asoc,int *numeroErrores,int *cont){
    int i=0;
    while(i < ca->longi){                                        //Mientras haya espacio en la caché
        
        //CASO PARA SI EL CONJUNTO AL QUE VA LA DIRECCIÓN ES EL MISMO QUE EL CONJUNTO ACTUAL
        if(ca->cach[i].indice == aQueNConjunto){                 //Si el conjunto al que va la dirección es la misma que la que toca en el conjunto actual
            int j=0;
            while(j < ca->cach[i].viasCompletas){                //Recorido por las vías completas
                if(aQueNLinea == ca->cach[i].nVias[j]){          //Si la línea a la que va la dirección coincide con la vía del conjunto
                    //REORDENAR LAS VÍAS
                    while(j != ca->cach[i].viasCompletas -1){    // While para actualizar el contenido de las vías, con respecto a la línea de la nueva dirección mediante el intercambio
                        intercambiar(&ca->cach[i].nVias[j],&ca->cach[i].nVias[j+1]);
                        j++;
                    }
                    break;
                }
                j=j+1;
            }
            if (aQueNLinea == ca->cach[i].nVias[ca->cach[i].viasCompletas-1]){    //Al acabarse el recorrido, si la linea a la que va la direccion es la última vía del conjunto, se sale
                break;
            }
            if(aQueNLinea != ca->cach[i].nVias[j]){                              //Si la linea a la que va la direccion no está en el conjunto, se produce un fallo
                *numeroErrores = *numeroErrores+1;
                lineaNoEstaEnConjunto(&(*ca), asoc, aQueNLinea,i);
                break;
            }
        }
        
        //EL CONJUNTO AL QUE VA LA DIRECCIÓN NO ES EL MISMO QUE EL CONJUNTO ACTUAL
        else{
            *cont=*cont+1;
        }
        i = i+1;
    }

    //EL CONJUNTO AL QUE VA LA DIRECCIÓN NO VA A NINGUN CONJUNTO DE LA LONGITUD DE LA CACHÉ
    if(*cont==ca->longi){  
        aumentarLongitudCache(&(*ca),aQueNLinea,aQueNConjunto);    //Si ya no queda suficinte es espacio en la caché aumentar la longitud
        *numeroErrores=*numeroErrores+1;
    }
}
