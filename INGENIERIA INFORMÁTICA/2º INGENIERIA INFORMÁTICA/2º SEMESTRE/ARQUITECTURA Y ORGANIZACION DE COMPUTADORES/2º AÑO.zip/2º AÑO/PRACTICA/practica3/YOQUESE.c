#include <stdio.h>
#include <stdlib.h>
#include <math.h>

typedef struct conjunto{
    unsigned long int num;
    int viasCompletas;
    unsigned long int nVias[64];
}conjunto;

typedef struct cache{
    int longi;
    conjunto cach[2048];
}cache;

cache actualizaVias(cache ca,int iCon,int iVia);
unsigned long int rangobits (int bitmenor, int bitmayor, unsigned long int n);
void intercambiar(long *l, long *l2);

int main(){
    long nlinea,tlinea,asoc,vc,bitMenor,bitMayorConj;
    unsigned long int aQueNLinea,aQueNConjunto;
    FILE *f,*fd;
    int numeroErrores,cont,numeroAccesos,i,v,j,z,m,w,pos;
    cache ca;

    f=fopen("config.txt","r+");
    fscanf(f, "Nlin: %ld\n", &nlinea); //Número de lineas de la caché
    fscanf(f, "Tlin: %ld\n", &tlinea); //Tamaño de la línea en bytes/linea
    fscanf(f, "Asoc: %ld\n", &asoc); //Número de vias por conjunto
    fscanf(f, "VC: %ld\n", &vc);
    fclose(f);

    long VC[vc];

    bitMenor=log(tlinea)/log(2);
    
    fd=fopen("traza.txt","r+");
    unsigned long int n;
    numeroErrores = 0;
    numeroAccesos = 0;
    ca.longi=0;
    if(vc==0){
        while(!feof(fd)){
            cont=0;
            fscanf(fd, "%lx", &n);

            aQueNLinea = rangobits(bitMenor,47,n);
            bitMayorConj = bitMenor + (log(nlinea/asoc) / log(2));
            aQueNConjunto=rangobits(bitMenor,bitMayorConj-1,n);
            
            printf("La linea %ld va al conjunto %ld\n", aQueNLinea,aQueNConjunto);
            
            if(ca.longi==0){
                ca.cach[0].nVias[0]= aQueNLinea;
                ca.cach[0].num = aQueNConjunto;
                ca.cach[0].viasCompletas = 1;
                ca.longi = 1;
                numeroErrores=numeroErrores+1;
            }
            else{
                i=0;
                while(i < ca.longi){
                    if(ca.cach[i].num == aQueNConjunto){
                        j=0;
                        while(j < ca.cach[i].viasCompletas){
                            if(aQueNLinea == ca.cach[i].nVias[j]){
                                ca=actualizaVias(ca,i,j);
                                break;
                            }
                            j=j+1;
                        }
                        if (aQueNLinea == ca.cach[i].nVias[ca.cach[i].viasCompletas-1]){
                            break;
                        }
                        if(aQueNLinea != ca.cach[i].nVias[j]){
                            numeroErrores = numeroErrores+1;
                            if(ca.cach[i].viasCompletas == asoc){
                                v = 0;
                                while(v < asoc-1){
                                    ca.cach[i].nVias[v] = ca.cach[i].nVias[v+1];
                                    v=v+1;
                                }
                                ca.cach[i].nVias[asoc-1] = aQueNLinea;
                            }
                            else if(ca.cach[i].viasCompletas < asoc){
                                ca.cach[i].nVias[ca.cach[i].viasCompletas]=aQueNLinea;
                                ca.cach[i].viasCompletas = ca.cach[i].viasCompletas+1;
                            }
                            break;
                        }
                    }
                    else{
                        cont=cont+1;
                    }
                    i = i+1;
                }
                if(cont==ca.longi){
                    ca.cach[ca.longi].nVias[0]= aQueNLinea;
                    ca.cach[ca.longi].num = aQueNConjunto;
                    ca.cach[ca.longi].viasCompletas = ca.cach[ca.longi].viasCompletas + 1;
                    ca.longi = ca.longi + 1;
                    numeroErrores=numeroErrores+1;
                }
            }
            
            
            numeroAccesos++;
        }
    }
    else{
        i=0;
        while(i < vc){
            VC[i] = -1;
            i = i+1;
        }
        while(!feof(fd)){
            cont=0;
            fscanf(fd, "%lx", &n);

            aQueNLinea = rangobits(bitMenor,47,n);
            bitMayorConj = bitMenor + (log(nlinea/asoc) / log(2));
            aQueNConjunto=rangobits(bitMenor,bitMayorConj-1,n);
            
            printf("La linea %ld va al conjunto %ld\n", aQueNLinea,aQueNConjunto);
            
            if(ca.longi==0){
                ca.cach[0].nVias[0]= aQueNLinea;
                ca.cach[0].num = aQueNConjunto;
                ca.cach[0].viasCompletas = 1;
                ca.longi = 1;
                numeroErrores=numeroErrores+1;
            }
            else{
                i=0;
                while(i < ca.longi){
                    if(ca.cach[i].num == aQueNConjunto){
                        j=0;
                        while(j < ca.cach[i].viasCompletas){
                            if(aQueNLinea == ca.cach[i].nVias[j]){
                                ca=actualizaVias(ca,i,j);
                                break;
                            }
                            j=j+1;
                        }
                        if (aQueNLinea == ca.cach[i].nVias[ca.cach[i].viasCompletas-1]){
                            break;
                        }
                        if(aQueNLinea != ca.cach[i].nVias[j]){
                            pos= -1;
                            v=0;
                            while(v < vc){
                                if(VC[v]== aQueNLinea){
                                    numeroErrores=numeroErrores-1;
                                    pos = v;
                                }
                                v=v+1;
                            }
                            
                            if (pos > -1){
                                w = pos;
                                while(w < vc-1){
                                    VC[w]=VC[w+1];
                                    w = w+1;
                                }
                            }
                            else{
                                z = 0;
                                while(z < vc-1){
                                    VC[z] = VC[z+1];
                                    z = z+1;
                                }
                                VC[vc-1]= ca.cach[i].nVias[0];
                            }
                            
                            numeroErrores=numeroErrores+1;
                            if(ca.cach[i].viasCompletas == asoc){
                                m = 0;
                                while(m < asoc-1){
                                    ca.cach[i].nVias[m] = ca.cach[i].nVias[m+1];
                                    m = m+1;
                                }
                                ca.cach[i].nVias[asoc-1]=aQueNLinea;
                            }
                            
                            else if(ca.cach[i].viasCompletas < asoc){
                                ca.cach[i].nVias[ca.cach[i].viasCompletas]=aQueNLinea;
                                ca.cach[i].viasCompletas = ca.cach[i].viasCompletas+1;
                            }
                            break;
                        }
                    }
                    else{
                        cont=cont+1;
                    }
                    i = i+1;
                }
                if(cont==ca.longi){
                    ca.cach[ca.longi].nVias[0]= aQueNLinea;
                    ca.cach[ca.longi].num = aQueNConjunto;
                    ca.cach[ca.longi].viasCompletas = ca.cach[ca.longi].viasCompletas + 1;
                    ca.longi = ca.longi + 1;
                    numeroErrores=numeroErrores+1;
                }
            }
            
            numeroAccesos++;
        }
    }
    numeroAccesos=numeroAccesos-1;
    printf("El número de accesos es: %d\n",numeroAccesos);
    printf("El número de errores es: %d\n",numeroErrores);
    printf("La tasa de fallos es: %f\n",((float)numeroErrores/numeroAccesos*100));
}

void intercambiar(long *l,long *l2){
    long aux;
    aux = *l;
    *l = *l2;
    *l2 = aux;
}

unsigned long int rangobits (int bitmenor, int bitmayor, unsigned long int n){
    unsigned long int bit2=1, bit1=1;
    if (bitmenor<0 || bitmenor>47) {
        printf("Error en Bitmenor: %d\n", bitmenor);
        exit(0);
    }
    else if (bitmayor<0 || bitmayor>47) {
        printf("Error en Bitmayor: %d\n", bitmayor);
        exit(0);
    }
    else if (bitmenor>bitmayor) {
        printf("Error en Orden\n");
        exit(0);
    }
    else if(bitmayor-bitmenor+1<48 ) {
        /** calcula valor 2 elevado a bitmenor **/
        bit1= bit1 << bitmenor;
        /** calcula valor 2 elevado a (bitmayor-bitmenor + 1) **/
        bit2 =bit2 << (bitmayor-bitmenor + 1);
        n=n / bit1;
        n=n % bit2;
    }
    return n;
}

cache actualizaVias(cache ca,int iCon,int iVia){
	int numeroViasLlenas = ca.cach[iCon].viasCompletas;
	while(iVia != numeroViasLlenas -1){
		intercambiar(&ca.cach[iCon].nVias[iVia],&ca.cach[iCon].nVias[iVia+1]);
		iVia++;
	}
	return ca;
}
