#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/*int main(){
	long res;
	FILE *f;
	f=fopen("traza.txt","w");
	float M[6][128];   tamaño del float 4 bytes 
		for (int j=0; j<128; j++)
			for (int i=0; i<6; i++){
				res = M[i][j];
				fprintf(f, "%p\n", &M[i][j]);
			}
}
*/

/*
int main(){
	double res;
	FILE *f;
    int i;
	f=fopen("traza.txt","w");
	double M[8][256]; 
	for (int j=0; j<256; j++){
		for (i=0; i<8; i++){
			res = res + M[i][j];
			fprintf(f, "%p\n", &M[i][j]);
		}
		for (i=7; i<=0; i--){
			res = res + M[i][j];
			fprintf(f, "%p\n", &M[i][j]);
		}
    }
}

*/

int main(){
	float res;
	FILE *f;
	f=fopen("traza.txt","w");
	float M[128][512]; 
    for (int i=0; i<128; i++){
        res = M[i][0];
        fprintf(f, "%p ", &M[i][0]);
    }
    for (int i=127; i>=0; i--){
        res = M[i][1];
        fprintf(f, "%p ", &M[i][1]);
    }
    for (int i=0; i<128; i++){
        res = M[i][2];
        fprintf(f, "%p ", &M[i][2]);
    }
    for (int i=127; i>=0; i--){
        res = M[i][3];
        fprintf(f, "%p ", &M[i][3]);
    }
}


/*
int main(){
	double res;
	FILE *f;
	f=fopen("traza.txt","w");
	double M[4][1024]; 
		for (int j=0; j<1024; j++)
			for (int i=0; i<4; i++){
				res = M[i][j];
				fprintf(f, "%p\n", &M[i][j]);
			}
}
*/

/*
double A[64][64*1024];

int main () {
	int i, j;
	double cte1=2.0, cte2;
    FILE *f;
	f=fopen("traza.txt","w");
	for (i=0; i<64; i++){
		for (j=0; j<64*1024; j++){
			A[i][j]=drand48();
        }
    }

    for (i=0; i<64*1024; i++){
        for (j=0; j<64; j++) {
            cte2=A[j][i]+cte1;
            fprintf(f, "%p ", &A[j][i]);
        }
    }
    fclose(f);
}
*/
