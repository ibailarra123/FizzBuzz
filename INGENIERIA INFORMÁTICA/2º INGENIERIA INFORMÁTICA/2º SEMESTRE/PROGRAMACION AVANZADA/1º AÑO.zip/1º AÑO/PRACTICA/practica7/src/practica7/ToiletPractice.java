/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica7;

import static java.lang.Thread.interrupted;
import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ToiletPractice {
    public static void main(String[] args) {
        new ToiletPractice().init();
    }
    
    public void init(){
        Toilet toiletman    = new ToiletHombre();
        Toilet toiletwoman    = new ToiletMujer();
        Toilet dual = new DualPersonToilet();
        new Person(dual, "Peter")   .start();
        new Person(dual, "Maria")   .start();
        new Person(dual, "Josh")    .start();
        new Person(dual, "Katy")    .start();
        new Person(dual, "Emma")    .start();
        new Person(dual, "Rachel")  .start();
        new Person(dual, "Lucy")    .start();
    }
    
    public abstract class Toilet{
        
        abstract void use();
        
        private void logEnter(){
            System.out.println("Thread " + 
                                Thread.currentThread().getName() +
                                " enters the Toilet to pee");
        }
        
        private void logExit(){
            System.out.println("Thread " + 
                                Thread.currentThread().getName() + 
                                " leaves the Toilet");
        }
        
        private void logException(Exception ex){
             System.out.println(ex);
        }
        
        
        public void pee(){
            logEnter();
            try {
                Thread.sleep((int)(Math.random() * 500) + 250);
            } catch (InterruptedException ex) {
                logException(ex);
            }
            logExit();
        }
    }
    
    
     public class ToiletHombre extends Toilet{
        
        @Override
        public synchronized void use(){
           
                pee();
            
        }
    }
     
    public class ToiletMujer extends Toilet{
        
        @Override
        public synchronized void use(){
           
                pee();
            
        }
    }
    
    public class Person extends Thread{
        private final Toilet toilet;

        public Person(Toilet toilet, String name) {
            this.toilet = toilet;
            setName(name);
        }

        @Override
        public void run() {
            while (! interrupted() ){
                try {
                    Thread.sleep((int)(Math.random() * 2000) + 1000);
                } catch (InterruptedException ex) {
                    System.out.println("Exception: " + ex);
                }
                toilet.use();
            }
        }
        
        
    }
    
    public class DualPersonToilet extends Toilet{
        private Semaphore sem = new Semaphore(2);

        @Override
        void use() {
            try {
                sem.acquire();
                pee();
            } catch (InterruptedException ex) {
                Logger.getLogger(ToiletPractice.class.getName()).log(Level.SEVERE, null, ex);
            } finally{
                sem.release();
            }
        }
        
    }
}
