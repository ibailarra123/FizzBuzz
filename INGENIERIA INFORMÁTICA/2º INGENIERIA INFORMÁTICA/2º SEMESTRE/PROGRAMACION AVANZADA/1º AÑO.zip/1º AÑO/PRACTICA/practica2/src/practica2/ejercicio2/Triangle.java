/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica2.ejercicio2;

/**
 *
 * @author ilarr
 */
public class Triangle implements Geometry{
    protected float height;
    protected float base;
    
    public Triangle(float base, float height){
        super();
        this.base = base;
        this.height = height;
    }

    @Override
    public float getPerimeter() {
        return 3*base; 
    }
    
    @Override
    public float getArea() {
        return (base*height)/2;
    }
}
