/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica2.ejercicio2;

/**
 *
 * @author ilarr
 */
public class Circle implements Geometry{
    protected float radius;
    
    public Circle(float radius){
        super();
        this.radius = radius;
    }

    @Override
    public float getPerimeter() {
        return (float) (2*Math.PI*radius); 
    }
    
    @Override
    public float getArea() {
        return (float) (Math.PI*Math.pow(radius,2));
    }
    
}
