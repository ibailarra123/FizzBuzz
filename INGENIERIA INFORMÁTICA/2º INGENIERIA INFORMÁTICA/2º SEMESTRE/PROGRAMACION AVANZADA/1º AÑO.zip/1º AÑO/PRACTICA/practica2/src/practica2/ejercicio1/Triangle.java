/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica2.ejercicio1;

/**
 *
 * @author ilarr
 */
public class Triangle extends Geometry{
    private float height;
    private float base;
    
    public Triangle(float base, float height){
        super();
        this.base = base;
        this.height = height;
    }

    @Override
    float getPerimeter() {
        return 3*base; 
    }
    
    @Override
    float getArea() {
        return (base*height)/2;
    }
}
