/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica2.ejercicio2;

/**
 *
 * @author ilarr
 */
public class Box extends Rectangle implements Geometry3D{
    private float depth;
    
    public Box(float depth,float width, float height){
        super(width,height);
        this.depth = depth;
    }

    @Override
    public float getPerimeter() {
        return (2*(width + height)); 
    }
    
    @Override
    public float getArea() {
        return (2*(width*height + depth*height + width * depth));
    }
    
    @Override
    public float getVolume(){
        return(width*height*depth);
    }
    
}
