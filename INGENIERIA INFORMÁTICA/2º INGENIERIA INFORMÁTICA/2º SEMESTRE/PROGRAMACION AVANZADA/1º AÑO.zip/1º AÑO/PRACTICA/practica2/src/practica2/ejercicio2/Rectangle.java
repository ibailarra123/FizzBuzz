/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica2.ejercicio2;

/**
 *
 * @author ilarr
 */
public class Rectangle implements Geometry{
    protected float width;
    protected float height;
    
    public Rectangle(float width, float height){
        super();
        this.width = width;
        this.height = height;
    }

    @Override
    public float getPerimeter() {
        return (width*2) + (height*2); 
    }
    
    @Override
    public float getArea() {
        return width*height;
    }
}
