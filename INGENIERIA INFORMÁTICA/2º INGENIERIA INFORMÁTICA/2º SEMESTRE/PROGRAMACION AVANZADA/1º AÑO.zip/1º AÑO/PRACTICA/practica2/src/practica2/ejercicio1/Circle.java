/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica2.ejercicio1;

/**
 *
 * @author ilarr
 */
public class Circle extends Geometry{
    private float radius;
    
    public Circle(float radius){
        super();
        this.radius = radius;
    }

    @Override
    float getPerimeter() {
        return (float) (2*Math.PI*radius); 
    }
    
    @Override
    float getArea() {
        return (float) (Math.PI*Math.pow(radius,2));
    }
    
    
    
}
