/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica2.ejercicio1;

/**
 *
 * @author ilarr
 */
public class Rectangle extends Geometry{
    private float width;
    private float height;
    
    public Rectangle(float width, float height){
        super();
        this.width = width;
        this.height = height;
    }

    @Override
    float getPerimeter() {
        return (width*2) + (height*2); 
    }
    
    @Override
    float getArea() {
        return width*height;
    }
    
}
