/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica2.ejercicio2;

/**
 *
 * @author ilarr
 */
public class TryGeometry {
    public static void main(String[] args) {
        Geometry[] geometrias = new Geometry[6];
        geometrias[0] = new Rectangle(3,2);
        geometrias[1] = new Circle(3);
        geometrias[2] = new Triangle(2,5);
        geometrias[3] = new Box(2,3,4);
        geometrias[4] = new Sphere(3);
        geometrias[5] = new Tetrahedron(2,3,4);
        
        System.out.println(geometrias[0]);
        System.out.println(geometrias[1]);
        System.out.println(geometrias[2]);
        System.out.println(geometrias[3]);
        System.out.println(geometrias[4]);
        System.out.println(geometrias[5]);
    }
    
}
