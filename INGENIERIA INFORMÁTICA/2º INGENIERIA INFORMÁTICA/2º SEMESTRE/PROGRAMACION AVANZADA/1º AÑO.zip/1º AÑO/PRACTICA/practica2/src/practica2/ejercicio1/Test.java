/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica2.ejercicio1;

/**
 *
 * @author ilarr
 */
public class Test {

    public static void main(String args[]){
        Geometry geometrys[] = new Geometry[3];
        // instanciamos
        geometrys[0] = new Circle(7);
        geometrys[1] = new Rectangle(1,2);
        geometrys[2] = new Triangle(9,9);
        
        System.out.println(geometrys[0].getArea());
    }
    
    
}
