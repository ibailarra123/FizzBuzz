/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica2.ejercicio2;

import static java.lang.Math.sqrt;

/**
 *
 * @author ilarr
 */
public class Tetrahedron extends Triangle implements Geometry3D{
    protected float depth;
   
    public Tetrahedron(float base, float height,float depth) {
        super(base, height);
        this.depth = depth;
    }
     @Override
    public float getPerimeter(){
        return (float) (0);
    }
    
    @Override
    public float getArea(){
        return (float) (base*base*sqrt(3));
    }
    
    @Override
    public float getVolume(){
        return(float) ((base*base*base*sqrt(2))/12);
    }
}
