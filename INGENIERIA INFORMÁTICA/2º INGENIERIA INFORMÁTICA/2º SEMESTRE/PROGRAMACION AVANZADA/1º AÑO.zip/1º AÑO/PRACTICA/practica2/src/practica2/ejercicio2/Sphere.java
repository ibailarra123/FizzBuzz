/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica2.ejercicio2;

/**
 *
 * @author ilarr
 */
public class Sphere extends Circle implements Geometry3D{
    
    public Sphere(float radius) {
        super(radius);
    }
    @Override
    public float getPerimeter(){
        return (float) (2*3.14*radius);
    }
    
    @Override
    public float getArea(){
        return (float) (4*3.14*radius*radius);
    }
    
    @Override
    public float getVolume(){
        return(float) ((4/3)*3.14*radius*radius*radius );
    }
    
}