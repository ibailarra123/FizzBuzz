/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica2.ejercicio2;

/**
 *
 * @author ilarr
 */
public interface Geometry3D extends Geometry{
    float getVolume();
}
