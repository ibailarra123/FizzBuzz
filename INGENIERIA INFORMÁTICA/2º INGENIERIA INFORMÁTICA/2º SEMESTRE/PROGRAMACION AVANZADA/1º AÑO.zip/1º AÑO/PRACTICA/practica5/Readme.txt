Autor: Ibai Larralde Baldanta
Versión: 1.0 
Resumen: Este progama trata de simular el juego del oso, en el que dos jugadores juegan en
un tablero de 10x10 para conseguir completar el máxmimo número de palabras "oso" y poder 
vencer. Para ello se va a establecer un servidor para el juego y otro para que puedan 
comunicarse los jugadores, de esta manera los jugadores podrán jugar de manera online estando
conectados.
Ejecución del programa: El programa consta de dos ejecutables: MainServidor y MainJugador. 
El ejecutable MainServidor se encarga de crear dos servidores, uno para el propio 
juego(ServidorJuego) y otro para el chat por el que se van a comunicar los 
jugadores(ServidorChat), cada uno con un puerto distinto, por tanto ambos son completamente
independientes.
El servidor del chat lo que hace es aceptar dos clientes(Jugadores), y cuando uno de ellos
mande un mensaje, lo recibirán todos los demás clientes, puedindo ellos también enviar 
mensajes.
En cuanto al servidor del juego, de lo que se encarga es de crear una nueva partida y aceptar
dos clientes, con forme los dos jugadores vayan jugando, el servidor se encargará de 
transmitir los movimientos de un jugador a otro para que sepan en todo momento como transcurre
la partida. Una vez acaba la partida, muestra a todos los jugadores quien ha sido el ganador
y guarda el nombre del ganador en un fichero de texto.

Por otro lado, el ejecutable MainJugador, lo que hace es crear un menú para que un cliente
introduzca los puertos del servidor de juego y del servidor de chat que quiere, además de un
nombre. Una vez introducidos, se crea un jugador con estos datos, puediendo conectarse tanto 
al servidor de Juego como al servidor de Chat, y comienza un a comunicación con ambos
servidores. 
Se crea además un tablero para cada jugador donde pueden ver en todo momento como
está funcionando la partida. En este tablero, los jugadores van a poder poder jugar e
intercambiar mensajes y una vez finalizada la partida verán quien ha sido el ganador.


