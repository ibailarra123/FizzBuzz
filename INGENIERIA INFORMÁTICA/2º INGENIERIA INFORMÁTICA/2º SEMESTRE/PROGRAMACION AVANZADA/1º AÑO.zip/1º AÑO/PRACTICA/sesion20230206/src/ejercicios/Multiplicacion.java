/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicios;

public class Multiplicacion extends Ejercicio{
    public Multiplicacion() {
        super();
        res = num1*num2;
    }
    
    @Override
    public String toString() {
        return num1+"*"+num2+"=";
    }  
}