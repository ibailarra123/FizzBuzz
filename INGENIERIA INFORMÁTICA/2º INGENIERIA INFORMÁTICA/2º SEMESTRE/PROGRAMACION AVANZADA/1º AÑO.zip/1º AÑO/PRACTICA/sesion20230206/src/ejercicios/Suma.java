/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicios;

/**
 *
 * @author ilarr
 */
public class Suma extends Ejercicio{
    public Suma() {
        super();
        res = num1+num2;
    }
    
    @Override
    public String toString() {
        return num1+"+"+num2+"=";
    }  
}
