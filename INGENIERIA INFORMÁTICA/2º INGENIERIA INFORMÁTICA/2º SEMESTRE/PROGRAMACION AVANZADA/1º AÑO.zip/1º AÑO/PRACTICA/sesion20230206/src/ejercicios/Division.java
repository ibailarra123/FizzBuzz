/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicios;

import java.util.Scanner;

public class Division extends Ejercicio{
    
    private int resto;
    private int resResto;
    
    public Division() {
        super();
        res = num1/num2;
        resResto = num1 % num2;
    }
    
    @Override
    public String toString() {
        return num1+"/"+num2+"=";
    }
    
    @Override
    public void resolver(){
        super.resolver();
        Scanner sc = new Scanner(System.in);
        System.out.println("Dame el resto: ");
        resto=sc.nextInt();
    }
    
    @Override
    public boolean isCorrect(){
        if(super.isCorrect()){
            return (resResto == resto);
        }
        return super.isCorrect();
    }
}
