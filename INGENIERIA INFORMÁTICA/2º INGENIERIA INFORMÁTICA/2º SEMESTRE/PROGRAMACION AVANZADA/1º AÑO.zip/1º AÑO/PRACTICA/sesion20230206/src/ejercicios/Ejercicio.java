/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejercicios;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author ilarr
 */
public abstract class Ejercicio {
    protected int num1;
    protected int num2;
    protected int resultado;
    protected boolean resuelto;
    protected int res;
    
    private int resto;
    private int resResto;
    
    public Ejercicio() {
        Random r = new Random();
        num1 = r.nextInt(1000);
        num2 = r.nextInt(1000);
        resuelto = false;
    }
    
    public void resolver(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Tu respuesta: ");
        resultado=sc.nextInt();
        resuelto = true;
    }
    
    public boolean isCorrect(){
        if(resuelto){
            if(res==resultado){
                return true;
            }else{
                return false;
            }
        }
        return false;
    }
}
