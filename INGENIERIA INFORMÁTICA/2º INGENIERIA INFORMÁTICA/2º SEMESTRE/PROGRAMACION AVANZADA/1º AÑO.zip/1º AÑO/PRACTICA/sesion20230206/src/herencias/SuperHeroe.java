/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herencias;

/**
 *
 * @author ilarr
 */
public class SuperHeroe extends Persona{
    public SuperHeroe(float velocidad, int hp, int altura, String nombre, int posicion, String apellido) {
        super(velocidad, hp, altura, nombre, posicion, apellido);
    }
    
    
    @Override
    public void mover(){
        //posicion+=velocidad*2;
        for(int i=0;i<2;i++){
            super.mover();
        }
    }
}
