/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herencias;

/**
 *
 * @author ilarr
 */
public class Kriptoniano extends SuperHeroe{
    
    public Kriptoniano(float velocidad, int hp, int altura, String nombre, int posicion, String apellido) {
        super(velocidad, hp, altura, nombre, posicion, apellido);
    }
    
    public void volar(){
    
    }
    
}
