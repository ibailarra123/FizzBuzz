/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicios;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 *
 * @author ilarr
 */
public class GeneradorEjercicios {

    

    public static void main(String args[]){
        int puntuacion=0;
        
        Random r = new Random();
        
        List<Ejercicio> ejercicios = new ArrayList<>();
        // instanciamos
        for(int i =0;i<10;i++){
            switch(r.nextInt(4)){
                case 0 -> ejercicios.add(new Suma());
                case 1 -> ejercicios.add(new Resta());
                case 2 -> ejercicios.add(new Multiplicacion());
                case 3 -> ejercicios.add(new Division());
                  
            }
        }
        // resolver
        for(Ejercicio ej: ejercicios){
            System.out.println(ej);
            if(ej.isCorrect()){
                puntuacion++;
            }
        }
        
        //puntuacion
        System.out.println("Tu puntuacion es "+puntuacion+"/10");
    }
    
}

    
