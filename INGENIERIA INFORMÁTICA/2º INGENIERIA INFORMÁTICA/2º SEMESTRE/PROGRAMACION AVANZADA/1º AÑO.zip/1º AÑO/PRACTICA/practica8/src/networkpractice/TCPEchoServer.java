package networkpractice;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.ServerSocket;
import java.net.SocketException;

public class TCPEchoServer {

    public static void main(String[] args) throws IOException{
        final int port = 12000;
        final ServerSocket serverSocket = new ServerSocket(port);
        System.out.println("Started server on " + port);

        for (;;) { //we are always waiting for connections all the time
            try( Socket clientSocket = serverSocket.accept(); ){ //get one client. This call blocks until somebody tries to connect
                System.out.println("Accepted connection from "
                        + clientSocket.getInetAddress() + ":" + clientSocket.getPort());

                //get the IO streams
                final DataInputStream in = new DataInputStream(clientSocket.getInputStream());
                final DataOutputStream out = new DataOutputStream(clientSocket.getOutputStream());

                //read a line from the input and send it to the output in mayus
                for (String line; (line = in.readUTF()) != null;) {
                    out.writeUTF(line.toUpperCase());
                }
                
            }catch (SocketException se){
                System.out.println("Connection lost: " + se.getMessage());
            }
        }
        
    }
}