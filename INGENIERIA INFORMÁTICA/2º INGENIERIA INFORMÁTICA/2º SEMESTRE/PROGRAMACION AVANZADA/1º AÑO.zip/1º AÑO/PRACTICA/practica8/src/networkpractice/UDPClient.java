package networkpractice;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;

public class UDPClient {

    public static void main(String[] args) throws Exception {
        final Scanner scanner = new Scanner(System.in);
        
        final int port = 12000;
        final InetAddress ipAddress = InetAddress.getByName("localhost"); //or 127.0.0.1
        
        final DatagramSocket clientSocket = new DatagramSocket();
        final byte[] buffer = new byte[1024];
        
        for(;;){
            System.out.print("Enter message: ");
            String msg = scanner.nextLine();
            if(msg.isEmpty())
                break;
            
            final byte[] sendData = msg.getBytes();
            final DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, ipAddress, port);
            clientSocket.send(sendPacket);

            DatagramPacket recvPacket = new DatagramPacket(buffer, buffer.length);
            clientSocket.receive(recvPacket);
            final String recvString = new String( recvPacket.getData(), 0, recvPacket.getLength() );
            System.out.println("From Server : " + recvString);
        }
    }
}
