package networkpractice;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

public class UDPEchoServer {
    static final int BUFFER_SIZE = 1024;
    
    public static void main(String[] args) throws IOException {
        final int port = 12000;
        
        final DatagramSocket sock = new DatagramSocket(port);
        DatagramPacket recvMsg = new DatagramPacket(new byte[BUFFER_SIZE], BUFFER_SIZE);
        System.out.println("UDP Listening at port " + port);
   
        for (;;) {
            sock.receive(recvMsg);
            final String recvStr = new String( recvMsg.getData(), 0, recvMsg.getLength() );
            System.out.println("Message received from " + recvMsg.getAddress() + " port " + recvMsg.getPort() + " -> " + recvStr);
            
            //sending back the message to the original sender but with the message in upper case
            final byte[] strB = recvStr.toUpperCase().getBytes();
            final DatagramPacket response = new DatagramPacket(strB, strB.length, recvMsg.getAddress(), recvMsg.getPort());
            sock.send( response );
        }
    }
 
}
