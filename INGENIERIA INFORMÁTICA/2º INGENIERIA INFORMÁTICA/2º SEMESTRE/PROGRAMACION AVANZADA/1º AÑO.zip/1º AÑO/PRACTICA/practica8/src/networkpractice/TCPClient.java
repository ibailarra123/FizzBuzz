package networkpractice;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

public class TCPClient {

    public static void main(String[] args) throws IOException {
        final String hostAddr = "127.0.0.1";
        final int port = 12000;
        final Scanner scanner = new Scanner(System.in);
        final Socket socket = new Socket(hostAddr, port);

        System.out.println("Socket connected to " + socket.getInetAddress() + ":" + socket.getPort());
        
        final DataInputStream in = new DataInputStream(socket.getInputStream());
        final DataOutputStream out = new DataOutputStream(socket.getOutputStream());
        System.out.println("Type empty line for just receiving, exit for finishing the app");
        
        for(;;){
            System.out.print("Enter message: ");
            String msg = scanner.nextLine();
            if(msg.equalsIgnoreCase("exit"))
                break;
            
            if (! msg.isEmpty()){ //we want to send
                out.writeUTF(msg); 
                out.flush(); //flush forces to send everything that may be in the buffer
            }else if(in.available() <= 0){ //we want to explicitly recv a message
                System.out.println("Nothing to recv");
                continue;
            }
            
            String recv = in.readUTF(); //this call will be blocked until something arrives
            System.out.println("Recv: " + recv);
        }

    }
}
