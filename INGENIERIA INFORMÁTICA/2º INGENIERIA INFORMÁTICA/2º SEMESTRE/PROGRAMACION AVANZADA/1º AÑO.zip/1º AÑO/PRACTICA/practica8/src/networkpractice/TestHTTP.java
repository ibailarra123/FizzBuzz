package networkpractice;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

public class TestHTTP {
    public static void main(String[] args) throws MalformedURLException, IOException {
        String address = "https://developers.google.com/custom-search/?q=";
	String query = "java tutorial";
	String charset = "UTF-8";
 
	URL url = new URL(address + URLEncoder.encode(query, charset));
 
        try (BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()))) {
            for (String str; (str = in.readLine()) != null;) {
                System.out.println(str);
            }
        }
    }
}