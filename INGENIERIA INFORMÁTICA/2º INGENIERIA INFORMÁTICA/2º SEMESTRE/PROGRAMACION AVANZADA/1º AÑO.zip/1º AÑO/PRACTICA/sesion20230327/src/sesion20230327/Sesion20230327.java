/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sesion20230327;

/**
 *
 * @author ilarr
 */
public class Sesion20230327 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
        
    // TODO code application logic here
        Recurso numero = new Recurso(0);
    
        MiHilo h1 = new MiHilo(numero,10000);
        MiHilo h2 = new MiHilo(numero,10000);
        
        h1.start();
        h2.start();
        
        h1.join();
        h2.join();

        System.out.println(""+numero.getNumero());
    }
    
}
