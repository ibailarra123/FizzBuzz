/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sesion20230327;

/**
 *
 * @author ilarr
 */
public class MiHilo extends Thread{
    
    int numSuma;
    Recurso numero;

    public MiHilo(Recurso numero, int numSuma) {
        this.numero = numero;
        this.numSuma = numSuma;
    }
    
    @Override
    public void run() {
        for(int i = 0;i<numSuma;i++){
            numero.setNumero(numero.getNumero()+1);
        }
    }
    
    
    
}
