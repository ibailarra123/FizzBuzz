/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica6;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ilarr
 */
public class Ej3 {
    
    List<Long> lista = new ArrayList<Long>();
    
    public static void main(String[] args) {
        Ej3 ej3 = new Ej3();
        ej3.init();
    }

    private void init() {
        
        int nucleos = Runtime.getRuntime().availableProcessors()-1;
        if(nucleos < 1)
            nucleos = 1;
        
        PrimeCalculator calculator;
        for (int i = 0; i <nucleos;i++){
            calculator = new PrimeCalculator(lista);
            calculator.start();
        }
        PrimeAverager mediador = new PrimeAverager(lista);
        mediador.start();
    }
    
}
