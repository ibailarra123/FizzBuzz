/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica6;

import static java.lang.Thread.interrupted;
import static java.lang.Thread.sleep;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ilarr
 */
public class PrimeAverager extends Thread{
    
    List<Long> lista;

    public PrimeAverager(List<Long> lista) {
        this.lista = lista;
    }
    
    @Override
    public void run(){
        while(!interrupted()){
            
            long suma = 0;
            for (int i = 0; i < lista.size();i++){
                suma+=lista.get(i);
                /*
                try {
                    sleep(1000);
                }catch (InterruptedException ex) {
                    Logger.getLogger(PrimeAverager.class.getName()).log(Level.SEVERE, null, ex);
                }
                */
            }
            System.out.println(suma/lista.size());
        }
    }
    
}
