==============================================================================================
                                    README - Oso v1.0
==============================================================================================

Autor: Ibai Larralde Baldanta
Versión: 1.0

==============================================================================================
                                    Resumen del Programa
==============================================================================================

Oso es una aplicación cliente-servidor que permite jugar al juego del oso, en el que 
dos  jugadores juegan en un tablero de 10x10 para conseguir completar el máxmimo número de 
palabras "oso" y poder  vencer. Para ello se va a establecer un servidor para el juego y otro 
para que puedan comunicarse los jugadores, de esta manera los jugadores podrán jugar de manera 
online estando conectados. 
La aplicación se divide en dos partes principales: el cliente y el servidor.
El servidor es la parte que se encarga de gestionar las solicitudes del cliente y procesarlas. 
Es responsable de crear dos servidores, uno para el propio 
juego(ServidorJuego) y otro para el chat por el que se van a comunicar los 
jugadores(ServidorChat), cada uno con un puerto distinto, por tanto ambos son completamente
independientes.
El servidor del chat lo que hace es aceptar dos clientes(Jugadores), y cuando uno de ellos
mande un mensaje, lo recibirán todos los demás clientes, puedindo ellos también enviar 
mensajes.
En cuanto al servidor del juego, de lo que se encarga es de crear una nueva partida y aceptar
dos clientes, con forme los dos jugadores vayan jugando, el servidor se encargará de 
transmitir los movimientos de un jugador a otro para que sepan en todo momento como transcurre
la partida. Una vez acaba la partida, muestra a todos los jugadores quien ha sido el ganador
y guarda el nombre del ganador en un fichero de texto.

Por otro lado, el cliente es la interfaz de usuario que permite a los usuarios interactuar con 
el programa. Proporciona una serie de opciones y funcionalidades para, que un jugador pueda 
conectarse a la partida. Lo que hace es crear un menú para que un clienteintroduzca los 
puertos del servidor de juego y del servidor de chat que quiere, además de un nombre. Una vez 
introducidos, se crea un jugador con estos datos, puediendo conectarse tanto 
al servidor de Juego como al servidor de Chat, y comienza un a comunicación con ambos
servidores. 
El clientee tiene además un tablero donde puede ver en todo momento como
está funcionando la partida. En este tablero, los jugadores van a poder poder jugar e
intercambiar mensajes y una vez finalizada la partida verán quien ha sido el ganador. 



==============================================================================================
                                Ejecución del Programa
==============================================================================================

Para ejecutar el programa, sigue los siguientes pasos:

1. Ejecuta el ejecutable del servidor(MainServidor). Se crearan dos servidores, uno para el 
   juego(puerto: 12.001) y otro para el chat(puerto: 12.000). Al ejecutarlo correctamente,
   aparecera el siguiente mensaje por consola:
        "Sevidor de Chat iniciado en el puerto 12000"
        "Sevidor de Juego iniciado en el puerto 12001"

2. Con el servidor en funcionamiento, se deben crear dos clientes. Para ello se ejecuta el
   ejecutable del cliente(MainCliente). Si se ha ejecutado correctamente aparecerá un menú en 
   pantalla con las siguientes opciones:
        - Crear partida(deshabilitado)
        - Configuración
        - Puntuación
        - Salir
    
    2.1 En caso de querer salir, se pulsa el botón "Salir" y se cierra menú y se para la 
        ejecución del cliente.
    
    2.2 En caso de querer ver la puntuación de todas las partidas, se pulsa el botón 
    "Puntuación" obteniendo así una pantalla onde cada fila indica el nombre del 
    jugador("JugadorXX") seguido de dos puntos(:) y el número de partidas que ha ganado. En 
    caso de ser la primera partida, se muestra el siguiente mensaje: 
    "No existe registro previo de partidas". Para salir se pulsa el boton "SALIR".

    2.3 En caso de querer jugar una partida, primero se debe completar la configuración. Para
        ello se pulsa el botón "Configuración" y tan solo se debe introducir un nombre, ya que
        los campos de nombre y puerto tanto para el servidor del chat como para el servidor
        del juego ya aparecen predeterminados en "localhost" y "12001" para el chat y en 
        "localhost" y "12000" para el juego. En caso de que se quisiera jugar en un servidor 
        con distinto puerto se puede introducir uno nuevo. Una vez introducidos los datos, si
        se quisiera salir de la pantalla "Configuración" se pulsa el botón "SALIR" y se vuelve 
        al menú. Pero si se quisiera guardar la configuración, se pulsa el boton "GUARDAR" y 
        se vuelve al menú pero esta vez con el boton "Crear Partida" habilitado.

    2.4 Para unirse a una partida se pulsa el botón "Crear Partida" desapareciendo así el menú
        y apareciendo una pantalla con un tablero 10x10 botones además de una pantalla donde 
        aparecen los mensajes enviados del chat, un rectángulo de texto debajo para poder 
        escribir un mensaje y enviarlo pulsando el boton "ENVIAR" y por útlimo, el nombre del
        jugador y su puntuación de la partida y el nombre del jugador rival y su puntuación en
        la partida.

3. Para poder empezar la partida se deben conectar 2 clientes. Una vez conectados, puede 
   empezar a jugar cualquiera de los 2 jugadores, el primero que haga el primer movimiento, 
   será el que inicie la partida. Para poder hacer un movimiento, el jugador debe pulsar uno
   de los 100 botones que existen en el tablero, y una vez pusado se abrirá una pequeña 
   ventana con dos botones, "s" o "o", y se selecciona la letra que se quiera poner en esa 
   posición.

4. Una vez puesta la letra, se deshabilitarán los botones para no poder poner otra letra y 
   será el turno del rival, al que se le habilitarán los botones. Se repetirá esto hasta 
   completar todo el tablero. Si se intenta poner una letra donde ya hay otra puesta, 
   aparecerá un mensaje de error en el chat y pasará el turno al rival.

5. Una vez se haya acabado la partida, se deshabilitaran los botones a los dos jugadores y se 
   mostrará en el chat el ganador de la partida. Para poder salir se pulsa el boton "SALIR".



==============================================================================================
                        Apartados Desarrollados y Sin Desarrollar
==============================================================================================

Los siguientes apartados han sido desarrollados en la versión actual del programa:

- Apartado 1: 
        - Clases y métodos para implementar el juego del “OSO".
        - Clases y métodos para implementar las comunicaciones para el juego.
        - Interfaz gráfica de usuario (GUI) para el tablero de juego.
        *Todo explicado en la ejecución del programa

- Apartado 2: Creación de clases y métodos de un chat independiente para permitir la 
              comunicación entre los jugadores. Los mensajes escritos y enviados aparecerán en
              el chat con el formato: "NombreJugador: mensaje".

- Apartado 3: Unificación del chat y la interfaz gráfica del tablero con el chat de 
              comunicación.

- Apartado 4: Generar el menú principal que creará las conexiones y gestionará el juego.
              *Comentado en la ejecución del programa.

- Apartado 5: Registro general de victorias almacenado en el servidor
              *Comentado en la ejecución del programa
              
              Creación de ficheros jar. Ubicados en la carpeta del proyecto "oso", posibilita 
              la opción de ejecutar el programa desde la terminal.


Los siguientes apartados están sin desarrollar y se consideran para futuras versiones:

- Apartado 6: Modificación del servidor para aceptar infinitos usuarios en partidas de 2 
              jugadores. Por ejemplo, si se conectan 3 jugadores al servidor, el servidor 
              creará 2 partidas independientes, la primera con 2 jugadores y la segunda con 1.

==============================================================================================


