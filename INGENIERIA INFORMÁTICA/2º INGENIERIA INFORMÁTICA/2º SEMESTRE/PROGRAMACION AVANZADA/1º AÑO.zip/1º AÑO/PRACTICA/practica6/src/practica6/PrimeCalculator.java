/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica6;

import java.util.List;

/**
 *
 * @author ilarr
 */
public class PrimeCalculator extends Thread{
    
    List<Long> lista;
    
     public PrimeCalculator(List<Long> lista) {
        this.lista = lista;
    }
    
    @Override
    public void run(){
        while(!interrupted()){
            long valor = (long)(Math.random() * (299792459-0))+0;
            
            if (isPrime(valor)){
                lista.add(valor);
            }
        }
    }
    
    public static boolean isPrime(final long n){
        if ( n < 2 || n % 2 == 0) return false;
        for (int i = 3, ii = 9; ii <= n; i+=2, ii+=(i+1)*4)
            if (n % i == 0) return false;
        return true;
    }

    
}
