/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica6;

import java.util.List;

/**
 *
 * @author ilarr
 */
public class PrimeNumberCalculator extends Thread{
    List<Long> lista;
    
     public PrimeNumberCalculator(List<Long> lista) {
        this.lista = lista;
    }
    
    @Override
    public void run(){
        while(lista.isEmpty()){
            long valor = (long)(Math.random() * (200000000-100000000))+100000000;
            
            if (isPrime(valor)){
                lista.add(valor);
            }
        }
    }
    
    public static boolean isPrime(final long n){
        if ( n < 2 || n % 2 == 0) return false;
        for (int i = 3, ii = 9; ii <= n; i+=2, ii+=(i+1)*4)
            if (n % i == 0) return false;
        return true;
    }
    
}
