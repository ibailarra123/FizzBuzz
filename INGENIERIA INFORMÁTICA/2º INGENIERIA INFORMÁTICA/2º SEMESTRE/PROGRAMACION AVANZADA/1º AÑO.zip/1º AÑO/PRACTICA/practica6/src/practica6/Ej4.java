/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica6;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ilarr
 */
public class Ej4 {
    public static void main(String[] args) throws InterruptedException {
        List<Long> lista = new ArrayList<Long>();
        PrimeNumberCalculator pnc = new PrimeNumberCalculator(lista);
        PrimeNumberCalculator pnc2 = new PrimeNumberCalculator(lista);
        
        pnc.run();
        pnc2.run();
        
        pnc.join();
        pnc2.join();
        
        System.out.println(pnc.lista.get(0));
        System.out.println(pnc2.lista.get(0));
        
    }
    
}
