/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logicajuego;

/**
 *
 * @author unai.perez
 */
public class JugadaInvalidaException extends Exception{

    public JugadaInvalidaException() {
    }

    public JugadaInvalidaException(String message) {
        super(message);
    }

}
