/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package logicajuego;

/**
 *
 * @author unai.perez
 */
public class Jugada {
    public static final String MSG_GAME_JUGADA = "/GM/";
    public static final String MSG_SEP = ":";
    
    private int x;
    private int y;
    private String letra;
    private int numJugador;

    
    public Jugada(int x, int y, String letra) {
        this.x = x;
        this.y = y;
        this.letra = letra;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public String getLetra() {
        return letra;
    }

    
    public int getNumJugador() {
        return numJugador;
    }
    public void setNumJugador(int numJugador) {
        this.numJugador =numJugador;
    }
    
    @Override
    public String toString() {
        return MSG_GAME_JUGADA+x+MSG_SEP+y+MSG_SEP+letra;
    }
    
    public static Jugada decodeJugada(String msg){
        if(!msg.startsWith(MSG_GAME_JUGADA))
            return null;
        msg=msg.replaceAll(MSG_GAME_JUGADA, "");
        String[] values=msg.split(MSG_SEP);
        System.out.println("decodeJugada"+msg);
        return new Jugada(Integer.valueOf(values[0]),Integer.valueOf(values[1]),values[2]);
    }



}
