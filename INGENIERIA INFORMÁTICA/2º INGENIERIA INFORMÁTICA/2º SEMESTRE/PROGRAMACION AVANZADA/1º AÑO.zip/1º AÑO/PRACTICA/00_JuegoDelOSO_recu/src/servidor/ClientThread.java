package servidor;

import comunicaciones.Connection;
import logicajuego.Jugada;
import java.io.IOException;
import java.net.Socket;
import java.util.List;
import logicajuego.JuegoOSO;
import logicajuego.JugadaInvalidaException;
import logicajuego.JugadorNoPermitidoException;


public class ClientThread extends Thread {

    List<ClientThread> clients;
    Connection con;
    JuegoOSO juego;
    String nombre;
    int numJugador;
    int puntos=0;
    
    public ClientThread(Socket socket, int num) throws IOException {
        con = new Connection(socket);
        nombre = "Invitado " + num;
        clients=null;
    }
    
    public ClientThread(List<ClientThread> clients, Socket socket, int num, int numJugador) throws IOException {
        this.clients = clients;
        con = new Connection(socket);
        nombre = "Invitado " + num;
        this.numJugador=numJugador;
    }

    public void setJuego(JuegoOSO juego) {
        this.juego = juego;
    }

    public void setClients(List<ClientThread> clients) {
        this.clients = clients;
    }
    
    public int getNumJugador() {
        return numJugador;
    }

    public void setNumJugador(int numJugador) {
        this.numJugador = numJugador;
    }

    public int getPuntos() {
        return puntos;
    }

    public String getNombre() {
        return nombre;
    }
    
    public void sendMsg(String msg){
        con.enviarMsg(msg);
    }
    public String recibirMsg(){
        return con.recibirMsg();
    }

    @Override
    public void run() {
        try {
            for (String line; (line = con.recibirMsg()) != null;) {
                if (line.startsWith(Connection.MSG_CHAT_HEAD)) {
                    line = line.replaceAll(Connection.MSG_CHAT_HEAD, "");
                    line = Connection.MSG_CHAT_HEAD+nombre+": "+line;
                }else if(line.startsWith(Jugada.MSG_GAME_JUGADA)){
                    Jugada j = Jugada.decodeJugada(line);
                    j.setNumJugador(numJugador);
                    try{
                        puntos += juego.anadirJugada(j);
                        synchronized (clients) { 
                            clients.forEach(c -> c.sendMsg(Jugada.MSG_GAME_JUGADA+juego.estadoJuego()));
                        }
                        
                        line=JuegoOSO.MSG_GAME_PUNTOS;
                        synchronized(clients) {
                            for (ClientThread c : clients) {
                                line+=c.getNombre()+":"+c.getPuntos()+";";
                            }
                        }
                        
                    }catch(JugadaInvalidaException juex){
                        line=null;
                        con.enviarMsg(Connection.MSG_CHAT_HEAD+"Sistema: "+juex.getMessage());
                    }catch(JugadorNoPermitidoException jnpex){
                        line=null;
                        con.enviarMsg(Connection.MSG_CHAT_HEAD+"Sistema: "+jnpex.getMessage());
                    }                    
                }else if(line.startsWith(JuegoOSO.OSO_EMPIEZA_JUEGO)){
                    line=Jugada.MSG_GAME_JUGADA+juego.estadoJuego();
                }
                
                String response = line;
                if(response!=null){
                    synchronized (clients) { 
                        clients.forEach(c -> c.sendMsg(response));
                    }
                }
                if(juego.finDeJuego()){
                    synchronized (clients) { 
                        clients.forEach(c -> c.sendMsg(Connection.MSG_CHAT_HEAD+"Fin del juego."));
                    }
                    break;
                }
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally { 
            con.desconectar();
            synchronized (clients) {
                clients.remove(this);
            }
        }
    }
}
