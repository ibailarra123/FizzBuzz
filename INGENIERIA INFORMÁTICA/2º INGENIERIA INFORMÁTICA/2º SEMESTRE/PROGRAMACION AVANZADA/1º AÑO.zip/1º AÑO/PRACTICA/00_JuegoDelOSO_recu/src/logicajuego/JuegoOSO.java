package logicajuego;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import servidor.ClientThread;

public class JuegoOSO {

    public static String OSO_EMPIEZA_JUEGO = "/GME/";
    public static String MSG_GAME_PUNTOS ="/GMUP/";
    public static String DIMENSION_JUEGO="/GMD/";
    public static String ELIGE_DIMENSION="/GMED/";
    public static int CLIENTE_ADDICIONAL_DENEGADO=0;
    public static int CLIENTE_ADDICIONAL_ACEPTADO=1;
    public static int NUMERO_USUARIOS_COMPLETO=2;
    
    private TableroArray tablero;
    private int turno,dimensionJuego;
    private int numeroJugadores;

    List<ClientThread> clients;
    public JuegoOSO() {
        clients = new LinkedList<>();
    }
    
    public JuegoOSO(int dim,int numeroJugadores) {
        crearTablero(dim);
        this.numeroJugadores=numeroJugadores;
        clients = new LinkedList<>();
    }
    
    public void crearTablero(){
        crearTablero(10);
    }
    public void crearTablero(int dim){
        crearTablero(dim,dim);
    }
    public void crearTablero(int x, int y){
        tablero = new TableroArray(x,y);
        tablero.fillArray(true);
        turno = 1;
    }
    
    public int anadirCliente(ClientThread clientThread) throws IOException{
        if(clients.size()<numeroJugadores| numeroJugadores==0){
            clientThread.setNumJugador(clients.size()+1);
            clientThread.setClients(clients);
            synchronized (clients) {
                clients.add(clientThread);
            }
            
            if(clients.size()==1){
                clientThread.sendMsg(JuegoOSO.ELIGE_DIMENSION);
                String msg=clientThread.recibirMsg();
                String[] data = msg.replaceAll(JuegoOSO.DIMENSION_JUEGO, "").split(";");
                dimensionJuego=Integer.valueOf(data[0]);
                crearTablero(dimensionJuego);
                numeroJugadores=Integer.valueOf(data[1]);
            
            }else if(clients.size()==numeroJugadores){
                    synchronized (clients) { 
                        clients.forEach(c -> c.sendMsg(JuegoOSO.DIMENSION_JUEGO+dimensionJuego));
                        clients.forEach(c -> c.sendMsg(JuegoOSO.OSO_EMPIEZA_JUEGO+c.getNumJugador()));
                    }
            }
            clientThread.setJuego(this);
            clientThread.start();
            if(clients.size()==numeroJugadores){
                return NUMERO_USUARIOS_COMPLETO;
            }
            return CLIENTE_ADDICIONAL_ACEPTADO;
        }else{
            return CLIENTE_ADDICIONAL_DENEGADO;
        }
    }
    
    public void setNumeroJugadores(int numeroJugadores) {
        this.numeroJugadores = numeroJugadores;
    }

    public int anadirJugada(Jugada jugada) throws JugadaInvalidaException, JugadorNoPermitidoException {
        if (turno != jugada.getNumJugador()) {
            throw new JugadorNoPermitidoException("No es tu turno.");
        }
        if (!tablero.getFicha(jugada.getX(), jugada.getY()).getLetra().equals(" ")) {
            throw new JugadaInvalidaException("Jugada Invalida.");
        }
        if(jugada.getNumJugador()>numeroJugadores){
            System.out.println(jugada.getNumJugador());
            System.out.println(numeroJugadores);
            throw new JugadorNoPermitidoException("No eres jugador de esta partida.");
        }
        
        Ficha f = tablero.getFicha(jugada.getX(), jugada.getY());
        f.setLetra(jugada.getLetra());
        f.setNumJugador(jugada.getNumJugador());
        int puntos = checkJugada(jugada.getX(), jugada.getY());
        
        if(puntos==0){
           turno++;
        }
           
        if(turno>numeroJugadores){
            turno=1;
        }
        return puntos;
    }

    public int checkJugada(int posX, int posY) {
        Ficha subset[][] = tablero.getSubMatrix(posX, posY);
        int puntos = 0;
        int subYPosition=posY;
        int subXPosition=posX;
        if(subYPosition>2){
            subYPosition=2;
        }
        if(subXPosition>2){
            subXPosition=2;
        }
        
        String aux="";
        for(int i=0; i<subset.length;i++){
            aux+=subset[i][subYPosition].getLetra();
        }

        puntos+=checkStringOSO(aux);
        aux="";
        for(int i=0; i<subset[0].length;i++){
            aux+=subset[subXPosition][i].getLetra();
        }
        puntos+=checkStringOSO(aux);
        aux="";
        
        if(subset.length>=3&&subset[0].length>=3){
            aux="";
            int diag = subset[0].length>subset.length?subset.length:subset[0].length;
            for(int i=0; i<diag;i++){
                aux+=subset[i][i].getLetra();
            }
            puntos+=checkStringOSO(aux);
        }
        
        if(subset.length>=3&&subset[0].length>=3){
            aux="";
            int diag = subset[0].length>subset.length?subset.length:subset[0].length;
            for(int i=0; i<diag;i++){
                aux+=subset[i][diag-(i+1)].getLetra();
            }
            puntos+=checkStringOSO(aux);
        }
        
        return puntos;
    }
    
    public static int checkStringOSO(String word){
        int puntos=0;
        for(int i=1;i<word.length()-1;i++){
            if(word.subSequence(i-1, i+2).equals("OSO")){
                puntos++;
            }
        }
        return puntos;
    }
    
    public String estadoJuego(){
        return turno+";"+tablero.estadoTablero();
    }
    
    public boolean finDeJuego(){
        return !tablero.emptyPosition();
    }
}
