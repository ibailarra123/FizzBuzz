package logicajuego;

public class TableroArray {
    private Ficha tablero[][];
    
    public TableroArray(int dim) {
        tablero =  new Ficha[dim][dim];
    }
    
    public TableroArray(int dimX, int dimY) {
        tablero =  new Ficha[dimX][dimY];
    }
    
    public void fillArray(boolean fillEmpty){
        int z=0;
        for (Ficha[] tablero1 : tablero) {
            for (int y = 0; y < tablero1.length; y++) {
                if(fillEmpty){
                    tablero1[y] = new Ficha(0," ");
                }else{
                    tablero1[y] = new Ficha(z," ");
                }
                z++;
            }
        }
    }
    
    public Ficha getFicha(int posX, int posY){
        return tablero[posX][posY];
    }
    
    public void setFicha(int posX, int posY, Ficha ficha){
        tablero[posX][posY]=ficha;
    }
    
    public Ficha[][] getSubMatrix(int posX, int posY){
        int minX = posX-2;
        int maxX = posX+2;
        int minY = posY-2;
        int maxY = posY+2;
        
        minX=minX<0?0:minX;
        minY=minY<0?0:minY;
        
        maxX=maxX>=dimension()[0]?(dimension()[0])-1:maxX;
        maxY=maxY>=dimension()[1]?(dimension()[1])-1:maxY;

        int subsetX=maxX-minX;
        int subsetY=maxY-minY;
        
        Ficha subMatrix[][] = new Ficha[subsetX+1][subsetY+1];
        int subX=0;
        for(int x=minX;x<=maxX;x++){
            int subY=0;
            for(int y=minY;y<=maxY;y++){
                subMatrix[subX][subY] = tablero[x][y];
                subY++;
            }
            subX++;
        }
        return subMatrix;
    }
    
    public int[] dimension(){
        int[] dim = new int[2];
        if (tablero!=null){
            dim [0] = tablero.length;
            dim [1] = tablero[0].length;
            return dim;
        }
        return null;
    }
    
    public static void printMatrix(Ficha[][] matrix){
        for (Ficha[] matrix1 : matrix) {
            String text="";
            for (Ficha y : matrix1) {
                text += "-" + y.getLetra();
            }
            System.out.println(text);
        }
    }

    public boolean emptyPosition() {
        for (Ficha[] tablero1 : tablero) {
            for (int y = 0; y < tablero1.length; y++) {
                if(tablero1[y].getLetra()==" ")
                    return true;
            }
        }
        return false;
    }
    
    public String estadoTablero(){
        String estado="";
        for (int x=0;x< tablero.length;x++) {
            for (int y=0;y< tablero[x].length;y++) {
                if(tablero[x][y].getLetra()!=" ")
                    estado += +x+"-"+y + ":"+tablero[x][y].getLetra()+";";
            }
        }
        return estado;
    }
}
