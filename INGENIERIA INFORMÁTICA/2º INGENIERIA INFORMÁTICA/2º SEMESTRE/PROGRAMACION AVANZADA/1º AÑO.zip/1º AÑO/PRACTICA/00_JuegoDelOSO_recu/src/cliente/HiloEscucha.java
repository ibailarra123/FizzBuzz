package cliente;

import javax.swing.JTextArea;
import comunicaciones.Connection;
import java.util.HashMap;
import javax.swing.JButton;
import javax.swing.JList;
import logicajuego.JuegoOSO;
import logicajuego.Jugada;

public class HiloEscucha implements Runnable {

    private Connection con;
    private JTextArea conversacion;
    private HashMap<String, JButton> botones;
    private int numJugador = -1;
    private JList<String> marcador;
    private Cliente clienteTablero;

    public HiloEscucha(Connection con, JTextArea conversacion, HashMap<String, JButton> botones, JList<String> marcador,Cliente clienteTablero) {
        this.con = con;
        this.conversacion = conversacion;
        this.botones = botones;
        this.marcador = marcador;
        this.clienteTablero=clienteTablero;
    }

    private void controlBotones(HashMap<String, String> usedButtons, boolean desactivar) {
        for (String pos : botones.keySet()) {
            if (!usedButtons.containsKey(pos)) {
                botones.get(pos).setEnabled(!desactivar);
            } else {
                botones.get(pos).setText(usedButtons.get(pos));
                botones.get(pos).setEnabled(false);
            }
        }
    }

    @Override
    public void run() {
        controlBotones(new HashMap<String, String>(), true);
        
        for (;;) {
            String line = con.recibirMsg();
            if (line.startsWith(Connection.MSG_CHAT_HEAD)) {
                line = line.replaceAll(Connection.MSG_CHAT_HEAD, "");
                conversacion.setText(conversacion.getText() + line+"\n");
            } else if (line.startsWith(Jugada.MSG_GAME_JUGADA)) {
                line = line.replaceAll(Jugada.MSG_GAME_JUGADA, "");

                String[] data = line.split(";");
                HashMap<String, String> usedButtons = new HashMap<String, String>();
                for (int i = 1; i < data.length; i++) {
                    String[] aux = data[i].split(":");
                    usedButtons.put(aux[0], aux[1]);
                }
                if (Integer.valueOf(data[0]) == numJugador) {
                    controlBotones(usedButtons, false);
                } else {
                    controlBotones(usedButtons, true);
                }
            } else if (line.startsWith(JuegoOSO.OSO_EMPIEZA_JUEGO)) {
                line = line.replaceAll(JuegoOSO.OSO_EMPIEZA_JUEGO, "");
                numJugador = Integer.valueOf(line);
                con.enviarMsg(JuegoOSO.OSO_EMPIEZA_JUEGO);
                
            } else if (line.startsWith(JuegoOSO.MSG_GAME_PUNTOS)) {//ej 1
                line = line.replaceAll(JuegoOSO.MSG_GAME_PUNTOS, "");
                String[] data = line.split(";");
                marcador.setListData(data);
                //String[] p = data[0].split(":");
                //jugador1.setText(p[0] + ": " + p[1]);
                //p = data[1].split(":");
                //jugador2.setText(p[0] + ": " + p[1]);
            }else if (line.startsWith(JuegoOSO.DIMENSION_JUEGO)) {//ej 2
                line = line.replaceAll(JuegoOSO.DIMENSION_JUEGO, "");
                clienteTablero.crearPanelJuego(Integer.valueOf(line));
            }else if (line.startsWith(JuegoOSO.ELIGE_DIMENSION)) {//ej 3 y 4
                line = line.replaceAll(JuegoOSO.ELIGE_DIMENSION, "");
                PartidaTamano jsd = new PartidaTamano(clienteTablero,true);
                jsd.setVisible(true);
                int dimension = jsd.getDimension();
                int numJugadores = jsd.getNumUsuarios();
                jsd.dispose();
                con.enviarMsg(JuegoOSO.DIMENSION_JUEGO+dimension+";"+numJugadores);
            }

        }
    }

}
