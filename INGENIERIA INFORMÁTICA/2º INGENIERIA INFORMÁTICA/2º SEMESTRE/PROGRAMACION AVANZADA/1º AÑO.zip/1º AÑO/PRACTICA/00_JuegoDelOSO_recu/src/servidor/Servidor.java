package servidor;

import static java.lang.Thread.interrupted;
import java.net.ServerSocket;
import java.net.Socket;
import logicajuego.JuegoOSO;

public class Servidor extends Thread{
    final int port;
    
    public Servidor(int port) {
        this.port = port;
    }

    @Override
    public void run(){
        try( ServerSocket serverSocket = new ServerSocket(port); ){
            System.out.println("Started server on port " + port);
            int numJugador=1;
            JuegoOSO juego=new JuegoOSO();
            
            while(! interrupted() ){
                Socket clientSocket = serverSocket.accept();
                System.out.println("Conectado cliente..."+clientSocket.getPort());
                ClientThread clientThread = new ClientThread( clientSocket,numJugador);
                
                if(juego.anadirCliente(clientThread)==JuegoOSO.CLIENTE_ADDICIONAL_DENEGADO){
                    juego = new JuegoOSO();
                    juego.anadirCliente(clientThread);
                    
                }
                numJugador++;
            }
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
    
    public static void main(String[] args){
        Servidor s = new Servidor(12000);
        s.start();
    }

}
