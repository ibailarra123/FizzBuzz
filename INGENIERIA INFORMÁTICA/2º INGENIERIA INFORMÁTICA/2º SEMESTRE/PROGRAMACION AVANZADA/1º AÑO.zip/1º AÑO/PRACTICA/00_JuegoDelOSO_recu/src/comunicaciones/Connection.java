package comunicaciones;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Connection {
    public static String MSG_CHAT_HEAD = "/CH/";
    
    private Socket socket;
    private DataOutputStream out;
    private DataInputStream in;

    public Connection(Socket socket) throws IOException {
        this.socket = socket;
        System.out.println("Connection from "
                + socket.getInetAddress() + ":" + socket.getPort());
        in = new DataInputStream(socket.getInputStream());
        out = new DataOutputStream(socket.getOutputStream());
    }

    public Connection(String server, int port) throws IOException {
        this.socket = new Socket(server, port);
        System.out.println("Connection from "
                + socket.getInetAddress() + ":" + socket.getPort());
        in = new DataInputStream(socket.getInputStream());
        out = new DataOutputStream(socket.getOutputStream());
    }


    public void desconectar() {
        try {
            socket.close();
        } catch (IOException ex) {
            Logger.getLogger(Connection.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void enviarMsg(String msg) {
        try {
            out.writeUTF(msg);
        } catch (IOException ex) {
            Logger.getLogger(Connection.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public String recibirMsg() {
        try {
            return in.readUTF();
        } catch (IOException ex) {
            Logger.getLogger(Connection.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}
