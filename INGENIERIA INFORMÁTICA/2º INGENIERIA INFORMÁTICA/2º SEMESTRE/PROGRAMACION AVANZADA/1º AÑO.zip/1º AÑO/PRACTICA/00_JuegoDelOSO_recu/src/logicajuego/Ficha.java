package logicajuego;

public class Ficha {
    private int numJugador;
    private String letra;

    public Ficha(int numJugador, String letra) {
        this.numJugador = numJugador;
        this.letra = letra;
    }

    public int getNumJugador() {
        return numJugador;
    }

    public void setNumJugador(int numJugador) {
        this.numJugador = numJugador;
    }

    public String getLetra() {
        return letra;
    }

    public void setLetra(String letra) {
        this.letra = letra;
    }

    @Override
    public String toString() {
        return "Ficha:" + "Jugador=" + numJugador + " Letra=" + letra;
    }
    
    
}
