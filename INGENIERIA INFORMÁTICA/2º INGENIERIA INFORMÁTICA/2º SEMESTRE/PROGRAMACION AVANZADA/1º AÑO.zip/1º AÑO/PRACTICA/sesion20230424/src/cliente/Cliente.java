/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cliente;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import static java.lang.Thread.interrupted;
import java.net.Socket;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ilarr
 */
public class Cliente implements Runnable{
    final int port;
    final String ip;
    
    final Socket socket;
    final DataOutputStream out;
    final DataInputStream in;
    final Scanner sc = new Scanner(System.in);
    
    public Cliente() throws IOException {
        port = 5555;
        ip = "127.0.0.1";
        socket = new Socket(ip,port);
        in = new DataInputStream(socket.getInputStream());
        out = new DataOutputStream(socket.getOutputStream());
    }
    
    /*
    public Cliente(String ip, int port) {
        this.port = port;
        this.ip = ip;
    }
    */
    
    
    public void envMsg() throws IOException{
        for(;;){
            System.out.println("Escribe un mensaje: ");
            String msg = sc.nextLine();
            out.writeUTF(msg);
        }
    }
    
    
    public static void main(String[] args) throws IOException {
        
        Cliente client = new Cliente();
        Thread th = new Thread(client);
        th.start();
        client.envMsg();
        
        System.out.println("Termina...");
    }

    @Override
    public void run() {
        while(true){
            try {
                String msg = in.readUTF();
                if(msg.equals("EXIT")){
                    break;
                }
                System.out.println(msg);
         
            } catch (IOException ex) {
                Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        try {
            socket.close();
        } catch (IOException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
