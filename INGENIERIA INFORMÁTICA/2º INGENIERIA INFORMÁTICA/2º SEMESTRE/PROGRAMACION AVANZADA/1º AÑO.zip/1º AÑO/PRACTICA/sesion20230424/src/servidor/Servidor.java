/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package servidor;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author ilarr
 */
public class Servidor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, InterruptedException {
        final int port = 5555;
        final ServerSocket serverSocket= new ServerSocket(port);
        
        System.out.println("Servidor creado en el puerto: "+port);
        
        Socket clientSocket = serverSocket.accept();
        System.out.println("Conexion aceptada desde "+clientSocket.getInetAddress()+": "+clientSocket.getPort());
        
        final DataInputStream in = new DataInputStream(clientSocket.getInputStream());
        final DataOutputStream out = new DataOutputStream(clientSocket.getOutputStream());
        
        while(true){
            String message = in.readUTF();
            System.out.println(message);
            
            message = message.toUpperCase();
            out.writeUTF(message);
            if(message.equals("EXIT")){
                break;
            }
            
        }
        clientSocket.close();     
    }
    
}
