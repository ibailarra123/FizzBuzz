/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oso;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ilarr
 */
public class ServidorJuego extends Thread{
    PartidaJuego partida;
    final int puerto;
    final java.util.List<Cliente> clientes = new LinkedList<>();
    
    public ServidorJuego(int puerto){
        this.puerto = puerto;
        this.partida = new PartidaJuego();
        this.partida.iniciar();
    }
    
    @Override
    public void run(){
        try (ServerSocket serverSocket = new ServerSocket(puerto);){
            Socket clientSocket1 = serverSocket.accept();
            Cliente cliente1 = new Cliente(clientSocket1, partida,0,clientes);
            cliente1.start();
                                                                                                     
            Socket clientSocket2 = serverSocket.accept();
            Cliente cliente2 = new Cliente(clientSocket2, partida,1,clientes);
            cliente2.start();
            
        } catch (IOException ex) {
            Logger.getLogger(ServidorJuego.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public class Cliente extends Thread{
        final Socket socket;
        DataOutputStream out;
        PartidaJuego partida;
        int nClientes;
        final java.util.List<Cliente> clientes;
        
        File fPuntuacion = new File("./puntuaciones.txt");
    
        public Cliente(Socket socket, PartidaJuego partida, int nClientes, java.util.List<Cliente> clientes){
            this.socket = socket;
            this.partida = partida;
            this.nClientes = nClientes;
            this.clientes = clientes;
        
        }
        
        synchronized public void enviarMensaje(String mensaje) throws IOException{
            out.writeUTF(mensaje);
        }
        
        @Override
        public void run(){
            System.out.println("Se ha conectado " + socket.getInetAddress());

            try {
                DataInputStream in = new DataInputStream(socket.getInputStream());
                out = new DataOutputStream(socket.getOutputStream());

                synchronized(clientes){
                    clientes.add(this);
                }

                for (String mensaje; (mensaje=in.readUTF()) != null;){
                    if(mensaje.equals("SALIR")){
                        clientes.forEach(cli->{
                            try {
                                cli.enviarMensaje("SALIR");
                            } catch (IOException ex) {
                                Logger.getLogger(ServidorChat.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        });
                        break;
                    }
                    else{
                        String[] parts = mensaje.split(":");
                        String nombre = parts[0];
                        String msg = parts[1]; //El mensaje es el número de la casilla donde el jugador desea colocar la ficha
                        String letra = parts[2];
                        int puntuacion1 = Integer.parseInt(parts[3]);
                        int puntuacion2 = Integer.parseInt(parts[4]);
                        String respuestaPartida = partida.turno(letra,Integer.parseInt(msg),nombre,puntuacion1,puntuacion2);
                        String[] parts2 = respuestaPartida.split(":");
                        String respuesta = parts2[0];
                        String jugador = parts2[1];
                        int punt1 = Integer.parseInt(parts2[2]);
                        int punt2 = Integer.parseInt(parts2[3]);
                        synchronized (clientes) { 
                            clientes.forEach(cli -> {
                                try {
                                    cli.enviarMensaje(respuesta + '-' + jugador +'-'+ punt1 + '-' +punt2+ '-' + msg + '-' + letra);
                                } catch (IOException ex) {
                                    Logger.getLogger(ServidorJuego.class.getName()).log(Level.SEVERE, null, ex);
                                }
                            });
                        } //PROTOCOLO: DEVUELVO AL JUGADOR UN MENSAJE, QUÉ COLOCAR Y DONDE COLOCARLO
                        if(respuesta.equals("Final partida")){
                            escribirPuntuaciones(jugador);
                        }
                    }   
                }

            } catch (IOException ex) {
                System.exit(0);
            }
        }
        
        private void escribirPuntuaciones(String jugador) throws IOException {
            Map<String, Integer> MapaVictorias = new HashMap<>();
            
            if (fPuntuacion.createNewFile()) { //Acabo de crear el fichero
                escribeMapa(MapaVictorias,jugador);
            } else {
                //Primeo leo el fichero por si algún jugador ya había ganado
                BufferedReader br = new BufferedReader(new FileReader(fPuntuacion));
                for (String line; (line = br.readLine()) != null;){
                    String[] partes = line.split(":"); //Nombre:NumVictorias
                    MapaVictorias.put(partes[0],Integer.parseInt(partes[1]));
                }

                //Una vez leido, compruebo
                escribeMapa(MapaVictorias,jugador);
            }
        }
        
        private void escribeMapa(Map<String, Integer> MapaVictorias, String jugador) throws IOException{
            if(!MapaVictorias.containsKey(jugador)){ //Todavía no hemos jugado ni una vez
                MapaVictorias.put(jugador,0);
            }
            MapaVictorias.put(jugador, MapaVictorias.get(jugador)+1);
            BufferedWriter bw = new BufferedWriter(new FileWriter(fPuntuacion));
            for (Map.Entry<String, Integer> entry : MapaVictorias.entrySet()) {
                bw.write(entry.getKey() + ":" + entry.getValue());
                bw.newLine();
            }
            bw.flush();
        }
        
    }   
      
}
