/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oso;

import java.io.IOException;


/**
 *
 * @author ilarr
 */
public class ComunicacionChat extends Thread{
    Jugador jugador;

    public ComunicacionChat(Jugador jugador) {
        this.jugador = jugador;
    }
    
    @Override
    public void run(){
        while(true){
            String mensaje;
            
            try {
                mensaje = jugador.inChat.readUTF();
                System.out.println(mensaje);
                if(mensaje.equalsIgnoreCase("SALIR")){
                    System.exit(0);
                    break;
                }
                jugador.tablero.getChat().append(mensaje);
                
            } catch (IOException ex) {
                System.exit(0);
            }
            
        }
    }
    
}
