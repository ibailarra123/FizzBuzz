/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oso;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import static java.lang.Thread.interrupted;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ilarr
 */
public class ServidorChat extends Thread{

    final int puerto;
    final java.util.List<Cliente> clientes = new LinkedList<>();
    
    public ServidorChat(int puerto) {
        this.puerto = puerto;
    }
    
    @Override
    public void run(){
        try(ServerSocket serverSocket = new ServerSocket(puerto);) {            
            int nClientes = 0;
            while(!interrupted() && nClientes < 2){
                Socket clientSocket = serverSocket.accept();
                nClientes = nClientes +1;
                Cliente hiloCliente = new Cliente(clientes, clientSocket);
                hiloCliente.start();
            }
            
        } catch (IOException ex) {
            Logger.getLogger(ServidorChat.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public class Cliente extends Thread{
        final java.util.List<Cliente> clientes;
        final Socket socket;
        DataOutputStream out;

        public Cliente(java.util.List<Cliente> clientes, Socket socket) {
            this.clientes = clientes;
            this.socket = socket;
        }
        
        synchronized public void enviarMensaje(String mensaje) throws IOException{
            out.writeUTF(mensaje);
        }
        
        @Override
        public void run(){
            System.out.println("Se ha conectado " + socket.getInetAddress());
            
            try {
                DataInputStream in = new DataInputStream(socket.getInputStream());
                out = new DataOutputStream(socket.getOutputStream());
                
                synchronized(clientes){
                    clientes.add(this);
                }
                
                for (String mensaje; (mensaje=in.readUTF()) != null;){
                    if(mensaje.equals("SALIR")){
                        clientes.forEach(cli->{
                            try {
                                cli.enviarMensaje("SALIR");
                            } catch (IOException ex) {
                                Logger.getLogger(ServidorChat.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        });
                        break;
                    }
                    
                    String msg = mensaje;
                    synchronized(clientes){
                        clientes.forEach(cli->{
                            try {
                                cli.enviarMensaje(msg);
                            } catch (IOException ex) {
                                Logger.getLogger(ServidorChat.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        });
                    }
                }
                
            } catch (IOException ex) {
                Logger.getLogger(ServidorChat.class.getName()).log(Level.SEVERE, null, ex);
            }
            finally{
                try{ socket.close();} catch(IOException ex){}
                synchronized(clientes){
                    clientes.remove(this);
                }
            }
        }
    }
    
    
}
