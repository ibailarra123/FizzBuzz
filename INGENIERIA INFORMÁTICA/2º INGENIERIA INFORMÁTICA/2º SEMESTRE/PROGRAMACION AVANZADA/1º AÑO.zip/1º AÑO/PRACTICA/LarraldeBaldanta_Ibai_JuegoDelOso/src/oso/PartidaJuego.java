/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oso;

import java.util.Arrays;

/**
 *
 * @author ilarr
 */
public class PartidaJuego {
    private char[][] tablero;
    String jugador;

    
    public void iniciar(){
        
        tablero  = new char[14][14];
        
        for (int i = 0; i < tablero.length; i++) {
            for (int j = 0; j < tablero[i].length; j++) {
                tablero[i][j] = ' ';
            }
        }
    }
    
    synchronized public String turno(String letra, int pos, String jugador, int puntuacion1, int puntuacion2){
        this.jugador = jugador;
        String comentario = null;
        
        
        //RECONVERTIR POSICION
        pos = pos-1;
        int posicionJ = (pos % 10)+2;
        int posicionI = ((pos- (pos % 10))/10)+2;
        
                
        if(!casillaOcupada(tablero,posicionI, posicionJ)){
            if("o".equals(letra)){
                tablero[posicionI][posicionJ] = 'o';
            }
            else{
                tablero[posicionI][posicionJ] = 's';
            }
            
            puntuacion1 = puntuacion1+ cuantosPuntos(tablero,posicionI,posicionJ,letra);

            if (estaLLenoTablero(tablero)){
                comentario = "Final partida";
            }

        }
        else{
            comentario = comentarErrorCasillaOcupada();
        }
        return (comentario + ":" +this.jugador+":" + puntuacion1 + ":"+ puntuacion2);
    }
    
    private boolean casillaOcupada(char[][] tablero, int posicionI, int posicionJ){
        return('o' == tablero[posicionI][posicionJ] || 's' == tablero[posicionI][posicionJ]);
    }
    
    private boolean esTurnoCorrecto(String turnoActual, String turnoAnterior){
        return(turnoActual != turnoAnterior);
    }
    
    private int cuantosPuntos(char[][] tablero, int posicionI, int posicionJ, String letra){
        int i = posicionI;
        int j = posicionJ;
        int puntos = 0;
        if("o".equals(letra)){
            if(tablero[i-1][j] == 's' || tablero[i-1][j-1] == 's' || tablero[i-1][j+1] == 's' || tablero[i][j-1] == 's'|| tablero[i][j+1] == 's' || tablero[i+1][j-1] == 's' || tablero[i+1][j] == 's' || tablero[i+1][j+1] == 's'){
                
                if(tablero[i-1][j] == 's'){
                    
                    if(tablero[i-2][j] == 'o'){
                        puntos = puntos+1;
                    }   
                }
                if(tablero[i-1][j-1] == 's'){
                    
                    if(tablero[i-2][j-2] == 'o'){
                        puntos = puntos+1;
                    }                    
                }
                if(tablero[i-1][j+1] == 's'){
                    
                    if(tablero[i-2][j+2] == 'o'){
                        puntos = puntos+1;
                    }                    
                }
                if(tablero[i][j-1] == 's'){
                    
                    if(tablero[i][j-2] == 'o'){
                        puntos = puntos+1;
                    }                   
                }
                if(tablero[i][j+1] == 's'){
                    
                    if(tablero[i][j+2] == 'o'){
                        puntos = puntos+1;
                    }                   
                }
                if(tablero[i+1][j-1] == 's'){
                    
                    if(tablero[i+2][j-2] == 'o'){
                        puntos = puntos+1;
                    }                  
                }
                if(tablero[i+1][j] == 's'){
                    
                    if(tablero[i+2][j] == 'o'){
                        puntos = puntos+1;
                    }                  
                }
                if(tablero[i+1][j+1] == 's'){
                    
                    if(tablero[i+2][j+2] == 'o'){
                        puntos = puntos+1;
                    }                   
                }
            }
        }
        
        else{
            if(tablero[i-1][j-1] == 'o' && tablero[i+1][j+1] == 'o'){
                puntos = puntos+1;
            }
            
            if(tablero[i-1][j+1] == 'o' && tablero[i+1][j-1] == 'o'){
                puntos = puntos+1;
            }
            
            if(tablero[i-1][j] == 'o' && tablero[i+1][j] == 'o'){
                puntos = puntos+1;
            }
            
            if(tablero[i][j-1] == 'o' && tablero[i][j+1] == 'o'){
                puntos = puntos+1;
            }    
        }
        
        
        return puntos;
    }
    
    private boolean estaLLenoTablero(char[][] tablero) {
        for(int i=2; i< tablero.length-2; i++){
            for(int j=2; j< tablero[0].length-2; j++){
                if(tablero[i][j]!='o' && tablero[i][j]!='s'){
                    return false;
                }
            }
        }
        return true;
    }
    
    
    
    private String comentarErrorCasillaOcupada(){
        return("ErrorFicha");
    } 
    
}
