/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package oso;

import java.io.IOException;

/**
 *
 * @author ilarr
 */
public class MainJugador {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException{
        Menu menu = new Menu();
        java.awt.EventQueue.invokeLater(new Runnable(){
            public void run(){
                menu.setVisible(true);
            }
        });
    }
    
}
