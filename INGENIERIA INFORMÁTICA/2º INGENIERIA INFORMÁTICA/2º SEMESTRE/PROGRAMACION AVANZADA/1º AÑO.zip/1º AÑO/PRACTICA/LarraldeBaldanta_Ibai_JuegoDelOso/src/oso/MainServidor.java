/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package oso;

/**
 *
 * @author ilarr
 */
public class MainServidor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ServidorChat servidorChat = new ServidorChat(12000);
        ServidorJuego servidorJuego = new ServidorJuego(12001);
        
        System.out.println("Sevidor de Chat iniciado en el puerto 12000");
        System.out.println("Sevidor de Juego iniciado en el puerto 12001");
        
        servidorChat.start();
        servidorJuego.start();
    }
    
}
