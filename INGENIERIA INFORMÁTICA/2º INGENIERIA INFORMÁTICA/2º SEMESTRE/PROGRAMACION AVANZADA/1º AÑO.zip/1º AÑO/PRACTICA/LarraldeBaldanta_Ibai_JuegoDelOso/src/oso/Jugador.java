/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oso;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author ilarr
 */
public class Jugador {
    final Scanner scanner = new Scanner(System.in);
    
    final Socket socketChat,socketJuego;
    
    final DataInputStream inChat,inJuego;
    final DataOutputStream outChat,outJuego;
    
    TableroJuego tablero;
    Configuracion configuracion;
    String nombre;
    int puntuacion;
    
    public Jugador (Configuracion configuracion, int puntuacion) throws IOException{
        this.nombre = configuracion.nombreJugador;
        this.puntuacion = puntuacion;
        
        socketChat = new Socket(configuracion.direccionChat,configuracion.puertoDeChat);
        
        inChat = new DataInputStream(socketChat.getInputStream());
        outChat = new DataOutputStream(socketChat.getOutputStream());
        
        
        socketJuego = new Socket(configuracion.direccionJuego,configuracion.puertoDeJuego);
        
        inJuego = new DataInputStream(socketJuego.getInputStream());
        outJuego = new DataOutputStream(socketJuego.getOutputStream());
        
        
        ComunicacionChat comunicacionChat = new ComunicacionChat(this); 
        ComunicacionJuego comunicacionJuego = new ComunicacionJuego(this);
        comunicacionJuego.start();
        comunicacionChat.start();

    }
    
     public void setInterfaz(TableroJuego tablero) {
        this.tablero = tablero;
    }

    public void setConfiguracion(Configuracion configuracion) {
        this.configuracion = configuracion;
    }

    public void enviaMensajeAlJuego(String msg) throws IOException{   
        outJuego.writeUTF(this.nombre+":"+msg+":"+this.tablero.miPuntuacion+":"+this.tablero.puntuacionRival); 
        outJuego.flush();
    }
    
    public void enviaMensajeAlChat(String msg) throws IOException{      
        outChat.writeUTF(this.nombre+":"+msg); 
        outChat.flush();
    }
    
    public void enviaMensajeSinNombre(String msg, DataOutputStream out) throws IOException{      
        out.writeUTF(msg); 
        out.flush();
    }
    

    public void setPuntuacion(int puntuacion) {
        this.puntuacion = puntuacion;
    }

    public int getPuntuacion() {
        return this.tablero.miPuntuacion;
    }
    
    public void setPuntuacionRival(int puntuacion) {
        this.tablero.miPuntuacion = puntuacion;
    }

    public int getPuntuacionRival() {
        return this.tablero.puntuacionRival;
    }

}
