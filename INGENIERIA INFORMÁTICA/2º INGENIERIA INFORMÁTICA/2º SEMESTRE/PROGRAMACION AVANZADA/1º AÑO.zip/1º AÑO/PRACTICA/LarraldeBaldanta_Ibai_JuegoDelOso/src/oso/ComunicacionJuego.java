/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oso;

import java.io.IOException;

/**
 *
 * @author ilarr
 */
public class ComunicacionJuego extends Thread{
    Jugador jugador;
    public ComunicacionJuego(Jugador jugador) {
        this.jugador = jugador;
    }

    @Override
    public void run() { //Vamos a escuchar al servidor del juego para ir actualizando el tablero en consecuencia
        while(true){
            String mensaje;
            
            try {
                mensaje = jugador.inJuego.readUTF();
                if (mensaje.equalsIgnoreCase("SALIR"))
                    break;
                jugador.tablero.actualizaTablero(mensaje);
            } catch (IOException ex) {
                System.exit(0);
            }
        }
    }
}
