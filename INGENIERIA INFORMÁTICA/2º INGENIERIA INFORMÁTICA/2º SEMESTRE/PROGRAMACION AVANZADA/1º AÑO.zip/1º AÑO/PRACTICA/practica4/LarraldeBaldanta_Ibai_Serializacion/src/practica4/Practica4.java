/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package practica4;


import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Map;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;

/**
 *
 * @author ilarr
 */
public class Practica4 {
    public static void main(String[] args) throws IOException, FileNotFoundException, ClassNotFoundException {
        
        //EJECICIO1
        //DEFINIIR LA RUTA DEL ARCHIVO CSV DE LOS PAISES
        String filepath = "./data/countries.csv";
        
        //CREAR UNA LISTA DE OBJETOS COUNTRY A PARTIR DEL ARCHIVO DE CIUDADES
        System.out.println("EJERCICIO1 /////////////////////////////");
        ArrayList<Country> listaPaises = Country.parseCSV(filepath);
        
        //IMPRIMIR EL NUMERO DE PAISES
        System.out.println("Numero de paises leidos: " + listaPaises.size());
        
        
        System.out.println("");
        
        
        //EJERCICIO2
        System.out.println("EJERCICIO2 /////////////////////////////");
        System.out.println("Paises con mas poblacion qye la media");
        
        //OBTENER MEDIA
        float media = Country.media(listaPaises);
                
        //COMPARAR LA MEDIA CON LA POBLACION DE TODOS LOS PAISES
        listaPaises.stream().filter((country)-> (country.getPopulation() > media)).forEachOrdered((country)-> {
            
            //IMPRIMIR EL NOMBRE DEL PAIS
            System.out.println(country.getCountry());
        });
        
        
        
        System.out.println("");
        
        
        //EJERCICIO3
        System.out.println("EJERCICIO3 /////////////////////////////"); 
        System.out.println("Regiones con el numero de paises que contine");
        
        //INICIALIZAR NUEVO MAPA
        Map<String, Integer> mapaRegiones = Country.mapaRegiones(filepath, listaPaises);
                
        //IR DE CLAVE EN CLAVE
        mapaRegiones.keySet().stream().filter((clave) -> (!"".equals(clave))).forEachOrdered((clave)-> {
            
            //IMPRIMIR CADA REGION CON EL NUMERO DE PAISES QUE TIENE(ES LA MISMA CLAVE)
            System.out.println(clave + ": " + mapaRegiones.get(clave));
        });
        
        
        
        System.out.println("");
        
        
        //EJERCICIO4
        System.out.println("EJERCICIO4 /////////////////////////////");       

        
        //DEFINIIR LA RUTA DEL ARCHIVO CSV DE LOS PAISES
        String path = "./data/cities.csv";
        
        //CREAR UNA LISTA DE OBJETOS COUNTRY A PARTIR DEL ARCHIVO DE CIUDADES
        ArrayList<City> listaCiudades = City.parseCSV(path, listaPaises);
        
        //IMPRIMIR TODAS LAS CIUDADES
        /*
        listaCiudades.forEach((ciudad) -> {
            System.out.println(ciudad.toString());
        });
        */
        
        System.out.println("");
        
        
        //EJERCICIO5
        System.out.println("EJERCICIO5 /////////////////////////////"); 
        
        //ORDENAR LISTA DE CIUDADES POR POBLACIÓN
        listaCiudades.sort(Comparator.comparing(City::getPopulation).reversed());
        
        //IMPRIMIR EL NOMBRE DE LOS PAISES DE LAS CIUDADES
        System.out.println("Las 10 ciuadades con mayor poblacion: ");
        for(int i = 0;i<10;i++){
            System.out.println(listaCiudades.get(i).getCountry());
        }
        
        //IMPRIMIR EL NOMBRE DEL PAIS DEL CUAL SON LAS CIUDADES CON MAYOR DIFERENCIA DE POBLACION
        System.out.println("El pais con las ciudades con mayor diferencia de poblacion es: " + City.mayorDiferenciaEntreCiudades(listaCiudades));
        
        
        System.out.println("");
        
        
        //EJERCICIO6
        System.out.println("EJERCICIO6 /////////////////////////////");
        
        //LISTA DONDE SE VAN A GUARDAR LOS PAISES CON MAYOR POBLACION QUE LA MEDIA
        ArrayList<Country> paisesPoblacionMayorMedia = new ArrayList<>();
        
        //MEDIA DE LA POBLACION DE LOS PAISES
        float media2 = Country.media(listaPaises);
        
        //COMPARAR LA MEDIA CON LA POBLACION DE TODOS LOS PAISES
        listaPaises.stream().filter((country)-> (country.getPopulation() > media2)).forEachOrdered((country) -> {
            
            //AÑADIR A LA NUEVA LISTA LOS PAISES QUE LO CUMPLAN
            paisesPoblacionMayorMedia.add(country);
        });
        
        //ESCRIBIR LA NUEVA LISTA DE PAISES EN UN FICHERO CSV
        Country.writeCSV(paisesPoblacionMayorMedia);
        
        
        System.out.println("");
        
        
        //EJERCICIO7
        System.out.println("EJERCICIO7 /////////////////////////////");
        
        //ESCRIBIR PAISES
        Country.escribirPaisesBin(listaPaises);
        
        //LEER FICHERO RECIEN ESCRITO Y CARGARLO EN UNA LISTA
        ArrayList<Country> listaLeidaBin = Country.leerPaisesBin();
        
        //COMPROBACION DE LOS PAISES
        /*
        listaLeidaBin.forEach((pais) -> {
            System.out.println(pais.toString());
        });
        */
        
        //COMPROBACION DE LAS CIUDADES
        /*
        listaCiudades.forEach((ciudad) -> {
            System.out.println(ciudad.toString());
        });
        */
        
        /*
            Las referencias de los paises en las ciudades siguen intactas
        */
        
        
        
        System.out.println("");
        
        
        //EJERCICIO8
        System.out.println("EJERCICIO8 /////////////////////////////");
        
        //DECLARAR UN NUEVO STREAM CON LA LISTA DE PAISES
        XStream xstream = new XStream( new DomDriver() );
        String xml = xstream.toXML(listaPaises);
        
        try {
            
            //ESCRIBIR
            Files.write(Paths.get("data/countries.xml"), xml.getBytes());
            
            //COMPROBACIÓN
            System.out.println("Creado correctamente");
        } 
        //EXCEPCION
        catch (IOException exception) {
            System.out.println("Error en la creacion el archivo xml: " + exception);
        }
        
        
        
        System.out.println("");
        
        
        //EJERCICIO9
        System.out.println("EJERCICIO9 /////////////////////////////");
        
        System.out.println("""
                           CSV:
                           Ventajas:
                 
                           Es f\u00e1cil de crear y leer, y es compatible con muchas aplicaciones de hojas de c\u00e1lculo.
                           Es un formato de archivo muy ligero y, por lo tanto, ocupa menos espacio de almacenamiento.
                           Es f\u00e1cil de importar y exportar en diferentes sistemas.
                           Es un formato de archivo plano, lo que significa que es f\u00e1cil de editar en un editor de texto.
                           
                           Desventajas:
                           
                           No es adecuado para datos complejos que requieren una estructura de datos compleja.
                           No tiene un est\u00e1ndar definido, lo que puede llevar a problemas de compatibilidad.
                           No es adecuado para almacenar datos binarios.
                           
                           
                           writeObject:
                           
                           Ventajas:
                           
                           Permite almacenar objetos Java completos en un archivo, incluidos objetos anidados y colecciones.
                           Permite una f\u00e1cil lectura y escritura de datos.
                           Es muy f\u00e1cil de usar y no requiere una estructura de archivo espec\u00edfica.
                           
                           Desventajas:
                           
                           Solo se puede leer y escribir en lenguajes de programaci\u00f3n que admiten objetos Java.
                           No es adecuado para transmitir datos a trav\u00e9s de la red.
                           No es compatible con otros lenguajes de programaci\u00f3n.
                           
                           
                           XML:
                           
                           Ventajas:
                           
                           Es un formato de archivo muy flexible y se puede utilizar para una amplia gama de aplicaciones.
                           Es compatible con muchos lenguajes de programaci\u00f3n y aplicaciones.
                           Es f\u00e1cil de entender y leer.
                           
                           Desventajas:
                           
                           Es un formato de archivo de texto pesado y puede ocupar mucho espacio de almacenamiento.
                           No es adecuado para almacenar grandes cantidades de datos binarios.
                           Puede ser dif\u00edcil de editar en un editor de texto, especialmente si se trata de archivos grandes.""");
                    
        
        System.out.println("");
        
        
        //EJERCICIO10
        System.out.println("EJERCICIO10 /////////////////////////////");
        
        System.out.println("""
                            Tanto writeObject como XStream utilizan la reflexión para acceder a los campos y métodos de un objeto en 
                            tiempo de ejecución, lo que les permite serializar y deserializar objetos sin conocer sus atributos de antemano. Sin embargo, 
                            es importante tener en cuenta que el uso excesivo de reflexión puede tener un impacto negativo en el rendimiento del programa, 
                            por lo que es importante utilizarla con precaución.""");
        
    }
    
}
