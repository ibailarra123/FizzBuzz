/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica4;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author ilarr
 */
public class Country implements Serializable{


    private String country;
    private String region;
    private double population;
    private double area;
    private double gdp;

    public Country(String country, String region, Double population, Double area, Double gdp) {
        this.country = country;
        this.region = region;
        this.population = population;
        this.area = area;
        this.gdp = gdp;
    }

    public String getCountry() {
        return country;
    }

    public String getRegion() {
        return region;
    }

    public double getPopulation() {
        return population;
    }

    public double getArea() {
        return area;
    }

    public double getGdp() {
        return gdp;
    }
    

    @Override
    public String toString() {
        return "country{" + "Country=" + country + ", Region=" + region + ", Population=" + population + ", Area=" + area + ", GDP=" + gdp + '}';
    }  
    
    public static ArrayList<Country> parseCSV(String filepath) throws FileNotFoundException, IOException{
        
        //DEFINIR NUEVA LISTA DE PAISES
        ArrayList<Country> listaPaises = new ArrayList<>();
        
        //OBTENER EL ARCHIVO CSV COGIENDO LA RUTA
        File csv = new File(filepath);
        
        try (BufferedReader br = new BufferedReader(new FileReader(csv))){
            
            //LEER LAS 5 PRIMERAS LINEAS DEL CSV PARA DESCARTARLAS YA QUE NO CONTIENEN INFORMACIÓN DE PAISES, TAN SOLO CABECERAS Y TÍTULOS
            for (int i = 0; i<5 ;i++){
                
                //LEER LINEA
                br.readLine();
            }
            
            //LINEA QUE SE LEE TODO EL TIEMPO
            String linea;
            
            //GUARDAR SEXTA LINEA
            linea = br.readLine();
            
            //CONTADOR DE LÍNEAS PARA CUANDO DE ERROR SABER EN QUE LÍNEA ESTÁ EL ERROR
            int contadorLineas = 6;
            
            //MIENTRAS NO ACABE EL FICHERO CSV
            while(linea!= null){
                try{ 
                    //SEPARAR LOS DISTINTOS CAMPOS DEL CSV SEPARADOS POR UNA COMA INTRODUCIENDOLOS EN UN ARRAY
                    String[] datos = linea.split(",");
                    
                    //TAMAÑO DE LA LINEA
                    int tamaño = datos.length;

                    //UNO DE LOS CAMPOS QUE NOS INTERESA, GDP(CAMPO 8/9), EN ALGUNAS LINEAS ESTA VACÍO ASI QUE SE INTRODUCE UN 0
                    //COMO NO SIEMPRE EL CAMPO GDP ESTA EN LA POSICION 8, SE LE RESTA A LA LONGITUD DE LA LÍNEA 12 Y EN EL 100% DE LOS CASOS SE OBTIENE EL CAMPO GDP
                    if (datos[tamaño - 12].isEmpty()){
                        datos[tamaño - 12] = "0";
                    }
                    
                    //LOS INICIOS DE LINEAS SON INCORRECTOS
                    if(tamaño == 21){
                        String parte = datos[0].substring(1, datos[0].length());
                        String parte2 = datos[1].substring(0, datos[1].length() - 2);
                        datos[0] = parte.concat(parte2);
                    }
                    else{
                        datos[0] = datos[0].substring(0, datos[0].length() - 1);
                        if(tamaño < 20){
                            tamaño = 20;
                        }
                    }
                    
                    //CREAR UN NUEVO PAIS CON LOS 5 CAMPOS DE LA LINEA QUE NOS INTERESAN: COUNTRY, REGION, POPULATION, AREA, GDP
                    Country pais = new Country(datos[0], datos[tamaño-19], Double.valueOf(datos[tamaño-18]), Double.valueOf(datos[tamaño-17]), Double.valueOf(datos[tamaño - 12]));
                    
                    //AÑADIR EL NUEVO PAIS A LA LISTA DE PAISES
                    listaPaises.add(pais);
                    
                    //LEER NUEVA LINEA
                    linea = br.readLine();
                   
                //EXCEPCIÓN
                }catch(NumberFormatException exception){
                    System.out.println("Error al leer la línea" + contadorLineas);
                }
                contadorLineas++;
            }
        }
        return listaPaises;
    }
    
    public static float media(ArrayList<Country> paises){
        float suma = 0;
        
        //RECORRER TODOS LOS PAISES
        for (int i=0; i< paises.size() ;i++){
            suma= (float)(suma + paises.get(i).getPopulation());
        }
        
        //DIVIDIR LA SUMA DE LAS POBLACIONES DE TODOS LOS PAISES ENTRE EL NUMERO TOTAL DE PAISES
        return suma/paises.size();
         
    }
    
    public static Map<String, Integer> mapaRegiones(String filepath, ArrayList<Country> paises) throws FileNotFoundException, IOException{
        
        //INICIALIZAR MAPA
        Map<String, Integer> mapaRegiones = new HashMap<>();
        
        //PARA CADA PAIS
        paises.forEach((pais)->{
            
            //SI NO EXISTE YA LA KEY PERTENCECIENTE A LA REGION DONDE ESTA EL PAIS
            if(!mapaRegiones.containsKey(pais.getRegion())){
                
                //PONERLE A LA REGION DEL PAIS EL VALOR 1
                mapaRegiones.put(pais.getRegion() ,1);
            }
            
            //SI YA EXISTE LA CLAVE IGUAL A LA REGION PORQUE ALGUN PAIS ANTERIOR ESTA EN LA MISMA REGION
            else{
                
                //SUSTITUIR A LA REGION DEL PAIS EL VALOR QUE TENIA MAS 1 PARA IR SUMANDO CUANTOS PAISES ESTAN EN ESA REGION
                mapaRegiones.replace(pais.getRegion() , mapaRegiones.get(pais.getRegion()) + 1);
            }
        });
        return mapaRegiones;
    }
    
    public static void writeCSV(List<Country> paises)throws IOException{
        
        //CREAR NUEVO FICHERO DE ESCRITURA
        FileWriter file =new FileWriter("./data/countries2.csv");
        
        //ABRIR EL FICHERO EN ESCRITURA
        try (BufferedWriter br = new BufferedWriter(file)){
            
            //PARA CADA PAIS DE LA LISTA DE PAISES
            for(Country pais : paises){
                
                //ESCRIBIR EL NOMBRE DEL PAIS
                br.write(pais.getCountry());
                br.write(",");
                
                //ESCRIBIR LA REGION DEL PAIS
                br.write(pais.getRegion());
                br.write(",");
                
                //ESCRIBIR LA POBLACION DEL PAIS
                br.write(Double.toString(pais.getPopulation()));
                br.write(",");
                
                //ESCRIBIR EL AREA DEL PAIS
                br.write(Double.toString(pais.getArea()));
                br.write(",");
                
                //ESCRIBIR EL GDP DEL PAIS
                br.write(Double.toString(pais.getGdp()));
                
                //SALTO DE LÍNEA
                br.write("\n");
            }
            
           
         //EXCEPCION   
        }catch(Exception exception){
            System.out.println("Error de escritura" + exception);
        }
        
        
    }
    
    public static void escribirPaisesBin(ArrayList<Country> paises){
        
        //CREAR UN NUEVO OBJETO OBJECT OUTPUT STREAM CON UN NUEVO FICHERO countriesAndCities
        try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("data/countriesAndCities.bin"))){
            
            //PARA CADA PAIS
            for(Country pais: paises){
                
                //ESCRIBIR EL PAIS EN EL FICHERO
                oos.writeObject(pais);
            }
            
         //EXCEPCION   
        }catch(Exception exception){
            System.out.println("Error de escritura BIN");
        }
    }
    
    
    public static ArrayList<Country> leerPaisesBin(){
        
        //DEFINIR NUEVA LISTA DE PAISES
        ArrayList<Country> paises = new ArrayList<>();
        
        //DEFINIR VARIABLE PARA LEER
        Country pais;
        
        //CREAR UN NUEVO OBJETO OBJECT INPUT STREAM PARA LEER EL FICHERO countriesAndCities
        try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream("data/countriesAndCities.bin"))){
            
            //LEER UN PAIS DEL FICHERO
            pais = (Country)ois.readObject();
            
            //MIENTRAS NO SE ACABEN LOS PAISES
            while(pais != null){
                
                //AÑADIR EL PAIS A LA LISTA
                paises.add(pais);
                
                //LEER UN PAIS DEL FICHERO
                pais = (Country)ois.readObject();
            }
            //CERRAR INPUT
            ois.close();
        //EXCEPCION
        //CUANDO SE ACABA EL FICHERO
        } catch(EOFException eofexception){
            return paises;
            
        }catch(Exception exception){
            System.out.println("Error en lectura BIN");
        }
        return null;
    }  
}
