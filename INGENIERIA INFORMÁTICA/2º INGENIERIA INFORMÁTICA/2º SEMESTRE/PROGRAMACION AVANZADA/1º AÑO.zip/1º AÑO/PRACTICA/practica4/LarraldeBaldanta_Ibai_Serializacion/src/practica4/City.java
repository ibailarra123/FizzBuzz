/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package practica4;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 *
 * @author ilarr
 */
public class City {
    private String city;
    private String country;
    private double population;
    private Country countryRef;

    public City(String city, String country, double population, Country countryRef) {
        this.city = city;
        this.country = country;
        this.population = population;
        this.countryRef = countryRef;
    }
    
    
    public City(String city, String country, double population) {
        this.city = city;
        this.country = country;
        this.population = population;
    }

    public String getCity() {
        return city;
    }

    public String getCountry() {
        return country;
    }

    public double getPopulation() {
        return population;
    }

    public Country getCountryRef() {
        return countryRef;
    }

    @Override
    public String toString() {
        return "City{" + "city=" + city + ", country=" + country + ", population=" + population + ", countryRef=" + countryRef + '}';
    }
    
    public static ArrayList<City> parseCSV(String filepath, List<Country> paises) throws FileNotFoundException, IOException{
        
        //DEFINIR NUEVA LISTA DE CIUDADES
        ArrayList<City> listaCiudades = new ArrayList<>();
        
        //OBTENER EL ARCHIVO CSV COGIENDO LA RUTA
        File csv = new File(filepath);
        
        try (BufferedReader br = new BufferedReader(new FileReader(csv))){
                
            //PASAR LA LISTA DE PAISES A UN MAPA PARA ACELERAR EL PROCEDIMIENTO DE BUSQUEDA POR NOMBRES
            HashMap<String, Country> countriesByName = new HashMap<>();
            
            //COMPROBACION DE SI LA LISTA PASADA COMO PARAMETRO ESTA VACIA O NO
            if(paises!=null){
                
                //PARA CADA PAIS AÑADIR ESTE AL MAPA Y COMO CLAVE SU NOMBRE
                paises.forEach((pais)-> {
                    countriesByName.put(pais.getCountry(), pais);
                });
            }
            
            //SALTAR LA PRIMERA LINEA
            br.readLine();

            
            //LINEA QUE SE LEE TODO EL TIEMPO
            String linea;
            
            //GUARDAR LA SEGUNDA LINEA
            linea = br.readLine();
            
            //CONTADOR DE LÍNEAS PARA CUANDO DE ERROR SABER EN QUE LÍNEA ESTÁ EL ERROR
            int contadorLineas = 2;
            
            //MIENTRAS NO ACABE EL FICHERO CSV
            while(linea!= null){
                try{ 
                    //SEPARAR LOS DISTINTOS CAMPOS DEL CSV SEPARADOS POR UNA COMA INTRODUCIENDOLOS EN UN ARRAY
                    String[] datos = linea.split(",");
                    
                    //TAMAÑO DE LA LINEA
                    int tamaño = datos.length;

                    //UNO DE LOS CAMPOS QUE NOS INTERESA, POPULATION(CAMPO 9), EN ALGUNAS LINEAS ESTA VACÍO ASI QUE SE INTRODUCE UN 0
                    //COMO NO SIEMPRE EL CAMPO POPULATION ESTA EN LA POSICION 9, SE LE RESTA A LA LONGITUD DE LA LÍNEA 2 Y EN EL 100% DE LOS CASOS SE OBTIENE EL CAMPO POPULATION
                    if (datos[tamaño - 2].isEmpty()){
                        datos[tamaño - 2] = "0";
                    }
                    
                    //INSERTAR LA NUEVA CIUDAD EN LA LISTA DE CIUDADES CON LOS CITY, COUNTRY(), POPULATION Y COUNTRY REF
                    City ciudad = new City(datos[1], datos[4], Integer.parseInt(datos[tamaño-2]),countriesByName.get(datos[4]));
                    listaCiudades.add(ciudad);
                  
                    
                    //LEER NUEVA LINEA
                    linea = br.readLine();
                   
                //EXCEPCIÓN 
                
                }catch (IOException exception){
                    
                    //ERROR AL LEER LA LINEA
                    System.out.println("Error en la linea " + contadorLineas + "de cities: " + exception);
                    
                    //LEER LA NUEVA LINEA
                    linea = br.readLine();
                
                }catch (NumberFormatException exception2) {
                
                    //SEPARAR LOS DISTINTOS CAMPOS DEL CSV SEPARADOS POR UNA COMA INTRODUCIENDOLOS EN UN ARRAY
                    String[] datos = linea.split(",");
                
                    //TAMAÑO DE LA LÍNEA
                    int tamaño = datos.length;
                
                    //EN LA MAYORIA DE LAS LINEAS, EL CAMPO POPULATION TIENE UNA LONGITUD MUY LARGA, POR TANTO SE LE DISMINUYE ESTA LONGITUD EN 2
                    datos[tamaño - 2] = datos[tamaño - 2].substring(0, datos[tamaño - 2].length() - 2);
                    
                    //INSERTAR LA NUEVA CIUDAD EN LA LISTA DE CIUDADES
                    City ciudad = new City(datos[1], datos[4], Integer.parseInt(datos[tamaño-2]),countriesByName.get(datos[4]));
                    listaCiudades.add(ciudad);
                
                    //LEER LA NUEVA LÍNEA
                    linea = br.readLine();
                }
                
                contadorLineas++;
            }
        }
        return listaCiudades;
    }
    
    
    public static String mayorDiferenciaEntreCiudades(ArrayList<City> listaCiudades){
        
        //VARIABLE DONDE SE VA A GUARDAR LA MÁXIMA DIFERENCIA
        int diferencia = 0;
        
        //VARIABLE DONDE SE VA A GUARDAR EL PAIS CUYAS CIUDADES TIENEN LA MAYOR DIFERENCIA DE POBLACION
        String pais = "ninguno";
        
        //BUCLE PARA RECORRER TODAS LAS CIUDADES
        for(int i = 0; i< listaCiudades.size();i++){
            
            //BUCLE INTERNO PARA QUE CADA CIUDAD PUEDA SER COMPARADA CON TODAS LAS DEAMAS CIUDADES
            for(int j = 0; j< listaCiudades.size();j++){
                
                //COMPROBAR QUE LAS DOS CIUDADES SON DEL MISMO PAÍS
                if(listaCiudades.get(i).getCountry().equals(listaCiudades.get(j).getCountry())){
                   
                    //COMPARAR LA DIFERENCIA DE LAS DOS CIUDADES CON LA MÁXIMA DIFERENCIA HASTA EL MOMENTO
                    if((listaCiudades.get(i).getPopulation() - listaCiudades.get(j).getPopulation()) > diferencia){
                        
                        //SI ES MAYOR QUE LA MAYOR DIFERENCIA HASTA EL MOMENTO, ACTUALIZAR LA MAYOR DIFERENCIA
                        diferencia = (int) (listaCiudades.get(i).getPopulation() - listaCiudades.get(j).getPopulation());
                        
                        //GUARDAR EL PAIS DEL CUAL SON LAS CIUDADES CON MAYOR DIFERENCIA DE POBLACION
                        pais = listaCiudades.get(i).getCountry();
                    }
                }
            }
        }
        return pais;
    } 
}
