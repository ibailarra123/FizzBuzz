/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package listasincrona;

import java.util.ArrayList;

/**
 *
 * @author ilarr
 */
public class ListaSincrona {
    private ArrayList lista;
    
    public ListaSincrona(){
        lista = new ArrayList();
    }

    public ArrayList getLista() {
        return lista;
    }
    
    
    public synchronized void insert(int pos, int elem){
        lista.add(pos,elem);
    }
    
    public synchronized void append(int elem){
        lista.add(elem);
    }
    
    public synchronized void remove(int pos){
        lista.remove(pos);
    }
}
