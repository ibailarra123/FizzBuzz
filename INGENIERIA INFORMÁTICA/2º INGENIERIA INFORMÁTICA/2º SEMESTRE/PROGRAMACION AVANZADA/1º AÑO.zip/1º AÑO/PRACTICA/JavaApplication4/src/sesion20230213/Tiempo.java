/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sesion20230213;

/**
 *
 * @author ilarr
 */
public class Tiempo {
    private int valor;
    private int valorMax;

    public Tiempo(int valorMax) {
        this.valorMax = valorMax;
        valor = 0;
    }
    
    public int incrementar(){
        if(valor< valorMax-1){
            valor++;
            return 0;
        }
        else{
            valor = 0;
            return 1;
        }
    }
    
    public int incrementar(int i){
        if(valor< valorMax-1){
            valor+=i;
            return 0;
        }
        else{
            valor = 0;
            return 1;
        }
    }

    @Override
    public String toString() {
        return "Tiempo{" + "valor=" + valor + '}';
    }
    
}
