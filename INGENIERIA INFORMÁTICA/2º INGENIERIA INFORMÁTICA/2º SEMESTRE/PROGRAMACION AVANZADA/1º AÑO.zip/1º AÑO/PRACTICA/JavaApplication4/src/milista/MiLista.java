package milista;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ilarr
 */
public class MiLista <E>{
    E[] lista;
    int longitud;

    public MiLista() {
        this.lista = (E[])new Object[longitud];
    }
    
    public void append(E elem){
        increaseSpace();
        lista[longitud] = elem;
    }
    
    public void remove(int index){
        lista[index] = null;
        longitud-=1;
        E[] aux = (E[])new Object[longitud];
        int i = 0;
        for(E e:lista){
            if(e!=null){
                aux[i]=e;
            }
            i++;
        }
    }
    
    private void increaseSpace(){
        longitud++;
        E[] copy = (E[])new Object[longitud];
        System.arraycopy(lista, 0, copy, 0, longitud);
        lista = copy;
    }
}
