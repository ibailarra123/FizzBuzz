/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sesion20230213;

/**
 *
 * @author ilarr
 */
public class Sesion20230213 {

    public static void main(String[] args){
       Tiempo t = new Tiempo(60);
       
       for(int i=0; i<70; i++){
           t.incrementar();
           System.out.println(t);
       }
   }
    
}
