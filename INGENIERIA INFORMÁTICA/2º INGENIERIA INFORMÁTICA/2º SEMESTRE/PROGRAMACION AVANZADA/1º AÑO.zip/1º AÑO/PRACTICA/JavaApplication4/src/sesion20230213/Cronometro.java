/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sesion20230213;

/**
 *
 * @author ilarr
 */
public class Cronometro {
    Tiempo valores[];
    //List <Tiempo> vlaores = new ArrayList<Tiempo>();
   
   public Cronometro(){
       valores = new Tiempo[2];
       valores[0] = new Tiempo(60); //segundos
       valores[1] = new Tiempo(60); //minutos
   }
   
   public void iniciar(){
       while(true){
           int incr = valores[0].incrementar();
           
            for(int i=1; i<valores.length; i++){
                incr = valores[1].incrementar(incr);
            }
       }
   }
   
   public void print(){
       for(Tiempo t:valores){
           System.out.print(t+" ");
       }
       System.out.println("");
   }
}
