#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <time.h>
#define LBUFFER 2000
#define LONG 11
#include <sys/types.h>
#include <signal.h>
#include <stdbool.h>
 
void recogePalabras(FILE *);
void cambiaPalabra(FILE *f, char palabra[17]);
void copiaPalabra(char palabra[17],char palabraAdivinar[17]);
void comprobarLetra(char palabra[17],char palabraAdivinar[17], char letra, bool *b);
void pedirPalabrasNuevas(FILE *f, int socket);

int main(int argc, char *argv[]){ //argv[1] = puerto, argv[2] = numero maximo de clientes
    FILE *palabras,*f_sock1, *f_sock2;
    int numCli;
    int vidas;
    int socket1;
    int SockCli1, SockCli2;
    struct sockaddr_in servidor_bind;
    struct sockaddr_in cliente_dir;
    char buf1[LBUFFER], buf2[LBUFFER], nombre1[17], nombre2[17], palabraActual[17], palabraAdivinar[17], letra/*, res1, res2*/;
    socklen_t cliente_dir_len;
    bool turnoPrimero, estaEnPalabra, primerTurno;
    
    numCli = 0;
    
    // Estableciendo Socket
    if ((socket1=socket(PF_INET, SOCK_STREAM, 0)) == -1){
        perror ("Error de Socket ()");
        exit(EXIT_FAILURE);
    }
    
    // Estableciendo Servidor -> Ip, Puerto
    servidor_bind.sin_family = AF_INET;
    servidor_bind.sin_port = htons(atoi(argv[1]));  //meter el puerto 
    servidor_bind.sin_addr.s_addr = INADDR_ANY;
    
    if(bind(socket1,(struct sockaddr *)&servidor_bind, sizeof(servidor_bind))== -1){
        perror("Error de Bind()\n");
        exit(-1);
    }
    printf("Bienvenido al juego del ahocado, introduzca 10 palabras una a una: \n");
    palabras = NULL;
    recogePalabras(palabras);
    
    if (listen(socket1,atoi(argv[2]))==-1){
        perror("Error de Listen()\n");
        exit(-1);
    }
    
    while(1){
        printf("Esperando clientes.\n");
        cliente_dir_len=sizeof(cliente_dir);
        // Jugador 1 se conecta
        if((SockCli1 = accept(socket1,(struct sockaddr *)&cliente_dir, &cliente_dir_len))== -1){
            perror("Error en accept()\n");
            exit(-1);
        }
        numCli++;
        
        // Abrimos un stream (FILE) con fdopen en vez de write/read
        if((f_sock1 = fdopen(SockCli1,"r+")) == NULL){
            perror("Error al abrir el fichero en escritura\n");
            exit(EXIT_FAILURE); 
        }
        
        setbuf(f_sock1,NULL);
        memset(buf1,0,sizeof(buf1));
        fprintf(f_sock1, "HOLA\n");
        
        setbuf(f_sock1,NULL);
        memset(buf1,0,sizeof(buf1));
        fgets(buf1,LBUFFER,f_sock1);
        sscanf(buf1, "HOLA NOMBRE %s\n", nombre1);
        
        printf("Conectado cliente %d desde %s. Nombre %s \n", ((numCli%2)+1), inet_ntoa(cliente_dir.sin_addr), nombre1);
        
        setbuf(f_sock1,NULL);
        memset(buf1,0,sizeof(buf1)); 
        fprintf(f_sock1, "HOLA NOMBRE OK\n");  
        
        // ESPERANDO a jugador 2
        memset(buf1,0,sizeof(buf1));
        fprintf(f_sock1, "ESPERANDO\n");
        setbuf(f_sock1,NULL);
        memset(buf1,0,sizeof(buf1));
        fgets(buf1,LBUFFER,f_sock1);
        sscanf(buf1,"ESPERANDO OK");
        
        // Jugador 2 se conecta
        if((SockCli2 = accept(socket1,(struct sockaddr *)&cliente_dir, &cliente_dir_len))== -1){
            perror("Error en accept()\n");
            exit(-1);
        } 
        numCli++;
        
        // Abrimos un stream (FILE) con fdopen en vez de write/read
        if((f_sock2 = fdopen(SockCli2,"r+")) == NULL){
            perror("Error al abrir el fichero en escritura\n");
            exit(EXIT_FAILURE); 
        }
        
        setbuf(f_sock2,NULL);
        memset(buf2,0,sizeof(buf2));
        fprintf(f_sock2, "HOLA\n");
        
        setbuf(f_sock2,NULL);
        memset(buf2,0,sizeof(buf2));
        fgets(buf2,LBUFFER,f_sock2);
        sscanf(buf2, "HOLA NOMBRE %s\n", nombre2);
        
        printf("Conectado cliente %d desde %s. Nombre %s \n", ((numCli%2)+1), inet_ntoa(cliente_dir.sin_addr), nombre2);
        
        setbuf(f_sock2,NULL);
        memset(buf2,0,sizeof(buf2)); 
        fprintf(f_sock2, "HOLA NOMBRE OK\n");
        
        // LISTOS a jugador 2
        memset(buf2,0,sizeof(buf2));
        fprintf(f_sock2, "LISTOS\n");

        setbuf(f_sock2,NULL);
        memset(buf2,0,sizeof(buf2));
        fgets(buf2,LBUFFER,f_sock2);
        sscanf(buf2,"LISTO OK");
        
        // LISTOS a jugador 1
        memset(buf1,0,sizeof(buf1));
        fprintf(f_sock1, "LISTOS\n");
        setbuf(f_sock1,NULL);
        memset(buf1,0,sizeof(buf1));
        fgets(buf1,LBUFFER,f_sock1);
        sscanf(buf1,"LISTO OK");
        
       
        
        // Presentacion jugador 1
        setbuf(f_sock1,NULL);
        memset(buf1,0,sizeof(buf1));
        fprintf(f_sock1, "PRESENTANDO %s\n", nombre2);

        setbuf(f_sock1,NULL);
        memset(buf1,0,sizeof(buf1));
        fgets(buf1,LBUFFER,f_sock1);
        sscanf(buf1,"ENCANTADO");

        // Presentacion jugador 2
        setbuf(f_sock2,NULL);
        memset(buf2,0,sizeof(buf2));
        fprintf(f_sock2, "PRESENTANDO %s\n", nombre1);

        setbuf(f_sock2,NULL);
        memset(buf2,0,sizeof(buf2));
        fgets(buf2,LBUFFER,f_sock2);
        sscanf(buf2,"ENCANTADO");

        /*res1 = 's';
        res2 = 's';*/
        printf("Empieza el juego\n");
        /*while(res1 != 'n' && res2 != 'n'){*/
            turnoPrimero = true;
            primerTurno = true;
            vidas = 10;
            memset(palabraActual,0,sizeof(char[17]));
            memset(palabraAdivinar,0,sizeof(char[17]));
            cambiaPalabra(palabras,palabraActual);
            copiaPalabra(palabraActual, palabraAdivinar);
            while(vidas != 0 && strcmp(palabraAdivinar, palabraActual) != 0){
                if(primerTurno && turnoPrimero){
                    memset(buf1,0,sizeof(buf1));
                    setbuf(f_sock1,NULL);
                    fprintf(f_sock1, "TUTURNO %s %d\n", palabraAdivinar , vidas);
                    memset(buf2,0,sizeof(buf2));
                    setbuf(f_sock2,NULL);
                    fprintf(f_sock2, "TURNO %s\n",nombre1);
                }else if(primerTurno && !turnoPrimero){
                    memset(buf2,0,sizeof(buf2));
                    setbuf(f_sock2,NULL);
                    fprintf(f_sock2, "TUTURNO %s %d\n", palabraAdivinar , vidas);
                    memset(buf1,0,sizeof(buf1));
                    setbuf(f_sock1,NULL);
                    fprintf(f_sock1, "TURNO %s\n",nombre2);
                }
                
                if(turnoPrimero){
                    primerTurno = false;
                    setbuf(f_sock1,NULL);
                    memset(buf1,0,sizeof(buf1));
                    fgets(buf1,LBUFFER,f_sock1);
                    sscanf(buf1,"LETRA %c", &letra);
                    comprobarLetra(palabraActual, palabraAdivinar, letra, &estaEnPalabra);
                    if(!estaEnPalabra){
                        turnoPrimero = false;
                        vidas--;
                        // Comunico fallo al jugador 1
                        memset(buf1,0,sizeof(buf1));
                        setbuf(f_sock1,NULL);
                        fprintf(f_sock1, "FALLO %c %s %d\n", letra, palabraAdivinar , vidas);
                        
                        // Comunico fallo al jugador 2
                        memset(buf2,0,sizeof(buf2));
                        setbuf(f_sock2,NULL);
                        fprintf(f_sock2, "FALLO %c %s %d\n", letra, palabraAdivinar , vidas);
                        
                        primerTurno = true;
                        
                    }else{
                        // Comunico correcto al jugador 1
                        memset(buf1,0,sizeof(buf1));
                        setbuf(f_sock1,NULL);
                        fprintf(f_sock1, "CORRECTO %c %s %d\n", letra, palabraAdivinar , vidas);
                        
                        // Comunico correcto al jugador 2
                        memset(buf2,0,sizeof(buf2));
                        setbuf(f_sock2,NULL);
                        fprintf(f_sock2, "CORRECTO %c %s %d\n", letra, palabraAdivinar , vidas);
                    }
                }else{
                    primerTurno = false;
                    memset(buf2,0,sizeof(buf2));
                    setbuf(f_sock2,NULL);
                    fgets(buf2,LBUFFER,f_sock2);
                    sscanf(buf2,"LETRA %c", &letra);
                    comprobarLetra(palabraActual, palabraAdivinar, letra, &estaEnPalabra);
                    if(!estaEnPalabra){
                        turnoPrimero = true;
                        vidas--;
                        
                        // Comunico fallo al jugador 2
                        memset(buf2,0,sizeof(buf2));
                        setbuf(f_sock2,NULL);
                        fprintf(f_sock2, "FALLO %c %s %d\n", letra, palabraAdivinar, vidas);
                        
                        // Comunico fallo al jugador 1
                        memset(buf1,0,sizeof(buf1));
                        setbuf(f_sock1,NULL);
                        fprintf(f_sock1, "FALLO %c %s %d\n", letra, palabraAdivinar , vidas);
                        primerTurno = true;
                        
                    }else{
                        // Comunico correcto al jugador 2
                        memset(buf2,0,sizeof(buf2));
                        setbuf(f_sock2,NULL);
                        fprintf(f_sock2, "CORRECTO %c %s %d\n", letra, palabraAdivinar , vidas);
                        
                        // Comunico correcto al jugador 1
                        memset(buf1,0,sizeof(buf1));
                        setbuf(f_sock1,NULL);
                        fprintf(f_sock1, "CORRECTO %c %s %d\n", letra, palabraAdivinar , vidas);
                    }
                }
            }
            if(vidas == 0){
                // Comunico derrota al jugador 1 
                memset(buf1,0,sizeof(buf1));
                setbuf(f_sock1,NULL);
                fprintf(f_sock1, "GAME OVER\n");
                // Comunico derrota al jugador 2 
                memset(buf2,0,sizeof(buf2));
                setbuf(f_sock2,NULL);
                fprintf(f_sock2, "GAME OVER\n");
                
            }else{
                if(turnoPrimero){
                    // Comunico correcto (ADIVINADO) al jugador 1 
                    memset(buf1,0,sizeof(buf1));
                    setbuf(f_sock1,NULL);
                    fprintf(f_sock1, "ENHORABUENA\n");
                        
                    // Comunico ganador (ADIVINADO) al jugador 2
                    memset(buf2,0,sizeof(buf2));
                    setbuf(f_sock2,NULL);
                    fprintf(f_sock2, "GANA %s\n", nombre1);
                        
                }else{
                    // Comunico correcto (ADIVINADO) al jugador 2
                    memset(buf2,0,sizeof(buf2));
                    setbuf(f_sock2,NULL);
                    fprintf(f_sock2, "ENHORABUENA\n");
                    
                    // Comunico ganador (ADIVINADO) al jugador 1
                    memset(buf1,0,sizeof(buf1));
                    setbuf(f_sock1,NULL);
                    fprintf(f_sock1, "GANA %s\n", nombre2);
                }
            }
            if(numCli%20 == 0){
                pedirPalabrasNuevas(palabras, socket1);
            }else{
                printf("Siguiente palabra\n");
            }
            /*// Pregunto si quiere seguir al jugador 1 
            memset(buf1,0,sizeof(buf1));
            setbuf(f_sock1,NULL);
            fprintf(f_sock1, "SEGUIR\n");

            fgets(buf1,LBUFFER,f_sock1);
            sscanf(buf1,"SEGUIR %c", &res1);
                
            // Pregunto si quiere seguir al jugador 2
            memset(buf2,0,sizeof(buf2));
            setbuf(f_sock2,NULL);
            fprintf(f_sock2, "SEGUIR\n");

            fgets(buf2,LBUFFER,f_sock2);
            sscanf(buf2,"SEGUIR %c", &res2);

            if(res1 == 's' && res2 == 's'){
                pedirPalabrasNuevas(palabras); (ANTES ERA DISTINTA LA ACCION)
                memset(buf2,0,sizeof(buf2));
                setbuf(f_sock2,NULL);
                fprintf(f_sock2, "SEGUIR s\n");
            }else{
                memset(buf2,0,sizeof(buf2));
                setbuf(f_sock2,NULL);
                fprintf(f_sock2, "SEGUIR n\n");
            }
        }*/
    }
}

void recogePalabras(FILE *f){
    char palabra[LONG];
    f = fopen("palabras.txt","w");
    for (int i = 0; i < 10; i++){
        printf("Palabra %d: ", i+1);
        scanf("%s", palabra);
        fprintf(f, "%s\n",palabra);
    }
    fclose(f);
}

void cambiaPalabra(FILE *f, char palabra[17]){
    FILE *tmp;
    char palAux[17];
    f = fopen("palabras.txt", "r");
    tmp = fopen("tmp.txt", "w");
    fscanf(f,"%s\n",palabra);
    while(!feof(f)){
       fscanf(f,"%s\n",palAux); 
       fprintf(tmp, "%s\n", palAux);
    }
    fclose(f);
    fclose(tmp);
    remove("palabras.txt");
    rename("tmp.txt", "palabras.txt");
}

void copiaPalabra(char palabra[17],char palabraAdivinar[17]){
    for (int i = 0; i < strlen(palabra); i++){
        palabraAdivinar[i] = '_';
    }
}

void comprobarLetra(char palabra[17],char palabraAdivinar[17], char letra, bool *b){
    *b = false;
    for(int i = 0; i < strlen(palabra);i++){
        if(letra == palabra[i]){
            *b = true;
            palabraAdivinar[i] = letra;
        }
    }
    
}

void pedirPalabrasNuevas(FILE *f, int socket){
    char res;
    printf("Las palabras se han acabado, ¿Quieres volver a poner 10? (s/n):\n");
    scanf(" %c", &res);
    if(res == 's'){
        recogePalabras(f);
    }else{
        close(socket);
        exit(-1);
    }
}
