/*Cliente*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <time.h>
#define LBUFFER 2000
#define LONG 11
#include <sys/types.h>
#include <signal.h>
#include <stdbool.h>

bool compara(char palabra[17]);
void mostrarDibujo(char lista[28], int vidas);
void dibujo(int vidas);
void aniadirLista(char lista[28],char letra);

int main(int argc, char *argv[]) { //argv[1] = IP, argv[2] = puerto
    int socket1, vidas;
    char nombre[17],nombre2[17], ocupado[8], esperando[10], tuturno[12], palabraAdivinar[17], correcto[9], letra, gameover[12],listaLetrasErroneas[28]/*, res*/;
    struct sockaddr_in servidor;
    char buf1[LBUFFER];
    system("clear");
    FILE *f_sock1;

    // Estableciendo Socket
    if ((socket1=socket(PF_INET,SOCK_STREAM,0)) == -1) {
        perror("Error de Socket \n");
        exit(EXIT_FAILURE); 
    }

    if (argc < 2) {
        printf("Falta la direccion ip. \n");
        return EXIT_SUCCESS; 
    }

    else if (argc < 3) {
        printf("Falta el puerto.\n");
        return EXIT_SUCCESS; 
    }

    
    //Rellenar la estructura de la direccion
    servidor.sin_family = AF_INET;
    servidor.sin_port = htons(atoi(argv[2]));
    servidor.sin_addr.s_addr = inet_addr(argv[1]);
    
    //Conexion al servidor TCP
    if (connect(socket1, (struct sockaddr *)&servidor,sizeof(struct sockaddr_in) ) == -1) {
        perror("Error de Conexion ");
        exit(EXIT_FAILURE); 
    }
    
    if((f_sock1= fdopen(socket1,"r+")) == NULL){
        perror("Error al abrir el fichero en escritura\n");
        exit(EXIT_FAILURE);
    }
    printf("Bienvenido al juego del ahorcado, por favor, introduce un nombre: \n");
    scanf("%s", nombre);
    
    fgets(buf1,LBUFFER,f_sock1);
    sscanf(buf1, "HOLA\n");
    
    setbuf(f_sock1,NULL);
    memset(buf1,0,sizeof(buf1));
    fprintf(f_sock1, "HOLA NOMBRE %s\n", nombre);
    
    fgets(buf1,LBUFFER,f_sock1);
    sscanf(buf1, "%s\n", ocupado);
    
    if(strcmp(ocupado,"OCUPADO") == 0){
        close(socket1);
        return 0;
    }else{
        fgets(buf1,LBUFFER,f_sock1);
        sscanf(buf1,"%s", esperando);
        if(strcmp(esperando, "ESPERANDO") == 0){
            printf("Esperando otro cliente.\n");
            setbuf(f_sock1,NULL);
            memset(buf1,0,sizeof(buf1));
            fprintf(f_sock1, "ESPERANDO OK\n");

            fgets(buf1,LBUFFER,f_sock1);
            sscanf(buf1,"%s", esperando);
            if(strcmp(esperando, "LISTOS") == 0){
                setbuf(f_sock1,NULL);
                memset(buf1,0,sizeof(buf1));
                fprintf(f_sock1, "LISTO OK\n");
            }
        }else{
            setbuf(f_sock1,NULL);
            memset(buf1,0,sizeof(buf1));
            fprintf(f_sock1, "LISTO OK\n");
        
        }
        setbuf(f_sock1,NULL);
        memset(buf1,0,sizeof(buf1));
        fgets(buf1,LBUFFER,f_sock1);
        sscanf(buf1,"PRESENTANDO %s", nombre2);
        printf("Presentando a %s\n", nombre2);
        setbuf(f_sock1,NULL);
        memset(buf1,0,sizeof(buf1));
        fprintf(f_sock1, "ENCANTADO\n");
        
        printf("Empieza el juego.\n");
        //EMPIEZA EL JUEGO
        setbuf(f_sock1,NULL);
        memset(buf1,0,sizeof(buf1));
        fgets(buf1,LBUFFER,f_sock1);
        sscanf(buf1,"%s", tuturno);
        vidas = 10;
        //res = 's';
        while(vidas > 0){/*&& res == 's'*/
            if(strcmp(tuturno, "TUTURNO") == 0){
                
                sscanf(buf1,"TUTURNO %s %d", palabraAdivinar, &vidas);
                if(vidas == 10){
                    printf("Tu palabra a descifrar es: %s\n", palabraAdivinar);
                }
                printf("Tu turno, introduce una letra: \n");
                scanf(" %c", &letra);
                setbuf(f_sock1,NULL);
                memset(buf1,0,sizeof(buf1));
                fprintf(f_sock1, "LETRA %c\n", letra);
                setbuf(f_sock1,NULL);
                memset(buf1,0,sizeof(buf1));
                fgets(buf1,LBUFFER,f_sock1);
                sscanf(buf1,"%s %c %s %d", correcto, &letra, palabraAdivinar, &vidas);
                while(strcmp(correcto, "CORRECTO") == 0){
                    mostrarDibujo(listaLetrasErroneas, vidas);
                    printf("Correcto! quedan %d vidas %s\n", vidas, palabraAdivinar);
                    if(compara(palabraAdivinar)){
                        fgets(buf1,LBUFFER,f_sock1);
                        sscanf(buf1,"%s", tuturno);
                        if(strcmp(tuturno, "ENHORABUENA") == 0){
                            printf("Correcto! has acertado la palabra. %s\n", palabraAdivinar);
                            vidas = -1;
                            break;
                        }else{
                            printf("Lo sentimos! %s ha acertado la palabra.\n", nombre2);
                            vidas = -1;
                            break;
                        }
                    }
                    printf("Tu turno, introduce una letra: \n");
                    scanf(" %c", &letra);
                    setbuf(f_sock1,NULL);
                    memset(buf1,0,sizeof(buf1));
                    fprintf(f_sock1, "LETRA %c\n", letra);

                    fgets(buf1,LBUFFER,f_sock1);
                    sscanf(buf1,"%s %c %s %d", correcto, &letra, palabraAdivinar, &vidas);
                }
                if(strcmp(tuturno, "ENHORABUENA") == 0){
                    break;
                }
                if(vidas == 0){
                        break;
                }
                aniadirLista(listaLetrasErroneas,letra);
                mostrarDibujo(listaLetrasErroneas, vidas);
                fgets(buf1,LBUFFER,f_sock1);
                sscanf(buf1,"%s", tuturno);
                printf("Incorrecto! quedan %d vidas. Turno de %s\n",vidas, nombre2);
                
            }else if(strcmp(tuturno, "TURNO") == 0){
                sscanf(buf1,"TURNO %s",nombre2);
                
                printf("Turno de %s\n", nombre2);
                fgets(buf1,LBUFFER,f_sock1);
                sscanf(buf1,"%s %c %s %d", correcto, &letra, palabraAdivinar, &vidas);
                
                while(strcmp(correcto, "CORRECTO") == 0){
                    mostrarDibujo(listaLetrasErroneas, vidas);
                    if(compara(palabraAdivinar)){
                        fgets(buf1,LBUFFER,f_sock1);
                        sscanf(buf1,"%s", tuturno);
                        if(strcmp(tuturno, "ENHORABUENA") == 0){
                            printf("Correcto! has acertado la palabra. %s\n", palabraAdivinar);
                            mostrarDibujo(listaLetrasErroneas, vidas);
                            vidas = -1;
                            break;
                        }else{
                            printf("Lo sentimos! %s ha acertado la palabra.\n", nombre2);
                            mostrarDibujo(listaLetrasErroneas, vidas);
                            vidas = -1;
                            break;
                        }
                    }
                    if(strcmp(tuturno, "GANA") == 0){
                        break;
                    }
                    if(vidas == 0){
                        break;
                    }   
                    printf("Ha dicho '%c'. Quedan %d vidas. %s\n",letra, vidas, palabraAdivinar);
                    fgets(buf1,LBUFFER,f_sock1);
                    sscanf(buf1,"%s %c %s %d", correcto, &letra, palabraAdivinar, &vidas);
                }
                aniadirLista(listaLetrasErroneas,letra);
                //mostrarDibujo(listaLetrasErroneas, vidas);
                if(vidas != -1 && vidas != 0){
                    fgets(buf1,LBUFFER,f_sock1);
                    sscanf(buf1,"%s", tuturno);
                    printf("Ha dicho '%c'. Quedan %d vidas. %s\n",letra, vidas, palabraAdivinar);
                }
            }
        }
        if(vidas == 0){
            fgets(buf1,LBUFFER,f_sock1);
            sscanf(buf1,"%s OVER", gameover);
            aniadirLista(listaLetrasErroneas,letra);
            mostrarDibujo(listaLetrasErroneas, vidas);
            printf("No habeis adivinado la palabra, lo sentimos!\n");
        }
        /*fgets(buf1,LBUFFER,f_sock1);
        sscanf(buf1,"SEGUIR");

        printf("¿Quieres volver a jugar otra partida? (s/n):\n");
        scanf(" %c", &res);

        setbuf(f_sock1,NULL);
        memset(buf1,0,sizeof(buf1));
        fprintf(f_sock1, "SEGUIR %c\n", letra);
        
        fgets(buf1,LBUFFER,f_sock1);
        sscanf(buf1,"SEGUIR %c", &res);*/

        
    }
    
    close(socket1);
    exit(-1);
    return EXIT_SUCCESS;
}

bool compara(char palabra[17]){
    for(int i = 0; i < strlen(palabra); i++){
        if(palabra[i] == '_'){
            return(false);
        }
    }
    return(true);

}
void mostrarDibujo(char lista[28], int vidas){
    printf("DIBUJO:\n");
    dibujo(vidas);
    printf("\nLISTA DE LETRAS QUE NO APARECEN:\n");
    printf("%s",lista);
    printf("\n");
}
void dibujo(int vidas){
    if(vidas == 9){
        printf("      \n");
        printf("      \n"); 
        printf("      \n");
        printf("      \n");
        printf("      \n");
        printf("______\n");
    }else if(vidas == 8){
        printf("|     \n");
        printf("|     \n");
        printf("|     \n");
        printf("|     \n");
        printf("|     \n");
        printf("|_____\n");
    }else if(vidas == 7){
        printf("____  \n");
        printf("|/    \n");
        printf("|     \n");
        printf("|     \n");
        printf("|     \n");
        printf("|_____\n");
    }else if(vidas == 6){
        printf("____  \n");
        printf("|/ |  \n");
        printf("|     \n");
        printf("|     \n");
        printf("|     \n");
        printf("|_____\n");
    }else if(vidas == 5){
        printf("____  \n");
        printf("|/ |  \n");
        printf("|  O  \n");
        printf("|     \n");
        printf("|     \n");
        printf("|_____\n");
    }else if(vidas == 4){
        printf("____  \n");
        printf("|/ |  \n");
        printf("|  O  \n");
        printf("|  |  \n");
        printf("|     \n");
        printf("|_____\n");
    }else if(vidas == 3){
        printf("____  \n");
        printf("|/ |  \n");
        printf("|  O  \n");
        printf("| /|  \n");
        printf("|     \n");
        printf("|_____\n");
    }else if(vidas == 2){
        printf("____  \n");
        printf("|/ |  \n");
        printf("|  O  \n");
        printf("| /|\ \n");
        printf("|     \n");
        printf("|_____\n");
    }else if(vidas == 1){
        printf("____  \n");
        printf("|/ |  \n");
        printf("|  O  \n");
        printf("| /|\ \n");
        printf("| /   \n");
        printf("|_____\n");
    }else if(vidas == 0){
       printf("____  \n");
        printf("|/ |  \n");
        printf("|  O  \n");
        printf("| /|\ \n");
        printf("| / \  \n");
        printf("|_____\n");
    }
}

void aniadirLista(char lista[50], char letra){
    char aux[3];
    aux[0] = letra;
    aux[1] = ' ';
    strcat(lista,aux);
    
}
