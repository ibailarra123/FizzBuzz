#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
 
int main(int argc, char *argv[]) {
    int i;
 
    printf("Hay %d argumentos \n", argc);
    for(i=0; i<argc; i++) {
        printf("El argumento %d es: %s\n",i,argv[i]);
    }
 
    return 0;
}
