#include <stdio.h>
                    
int main() {
printf("primer programa de RC... \n");
    return 0;
}
