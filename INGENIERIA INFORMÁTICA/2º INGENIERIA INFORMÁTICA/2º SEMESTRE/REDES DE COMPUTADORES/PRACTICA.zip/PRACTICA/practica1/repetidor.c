
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
 
int main(int argc, char *argv[]) {
    int i;
    char *filename;
    FILE *f;
 
    if(argc < 2) {
        exit(0);
    }
 
    filename = argv[1];
    f = fopen(filename,"w");
    if(f == NULL) {
        printf("No puedo abrir el fichero %s\n",argv[1]);
    }
 
    fprintf(f, "Has escrito %d argumentos \n", argc);
    for (i=0; i<argc; i++) {
        fprintf(f, "El argumento %d es: %s\n", i, argv[i]);
    }
 
    return 0;
}
