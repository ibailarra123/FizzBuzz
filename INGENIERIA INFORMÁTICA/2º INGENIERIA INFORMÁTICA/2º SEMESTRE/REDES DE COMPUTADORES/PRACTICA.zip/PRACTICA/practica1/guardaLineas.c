
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
 
int main(int argc, char *argv[]) {
    int i;
    char *filename;
    FILE *f;
    char buf[256];
 
    if(argc < 2) {
        filename = "out";
    }
    else {
        filename = argv[1];
    }
 
    f = fopen(filename, "w");
    if(f == NULL) {
        printf("No puedo abrir el fichero %s\n", argv[1]);
    }
 
    printf("> ");
 
    while(fgets(buf, 255, stdin) != NULL) {
        fprintf(f, "%s", buf);
        printf("> ");
    }
 
    fclose(f);
 
    return 0;
}
