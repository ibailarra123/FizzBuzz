#include <stdio.h>
                    
int main() {
printf("segundo programa de RC... \n");
    return 0;
}
