
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
 
int main(int argc, char *argv[]) { //argv[1] = filename, argv[2] = numero de veces a repetir
    int i;
    char *filename;
    FILE *f;
    char palabra[20];
 
    if(argc < 2) {
        filename = "out";
    }
    else {
        filename = argv[1];
    }
 
    f = fopen(filename, "w");
    if(f == NULL) {
        printf("No puedo abrir el fichero %s\n", argv[1]);
    }
    scanf("%s", palabra);
 
    for (i = 0; i < atoi(argv[2]); i++){
    	fprintf(f,"%d: %s\n", i+1, palabra);
    } 
 
    fclose(f);
 
    return 0;
}
