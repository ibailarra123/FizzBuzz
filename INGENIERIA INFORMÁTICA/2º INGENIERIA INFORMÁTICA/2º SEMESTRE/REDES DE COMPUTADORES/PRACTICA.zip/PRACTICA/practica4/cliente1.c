/*Cliente*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#define LBUFFER 2000

int main(int argc, char *argv[]) {
    int x,y;
    int socket_fd;
    char ok[6],okset[6];
    char id[11];
    struct sockaddr_in servidor;
    char buffer_fd[LBUFFER];
    double tiempoServidor, tiempoCliente;
    system("clear");
    FILE *f, *ids;

    // Estableciendo Socket
    if ((socket_fd=socket(PF_INET,SOCK_STREAM,0)) == -1) {
        perror("Error de Socket \n");
        exit(EXIT_FAILURE); 
    }

    if (argc < 2) {
        printf("Falta la direccion ip. \n");
        return EXIT_SUCCESS; 
    }

    else if (argc < 3) {
        printf("Falta el puerto.\n");
        return EXIT_SUCCESS; 
    }

    
    //Rellenar la estructura de la direccion
    servidor.sin_family = AF_INET;
    servidor.sin_port = htons(atoi(argv[2]));
    servidor.sin_addr.s_addr = inet_addr(argv[1]);
    
    //Conexion al servidor TCP
    if (connect(socket_fd, (struct sockaddr *)&servidor,sizeof(struct sockaddr_in) ) == -1) {
        perror("Error de Conexion ");
        exit(EXIT_FAILURE); 
    }
    
    if((f = fdopen(socket_fd,"r+")) == NULL){
        perror("Error al abrir el fichero en escritura\n");
        exit(EXIT_FAILURE); 
    }
    
    if(access("cliente.txt", W_OK)){
        printf("No existe id almacenado, realizando petición de registro\n");
        fprintf(f,"REGISTRAR\n");
        
        fgets(buffer_fd,LBUFFER,f);
        sscanf(buffer_fd, "RESUELVE %d %d\n",&x, &y);
        printf("Resuelve %d + %d = %d\n", x, y, (x+y));
        
        memset(buffer_fd,0,sizeof(buffer_fd));
        
        fprintf(f,"RESPUESTA %d\n",(x+y));
        
        fgets(buffer_fd,LBUFFER,f); 
        sscanf(buffer_fd, "REGISTRADO %s %s\n",ok,id);
        
        if(strcmp(ok,"OK") == 0){
			ids = fopen("cliente.txt","w");
            printf("Sesión establecida con id %s \n",id);
            printf("Conexión abierta\n");
            fprintf(ids, "%s %d\n", id, (x+y));
            fclose(ids);
        }
        else{
            printf("ERROR EN EL REGISTRO\n");
            exit(-1);
        }
    }
    else{
        int sol,opcion;
        char nombreUs[17];
		ids = fopen("cliente.txt","r");
        printf("Hay datos para el usuario %s, probamos autentificación\n", id);
		fscanf(ids, " %s %d\n", id, &sol);
        fprintf(f,"LOGIN %s %d\n", id, sol);
        fclose(ids);
        fgets(buffer_fd,LBUFFER,f);
        sscanf(buffer_fd, "LOGIN %s",ok);
        setbuf(f,NULL);
        memset(buffer_fd,0,sizeof(buffer_fd));
        if(strcmp(ok, "OK") == 0){
            
            printf("Sesión establecida con id %s\n", id);
            while(opcion != 5){
                printf("¿Qué quieres hacer?\n");
                printf("1. Cambiar nombre\n");
                printf("2. Ver tu nombre\n");
                printf("3. Ver lista de usuarios conectados\n");
                printf("4. Ver tiempo de conexion\n");
                printf("5. Cerrar conexión\n");
                printf("Opción: \n");
                scanf("%d",&opcion);
                
                if(opcion == 1){
                    printf("Elige nombre: \n");
                    scanf("%s",nombreUs);
                    setbuf(f,NULL);
                    memset(buffer_fd,0,sizeof(buffer_fd));
                    fprintf(f,"SETNAME %s\n",nombreUs);

                    fgets(buffer_fd,LBUFFER,f);
                    sscanf(buffer_fd,"SETNAME %s", okset);
                    if(strcmp(okset,"OK") == 0){
                        printf("Nombre cambiado con éxito\n");
                    }else{
                        printf("ERROR al cambiar el nombre\n");
                    }
                    
                }
                else if(opcion == 2){
                    setbuf(f,NULL);
                    memset(buffer_fd,0,sizeof(buffer_fd));
                    fprintf(f,"GETNAME\n");
                    
                    fgets(buffer_fd,LBUFFER,f);
                    sscanf(buffer_fd,"GETNAME %s",nombreUs);
                    printf("Tu nombre es: %s\n",nombreUs);
                }else if(opcion == 3){
                    setbuf(f,NULL);
                    memset(buffer_fd,0,sizeof(buffer_fd));
                    fprintf(f,"UPTIME\n");
                    
                }else if(opcion == 4){
                    setbuf(f,NULL);
                    memset(buffer_fd,0,sizeof(buffer_fd));
                    fprintf(f,"UPTIME\n");

                    fgets(buffer_fd,LBUFFER,f);
                    sscanf(buffer_fd,"UPTIME %lf %lf",&tiempoServidor, &tiempoCliente);
                    printf("Tiempo que lleva conectado el servidor: %lf segundos\n", tiempoServidor);
                    printf("Tiempo que llevas conectado al servidor: %lf segundos\n", tiempoCliente);
                }else{
                    setbuf(f,NULL);
                    memset(buffer_fd,0,sizeof(buffer_fd));
                    fprintf(f,"FIN\n");
                }
            }
            
        }else{
            printf("ERROR EN EL LOGIN\n");
            close(socket_fd);
            fclose(ids);
            exit(-1);
        }
    }
    close(socket_fd);
    return EXIT_SUCCESS;
}
