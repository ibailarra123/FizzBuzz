/*Servidor*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <time.h>
#define LBUFFER 2000
#include <sys/types.h>
#include <signal.h>
#include <stdbool.h>

void crearID(char *destino);
bool haCambiado(char arch[8], char nombre[17],char id[11], int contrasena);

int main(int argc, char *argv[]) { // argv[1] = puerto, argv[2] = numeroClentes
    char opcion[8], nombreUs[17], regis[10], nombreAux[17], nombreGet[17];
    int x,y,sol,solAux;
    int socket1;
    int SockCli1;
    struct sockaddr_in servidor_bind;
    struct sockaddr_in cliente_dir;
    char buf1[2000];
    char Id[11], IdAux[11];
    socklen_t cliente_dir_len;
    FILE *f_sock1, *ids, *tmp, *lista, *tmpNombres;
    time_t tiempoInicial, tiempoCliente, t;
    double tiempoAcSer, tiempoAcCli;
    system("clear");
    
    srand (time(NULL));
    x = rand() % 11;
    y = rand() % 11;
    
    // Estableciendo Socket
    if ((socket1=socket(PF_INET, SOCK_STREAM, 0)) == -1){
        perror ("Error de Socket ()");
        exit(EXIT_FAILURE);
    }
    
    // Estableciendo Servidor -> Ip, Puerto
    servidor_bind.sin_family = AF_INET;
    servidor_bind.sin_port = htons(atoi(argv[1]));  //meter el puerto 
    servidor_bind.sin_addr.s_addr = INADDR_ANY;
    
    if(bind(socket1,(struct sockaddr *)&servidor_bind, sizeof(servidor_bind))== -1){
        perror("Error de Bind()\n");
        exit(-1);
    }
    
    time(&tiempoInicial); //guardamos el tiempo en el que empieza a escuchar clientes
    
    if (listen(socket1,atoi(argv[2]))==-1){ //numero maximo de clientes conectados
        perror("Numero de usuarios conectados maximo alcanzado, intentelo en otro momento.\n");
        exit(-1);
    }
    
    while(1){
        cliente_dir_len=sizeof(cliente_dir);
        if((SockCli1 = accept(socket1,(struct sockaddr *)&cliente_dir, &cliente_dir_len))== -1){
            perror("Error en accept()\n");
            exit(-1);
        }
        
        time(&tiempoCliente); //tiempo inicial del cliente
        // Abrimos un stream (FILE) con fdopen en vez de write/read
        if((f_sock1 = fdopen(SockCli1,"r+")) == NULL){
            perror("Error al abrir el fichero en escritura\n");
            exit(EXIT_FAILURE); 
        }
        
        printf("Escuchando conexiones en el puerto\n");
        printf("Conexion establecida desde la ip %s puerto %d \n",inet_ntoa(cliente_dir.sin_addr), cliente_dir.sin_port);
        
        setbuf(f_sock1,NULL);
        memset(buf1,0,sizeof(buf1));
        fgets(buf1,LBUFFER,f_sock1);
        sscanf(buf1, "%s\n", regis);
        
        if (strcmp(regis, "REGISTRAR") == 0){
            printf("Recibida peticion de registro\n");
            printf("Estableciendo prueba %d + %d.\n", x, y);
            setbuf(f_sock1,NULL);
            memset(buf1,0,sizeof(buf1));
            fprintf(f_sock1, "RESUELVE %d %d\n",x,y);
            fgets(buf1,2000,f_sock1);
            sscanf(buf1, "RESPUESTA %d\n", &sol);
            if (sol == (x + y)){
                memset(buf1,0,sizeof(buf1));
                printf("Recibido %d, prueba superada.\n", sol);
                crearID(Id);
                printf("Asignando id %s \n", Id);
                fprintf(f_sock1,"REGISTRADO OK %s\n",Id);
            }
            else{
                printf("Recibido %d, prueba NO superada.\n", sol);
                fprintf(f_sock1,"REGISTRADO ERROR \n");
                
                fclose(f_sock1);
                close(socket1);
                return EXIT_SUCCESS;
            }
        }else if(strcmp(regis, "LOGIN") == 0){
            sscanf(buf1, "LOGIN %s %d", Id, &sol);
            
            ids = fopen("servidor.txt","r");
            
            fscanf(ids, "%s %d %s", IdAux, &solAux , nombreAux);
            
            while(!feof(ids) && (strcmp(Id, IdAux) != 0)){
                fscanf(ids, "%s %d %s", IdAux, &solAux, nombreAux);
            }
            
            lista = fopen("lista.txt","w");
            fprintf(lista, "%s\n",nombreAux);
            fclose(lista);
            strcpy(nombreGet,nombreAux);
            
            if(feof(ids)){
                if(strcmp(Id, IdAux) == 0){
                    if (sol == solAux){
                        printf("Usuario con id %s autentificado\n", Id);
                        setbuf(f_sock1,NULL);
                        memset(buf1,0,sizeof(buf1));
                        fprintf(f_sock1, "LOGIN OK\n");
                        
                        strcpy(opcion, "notfin");
                        while (strcmp(opcion,"FIN")!=0){
                            fgets(buf1,LBUFFER,f_sock1);
                            sscanf(buf1, "%s", opcion);
                            if(strcmp(opcion, "SETNAME") == 0){
                                if (ids == NULL){ /* control del error de apertura */
                                    ids=fopen("servidor.txt","r");
                                }
                                tmp = fopen("tmp.txt", "w");
                                sscanf(buf1, "SETNAME %s", nombreUs);
                                strcpy(nombreGet,nombreUs);
                                rewind(ids);
                                while(!feof(ids)){
                                    fscanf(ids, "%s %d %s\n", IdAux, &solAux, nombreAux);
                                    if(strcmp(Id, IdAux) == 0){
                                    fprintf(tmp,"%s %d %s\n", IdAux, solAux, nombreUs);
                                    }else{
                                        fprintf(tmp, "%s %d %s\n", IdAux, solAux, nombreAux);
                                    }
                                }
                                
                                lista=fopen("lista.txt","r");
                                tmpNombres = fopen("tmpNombres.txt", "w");
                                rewind(lista);
                                
                                while(!feof(lista)){
                                    if(strcmp(nombreUs, nombreAux) == 0){
                                        fprintf(tmpNombres,"%s\n", nombreUs);
                                    }else{
                                        fprintf(tmpNombres, "%s\n",nombreAux);
                                    }
                                }
                                
                                fclose(lista);
                                fclose(tmpNombres);
                                
                                remove("lista.txt");
                                rename("tmpNombres.txt", "lista.txt");
                                    
                                fclose(ids);
                                ids = NULL;
                                fclose(tmp);
                                if(haCambiado("tmp.txt", nombreUs, Id, sol)){
                                    setbuf(f_sock1,NULL);
                                    memset(buf1,0,sizeof(buf1));
                                    fprintf(f_sock1, "SETNAME OK\n");
                                    printf("Usuario con id %s ha cambiado su nombre a %s\n", Id, nombreUs);
                                }else{
                                    setbuf(f_sock1,NULL);
                                    memset(buf1,0,sizeof(buf1));
                                    fprintf(f_sock1, "SETNAME ERROR\n");
                                    printf("ERROR al cambiar el nombre del usuario con id %s\n", Id);
                                }
                                remove("servidor.txt");
                                rename("tmp.txt", "servidor.txt");
                        }else if(strcmp(opcion, "GETNAME") == 0){
                            setbuf(f_sock1,NULL);
                            memset(buf1,0,sizeof(buf1));
                            fprintf(f_sock1, "GETNAME %s\n", nombreGet);
                        }else if(strcmp(regis, "LISTA") == 0){
                            
                        }else if(strcmp(regis, "UPTIME") == 0){
                            tiempoAcCli = difftime(time(&t),tiempoCliente);
                            tiempoAcSer = difftime(time(&t),tiempoInicial);
                            setbuf(f_sock1,NULL);
                            memset(buf1,0,sizeof(buf1));
                            fprintf(f_sock1, "UPTIME %f %f\n", tiempoAcSer, tiempoAcCli);
                        }else{
                            printf("Conexión con %s cerrada\n", Id);
                            
                        }
                    }
                }
            }else{
                fclose(f_sock1);
                close(socket1);
                printf("No hay información para la Id %s\n", Id);
                exit(-1);
                }      
            }else{
                if (sol == solAux){
                        printf("Usuario con id %s autentificado\n", Id);
                        setbuf(f_sock1,NULL);
                        memset(buf1,0,sizeof(buf1));
                        fprintf(f_sock1, "LOGIN OK\n");
                        
                        strcpy(opcion, "notfin");
                        while (strcmp(opcion,"FIN")!=0){
                            fgets(buf1,LBUFFER,f_sock1);
                            sscanf(buf1, "%s", opcion);
                            if(strcmp(opcion, "SETNAME") == 0){
                                if (ids == NULL){ /* control del error de apertura */
                                    ids=fopen("servidor.txt","r");
                                }
                                tmp = fopen("tmp.txt", "w");
                                sscanf(buf1, "SETNAME %s", nombreUs);
                                strcpy(nombreGet,nombreUs);
                                rewind(ids);
                                while(!feof(ids)){
                                    fscanf(ids, "%s %d %s\n", IdAux, &solAux, nombreAux);
                                    if(strcmp(Id, IdAux) == 0){
                                    fprintf(tmp,"%s %d %s\n", IdAux, solAux, nombreUs);
                                    }else{
                                        fprintf(tmp, "%s %d %s\n", IdAux, solAux, nombreAux);
                                    }
                                }
                                
                                lista = fopen("lista.txt","r");
                                tmpNombres = fopen("tmpNosmbres.txt", "w");
                                rewind(lista);
                                
                                while(!feof(lista)){
                                    if(strcmp(nombreUs, nombreAux) == 0){
                                        fprintf(tmpNombres,"%s\n", nombreUs);
                                    }else{
                                        fprintf(tmpNombres, "%s\n",nombreAux);
                                    }
                                }
                                
                                fclose(lista);
                                lista = NULL;
                                fclose(tmpNombres);
                                
                                remove("lista.txt");
                                rename("tmpNombres.txt", "lista.txt");
                                    
                                fclose(ids);
                                ids = NULL;
                                fclose(tmp);
                                if(haCambiado("tmp.txt", nombreUs, Id, sol)){
                                    setbuf(f_sock1,NULL);
                                    memset(buf1,0,sizeof(buf1));
                                    fprintf(f_sock1, "SETNAME OK\n");
                                    printf("Usuario con id %s ha cambiado su nombre a %s\n", Id, nombreUs);
                                }else{
                                    setbuf(f_sock1,NULL);
                                    memset(buf1,0,sizeof(buf1));
                                    fprintf(f_sock1, "SETNAME ERROR\n");
                                    printf("ERROR al cambiar el nombre del usuario con id %s\n", Id);
                                }
                                remove("servidor.txt");
                                rename("tmp.txt", "servidor.txt");
                        }else if(strcmp(opcion, "GETNAME") == 0){
                            setbuf(f_sock1,NULL);
                            memset(buf1,0,sizeof(buf1));
                            fprintf(f_sock1, "GETNAME %s\n", nombreGet);
                        }else if(strcmp(opcion, "LISTA") == 0){
                            
                        }else if(strcmp(opcion, "UPTIME") == 0){
                            tiempoAcCli = difftime(time(&t),tiempoCliente);
                            tiempoAcSer = difftime(time(&t),tiempoInicial);
                            setbuf(f_sock1,NULL);
                            memset(buf1,0,sizeof(buf1));
                            fprintf(f_sock1, "UPTIME %.2f %.2f\n", tiempoAcSer, tiempoAcCli);
                        }else{
                            printf("Conexión con %s cerrada\n", Id);
                            
                        }
                    }
                }
            }
            }else{
            fclose(f_sock1);
            close(socket1);
            printf("Clave incorrecta para id %s\n", Id);
            exit(-1);
            }
    } 
}


void crearID(char *destino) {
    static const char muestra[] = "abcdefghijklmnopqrstuvwxyz1234567890";
    for (int x = 0; x < 10; x++) {
        destino[x] = muestra[rand() % (sizeof(muestra)-1)];
    }
}

bool haCambiado(char arch[8], char nombre[17],char id[11], int contrasena){
    bool b;
    char IdAux[11], nombreAux[17];
    int solAux;
    FILE *f = fopen(arch, "r");
    rewind(f);
    fscanf(f, "%s %d %s", IdAux, &solAux , nombreAux);
    while(!feof(f) && (strcmp(id, IdAux) != 0)){
                fscanf(f, "%s %d %s", IdAux, &solAux, nombreAux);
    }
    if(feof(f)){
        if(strcmp(id, IdAux) == 0){
            if(solAux == contrasena){
                b = (strcmp(nombreAux, nombre) == 0);
            }else{
                b = false;
            }
        }else{
            b = false;
        }
    }else{
        if(solAux == contrasena){
            b = (strcmp(nombreAux, nombre) == 0);
        }else{
            b = false;
        }
    }
    return b;
}
