#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#define LBUFFER 200

int main(int argc, char *argv[]) {
    int socket_fd;
    struct sockaddr_in servidor;
    char buffer_fd[LBUFFER];
    system("clear");

    // Estableciendo Socket
    if ((socket_fd=socket(PF_INET,SOCK_STREAM,0)) == -1) {
        perror("Error de Socket \n");
        exit(EXIT_FAILURE); 
    }

    if (argc < 2) {
        printf("Falta la direccion ip. \n");
        return EXIT_SUCCESS; 
    }

    else if (argc < 3) {
        printf("Falta el puerto.\n");
        return EXIT_SUCCESS; 
    }

    else if (argc < 4) {
        printf("Falta el mensaje.\n");
        return EXIT_SUCCESS; 
    }
    
    //Rellenar la estructura de la direccion
    servidor.sin_family = AF_INET;
    servidor.sin_port = htons(atoi(argv[2]));
    servidor.sin_addr.s_addr = inet_addr(argv[1]);
    strcpy(buffer_fd,argv[3]);
    
    //Conexion al servidor TCP
    if (connect(socket_fd, (struct sockaddr *)&servidor,sizeof(struct sockaddr_in) ) == -1) {
        perror("Error de Conexion ");
        exit(EXIT_FAILURE); 
    }
    
    // Escribiendo en el buffer
    write(socket_fd,buffer_fd,strlen(buffer_fd));
    
    close(socket_fd);
    return EXIT_SUCCESS;
}


