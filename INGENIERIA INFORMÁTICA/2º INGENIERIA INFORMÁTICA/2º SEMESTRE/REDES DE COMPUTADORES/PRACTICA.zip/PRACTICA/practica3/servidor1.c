// servidor
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/wait.h>
#include <time.h>
#define LBUFFER 2000
#include <sys/types.h>
#include <signal.h>
#include <stdbool.h>



void crearID(char *destino);


int main(int argc, char *argv[]) { // argv[1] = puerto
    char regis[9];
    int x,y,sol;
    int socket1;
    int SockCli1;
    struct sockaddr_in servidor_bind;
    struct sockaddr_in cliente_dir;
    char buf1[2000];
    char Id[10];
    socklen_t cliente_dir_len;
    FILE *f_sock1, *ids;
    system("clear");
    
    srand (time(NULL));
    x = rand() % 11;
    y = rand() % 11;
    
    // Estableciendo Socket
    if ((socket1=socket(PF_INET, SOCK_STREAM, 0)) == -1){
        perror ("Error de Socket ()");
        exit(EXIT_FAILURE);
    }
    
    // Estableciendo Servidor -> Ip, Puerto
    servidor_bind.sin_family = AF_INET;
    servidor_bind.sin_port = htons(atoi(argv[1]));  //meter el puerto 
    servidor_bind.sin_addr.s_addr = INADDR_ANY;
    
    if(bind(socket1,(struct sockaddr *)&servidor_bind, sizeof(servidor_bind))== -1){
        perror("Error de Bind()\n");
        exit(-1);
    }
    
    if (listen(socket1,5)==-1){
        perror("Error de Listen()\n");
        exit(-1);
    }
    
    while(1){
        cliente_dir_len=sizeof(cliente_dir);
        if((SockCli1 = accept(socket1,(struct sockaddr *)&cliente_dir, &cliente_dir_len))== -1){
            perror("Error en accept()\n");
            exit(-1);
        }

        // Abrimos un stream (FILE) con fdopen en vez de write/read
        if((f_sock1 = fdopen(SockCli1,"r+")) == NULL){
            perror("Error al abrir el fichero en escritura\n");
            exit(EXIT_FAILURE); 
        }
        
        printf("Escuchando conexiones en el puerto\n");
        printf("Conexion establecida desde la ip %s puerto %d \n",inet_ntoa(cliente_dir.sin_addr), cliente_dir.sin_port);
        printf("Recibida peticion de registro\n");
        printf("Estableciendo prueba %d + %d.\n", x, y);
        

        setbuf(f_sock1,NULL);
        fgets(buf1,LBUFFER,f_sock1);
        sscanf(buf1,"%s",regis);
        
        if (strcmp(regis, "REGISTRAR") == 0){
            setbuf(f_sock1,NULL);
            fprintf(f_sock1, "RESUELVE %d %d\n",x,y);
            fgets(buf1,2000,f_sock1);
            sscanf(buf1, "RESPUESTA %d", &sol);
            if (sol == (x + y)){
                memset(buf1,0,sizeof(buf1));
                printf("Recibido %d, prueba superada.\n", sol);
                crearID(Id);
                printf("Asignando id %s\n", Id);
                ids = fopen("servidor.txt", "w");
                fprintf(ids, "%s %d Invitado", Id, sol);
                setbuf(f_sock1, NULL);
                memset(buf1,0,sizeof(buf1));
                fprintf(f_sock1,"REGISTRADO OK %s\n",Id);
                fclose(ids);
            }
            else{
                printf("Recibido %d, prueba NO superada.\n", sol);
                fprintf(f_sock1,"REGISTRADO ERROR\n");
                
                fclose(f_sock1);
                close(socket1);
                return EXIT_SUCCESS;
            }
        }
    }
}


void crearID(char *destino) {
    static const char muestra[] = "abcdefghijklmnopqrstuvwxyz1234567890";
    for (int x = 0; x < 10; x++) {
        destino[x] = muestra[rand() % (sizeof(muestra)-1)];
    }
}
