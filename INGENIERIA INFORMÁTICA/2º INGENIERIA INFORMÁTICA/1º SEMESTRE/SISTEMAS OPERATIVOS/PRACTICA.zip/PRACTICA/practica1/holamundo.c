#include <stdlib.h> 
#include <stdio.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    if (argc != 2)
       exit(1);
    sleep (5);
    FILE *fp;
    fp = fopen(argv[1], "w");         
    fputs("Hola Mundo", fp);
    fclose ( fp );         
    return 0;
}
