#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdlib.h> 
#include <stdio.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    int f;
    if ((f == open(argv[1], O_RDONLY))==-1) 
       exit(-1);
    char buffer;
    while(read(f,&buffer,1)>0){
        switch(buffer){
            case 'a':
                printf("A");
                break;
        }
    }
    close(f);
    return 0;
}
    
