#include <stdlib.h> 
#include <stdio.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    char caracteres[100];
    if (argc != 2)
       exit(1);
    FILE *fp;
    fp = fopen(argv[1], "r");         
    while (feof(fp) == 0) {                 
        fgets(caracteres,100,fp);                 
        printf("%s",caracteres);
    }
    fclose ( fp );         
    return 0;
}
