#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <unistd.h> 
#include <sys/types.h> 
#include <sys/ipc.h> 
#include <sys/msg.h> 
 
 
typedef struct mensaje_t { 
    int idMensaje; 
    double datoNumerico; 
    char contenido[10]; 
}mensaje_t; 
 
struct msgbuf { 
    long mtype;        
    mensaje_t mensaje;    
}; 
 
int main(int argc, char **argv) { 
    key_t clave; 
    int idColaMensajes; 
    struct msgbuf msgBuffer; 
 
    clave = ftok ("/etc", 22); 
  
    idColaMensajes = msgget (clave, 0777 | IPC_CREAT); 
    
    for (int i=0; i<10;i++){
 
        msgrcv (idColaMensajes, &msgBuffer, sizeof(struct msgbuf) -sizeof(long), 2, 0); 
 
        printf("__________________________________________________________________\n"); 
        printf("ID del mensaje: %d\n", msgBuffer.mensaje.idMensaje + i); 
        printf("Dato del mensaje: %lf\n", msgBuffer.mensaje.datoNumerico); 
        printf("Contenido del mensaje: %s\n", msgBuffer.mensaje.contenido); 
        printf("__________________________________________________________________\n"); 
        sleep(atoi(argv[1]));
    }
  
    msgctl (idColaMensajes, IPC_RMID, 0); 
} 
