#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <unistd.h> 
#include <sys/types.h> 
#include <sys/ipc.h> 
#include <sys/msg.h> 
 
 
typedef struct mensaje_t { 
    int idMensaje; 
    double datoNumerico; 
    char contenido[10]; 
}mensaje_t; 
 
struct msgbuf { 
    long mtype;        
    mensaje_t mensaje;    
}; 
 
int main(int argc, char **argv) { 
    key_t clave; 
    int idColaMensajes; 
    struct msgbuf msgBuffer; 
 
    clave = ftok ("/etc", 22); 
  
    idColaMensajes = msgget (clave, 0777 | IPC_CREAT); 
 
    msgBuffer.mtype = 2; 
    msgBuffer.mensaje.idMensaje = 1; 
    msgBuffer.mensaje.datoNumerico = 11.3; 
    strcpy (msgBuffer.mensaje.contenido, "Mensaje"); 
    
    for(int i=0; i<10; i++){
        msgsnd (idColaMensajes, &msgBuffer, sizeof(struct msgbuf)-sizeof(long), IPC_NOWAIT);
        sleep(atoi(argv[1]));
    }
  
    msgctl (idColaMensajes, IPC_RMID, 0); 
} 
