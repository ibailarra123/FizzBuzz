#include <stdio.h> 
#include <sys/types.h> 
#include <unistd.h> 
#include <sys/wait.h> 
#include <errno.h>

#include <stdlib.h> 
#include <string.h> 
 
#include <sys/types.h> 
#include <sys/ipc.h> 
#include <sys/msg.h>

void itoa(int n, char s[]);
void reverse(char s[]);
 
int main(int argc, char** argv) { 
    for(int i=0; i<5;i++){
        pid_t pid = fork();
        if(pid == 0){
            char s[1];
            itoa(i,s);
            execlp("./p7_1","./p7_1",s,NULL);
        }
    }
    return (0); 
} 
void itoa(int n, char s[])
 {
     int i, sign;

     if ((sign = n) < 0)  /* record sign */
         n = -n;          /* make n positive */
     i = 0;
     do {       /* generate digits in reverse order */
         s[i++] = n % 10 + '0';   /* get next digit */
     } while ((n /= 10) > 0);     /* delete it */
     if (sign < 0)
         s[i++] = '-';
     s[i] = '\0';
     reverse(s);
}  
 /* reverse:  reverse string s in place */
 void reverse(char s[])
 {
     int i, j;
     char c;

     for (i = 0, j = strlen(s)-1; i<j; i++, j--) {
         c = s[i];
         s[i] = s[j];
         s[j] = c;
     }
} 
