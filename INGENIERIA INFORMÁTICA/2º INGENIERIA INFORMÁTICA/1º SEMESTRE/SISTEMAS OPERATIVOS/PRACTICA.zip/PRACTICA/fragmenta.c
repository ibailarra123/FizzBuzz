#include<stdio.h>
#include "fragmenta.h"
#include <string.h>
#include <stdlib.h>

char** fragmenta(const char* cadena){
    char* copia;
    char* copia2;
    char* cad;
    int i;
    copia = calloc(strlen(cadena)+1, sizeof(char));
    copia2 = calloc(strlen(cadena)+1, sizeof(char));
    strcpy(copia,cadena);
    cad = strtok(copia," ");
    int contador =0;
    while (cad !=NULL){
        contador=contador+1;
        cad = strtok(NULL," ");
    }
    char** arg = calloc(contador+1,sizeof(char*));
    strcpy(copia2,cadena);
    cad = strtok(copia2," ");
    for(i=0;i<contador;i=i+1){
        arg[i] = calloc(strlen(cad)+1,sizeof(char));
        strcpy(arg[i],cad);
        cad = strtok(NULL," ");
    }
    return arg;
    
}

void borrarg(char **arg){
    int i=0;
    while(arg[i] != NULL){
        free(arg[i]);
        i=i+1;
    }
    free(arg);
}
