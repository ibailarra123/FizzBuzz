#include <stdio.h>
#include <stdlib.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/msg.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>

struct indicador{
		int ok;
		int nok;
		int pruebasRealizadas;
};

int main(int argc, char *argv[])
{
	key_t clave = ftok("/tmp", atoi(argv[1]));
	
	//Vinculador con la zona de memoria
	int shmid = shmget (clave, 0, 0666);
	if (shmid == -1)
		perror("Error al crear la memoria");
	else
		printf("Me he vinculado a la memoria: %d\n",shmid);
		
	struct indicador* memoria = (struct indicador*)shmat(shmid, NULL, 1);
	if ((void*)memoria == (void*)-1)
		perror("Error vinculando la memoria");
		
	//Vinculador al semáforo
	int semID = semget(clave,1, 0666);
	if(semID == -1)
		perror("Obtención del semáforo");
	else
		printf("He obtenido el semáforo: %d\n",semID);
	
	
    struct sembuf semaforo;
	semaforo.sem_num = 0;
	semaforo.sem_flg = 0;
	
	while(1)
	{
		sleep(atoi(argv[2]));
		semaforo.sem_op = -1;
		  
		//Espero hasta que el semáforo sea verde y lo pongo rojo
		int result = semop(semID,&semaforo,1);
        
		
		
		time_t tiempo = time(0); 
		struct tm *tlocal = localtime(&tiempo); 
		char output[128]; 
		strftime(output,128,"%d/%m/%y %H:%M:%S",tlocal);
		printf("%s informador %d control de calidad: [%d, %d, %d]\n",output,getpid(),memoria->ok,memoria->nok,memoria->pruebasRealizadas); 
		
		//semáforo a verde
		semaforo.sem_op = 1;
		result = semop(semID,&semaforo,1);
	}
}
