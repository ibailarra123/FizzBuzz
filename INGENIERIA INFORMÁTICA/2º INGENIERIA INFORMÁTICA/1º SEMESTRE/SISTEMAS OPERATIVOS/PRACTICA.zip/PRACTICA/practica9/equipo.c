#include <stdio.h>
#include <stdlib.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/wait.h>
#include <sys/sem.h>
#include <sys/msg.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>

struct indicador{
	int ok;
	int nok;
	int pruebasRealizadas;
};


struct mensaje { 
  long idMercancia; 
  struct tm instante;
  int resultadoPrueba;
  int numeroPrueba;
  int probadorID;
};

struct prueba { 
         long idMercancia; 
         int resulPrueba;   
         int numeroPrueba; 
         int probadorID; 
};

//./equipoSupervisor   idEquipoSupervisor   numProbadores   clave  periodoP
int main(int argc, char *argv[])
{	
	int tuberia[2];
	pipe(tuberia);
	
	//Genero el fichero y lo abro en escritura
	char nombreFichero[32];
	sprintf(nombreFichero, "log_%d.txt",atoi(argv[1]));
	int fichero = open(nombreFichero,O_CREAT|O_WRONLY,S_IRUSR|S_IWUSR);
	
	key_t clave = ftok("/tmp", atoi(argv[3]));
	
	//Vinculador a la zona de memoria
	int shmid = shmget (clave, 0, 0666);
	if (shmid == -1)
		perror("Error creando la memoria");
	else
		printf("[EQUIPO_SUPERVISOR %d] Me he vinculado a la memoria: %d\n",atoi(argv[1]),shmid);
		
	struct indicador* memoria = (struct indicador*)shmat(shmid, NULL, 1);
	if ((void*)memoria == (void*)-1)
		perror("Error vinculando la memoria");
		
	//Vinculador al semáforo
	int semID = semget(clave,1, 0666);
	if(semID == -1)
		perror("Obtención del semáforo");
	else
		printf("[EQUIPO_SUPERVISOR %d] He obtenido el semáforo: %d\n",atoi(argv[1]),semID);
	
	struct sembuf semaforo;
	semaforo.sem_num = 0;
	semaforo.sem_flg = 0;
	
	//CREACIÓN ESTANCIAS DE PRUEBACALIDAD
	char idProbador[3];
	for(int i = 0; i < atoi(argv[2]); i++)
	{
		pid_t hijoPid = fork();
		
		if (hijoPid <= 0)//HIJO
		{
			//Redirijo la salida de fichero (lo que se escribiría en uno) y lo escribo por la tubería
			dup2(tuberia[1],STDOUT_FILENO);
			sprintf(idProbador, "%d", i+1);
			if(execl("./pruebaCalidad","./pruebaCalidad",argv[3],idProbador,argv[1],argv[4],(char*)NULL) == -1)
				perror("Error ejecutando pruebaCalidad\n");
			break;
		}
		
	}
	int result;
	char mensajeFichero[100];
	char okONok[4];
	struct prueba miPrueba;
	while(1)
	{
		//Leo por la tubería donde antes he escrito
		read(tuberia[0], &miPrueba, sizeof(miPrueba));
		
		//Espero hasta que el semáforo sea verde y lo pongo rojo
		semaforo.sem_op = -1;
		result = semop(semID,&semaforo,1);
		
		if(miPrueba.resulPrueba == 0)
		{
			memoria->nok ++;
			strcpy(okONok,"NOK");
		}
		else if (miPrueba.resulPrueba == 1)
		{
			memoria->ok++;
			strcpy(okONok,"OK");
		}
		memoria->pruebasRealizadas++;
		
		//Paso el semáforo a verde
		semaforo.sem_op = 1;
		result = semop(semID,&semaforo,1);
		
		sprintf(mensajeFichero,"Prueba %d del probador %d sobre la mercancia %ld con resultado %s\n",miPrueba.numeroPrueba,atoi(argv[1]),miPrueba.idMercancia,okONok);
		write(fichero,&mensajeFichero,strlen(mensajeFichero));
	}
}
