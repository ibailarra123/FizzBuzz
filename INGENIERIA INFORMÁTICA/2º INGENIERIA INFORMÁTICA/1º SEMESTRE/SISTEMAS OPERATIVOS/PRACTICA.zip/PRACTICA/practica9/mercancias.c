#include <stdio.h>
#include <stdlib.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/msg.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>

#define FIFONAME "fifo"	

struct mensaje { 
    long idMercancia; 
    struct tm instante;
    int resultadoPrueba;
    int numeroPrueba;
    int probadorID;
};

int main(int argc, char *argv[])
{
    printf("Mercancia: %d\n",getpid());
    
    struct mensaje miMensaje;
    
    int fifo_a = open(FIFONAME, O_WRONLY);
    
    miMensaje.numeroPrueba=0;

    while(1){
        
        sleep(atoi(argv[2]));

        time_t tiempo = time(0); 
        
        miMensaje.idMercancia = getpid();
        miMensaje.instante= *(localtime(&tiempo));;
        miMensaje.resultadoPrueba = -1;
        
        write(fifo_a, &miMensaje, sizeof(miMensaje));
        
        miMensaje.numeroPrueba=miMensaje.numeroPrueba + 1;
    }
}
