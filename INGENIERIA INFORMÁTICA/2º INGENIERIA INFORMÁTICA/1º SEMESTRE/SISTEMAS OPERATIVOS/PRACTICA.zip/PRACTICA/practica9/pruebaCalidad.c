#include <stdio.h>
#include <stdlib.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/wait.h>
#include <sys/sem.h>
#include <sys/msg.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>

struct mensaje { 
    long idMercancia; 
    struct tm instante;
    int resultadoPrueba;
    int numeroPrueba;
    int probadorID;
};

struct prueba { 
         long idMercancia; 
         int resulPrueba;   
         int numeroPrueba; 
         int probadorID; 
};

int main(int argc, char *argv[])
{
	fprintf(stderr, "Se ha creado el probador %d\n", getpid());
	
    struct prueba prueba1;
	prueba1.numeroPrueba = 0;
    
	struct mensaje miMensaje;
    
	int claveCola = atoi(argv[1]) + atoi(argv[3]);
	int cola = msgget(claveCola, 0777);
	while(1)
	{
		
		//Recibir el mensaje de la cola de mensajes
		msgrcv(cola,&miMensaje,(sizeof(miMensaje)-sizeof(long)),0,0);
	
		sleep(atoi(argv[4]));
		
        double n; 
		
        srand((unsigned)time(NULL) + getpid()); 
		n = (double) rand()/RAND_MAX; //número en [0,1] 
		if (n < 0.5) prueba1.resulPrueba = 0; 
		else prueba1.resulPrueba =1; 
		
		prueba1.idMercancia = miMensaje.idMercancia;
		prueba1.numeroPrueba += 1;
		prueba1.probadorID = getpid();
		
		if(prueba1.numeroPrueba %5 == 0)
		{
			fprintf(stderr, "Probador %d descansando tras %d pruebas realizadas\n", getpid(),prueba1.numeroPrueba);
			sleep(3);
		}
		
		//Mandar el mensaje
		write(STDOUT_FILENO, &prueba1, sizeof(prueba1));
	}
}
