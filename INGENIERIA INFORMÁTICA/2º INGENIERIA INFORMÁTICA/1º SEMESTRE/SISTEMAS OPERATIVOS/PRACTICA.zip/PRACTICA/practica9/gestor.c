#include <stdio.h>
#include <stdlib.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/wait.h>
#include <sys/sem.h>
#include <sys/msg.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>

#define FIFONAME "FIFO"

struct indicador{
		int ok;
		int nok;
		int pruebasRealizadas;
	};

struct mensaje { 
    long idMercancia; 
    struct tm instante;
    int resultadoPrueba;
    int numeroPrueba;
    int probadorID;
};

int x,shmid,semID,colas[];

void funcionFin(){
	printf("El programa procede a terminar\n");
	//ELIMINACIÓN FIFO
	remove(FIFONAME);
	
	//ELIMINACION ZONA DE MEMORIA
	if(shmctl(shmid,IPC_RMID,NULL) == -1)
		perror("Error eliminando la zona de memoria\n");
	
	//ELIMINACION DEL SEMAFORO
	int borrar = semctl(semID,0,IPC_RMID);
	if(borrar == -1)
		perror("Error al borrar el semáforo");
		
	//ELIMINACION DE LAS COLAS
	for(int i = 0; i<x; i++)
	{
		if(msgctl(colas[i],IPC_RMID,NULL) == -1)
			perror("Error al borrar las colas\n");
	}
	//ELIMINACION DEL PROPIO PROCESO
	kill(getpid(),SIGKILL);
}

int main(int argc, char *argv[])
{
	
    signal(SIGINT,funcionFin);
    
	key_t clave = ftok("/tmp",atoi(argv[1]));
	printf("He creado la clave: %d\n",clave);
	
	//CREACIÓN DE ZONA DE MEMORIA
	shmid = shmget (clave, (sizeof(struct indicador)), IPC_CREAT |SHM_R | SHM_W | 0666);
	if(shmid == -1)
		perror("Error en la creación de zona de memoria");
	else
		printf("He creado la zona de memoria: %d\n",shmid);
    
    //INICIALIZAR LA ZONA DE MEMORIA
	struct indicador* memoria = (struct indicador*)shmat(shmid, NULL, 1);
	if ((void*)memoria == (void*)-1)
		perror("Error vinculando la memoria");
	memoria->ok = 0;
	memoria->nok = 0;
	memoria->pruebasRealizadas = 0;
		
	//CREACIÓN DEL SEMÁFORO
	semID = semget(clave,1, 0640 | IPC_CREAT);
	if(semID == -1)
		perror("Error en la creación del semáforo");
	else
		printf("He creado el semáforo con id: %d\n",semID);
	
	//INICIALIZAR EL SEMÁFORO
	union semun 
	{ 
		int val;               
		struct semid_ds *buf;  
		ushort *array;         
	};	
	union semun arg;
	arg.val = 1/*Verde*/; //0 = ROJO
	int result1 = semctl(semID,0, SETVAL,arg);
	if(result1 == -1)
		perror("Error en la inicialzación del semáforo");
	
	
    //CREACIÓN DEL FIFO
	if(mkfifo(FIFONAME, S_IFIFO|0660) == -1)
		perror("Error creando la FIFO\n");
	else
		printf("[GESTOR] FIFO creada correctamente\n");
		
	//CREACIÓN INSTANCIAS DE MERCANCIA
	for(int i = 0; i < atoi(argv[2]); i++)
	{
		pid_t hijoPid = fork();
		
		if (hijoPid <= 0)//HIJO
			execl("./mercancia","./mercancia",argv[5],(char*)NULL);
	}
	
	//CREADOR DE LAS COLAS E INSTANCIAS DE EQUIPOSUPERVISOR
	x = atoi(argv[3]);
	colas[atoi(argv[3])];
	char idEquipoSupervisor[3];
	for(int i = 0; i < atoi(argv[3]);i++)
	{
		colas[i] = msgget(atoi(argv[1]) + (i + 1), 0777| IPC_CREAT);
		if (colas[i] == -1)
			perror("Error creando la cola");
			
		pid_t hijoPid2 = fork();
		
		if(hijoPid2 <= 0) //HIJO
		{
			sprintf(idEquipoSupervisor, "%d", i+1);
			if((execl("./equipoSupervisor","./equipoSupervisor",idEquipoSupervisor,argv[4],argv[1],argv[6],(char*)NULL)) == -1)
				perror("Error ejecutando equipoSupervisor\n");
		}
	}
	
	//LEO MENSAJE DE LA FIFO CON MERCANCIA Y LO MANDO SECUENCIALMENTE POR LAS COLAS
	int i = 1;
	int fifo_a = open(FIFONAME, O_RDONLY);
	struct mensaje miMensaje;
	
	while(1)
	{
		//LECTURA DE FIFO
		read(fifo_a, &miMensaje, sizeof(miMensaje));
		
		if(msgsnd(colas[i%atoi(argv[3])],&miMensaje,(sizeof(miMensaje)-sizeof(long)),IPC_NOWAIT) == -1)
			perror("Error enviando el mensaje");
			
		if (i > 10) i = 0;
		i++;
		}
            
	
	
	
	
	
	
	
}
