#include <stdbool.h>

char** fragmenta(const char*);

void borrarg(char **arg);
