#include<stdio.h>
#include "fragmenta.h"
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <sys/wait.h> 
#include <pthread.h> 


int main(void) {
    char *input=(char*)malloc(100);
    int status;
    int fp;
    int pos_operando;
    int opcion;
    int i;
    while(1){
        printf("minishell""\\""> ");
        scanf("%[^\n]", input);
        fgetc(stdin);
        
        char **frags;
        
        pid_t pid = fork();
        if(pid == 0){
            frags = fragmenta(input);
            i=0;
            while(frags[i]!=NULL){
                if (strcmp(frags[i],"exit")== 0){
                    kill(getppid(),SIGTERM);
                    sleep(1);
                    exit(0);
                }
                
                else if (strcmp(frags[i],">")== 0){
                    pos_operando=i;
                    fp = open(frags[pos_operando+1],O_WRONLY | O_CREAT | O_TRUNC, 0600);
                    dup2(fp,STDOUT_FILENO);
                    close(fp);
                    frags[pos_operando]=NULL;
                }
                
                else if (strcmp(frags[i],"<")== 0){
                    pos_operando=i;
                    fp = open(frags[pos_operando+1],O_RDONLY);
                    dup2(fp,STDIN_FILENO);
                    close(fp);
                    frags[pos_operando]=NULL;
                }
                
                else if (strcmp(frags[i],">>")== 0){
                    pos_operando=i;
                    fp = open(frags[pos_operando+1],O_WRONLY | O_APPEND | O_TRUNC, 0600);
                    dup2(fp,STDOUT_FILENO);
                    close(fp);
                    frags[pos_operando]=NULL;
                }
                
                else if (strcmp(frags[i],"|")== 0){
                    pos_operando=i;
                    int tuberia[2];
                    pipe(tuberia);
                    pid_t pid2=fork();
                    if(pid2 == 0){
                        close(tuberia[0]);
                        dup2(tuberia[1],STDOUT_FILENO);
                        frags[pos_operando]=NULL;
                    }
                    else if(pid2 >0){
                        close(tuberia[1]);
                        dup2(tuberia[0],STDIN_FILENO);
                        waitpid(pid2,&status,0);
                        execvp(frags[pos_operando+1],&frags[pos_operando+1]);
                    }
                }
                i=i+1;
            }
            execvp(frags[0],&frags[0]);
            exit(7);
        }
        else if (pid >0){
            waitpid(pid,&status,0);
        }
    }
}
