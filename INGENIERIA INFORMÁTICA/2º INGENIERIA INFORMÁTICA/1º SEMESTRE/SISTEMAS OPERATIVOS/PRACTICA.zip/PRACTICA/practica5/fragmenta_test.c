#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fragmenta.h"

int main(int argc, char **argv)
{

  if (argc <= 2)
    return (-1);

  int arguments_size = 0;

  int i = 1;
  while (argv[i] != NULL)
  {
    arguments_size += sizeof(argv[i]);
    i++;
  }
  arguments_size += sizeof(" ") * (argc - 2);

  printf("Hay %d argumentos y ocupan %d bytes\n", argc - 2, arguments_size);
  char *test = (char *)malloc(arguments_size);

  i = 1;
  while (argv[i] != NULL)
  {
    strcat(test, argv[i]);
    if (argv[i + 1] != NULL)
      strcat(test, " ");
    i++;
  }

  printf("test: %s\n", test);

  char **f = fragmenta(test);

  i = 0;
  while (f[i] != NULL)
  {
    printf("fragmento: %s\n", f[i]);
    i++;
  }
  borrarg(f);
}
