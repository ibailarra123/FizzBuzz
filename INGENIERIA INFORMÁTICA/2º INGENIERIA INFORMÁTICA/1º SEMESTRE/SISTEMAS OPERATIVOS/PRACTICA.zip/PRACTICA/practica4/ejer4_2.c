#include <stdio.h> 
#include <sys/types.h> 
#include <unistd.h> 
#include <sys/wait.h>
#include <stdlib.h>
#include <errno.h>
#include <pthread.h> 
#include <sys/types.h>  
#include <signal.h> 
#include <fcntl.h>

void mifuncion1(int signum);
void mifuncion2(int signum);
int funciona=0;
int contador=0;
int main(void){
    int cr;
    pid_t pid=fork();
    signal(SIGUSR1,mifuncion1);
    if(pid>0){
        printf("Introduzca 0 para salir\n");
        printf("Introduzca 1 para comenzar/parar el cronómetro\n");
        printf("Introduzca 2 para resetear el cronómetro\n");
        scanf("%d",&cr);
        while(1){
            if(cr==0) {
                sleep(1);
                kill(pid,SIGKILL);
                exit(0);
            }
            else if(cr==1) {
                sleep(1);
                kill(pid, SIGUSR1);
            }
            else if(cr==2) {
                sleep(1);
                kill(pid, SIGUSR2);
            }
        }
    }
    else if(pid==0){
        while(1){
            pause();
            if(funciona==1){
                printf("%d",contador);
                contador=contador+1;
            }
        }
    }
    return 0;
}
void mifuncion1(int signum){
    if(funciona==0)
        funciona=1;
    else
        funciona=0;
}

void mifuncion2(int signum){
    contador=0;
}
