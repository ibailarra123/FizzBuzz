#include <stdio.h> 
#include <sys/types.h> 
#include <unistd.h> 
#include <sys/wait.h>
#include <stdlib.h>
#include <errno.h>
#include <pthread.h> 
#include <sys/types.h>  
#include <signal.h> 
#include <fcntl.h>

void mifuncion1(int signum);
void mifuncion2(int signum);
int i=0;
int main(void){
    int j;
    signal(SIGUSR1,mifuncion1);
    signal(SIGUSR2,mifuncion2);
    pid_t pid=fork();
    if(pid>0){
        for(j=0;j<5;j=j+1){
            sleep(1);
            kill(pid,SIGUSR1);
            sleep(1);
            pause();
            printf("Mensaje %d\n",i);
        }
        
    }
    else if(pid==0){
        for(j=0;j<5;j=j+1){
            pause();
            printf("Mensaje %d\n",i);
            i=i+1;
            sleep(1);
            kill(getppid(),SIGUSR2);
            sleep(1);
        }
        exit(0);
    }
}
void mifuncion1(int signum){
    i=i+1;
}

void mifuncion2(int signum){
    i=i+1;
}



