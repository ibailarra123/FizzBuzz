#include <stdio.h> 
#include <sys/types.h> 
#include <unistd.h> 
#include <sys/wait.h> 
#include <errno.h>
 
int main(int argc, char* argv[]) { 
    char p[100];
    char *const argv2[] = {NULL};
    int status;
    printf("Por favor introduzca el programa a ejecutar:\n");
    scanf("%s",p);
    pid_t pid = fork();
    if(pid == 0){
        execv(p,argv2);
    }
    else if (pid >0){
        waitpid(pid,&status,0);
    }
    return (0); 
} 
