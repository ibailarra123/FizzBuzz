#include <stdio.h> 
#include <sys/types.h> 
#include <unistd.h> 
#include <sys/wait.h> 
#include <errno.h>
 
int main(int argc, char* argv[]) { 
    int a,b,c,d,e,pa,pb,pc,pd,pe;
    int status= 0;
    pid_t pid=fork();
    if(pid==0){
        sleep(1);
        a = getpid();
        pa = getppid();
        printf("Yo soy el %d y mi padre es el %d \n",a,pa);
        pid_t pid2 = fork();
        if (pid2 ==0){
            sleep(1);
            b = getpid();
            pb = getppid();
            printf("Yo soy el %d y mi padre es el %d \n",b,pb);
            pid_t pid3 = fork();
            if (pid3 ==0){
                sleep(1);
                c = getpid();
                pc = getppid();
                printf("Yo soy el %d y mi padre es el %d \n",c,pc);
                pid_t pid4 = fork();
                if (pid4 ==0){
                    sleep(1);
                    d = getpid();
                    pd = getppid();
                    printf("Yo soy el %d y mi padre es el %d \n",d,pd);
                    pid_t pid5 = fork();
                    if (pid5 ==0){
                        sleep(1);
                        e = getpid();
                        pe = getppid();
                        printf("Yo soy el %d y mi padre es el %d \n",e,pe);
                    }
                    else if (pid5 >0){
                        waitpid(pid5,&status,0);
                    }
                }
                else if (pid4 >0){
                    waitpid(pid4,&status,0);
                }
            }
            else if (pid3 >0){
                waitpid(pid3,&status,0);
            }
        }
        else if (pid2 >0){
            waitpid(pid2,&status,0);
        }
    }
    else if (pid >0){
        waitpid(pid,&status,0);
    }
    return 0;

} 
