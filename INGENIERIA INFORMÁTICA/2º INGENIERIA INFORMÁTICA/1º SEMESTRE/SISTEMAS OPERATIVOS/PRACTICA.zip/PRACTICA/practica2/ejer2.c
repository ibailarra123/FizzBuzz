#include <stdio.h> 
#include <sys/types.h> 
#include <unistd.h> 
#include <sys/wait.h> 
#include <errno.h>
 
int main() { 
    pid_t pid=fork();
    int a,b,c,pa,pb,pc,d,pd,status;
        if (pid >0){
            a = getpid();
            pa = getppid();
            printf("aYo soy el %d y mi padre es el %d \n",a,pa);        
        }
        else if(pid==0){
            b = getpid();
            pb = getppid();
            printf("bYo soy el %d y mi padre es el %d \n",b,pb);
            waitpid(pid,&status,0);
            pid_t pid2=fork();
            if (pid2 >0){
                c = getpid();
                pc = getppid();
                printf("cYo soy el %d y mi padre es el %d \n",c,pc); 
                waitpid(pid2,&status,0);
                
            }
            else if (pid2 ==0){
                d = getpid();
                pd = getppid();
                printf("dYo soy el %d y mi padre es el %d \n",d,pd);
                waitpid(pid2,&status,0);
            }
        }
    return (0); 
} 









                                  
