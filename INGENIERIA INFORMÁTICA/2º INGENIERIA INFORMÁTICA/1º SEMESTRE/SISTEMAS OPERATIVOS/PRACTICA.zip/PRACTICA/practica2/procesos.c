#include <stdio.h> 
#include <sys/types.h> 
#include <unistd.h> 
#include <sys/wait.h> 
#include <errno.h>
 
int main() { 
    pid_t pid=fork();
    int status,a,b,c,pa,pb,pc;
    if(pid==0){
        a = getpid();
        pa = getppid();
        printf("Yo soy el %d y mi padre es el %d \n",a,pa);
        pid_t pid2 = fork();
        if (pid2 ==0){
            b = getpid();
            pb = getppid();
            printf("Yo soy el %d y mi padre es el %d \n",b,pb);
            pid_t pid3 = fork();
            if (pid3 ==0){
                c = getpid();
                pc = getppid();
                printf("Yo soy el %d y mi padre es el %d \n",c,pc);
            }
            else if (pid3 >0){
                waitpid(pid3,&status,0);
            }
        }
        else if (pid2 >0){
            waitpid(pid2,&status,0);
        }
    }
    else if (pid >0){
        waitpid(pid,&status,0);
    }
    return (0); 
} 
