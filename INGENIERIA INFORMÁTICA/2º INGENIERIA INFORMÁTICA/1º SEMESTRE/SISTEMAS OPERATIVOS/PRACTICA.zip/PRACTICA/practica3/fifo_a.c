#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h> 

#define FIFOA "fifoa"
#define FIFOB "fifob"



int main(){
    struct mensaje {
        int count, pid;
    } mensaje;
    mensaje.count=10;
    mkfifo(FIFOA,0660);
    mkfifo(FIFOB,0660);
    int fp_a,fp_b;
    fp_a = open(FIFOA,O_WRONLY);
    fp_b = open(FIFOB,O_RDONLY);
    while(mensaje.count != 0){
        write(fp_a,&mensaje,sizeof(mensaje));
        read(fp_b,&mensaje,sizeof(mensaje));
        printf("El mensaje es %d\n",mensaje.pid);
        mensaje.pid = mensaje.pid+1;
        mensaje.count = mensaje.count-1;
    }
    close(fp_a);
    close(fp_b);
    remove(FIFOA);
    remove(FIFOB);
    exit(0);
}
