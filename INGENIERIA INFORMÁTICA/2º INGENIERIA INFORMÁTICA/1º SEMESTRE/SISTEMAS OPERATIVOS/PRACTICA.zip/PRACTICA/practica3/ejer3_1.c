#include <stdio.h> 
#include <sys/types.h> 
#include <unistd.h> 
#include <sys/wait.h>
#include <stdlib.h>
#include <errno.h>
#include <pthread.h> 
struct mensaje{
    int count,pid;
}mensaje;
int main(void){
    mensaje.count = 10;
    int pipea[2];
    int pipeb[2];
    pipe(pipea);
    pipe(pipeb);
    pid_t pid = fork();
    if(pid == 0){
        while(mensaje.count != 0){
            read(pipea[0],&mensaje,sizeof(mensaje)); // devuelve el numero de bytes que hemos leido.
            printf("El mensaje es: %d\n",mensaje.pid);
            mensaje.pid +=1;
            write(pipeb[1],&mensaje,sizeof(mensaje)); // el hijo escribe tras leer.
            mensaje.count -= 1;
        }
    }
    else{
        while(mensaje.count != 0){
            write(pipea[1],&mensaje,sizeof(mensaje)); //el padre empieza escribiendo
            read(pipeb[0],&mensaje,sizeof(mensaje)); // ahora el padre lee
            printf("El mensaje es: %d\n",mensaje.pid);
            mensaje.pid +=1;
            mensaje.count -= 1;
        }
        }
}
