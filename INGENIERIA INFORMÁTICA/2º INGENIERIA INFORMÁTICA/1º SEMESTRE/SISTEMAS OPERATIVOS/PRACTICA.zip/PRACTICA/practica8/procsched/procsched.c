#include <stdio.h>
#include <stdlib.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/wait.h>
#include <sys/msg.h>
#include <string.h>
#include <signal.h>
#include <errno.h>
#include <unistd.h>
#include <stdbool.h>
#include "fragmenta.h"

#define STLEN 100

pid_t hijoPid;
pid_t nietoPid;
int cola;
char cadena[100];
FILE* fichero;
int cambiosContexto = 0;
int nivel1 = 0;
int nivel2 = 0;
struct sigaction comoParo;

struct miMensaje { 
    long prioridad;        
    char comando[100];
    bool haSidoEjecutado;
    pid_t pidEjecutor;
}; 
struct miMensaje mensaje;

void funcionFinNieto()
{
	printf("\nEl programa procede a matar a hijos y nietos\n");
	printf("Cambios de contexto: %d\n", cambiosContexto);
	printf("Procesos ejecutados de nivel 1 : %d\n",nivel1);
	printf("Procesos ejecutados de nivel 2 : %d\n",nivel2);
	
	if(nietoPid > 0)
	{
		kill(nietoPid,SIGKILL);
	}
}

void funcionFin()
{
	printf("\nEl programa procede a terminar\n");
	sleep(2);
	if(hijoPid > 0)
	{
		kill(hijoPid,SIGKILL);
	}
	//Borramos la cola de mensajes
	if(msgctl(cola, IPC_RMID,NULL) == -1)
		perror("Error eliminado la cola de mensajes\n");
	kill(getpid(),SIGKILL);
}

void parada()
{
	printf("Se acabó\n");
	mensaje.haSidoEjecutado = true;
}

void funcionInterrupcion()
{
	kill(nietoPid,SIGSTOP);
}

int main(int argc, char *argv[])
{
	
	//Creo la clave y la cola
	key_t clave = ftok("/tmp",27);
		
	cola = msgget(clave, 0777| IPC_CREAT);
	if (cola == -1)
		perror("Error creando la cola");
		
	hijoPid = fork();
	int espera = 0;
	
	if (hijoPid > 0)//PADRE
	{
		signal(SIGINT,funcionFin);
		if (argv[1] != NULL)
		{
			fichero = fopen(argv[1],"r"); //Encolo por fichero
			while (!feof(fichero))
			{
				fgets(cadena,STLEN,fichero);
				if(feof(fichero))
					break;
				mensaje.prioridad = (long)atoi(&cadena[0]); //Nota: recuerdo que el atoi convierte un char en un int
				strcpy(mensaje.comando,cadena);
				mensaje.pidEjecutor = '5';
				printf("Mando el mensaje: %s\n",mensaje.comando);
				if(msgsnd(cola,&mensaje,(sizeof(mensaje)-sizeof(long)),IPC_NOWAIT) == -1)
					perror("Error enviando el mensaje");
			}
		}
		else
		{
			fichero = stdin; //Encolo por teclado
			while (!feof(fichero))
			{
				printf("\nIntroduce tu comando: ");
				fgets(cadena,STLEN,fichero);
				cadena[strcspn(cadena, "\n")] = 0;

				mensaje.prioridad = (long)atoi(&cadena[0]); //Nota: recuerdo que el atoi, convierte un char en un int
				strcpy(mensaje.comando,cadena);
				mensaje.pidEjecutor = '5';
				
				if(mensaje.prioridad == 1 || mensaje.prioridad == 2 || mensaje.prioridad == 3)
				{
					kill(hijoPid,SIGUSR2);
				}
				
				printf("Mando el mensaje: %s de prioridad %ld\n",mensaje.comando,mensaje.prioridad);
				if(msgsnd(cola,&mensaje,(sizeof(mensaje)-sizeof(long)),IPC_NOWAIT) == -1)
					perror("Error enviando el mensaje");
			}
		}
		wait(&espera); //Espero a que todos mis hijos terminen la ejecución
	}
	else //HIJO
	{
		signal(SIGUSR2,funcionInterrupcion);
		signal(SIGINT,funcionFinNieto);
		comoParo.sa_flags = SA_NOCLDSTOP;
		comoParo.sa_handler = parada;
		sigaction(SIGCHLD,&comoParo,NULL);
		while(1)
		{
			if(msgrcv(cola,&mensaje,(sizeof(mensaje)-sizeof(long)),1,IPC_NOWAIT) != -1)
				printf("He encontrado mensaje de tipo 1\n");
			else if(msgrcv(cola,&mensaje,(sizeof(mensaje)-sizeof(long)),2,IPC_NOWAIT) != -1)
				printf("He encontrado mensaje de tipo 2\n");
			else if(msgrcv(cola,&mensaje,(sizeof(mensaje)-sizeof(long)),3,IPC_NOWAIT) != -1)
				printf("He encontrado mensaje de tipo 3\n");
			else if(msgrcv(cola,&mensaje,(sizeof(mensaje)-sizeof(long)),4,IPC_NOWAIT) != -1)
				printf("He encontrado mensaje de tipo 4\n");
			else if(msgrcv(cola,&mensaje,(sizeof(mensaje)-sizeof(long)),0,0))
				printf("He encontrado mensaje\n");	
				
			if(mensaje.prioridad == 1)
			{
				nivel1++;
				cambiosContexto++;
				nietoPid = fork();
				mensaje.pidEjecutor = nietoPid;
				if(nietoPid > 0)
				{
					waitpid(nietoPid,&espera,0);
				}
				else
				{
					printf("Mensaje recibido de prioridad %ld: %s\n",mensaje.prioridad,mensaje.comando);
					char **f = fragmenta(mensaje.comando);
					execvp(f[1],&f[1]);
				}
			}
			else if(mensaje.prioridad == 2)
			{
				nivel1++;
				cambiosContexto++;
				nietoPid = fork();
				mensaje.pidEjecutor = nietoPid;
				if(nietoPid > 0)
				{
					waitpid(nietoPid,&espera,0);
				}
				else
				{
					printf("Mensaje recibido de prioridad %ld: %s\n",mensaje.prioridad,mensaje.comando);
					char **f = fragmenta(mensaje.comando);
					execvp(f[1],&f[1]);
				}
			}
			else if(mensaje.prioridad == 3)
			{
				nivel1++;
				cambiosContexto++;
				nietoPid = fork();
				mensaje.pidEjecutor = nietoPid;
				if(nietoPid > 0)
				{
					waitpid(nietoPid,&espera,0);
				}
				else
				{
					printf("Mensaje recibido de prioridad %ld: %s\n",mensaje.prioridad,mensaje.comando);
					char **f = fragmenta(mensaje.comando);
					execvp(f[1],&f[1]);
				}
			}
			else if(mensaje.prioridad == 4)
			{
				if(mensaje.pidEjecutor =='5')
				{
					nietoPid = fork();
					mensaje.pidEjecutor = nietoPid;
				}
				if(nietoPid > 0)
				{
					kill(mensaje.pidEjecutor,SIGCONT);
					sleep(3);
					if(mensaje.haSidoEjecutado == false)
					{
						kill(mensaje.pidEjecutor,SIGSTOP);
						cambiosContexto++;
						if(msgsnd(cola,&mensaje,(sizeof(mensaje)-sizeof(long)),IPC_NOWAIT) == -1)
							perror("Error enviando el mensaje");
					}
					else
					{
						cambiosContexto++;
						nivel2++;
						printf("No reencolo\n");
					}
				}
				else
				{
					printf("Mensaje recibido de prioridad %ld: %s\n",mensaje.prioridad,mensaje.comando);
					char **f = fragmenta(mensaje.comando);
					execvp(f[1],&f[1]);				
				}
			}
		}
	}
}
