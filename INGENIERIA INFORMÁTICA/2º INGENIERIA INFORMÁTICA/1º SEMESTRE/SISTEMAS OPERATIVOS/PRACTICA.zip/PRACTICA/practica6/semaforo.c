#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <sys/types.h>  
#include <sys/ipc.h> 
#include <sys/ipc.h> 
#include <sys/shm.h>
#include <sys/sem.h>

//rojo = -1
//verde>1

union semun { 
    int val;               
    struct semid_ds *buf;  
    ushort *array;         
};

int main(int argc, char ** argv){
    key_t key =ftok(argv[1],42);
    int shid= shmget(key ,atoi(argv[2])*sizeof(int),IPC_CREAT | 0777);
    int sem_id=semget(key,1,IPC_CREAT | 0640);
    union semun sem;/////////////
    sem.val = 1;
    semctl(sem_id,0,SETVAL,sem);///para poner en verde inicializacion
    pause();
}
