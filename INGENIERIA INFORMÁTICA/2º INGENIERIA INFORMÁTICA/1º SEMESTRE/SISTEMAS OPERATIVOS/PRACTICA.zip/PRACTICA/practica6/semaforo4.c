#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <sys/types.h>  
#include <sys/ipc.h> 
#include <sys/ipc.h> 
#include <sys/shm.h>
#include <sys/sem.h>

void sem_set(int sem_group_id, int op);

int main(int argc, char ** argv){
    key_t key =ftok(argv[1],42);
    int shid= shmget(key ,(atoi(argv[2]))*(sizeof(int)),IPC_CREAT | 0777);
    int sem_id = semget(key,1,IPC_CREAT | 0640);
    int*shmstart = (int*)shmat(shid,NULL,0);
    sem_set(sem_id,-1);
    *(shmstart)= atoi(argv[3]);
    sem_set(sem_id,1);
}


void sem_set(int sem_group_id, int op){  ///para pasar de verde a rojo
    struct sembuf sem_action;
    sem_action.sem_num=0;
    sem_action.sem_op =op;
    sem_action.sem_flg=0;
    semop(sem_group_id,&sem_action,1);
}
