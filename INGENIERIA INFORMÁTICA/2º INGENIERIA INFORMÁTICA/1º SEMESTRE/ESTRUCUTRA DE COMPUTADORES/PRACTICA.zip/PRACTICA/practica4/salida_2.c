/* Llamada al sistema desde C
Prototipo: int syscall(int number, ...);
man syscall
*/

#define _GNU_SOURCE
#include <unistd.h>
#include <sys/syscall.h>

void main (void)
{
    syscall (__NR_exit,0xFF);
        }
