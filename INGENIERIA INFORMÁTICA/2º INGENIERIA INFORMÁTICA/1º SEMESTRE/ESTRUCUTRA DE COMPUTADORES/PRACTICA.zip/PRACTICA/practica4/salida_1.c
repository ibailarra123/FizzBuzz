#include <stdlib.h>
void main (void)
{
    exit (0xFF);
        }
