import java.io.*;
public class cubo{
    public static void main(String[] args) throws IOException {
    //Inicializ. de las variables
        int num,cubo1;
        String textoNum;
        BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("Introduce un número entero positivo: ");
        textoNum = teclado.readLine();
        Integer intnum = Integer.valueOf(textoNum);
        num = intnum.intValue();
        cubo1 = (num * num * num);
        System.out.println("El cubo de " + num + " es " + cubo1 + "");

    }
}
