/**
* Paquete para ejecutar el Hola Mundo
Grado en Ingeniar ́ıa inform ́atica. Pr ́acticas de Ingenier ́ıa del software. 18
*/
package util;
import holamundo.HolaMundoO;
public class EjecutorHolaMundoO {
HolaMundoO hola;
public EjecutorHolaMundoO(){
hola=new HolaMundoO();
hola.mostrarSaludo();
}
public static void main(String[] args) {
EjecutorHolaMundoO ejecutor=new EjecutorHolaMundoO();
}
}
