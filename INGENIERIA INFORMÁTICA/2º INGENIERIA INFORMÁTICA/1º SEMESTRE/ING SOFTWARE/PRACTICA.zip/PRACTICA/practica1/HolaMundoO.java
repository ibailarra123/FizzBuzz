/**
* Esta clase que saca por pantalla la frase Hello World
*/
/* la linea de importaciones se incluye por motivos didacticos.
* En este ejemplo no es realmente necesaria
*/
package holamundo;
import java.lang.String;
import java.lang.System;
public class HolaMundoO {
String saludo;
//Creamos el constructor de la clase
public HolaMundoO() {
saludo = "Hola mundo"; //El constructor inicia las propiedades
}
public void mostrarSaludo(){
System.out.println(saludo);
}
}
