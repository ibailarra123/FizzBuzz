import java.io.*;
public class Dado{
    public static void main(String[] args) throws IOException {
        //Inicializ. de las variables
        int Num1 = (int)(Math.random()*6) + 1;
        System.out.print("El lanzamiento del primer dado es \n" + Num1);
        int Num2 = (int)(Math.random()*6) + 1;
        System.out.print("El lanzamiento del segundo dado es \n" + Num2);
        int Num3 = Num1 + Num2;
        System.out.print("El total de los dos lanzamientos es " + Num3);
    }
}
