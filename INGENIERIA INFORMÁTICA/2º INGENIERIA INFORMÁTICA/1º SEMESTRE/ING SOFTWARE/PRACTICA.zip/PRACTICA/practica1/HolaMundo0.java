/**
* Esta clase que saca por pantalla la frase Hello World
*/
/* la linea de importaciones se incluye por motivos didacticos.
* En este ejemplo no es realmente necesaria
*/
import java.lang.*;
public class HolaMundo0 {
String saludo; //La clase String se importa de java.lang
public HolaMundo0() {
saludo = "Hola mundo"; //El constructor inicia las propiedades
}
public void mostrarSaludo(){
System.out.println(saludo); //se importa de java.lang
}
}
