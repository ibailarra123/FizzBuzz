import java.io.*;
public class cubomod{
    public static void main(String[] args){
        // Lee el primer argumento pasado por la linea de comandos
        int cubo1;
        int num = Integer.parseInt(args[0]);
        cubo1 = (num * num * num);
        System.out.println("El cubo de " + num + " es " + cubo1 + "");
    }
}
