/**
* Esta clase implementa una aplicacion que saca por pantalla
* la frase Hello World
*/
/* la linea de importaciones se incluye por motivos didacticos.
* En este ejemplo no es realmente necesaria
*/
import java.lang.*;
class HolaMundo {
    public static void main(String[] args){
        System.out.println("Hola Mundo!!!!!!!!");
            //System se importa de java.lang
        }
}
