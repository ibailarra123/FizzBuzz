import java.util.Scanner;
import java.io.*;
//Se crea la clase Turno para realizar la suma del lanzamiento de los dos dados
public class Turno{
    //private Dado    =new Dado()
    private int suma;
    public int empiezaTurno(){
        //Se lanza un dado
        Dado dado =new Dado();
        dado.tirada();
        int x = dado.muestraResultado();
        System.out.println("El lanzamiento del primer dado es " + x + "\n" );
        //Se lanza otro dado;
        dado.tirada();
        int y = dado.muestraResultado();
        System.out.println("El lanzamiento del segundo dado es " + y + "\n" );
        //Se realiza la suma de los dos dados
        suma = (x + y);
        System.out.println("El total de los dos lanzamientos es " + suma + "\n" );
        return suma;
        }
}
        
