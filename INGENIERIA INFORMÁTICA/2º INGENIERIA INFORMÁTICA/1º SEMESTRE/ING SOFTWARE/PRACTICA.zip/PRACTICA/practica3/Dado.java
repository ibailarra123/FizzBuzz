//Se crea la clase Dados para lanzar los dados
public class Dado{
    //Se crea un valor privado resultado
    private int resultado;
    //Se crea un valor publico para lanzar el dado
    public void tirada(){
        resultado = (int)(Math.random()*6) + 1;
    }
    //Se crea un valor público para mostrar el lanzamiento del dado
    public int muestraResultado(){
        return resultado;
    }
}
