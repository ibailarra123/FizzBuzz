import java.util.Scanner;
import java.io.*;

public class Casino{
    public static void main(String[] args) throws IOException {
        Scanner scan = new Scanner(System.in);
        System.out.println("Introduzca el nombre del jugador1: ");
        String jugador1 = scan.nextLine();
        System.out.println("Introduzca el nombre del jugador2: ");
        String jugador2 = scan.nextLine();
        Partida p = new Partida();
        p.avanzaPartida(jugador1,jugador2);
    }
}



