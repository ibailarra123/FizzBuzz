import java.util.Scanner;
import java.io.*;
//Se crea la clase Turno para realizar la suma del lanzamiento de los dos dados
public class Turno2{
    //private Dado    =new Dado()
    private int suma,concual;
    public int empiezaTurno(int concual){
        //Se lanza un dado
        DadoBueno dado =new DadoBueno();
        dado.tirada();
        int x = dado.muestraResultado();
        System.out.println("El lanzamiento del primer dado es " + x + "\n" );
        //Se lanza otro dado;
        if (concual==1){
            DadoTrucado dado2 =new DadoTrucado();
            int y = dado2.muestraResultado();
            System.out.println("El lanzamiento del segundo dado es " + y + "\n" );
            //Se realiza la suma de los dos dados
            suma = (x + y);
            System.out.println("El total de los dos lanzamientos es " + suma + "\n" );
        }
        else if(concual==2){
            DadoBueno dado2 =new DadoBueno();
            dado2.tirada();
            int y = dado2.muestraResultado();
            System.out.println("El lanzamiento del segundo dado es " + y + "\n" );
            //Se realiza la suma de los dos dados
            suma = (x + y);
            System.out.println("El total de los dos lanzamientos es " + suma + "\n" );
        }
        return suma;
    }
}
