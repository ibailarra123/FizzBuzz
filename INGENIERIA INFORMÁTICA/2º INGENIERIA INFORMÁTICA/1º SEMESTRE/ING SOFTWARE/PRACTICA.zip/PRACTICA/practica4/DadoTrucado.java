public class DadoTrucado extends DadoBueno{
    private int resultado=1;
    public int muestraResultado(){
        return resultado;
    }
}
