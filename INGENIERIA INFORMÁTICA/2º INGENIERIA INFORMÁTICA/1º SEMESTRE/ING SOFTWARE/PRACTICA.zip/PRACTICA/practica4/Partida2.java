//Se crea la clase Partida para meter en un array las 5 sumas de las 5 tiradas
public class Partida2{
    Turno2[] tjugador =new Turno2[5];
    private int tiro1,tiro2,contador1,contador2,concual1,concual2;
    public Partida2(){
        tjugador[0]=new Turno2();
        tjugador[1]=new Turno2();
        tjugador[2]=new Turno2();
        tjugador[3]=new Turno2();
        tjugador[4]=new Turno2();
    }
    
    public void avanzaPartida(String jugador1,String jugador2,int concual1,int concual2){
        System.out.println("Comienza la partida \n" );
        contador1 =0;
        contador2 =0;
        for(int i=0;i<5;i++){
            System.out.println("Turno " + (i+1) + "\n" );
            System.out.println("Juega " + jugador1 + "\n"  );
            
            tiro1 = tjugador[i].empiezaTurno(concual1);
            if (tiro1 == 2)
                System.out.println("Enorabuena, has obtenido ojos de tigre\n" );
            
            System.out.println("Juega " + jugador2 + "\n" );
            tiro2 = tjugador[i].empiezaTurno(concual2);
            if (tiro2 ==2)
                System.out.println("Enorabuena, has obtenido ojos de tigre\n" );
            
            
            
            if (tiro1==2){
                if (tiro2!=2){
                    System.out.println( jugador1 + " ha ganado el turno " + (i+1) + " con ojos de tigre\n");
                    System.out.println(jugador1 + " gana la partida \n");
                    System.exit(0);
                }
            }
            else if (tiro2==2){
                if (tiro1!=2){
                    System.out.println( jugador2 + " ha ganado el turno " + (i+1) + " con ojos de tigre\n");
                    System.out.println(jugador2 + " gana la partida \n");
                    System.exit(0);
                }
            }
            
            
            
            if (tiro1>tiro2){
                System.out.println( jugador1 + " ha ganado el turno " + (i+1) + "\n" );
                contador1=contador1+1;
            }
            else if (tiro2>tiro1){
                System.out.println( jugador2 + " ha ganado el turno " + (i+1) + "\n" );
                contador2=contador2+1;
            }
            else
                System.out.println( "Ha habido empate en el turno " + (i+1) + "\n" );
                
        }
        if(contador1>contador2){
            System.out.println("El resultado ha sido " + contador1 + " - " + contador2 + "\n" );
            System.out.println(jugador1 + " gana la partida\n" );
        }
        else if(contador2>contador1){
            System.out.println("El resultado ha sido " + contador1 + " - " + contador2 + "\n" );
            System.out.println(jugador2 + " gana la partida\n" );
        }
        else{
            System.out.println("El resultado ha sido " + contador1 + " -" + contador2 + "\n" );
            System.out.println("Ha habido empate\n");
        }
    }
}
