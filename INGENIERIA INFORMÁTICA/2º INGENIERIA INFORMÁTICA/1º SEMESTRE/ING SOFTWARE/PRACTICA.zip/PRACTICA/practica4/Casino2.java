import java.util.Scanner;
import java.io.*;

public class Casino2{
    public static void main(String[] args) throws IOException {
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Introduzca el nombre del jugador1: ");
        String jugador1 = scan.nextLine();
        
        System.out.println("Introduzca el nombre del jugador2: ");
        String jugador2 = scan.nextLine();
        
        System.out.println(jugador1 + ", si quiere jugar con un dado trucado introduzca un 1, si quiere jugar con un dado normal introduzca 2: ");
        int concual1 = scan.nextInt();
        
        
        while (concual1 != 1 && concual1!= 2){
            System.out.println("Número introducido erróneo: ");
            System.out.println(jugador1 + ", si quiere jugar con un dado trucado introduzca un 1, si quiere jugar con un dado normal introduzca 2: ");
            concual1 = scan.nextInt();
        }
        
        System.out.println(jugador2 + ", si quiere jugar con un dado trucado introduzca un 1, si quiere jugar con un dado normal introduzca 2: ");
        int concual2 = scan.nextInt();
        
        while (concual2 != 1 && concual2!= 2){
            System.out.println("Número introducido erróneo: ");
            System.out.println(jugador2 + ", si quiere jugar con un dado trucado introduzca un 1, si quiere jugar con un dado normal introduzca 2: ");
            concual2 = scan.nextInt();
        }
        
        Partida2 p = new Partida2();
        p.avanzaPartida(jugador1,jugador2,concual1,concual2);
    }
}
