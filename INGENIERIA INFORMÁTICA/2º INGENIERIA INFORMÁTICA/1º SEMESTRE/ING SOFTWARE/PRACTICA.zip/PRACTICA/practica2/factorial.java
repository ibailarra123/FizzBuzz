import java.util.Scanner;
import java.io.*;
public class factorial {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        System.out.print("Introduce un numero entero para calcular su factorial: ");
        int num = scan.nextInt();
        int fact = 1;
        for (int b = num; b > 1; b--){
            fact = fact * b;
        }
        System.out.println("El factorial de " + num + " es: " + fact);
    }
}
