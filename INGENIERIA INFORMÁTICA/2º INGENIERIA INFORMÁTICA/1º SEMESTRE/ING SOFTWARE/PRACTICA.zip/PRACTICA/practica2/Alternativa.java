import java.util.Scanner;
import java.io.*;
public class Alternativa {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);
        System.out.print("Indique el número de lados de la figura que desea visualizar ( 3 o 4 ): ");
        int figura = scan.nextInt();
        System.out.print("Introduzca el número de líneas de la figura: ");
        int num = scan.nextInt();
        if (figura == 4){
            for (int i = 1; i < num+1; i++){
                for (int j = 1; j < num+1; j++){
                    System.out.print("* ");            
                }
                System.out.println();
            }
        }
        else {
            for (int i = 1; i < num+1; i++){
                for (int j = 1; j < num+1; j++){
                    if (i+j < num+1){
                        System.out.print(" "); 
                    }
                    else if(j<num+1){
                        System.out.print(" *");
                    }
                }
                System.out.println();
            }
        }
    }
}
