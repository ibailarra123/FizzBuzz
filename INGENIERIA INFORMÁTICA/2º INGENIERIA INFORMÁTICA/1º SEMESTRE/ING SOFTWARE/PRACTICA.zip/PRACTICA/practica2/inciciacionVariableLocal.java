import java.io.*;
class iniciacionVariableGlobal{
    public static void main(String[] args){
        int x;
        System.out.println(x);
    }
}
