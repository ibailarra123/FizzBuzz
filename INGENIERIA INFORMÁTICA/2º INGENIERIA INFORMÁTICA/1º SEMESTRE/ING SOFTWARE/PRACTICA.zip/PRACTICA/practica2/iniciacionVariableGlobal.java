import java.io.*;
class iniciacionVariableGlobal{
    public static int x;
    public static void main(String[] args){
        System.out.println(x);

    }
}


