/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package casino;

/**
 *
 * @author alumno
 */
public class CasinoExtendido {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Jugador jugadorA = new Jugador(new Dado(), new DadoTrucado(1));
        Jugador jugadorB = new Jugador(new Dado(), new DadoTrucado(6));
        Turno[] turnos = new Turno[5];
        for(int i=0; i < turnos.length; i++){
            turnos[i] = new Turno();
        }
        Partida partida = new Partida(turnos, jugadorA, jugadorB);
        partida.solicitarNombres();
        for(int j=0; j <100; j++){
            partida.jugarTurnos();
            partida.mostrarGanador();
        }
        // TODO code application logic here
    }
    
}
