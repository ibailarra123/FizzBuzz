/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package casino;

/**
 *
 * @author alumno
 */
public class Casino {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Jugador jugadorA = new Jugador(new Dado(), new Dado());
        Jugador jugadorB = new Jugador(new Dado(), new Dado());
        Turno[] turnos = new Turno[5];
        for(int i=0; i < turnos.length; i++){
            turnos[i] = new Turno();
        }
        Partida partida = new Partida(turnos, jugadorA, jugadorB);
        partida.solicitarNombres();
        partida.jugarTurnos();
        partida.mostrarGanador();
    }
    
}
