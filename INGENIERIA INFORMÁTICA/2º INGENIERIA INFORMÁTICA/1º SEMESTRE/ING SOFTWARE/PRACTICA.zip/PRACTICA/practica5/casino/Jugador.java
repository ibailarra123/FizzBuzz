/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package casino;

/**
 *
 * @author alumno
 */
public class Jugador {
    public int puntuacion;
    public boolean esOjosDeTigre;
    public String nombre;
    public int numeroTurnosGanados;
    public Dado dado1;
    public Dado dado2;
    
    public Jugador(Dado dado1, Dado dado2) {
        this.dado1 = dado1;
        this.dado2 = dado2;
        
        this.nombre = "";
        this.numeroTurnosGanados = 0;
        this.puntuacion = 0;
        this.esOjosDeTigre = false;
    }
    
    public void juega(){
        dado1.tirar();
        int resultadoDado1 = dado1.valor();
        dado2.tirar();
        int resultadoDado2 = dado2.valor();
        this.puntuacion =  resultadoDado1 + resultadoDado2;
        this.esOjosDeTigre = resultadoDado1 == 1 && resultadoDado2 == 1;
    }

    public void computarVictoria(){
        numeroTurnosGanados++;
    } 
}
