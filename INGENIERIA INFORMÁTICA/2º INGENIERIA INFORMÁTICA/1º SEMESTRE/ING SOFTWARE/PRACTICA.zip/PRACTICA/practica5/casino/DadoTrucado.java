/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package casino;

/**
 *
 * @author alumno
 */
public class DadoTrucado extends Dado {
    
    private final int valorConstante;
    
    public DadoTrucado(int valor) {
        valorConstante = valor;
    }
    
    @Override
    
    public int valor(){
        return valorConstante;
    }   
}
