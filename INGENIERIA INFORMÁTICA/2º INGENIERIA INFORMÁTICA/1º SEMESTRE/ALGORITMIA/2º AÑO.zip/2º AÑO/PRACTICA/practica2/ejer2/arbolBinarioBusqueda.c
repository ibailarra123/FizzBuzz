#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include "arbolBinarioBusqueda.h"


void nuevoArbolBB(tipoArbolBB *a){
    *a = NULL;
}

void insertar(tipoArbolBB *a, tipoElementoArbolBusqueda e){
    if(esVacio(*a)){
        celdaArbolBusqueda *nuevo;
        nuevo = (celdaArbolBusqueda*)malloc(sizeof(celdaArbolBusqueda));
        nuevo-> elem = e;
        nuevo->izda = NULL;
        nuevo->dcha = NULL;
        *a = nuevo;
    }
    else{
        if(((*a)->elem) > e)
            insertar(&((*a)->izda), e);
        else
            insertar(&((*a)->dcha), e);
    }
}

void borrar(tipoArbolBB *a, tipoElementoArbolBusqueda e){
    if(esVacio(*a))
        printf("El elemento no está en el árbol\n");
    else{
        if(((*a)->elem) > e)
            borrar(&((*a)->izda), e);
        else if(((*a)->elem) < e)
            borrar(&((*a)->dcha), e);
        else{
            celdaArbolBusqueda *nuevo;
            if(esVacio(((*a)->izda)) && esVacio(((*a)->dcha))){
                nuevo = *a;
                *a = NULL;
                free(nuevo);
            }
            else if (esVacio((*a)->izda) && (!esVacio((*a)->dcha))) {
                celdaArbolBusqueda *nuevo;
                nuevo = *a;
                *a = ((*a)->dcha);
                free(nuevo);
            }
            else if ((!esVacio((*a)->izda)) && esVacio((*a)->dcha)) {
                celdaArbolBusqueda *nuevo;
                nuevo = *a;
                *a = ((*a)->izda);
                free(nuevo);
            }
            else{
                celdaArbolBusqueda *nuevo;
                nuevo=((*a)->dcha);
                while((nuevo->izda)!= NULL)
                    nuevo=nuevo->izda;
                (*a)->elem = nuevo->elem;
                borrar(&(*a)->dcha, (*a)->elem);
            }
        }
    }
}



void mostrarPreorden(tipoArbolBB a){
    if(!(esVacio(a))){      
        printf("%d",a->elem);
        mostrarPreorden(a->izda);
        mostrarPreorden(a->dcha);
    }
}

void mostrarInorden(tipoArbolBB a){
    if(!(esVacio(a))){  
        mostrarInorden(a->izda);    
        printf("%d",a->elem);
        mostrarInorden(a->dcha);
    }
}

void mostrarPostorden(tipoArbolBB a){
    if(!(esVacio(a))){  
        mostrarPostorden(a->izda);    
        mostrarPostorden(a->dcha);
        printf("%d",a->elem);
    }
}

bool esVacio(tipoArbolBB a){
    return (a == NULL);
}