#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include "arbolBin.h"

void nuevoArbolBin(tipoArbolBin *a){
    *a = NULL;
}

bool esVacio(tipoArbolBin a){
    return(a == NULL);
}

tipoArbolBin construir(tipoElementoArbolBin e, tipoArbolBin a, tipoArbolBin b){
    celdaArbolBin *nuevo;
    nuevo =(celdaArbolBin*)malloc(sizeof(celdaArbolBin));
    nuevo->elem = e;
    nuevo->dcha = b;
    nuevo->izda = a;
    return nuevo;
}

tipoElementoArbolBin devolverRaiz(tipoArbolBin a){
    if (esVacio(a))
        printf("El árbol está vacío\n");
    else
        return a->elem;
}

void preorden(tipoArbolBin a){
    if(!(esVacio(a))){      
        printf("%d",a->elem);
        preorden(a->izda);
        preorden(a->dcha);
    }
}

void inorden(tipoArbolBin a){
    if(!(esVacio(a))){      
        inorden(a->izda);
        printf("%d",a->elem);
        inorden(a->dcha);
    }
}

void postorden(tipoArbolBin a){
    if(!(esVacio(a))){      
        postorden(a->izda);
        postorden(a->dcha);
        printf("%d",a->elem);
    }
}