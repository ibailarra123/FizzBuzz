#include "minMonticulo.h"
#include <stdio.h>
#include <stdlib.h>


int main(void){
    tipoElementoMinMonticulo num;
	tipoMinMonticulo min;
    char quiereSalir;
    int numero;
    
    do{
        printf("Introduce el número de elementos a ordenar: ");
        scanf("%d",&numero);
        nuevoMinMonticulo(&min,numero);

        printf("Introduce elementos para ordenar. \n");
        for(int i=1; i<= numero;i++){
            scanf("%d",&num);
            insertarMinMonticulo(&min,num);
        }
        printf("\n");
        printf("Los elementos ordenados son: ");
        mostrarAnchura(min);
        printf("\n");

        printf("Si desea salir pulse s, para repetir la ejecucion cualquier otra cosa.");
        scanf("\n%c", &quiereSalir);
	} while (quiereSalir != 's');
	return 0;
}