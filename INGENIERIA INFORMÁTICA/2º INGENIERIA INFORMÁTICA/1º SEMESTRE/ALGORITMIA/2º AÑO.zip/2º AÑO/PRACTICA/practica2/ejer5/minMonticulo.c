#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

typedef int tipoElementoMinMonticulo;

typedef struct tMM{
	tipoElementoMinMonticulo* array;
	int pos;
	int numEl;
}tipoMinMonticulo;

bool esVacio(tipoMinMonticulo m){
    return(m.pos == -1);
}

bool estaLleno(tipoMinMonticulo m){
    return (m.pos == m.numEl);
}


void nuevoMinMonticulo(tipoMinMonticulo* min, int a){
    min->pos=-1;
    min->array=(int *)malloc(a*sizeof(int));
    min->numEl=a;
}

void insertarMinMonticulo(tipoMinMonticulo *min, tipoElementoMinMonticulo e){
    if (estaLleno(*min))
        printf("El árbol está lleno\n");
    else{
        int aux,aux2;
        min->pos = min->pos + 1;
        (min->array)[min->pos]=e;
        aux = min->pos;
        while ((min->array)[(aux-1)/2] > -1 && (min->array)[(aux-1)/2] > e){
            aux2 = (min->array)[(aux-1)/2];
            (min->array)[(aux-1)/2] = (min->array)[aux];
            (min->array)[aux] = aux2;
            aux = (aux-1)/2;
        }
    }
}

void eliminarElemento(tipoMinMonticulo *min, tipoElementoMinMonticulo e){
    if (esVacio(*min))
        printf("El árbol está vacío\n");
    else{
        int i = 0;
        int aux;
        while ((min->array)[i] != e && i!=min->pos+1)
            i++;
        if (i==min->pos+1)
            printf("El elemento no está\n");
        else{
            aux = min->array[min->pos];
            min->array[min->pos] = min->array[i];
            min->array[i]=aux;
            min->pos = min->pos-1;
            //while(!)
        }
    }
}


tipoElementoMinMonticulo devolverRaiz(tipoMinMonticulo m){
    if (!esVacio(m))
        return((m.array[0]));
    else{
        printf("El árbol está vacío\n");
        return(-1);
    }
}

void mostrarAnchura(tipoMinMonticulo m){
    for (int i=0; i<=m.numEl; i++){
        printf("%d ",m.array[i]);
    }
}
