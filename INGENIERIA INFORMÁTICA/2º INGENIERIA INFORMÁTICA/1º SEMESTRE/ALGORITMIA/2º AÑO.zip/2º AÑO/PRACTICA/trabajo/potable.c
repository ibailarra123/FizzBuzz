#include "pilaAtributosDinamica.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <string.h>
#include <unistd.h>

int main(void){

    //Abrir fichero dataset 

    FILE *fp = fopen("data.csv","r");

    if(fp == NULL) {
        perror("Error al abrir el fichero");
        exit(1);
    }


    //Variables para leer desde csv

    char *line = NULL;          /* pointer to use with getline ()   */
    ssize_t read = 0;           /* characters read by getline ()    */
    size_t n = 0;               /* number of bytes to allocate      */
    char *sp = NULL;            /* start pointer for parsing line   */
    char *p = NULL;             /* end pointer to use parsing line  */
    int atributo ;           /* counter for field in line        */
    int fila = 0;               /* contador de numero de filas      */
    
    
    //Declaración de variables para el codigo

    char res;
    int numVecinos = 0, accion = 0, contador = 0,id = 1;

    enum r potable;
    tep atrib[NUM_FLOATS];


    //Inicialización de la pila a utilizar

    tipoPila pilaAtributos;
    nuevaPila(&pilaAtributos);


    //Saltar la primera linea del csv que contiene el nombre de los atributos

    char buf[500];
    fgets(buf, sizeof(buf), fp); //Salta la primera fila


    

    //Leer 3000 ejemplos del dataset
    while ((read = getline (&line, &n, fp)) != -1 && contador < 1000){ /* lee cada linea del archvio*/
        sp = p = line;  /* pones el puntero de inicio y el puntero de recorrido al principio*/
        atributo = 0;
        while(*p) {
            if(*p == ','){      /*final de atributo*/
                *p = 0;         /*indicamos el inicio de la siguiente palabra*/
                atrib[atributo] = atof(sp);
                *p = ',';   /* reemplaza con el original */
                sp = p+1;   /* asignar al puntero de inicio una nueva posición de inicio*/
                atributo++; /* actualizar el contador de atributos*/
            }
            p++;            /* incrementamos el puntero p*/
        }
        
        
        //Atributo que dice si el agua es potable(1) o no es potable(0)
        if(atributo == 20){
            if (*sp == '0')
                potable = 0;
            else 
                potable = 1;
        }


        //Apilar cada muestra del csv
        apilar(&pilaAtributos,id,potable,atrib[0],atrib[1],atrib[2],atrib[3],atrib[4],
                atrib[5],atrib[6],atrib[7],atrib[8],atrib[9],atrib[10],atrib[11],atrib[12],atrib[13],
                atrib[14],atrib[15],atrib[16],atrib[17],atrib[18],atrib[19]);
        id++;
        fila ++;
        contador++;
    }
  
    

    //Comienza interfaz

    printf("\nPREDICCION DE LA POTABILIDAD DEL AGUA\n");
    printf("-----------------------------------------------\n\n");
    printf("\n\t¿Desea introducir los datos de una nueva muestra [s/n]?: ");
    scanf(" %c",&res);//Preguntar si se desea introducir una nueva muestra o no
    printf("\n");


    //En caso de que el usuario haya decidido introducir una nueva muestra, se escanean todos los atributos
    if(res == 's' || res == 'S') {
        printf("\n ____________________________________________________________________________________\n");
        printf("|                                                                                   |\n");
        printf("| A continuación deberá de introducir los 20 parametros de la muestra de agua a estudiar |\n");
        printf("|___________________________________________________________________________________|\n\n");
        printf("Los datos entre corchetes [] son solo de referencia\n");
        printf("\n-------------------------------------------------------------------------------------\n\n");

        printf("\tNumero de muestra [sugerencia: 20]: ");
        scanf("%d",&id);
        printf("\tConcentración de aluminio. Es peligroso si es superior a 2.8 mg/l. Muesta [0 - 5 (mg/l)]: ");
        scanf("%f",&atrib[0]);
        printf("\tConcentración de amoniaco. Es peligroso si es superior a 32.5 mg/l. Muesta [0 - 50 (mg/l)]: ");
        scanf("%f",&atrib[1]);
        printf("\tConcentración de arsenico. Es peligroso si es superior a 0.01 mg/l. Muesta [0 - 0.5 (mg/l)]: ");
        scanf("%f",&atrib[2]);
        printf("\tConcentración de bario. Es peligroso si es superior a 2 mg/l. Muesta [0 - 5 (mg/l)]: ");
        scanf("%f",&atrib[3]);
        printf("\tConcentración de cadmio. Es peligroso si es superior a 0.005 mg/l. Muesta [0 - 0.1 (mg/l)]: ");
        scanf("%f",&atrib[4]);
        printf("\tConcentración de cloramina. Es peligroso si es superior a 4 mg/l. Muesta [0 - 8 (mg/l)]: ");
        scanf("%f",&atrib[5]);
        printf("\tConcentración de cromo. Es peligroso si es superior a 0.1 mg/l. Muesta [0 - 1 (mg/l)]: ");
        scanf("%f",&atrib[6]);
        printf("\tConcentración de cobre. Es peligroso si es superior a 1.3 mg/l. Muesta [0 - 5 (mg/l)]: ");
        scanf("%f",&atrib[7]);
        printf("\tConcentración de fluor. Es peligroso si es superior a 1.5 mg/l. Muesta [0 - 5 (mg/l)]]: ");
        scanf("%f",&atrib[8]);
        printf("\tConcentración de bacterias. Es peligroso si es superior a 0 unidades. Muesta [0 - 5 (unidades)]: ");
        scanf("%f",&atrib[9]);

        printf("\tConcentración de virus. Es peligroso si es superior a 0 unidades. Muesta [0 - 5 (unidades)]: ");
        scanf("%f",&atrib[10]);
        printf("\tConcentración de plomo. Es peligroso si es superior a 0.015 mg/l. Muesta [0 - 0.5 (mg/l)]: ");
        scanf("%f",&atrib[11]);
        printf("\tConcentración de nitratos. Es peligroso si es superior a 10 mg/l. Muesta [0 - 20 (mg/l)]: ");
        scanf("%f",&atrib[12]);
        printf("\tConcentración de nitritos. Es peligroso si es superior a 1 mg/l. Muesta [0 - 5 (mg/l)]: ");
        scanf("%f",&atrib[13]);
        printf("\tConcentración de mercurio. Es peligroso si es superior a 0.002 mg/l. Muesta [0 - 0.1 (mg/l)]: ");
        scanf("%f",&atrib[14]);
        printf("\tConcentración de perclorato. Es peligroso si es superior a 56 mg/l. Muesta [0 - 100 (mg/l)]: ");
        scanf("%f",&atrib[15]);
        printf("\tConcentración de radio. Es peligroso si es superior a 5 mg/l. Muesta [0 - 10 (mg/l)]: ");
        scanf("%f",&atrib[16]);
        printf("\tConcentración de selenio. Es peligroso si es superior a 0.5 mg/l. Muesta [0 - 5 (mg/l)]: ");
        scanf("%f",&atrib[17]);
        printf("\tConcentración de plata. Es peligroso si es superior a 0.1 mg/l. Muesta [0 - 3 (mg/l)]: ");
        scanf("%f",&atrib[18]);
        printf("\tConcentración de uranio. Es peligroso si es superior a 0.3 mg/l. Muesta [0 - 3 (mg/l)]: ");
        scanf("%f",&atrib[19]);

        potable = 0;


        //Apilar la nueva muestra introducida

        apilar(&pilaAtributos,id,potable,atrib[0],atrib[1],atrib[2],atrib[3],atrib[4],
                atrib[5],atrib[6],atrib[7],atrib[8],atrib[9],atrib[10],atrib[11],atrib[12],atrib[13],
                atrib[14],atrib[15],atrib[16],atrib[17],atrib[18],atrib[19]);


        fila ++;
    }

    printf("Procediendo al analisis. . .\n\n");
    
    fila--;


    //Normalizar muestra
    
    normalizar(&pilaAtributos,fila);



    //Menú de opraciones posibles a realizar

    printf("Escoja una opcion:\n");

    printf("\t1: Clasificar el nuevo ejemplo o en su defecto el ultimo almacenado del dataset mediante K-NN para K = 1\n");
    printf("\t2: Clasificar el nuevo ejemplo o en su defecto el último almacenado del dataset mediante K-NN para K = k\n");
    printf("\t3: Aplicar wilson y calcular la precisión\n");
    printf("\t4: Calcular la precisión sin wilson\n");
    printf("\t5: Salir\n");
    printf("\n\t Respuesta: ");
    scanf("%d",&accion);
    switch (accion)
    {
    case 1:

        predecirUsuarioKConLista(&pilaAtributos, fila, 1);
        informarDeResultado(&pilaAtributos);
        break;

    case 2:

        printf("Introduce el numero de vecinos con los que comparar: ");
        scanf("%d",&numVecinos); //Ecanear numero de vecinos para comparar
        getchar();
        predecirUsuarioKConLista(&pilaAtributos, fila, numVecinos);
        informarDeResultado(&pilaAtributos);
        break;

    case 3:

        printf("Introduce el numero de vecinos con los que comparar: ");
        scanf("%d",&numVecinos); //Ecanear numero de vecinos para comparar
        getchar();
        wilson(&pilaAtributos,&fila,numVecinos);
        calcularPrecision(&pilaAtributos,fila,numVecinos);
        break;
    
    case 4:

        printf("Introduce el numero de vecinos con los que comparar el ultimo ejemplo por defecto: ");
        scanf("%d",&numVecinos); //Ecanear numero de vecinos para comparar
        getchar();
        calcularPrecision(&pilaAtributos,fila,numVecinos);
        break;

    default:
        break;
    }

    return 0;
}
