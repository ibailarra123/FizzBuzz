/*
  FICHERO: pilaAtributosDinamica.c
  VERSION: 1.0.0
  HISTORICO:
  Creado por Ibai Larralde
*/

#include "pilaAtributosDinamica.h"


void nuevaPila(tipoPila *p){
	*p=NULL;
}

void errorPila(char s[]){
	printf("\n\n\nERROR en el modulo pilas: %s \n", s);
}

void apilar(tipoPila *p, int id, enum r potable, tep aluminium,tep ammonia,tep arsenic,
			tep barium,tep cadmium,tep chloramine,tep chromium,
   			tep copper,tep flouride,tep bacteria,tep viruses,tep lead,tep nitrates,tep nitrites,
			tep mercury,tep perchlorate,tep radium,
   			tep selenium,tep silver,tep uranium) {

	celdaPila *nuevo;
	nuevo=(celdaPila*)malloc(sizeof(celdaPila));
	nuevo->id = id;
	nuevo->potable = potable;
	nuevo->atributo[0] = aluminium;
	nuevo->atributo[1] = ammonia;
	nuevo->atributo[2] = arsenic;
	nuevo->atributo[3] = barium;
	nuevo->atributo[4] = cadmium;
	nuevo->atributo[5] = chloramine;
	nuevo->atributo[6] = chromium;
	nuevo->atributo[7] = copper;
	nuevo->atributo[8] = flouride;
	nuevo->atributo[9] = bacteria;
	nuevo->atributo[10] = viruses;
	nuevo->atributo[11] = lead;
	nuevo->atributo[12] = nitrates;
	nuevo->atributo[13] = nitrites;
	nuevo->atributo[14] = mercury;
	nuevo->atributo[15] = perchlorate;
	nuevo->atributo[16] = radium;
	nuevo->atributo[17] = selenium;
	nuevo->atributo[18] = silver;
	nuevo->atributo[19] = uranium;
	nuevo->sig=*p;
	*p=nuevo;
}

void desapilar(tipoPila *p){
	if (esNulaPila(*p))
		errorPila("No se puede desapilar en una pila vacia.");
	else{
		celdaPila *aux;
		aux=*p;
		*p=(*p)->sig;
		free(aux);
	}
}

void mostrarCima(tipoPila p){

	printf("%d,",p->id);
	if(p->potable == 0) printf("No,");
	else printf("Yes,");

	for(int i = 0; i < NUM_FLOATS; i++) {

		printf("%f,",p->atributo[i]);
	}
	printf("\n");
}

void escribirEnFichero(tipoPila p, FILE *f) {

	fprintf(f,"%d,",p->id);
	if(p->potable == 0) fprintf(f,"No,");
	else fprintf(f,"Yes,");

	for(int i = 0; i < NUM_FLOATS; i++) {

		fprintf(f,"%f,",p->atributo[i]);
	}
	fprintf(f,"\n");
}

void normalizar(tipoPila *p, int fila) {

	celdaPila *pAux1, *pAux2;
	pAux1 = pAux2 = *p;
	float mayor[NUM_FLOATS],menor[NUM_FLOATS];

	for(int i = 0; i<NUM_FLOATS; i++) {

		mayor[i] = menor[i] = pAux1->atributo[i];
	}
	pAux1 = pAux1->sig;

	for(int i = 0; i<(fila-1); i++) {

		for(int j = 0; j<NUM_FLOATS; j++){

			if(pAux1->atributo[j] > mayor[j]) mayor[j] = pAux1->atributo[j];
			if(pAux1->atributo[j] < menor[j]) menor[j] = pAux1->atributo[j];
		}
		pAux1 = pAux1->sig;
	}

	for(int j = 0; j<fila; j++) {

		for(int i =0; i<NUM_FLOATS; i++){

			pAux2->atributo[i] = (pAux2->atributo[i] - menor[i]) / (mayor[i] - menor[i]);
		}
		pAux2 = pAux2->sig;
	}
}

void mostrarPila(tipoPila p, int fila){

	celdaPila *pAux;
	pAux = p;
	for(int i = 0; i<fila; i++){

		mostrarCima(pAux);
		pAux = pAux->sig;
	}
}


void predecirUsuarioKConLista(tipoPila *p, int fila, int numVecinos){

	celdaPila *pAux1;
	tipoLista listaAtributos;
	nuevaLista(&listaAtributos);

	pAux1 = *p;
	pAux1 = pAux1->sig;
	float d = 0.0;
	float dist[NUM_FLOATS];
	float distanciaTotal = 0.0;

	for(int i = 0; i<fila-1; i++) {

		for(int k = 0; k<NUM_FLOATS; k++) {

			dist[k] = pAux1->atributo[k] - (*p)->atributo[k];
			distanciaTotal = distanciaTotal + powf(dist[k],2);
		}
		distanciaTotal = sqrtf(distanciaTotal);
		insertar(&listaAtributos,pAux1->id,pAux1->potable,distanciaTotal);
		pAux1 = pAux1->sig;
		distanciaTotal = 0.0;
	}
	int contador_M = 0;
	int contador_B = 0;
	int empate = consultarMenorDiagnosis(listaAtributos);

	for(int i=0; i<numVecinos; i++) {

		if(consultarMenorDiagnosis(listaAtributos) == 0) contador_B++;
		if(consultarMenorDiagnosis(listaAtributos) == 1) contador_M++;
		eliminarMenor(&listaAtributos);
	}
	if(contador_B == contador_M) (*p)->potable = empate;
	if(contador_B > contador_M) (*p)->potable = 0;
	if(contador_B < contador_M) (*p)->potable = 1;
}

void calcularPrecision(tipoPila *p, int fila, int numVecinos){

	tipoPila pAux2;
    nuevaPila(&pAux2);
	celdaPila *pAux;
	pAux = *p;
	int diagnosticoAnt = 0, diagnosticoPost = 0, aciertos = 0, fallos = 0;
	for(int i = 0; i<fila; i++){

		diagnosticoAnt = (*p)->potable;
		predecirUsuarioKConLista(p,fila,numVecinos);
		diagnosticoPost = (*p)->potable;
		pAux = pAux->sig;
		apilar(&pAux2,(*p)->id,(*p)->potable,(*p)->atributo[0],(*p)->atributo[1],(*p)->atributo[2],(*p)->atributo[3],(*p)->atributo[4],(*p)->atributo[5],(*p)->atributo[6],(*p)->atributo[7],(*p)->atributo[8],(*p)->atributo[9],
                (*p)->atributo[10],(*p)->atributo[11],(*p)->atributo[12],(*p)->atributo[13],(*p)->atributo[14],(*p)->atributo[15],(*p)->atributo[16],(*p)->atributo[17],(*p)->atributo[18],(*p)->atributo[19]);

		intercambioPosicionesPila(&pAux,p,&pAux2);
		if(diagnosticoAnt == diagnosticoPost) aciertos++;
		else fallos++;
		while(!esNulaPila(pAux2)) {

			desapilar(&pAux2);
		}
	}
	free(pAux2);
	float precision = ((float)aciertos/(float)fila)*100;
	printf("La precison con %d vecinos es de %f \n",numVecinos,precision);
}

void intercambioPosicionesPila(tipoPila *p1, tipoPila *p2, tipoPila *pAux) {

	(*p2)->id = (*p1)->id;
	(*p2)->potable = (*p1)->potable;
	for(int i = 0; i<NUM_FLOATS; i++) {

		(*p2)->atributo[i] = (*p1)->atributo[i];
	}
	(*p1)->id = (*pAux)->id;
	(*p1)->potable = (*pAux)->potable;
	for(int i = 0; i<NUM_FLOATS; i++) {

		(*p1)->atributo[i] = (*pAux)->atributo[i];
	}
}
void wilson(tipoPila *p, int *fila, int numVecinos) {

	tipoPila pAux2;
    nuevaPila(&pAux2);
	celdaPila *pAux;
	pAux = *p;
	int diagnosticoAnt = 0, diagnosticoPost = 0;
	for(int i = 0; i<(*fila); i++){

		diagnosticoAnt = (*p)->potable;
		predecirUsuarioKConLista(p,(*fila),numVecinos);
		diagnosticoPost = (*p)->potable;
		pAux = pAux->sig;
		apilar(&pAux2,(*p)->id,(*p)->potable,(*p)->atributo[0],(*p)->atributo[1],(*p)->atributo[2],(*p)->atributo[3],(*p)->atributo[4],(*p)->atributo[5],(*p)->atributo[6],(*p)->atributo[7],(*p)->atributo[8],(*p)->atributo[9],
                (*p)->atributo[10],(*p)->atributo[11],(*p)->atributo[12],(*p)->atributo[13],(*p)->atributo[14],(*p)->atributo[15],(*p)->atributo[16],(*p)->atributo[17],(*p)->atributo[18],(*p)->atributo[19]);
		intercambioPosicionesPila(&pAux,p,&pAux2);
		if(diagnosticoAnt != diagnosticoPost) {

			desapilar(p);
			(*fila)--;
		}
		while(!esNulaPila(pAux2)) {

			desapilar(&pAux2);
		}
	}
}

void informarDeResultado(tipoPila *p) {

	int informe = (*p)->potable;
	if(informe == 0) {

		printf("\n\n ______________________________________________________________\n");
		printf("|                                                             |\n");
		printf("| El estudio informa que el agua no es potable                |\n");
		printf("| Número de la muestra: %d                                  |\n",(*p)->id);
		printf("|_____________________________________________________________|\n\n");
	}
	if(informe == 1) {

		printf("\n\n _____________________________________________________________\n");
		printf("|                                                            |\n");
		printf("| El estudio informa que el agua es potable                  |\n");
		printf("| Número de la muestra: %d                                 |\n",(*p)->id);
		printf("|____________________________________________________________|\n\n");
	}
}

bool esNulaPila(tipoPila p){
	return p==NULL;
}
