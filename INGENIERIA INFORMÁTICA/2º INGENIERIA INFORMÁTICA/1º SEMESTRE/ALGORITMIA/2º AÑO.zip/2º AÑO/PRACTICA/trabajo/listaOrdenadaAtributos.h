/*
  FICHERO: listaOrdenadaAtributos.h
  VERSION: 1.0.0
  HISTORICO:
  Creado por Ibai Larralde
*/

enum r {No, Yes};

#include <stdbool.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

typedef float atrib;
typedef struct celdaL{

  int id;
  enum r potable;
  atrib distancia;

	struct celdaL *sig;
	struct celdaL *ant;

}celdaLista;

typedef struct tipoL{

  celdaLista *ini;
	celdaLista *fin;

}tipoLista;

void nuevaLista(tipoLista *);

void insertar(tipoLista *,int , enum r ,atrib);

void eliminarMenor(tipoLista *);

void eliminarMayor(tipoLista *);

int contarFilas(tipoLista);

int consultarMenorId(tipoLista l);
int consultarMayorId(tipoLista l);

int consultarMenorDiagnosis(tipoLista l);
int consultarMayorDiagnosis(tipoLista l);

atrib consultarMenorDistancia(tipoLista l);
atrib consultarMayorDistancia(tipoLista l);

void consultarFilaMenor(tipoLista);
void consultarFilaMayor(tipoLista);

bool estaElemento(tipoLista, atrib);

bool esNulaLista(tipoLista);

void concatenar (tipoLista *, tipoLista *);

void imprimirLista (tipoLista);