/*
    Fichero: listaOrdenadaEnteros.c
    Version: 1.0
    HISTORICO
        Autor: Ibai Larralde
        Fecha: 03/11/2022
*/

//librerias
#include "listaOrdenadaAtributos.h"

/*
 * ACCION: nuevaLista
 * ENTRADA: una lista
 * SALIDA: la lista inicializada con el inicio y fin como null
*/
void nuevaLista(tipoLista *lista){
    lista->fin = NULL;
    lista->ini = NULL;
}

/*
 * ACCION: errorLista
 * ENTRADA: un string con una frase de error
 * SALIDA: una frase indicadora de errorFO
*/
void errorLista(char s[]){
	printf("\n\n\nERROR en el modulo listaOrdenada: %s \n", s);
}

/*
 * ACCION: insertar
 * ENTRADA: una lista y un elemento
 * SALIDA: la lista con el elemento colocado en su posicion segun el orden creciente
*/

void insertar(tipoLista *l,int id,enum r d,atrib distancia){
    celdaLista *nueva;
    nueva = (celdaLista*)malloc(sizeof(celdaLista));
    nueva->id = id;
    nueva->potable = d;
    nueva->distancia = distancia;

    if(esNulaLista(*l)){
        l->ini = nueva;
        l->fin = nueva;
        nueva->ant = NULL;
        nueva->sig = NULL;
    } else {
        celdaLista *aux;
        celdaLista *auxant;
        auxant = l->ini;
        aux = l->ini->sig;
        while((distancia > auxant->distancia) && (aux != NULL)){
            auxant = aux;
            aux = aux->sig;
        }
        if((distancia < auxant->distancia) && (auxant == l->ini)){
            nueva->sig = auxant;
            nueva->ant = NULL;
            auxant->ant = nueva;
            l->ini = nueva;
        } else if(distancia < auxant->distancia){
            aux = auxant;
            auxant = auxant->ant;
            nueva->sig = aux;
            nueva->ant = auxant;
            auxant->sig = nueva;
            aux->ant = nueva;
        } else{
            nueva->sig = aux;
            nueva->ant = auxant;
            auxant->sig = nueva;
            l->fin = nueva;
        }
    }
}

/*
 * ACCION: eliminaMenor
 * ENTRADA: una lista
 * SALIDA: la lista sin el elemento menor (primer elemento)
*/
void eliminarMenor(tipoLista *lista){
    celdaLista *aux;
    aux = lista->ini;
    if(esNulaLista(*lista)){
        errorLista("No se puede eliminar el elemento menor de una lista vacia");
    }
    else{
        if(lista->ini->sig == NULL){
            lista->ini = NULL;
            lista->fin = NULL;
        }
        else{
            lista->ini = lista->ini->sig;
            lista->ini->ant = NULL;
        }
        free(aux);
    }
}

/*
 * ACCION: eliminaMayor
 * ENTRADA: una lista
 * SALIDA: la lista sin el elemento mayor (ultimo elemento)
*/
void eliminarMayor(tipoLista *lista){
    celdaLista *aux;
    aux = lista->fin;
    if(esNulaLista(*lista)){
        errorLista("No se puede eliminar el elemento menor de una lista vacia");
    }
    else{
        if(lista->fin->ant == NULL){
            lista->ini = NULL;
            lista->fin = NULL;
        }
        else{
            lista->fin = lista->fin->ant;
            lista->fin->sig = NULL;
        }
        free(aux);
    }
}

/*
 * ACCION: consultaMenor
 * ENTRADA: una lista
 * SALIDA: el elemento que se situa al principio de la lista (menor)
*/

int consultarMenorId(tipoLista lista){

    if(esNulaLista(lista)){
        errorLista("La lista esta vacia");
    }
    else return(lista.ini->id);
}
int consultarMayorId(tipoLista lista){

    if(esNulaLista(lista)){
        errorLista("La lista esta vacia");
    }
    else return(lista.fin->id);
}

int consultarMenorDiagnosis(tipoLista lista){

    if(esNulaLista(lista)){
        errorLista("La lista esta vacia");
    }
    else return(lista.ini->potable);
}
int consultarMayorDiagnosis(tipoLista lista){

    if(esNulaLista(lista)){
        errorLista("La lista esta vacia");
    }
    else return(lista.fin->potable);
}

atrib consultarMenorDistancia(tipoLista lista){

    if(esNulaLista(lista)){
        errorLista("La lista esta vacia");
    }
    else return(lista.ini->distancia);
}
atrib consultarMayorDistancia(tipoLista lista){

    if(esNulaLista(lista)){
        errorLista("La lista esta vacia");
    }
    else return(lista.fin->distancia);
}

void MostrarFilaMenor(tipoLista lista){

    int id = consultarMenorId(lista);
    int diagnosis = consultarMenorDiagnosis(lista);
    float distancia = consultarMenorDistancia(lista);

    printf("Número de muestra: %d | ",id);
    if(diagnosis == 0) printf("Diagnostico: NO Potable| ");
	else printf("Diagnostico: Potable | ,");
    printf("Distancia: %f",distancia);
}
void MostrarFilaMayor(tipoLista lista){

    int id = consultarMayorId(lista);
    int diagnosis = consultarMayorDiagnosis(lista);
    float distancia = consultarMayorDistancia(lista);

    printf("Id: %d | ",id);
    if(diagnosis == 0) printf("Diagnostico: NO Potable | ");
	else printf("Diagnostico: Potable | ,");
    printf("Distancia: %f",distancia);
}
/*
 * ACCION: esNulaLista
 * ENTRADA: una lista
 * SALIDA: un booleano que dice si es o no nula lista
*/
bool esNulaLista(tipoLista lista){
    return((lista.ini == NULL) && (lista.fin == NULL));
}

/*
 * ACCION: concatenar
 * ENTRADA: dos listas
 * SALIDA: la lista 1 con todos los elementos de la lista 2 añadidos en orden
*/
void concatenar (tipoLista *lista1, tipoLista *lista2){
    if(esNulaLista(*lista2))
        errorLista("la segunda lista esta vacia");
    else{
        while(!esNulaLista(*lista2)){
            insertar(lista1,lista2->ini->id,lista2->ini->potable,lista2->ini->distancia);
            eliminarMenor(lista2);
        }
    }
}

/*
 * ACCION: imprimir lista
 * ENTRADA: una lista
 * SALIDA: muestra por pantalla todos los elementos de la lista de menor a mayor separados por un espacio
*/
void imprimirLista (tipoLista lista){
    if(esNulaLista(lista))
        errorLista("la lista esta vacia");
    else{
        celdaLista *nuevaCelda;
        nuevaCelda = lista.ini;
        while(nuevaCelda != NULL){
            printf("%d,%d,%f\n",nuevaCelda->id,nuevaCelda->potable,nuevaCelda->distancia);
            nuevaCelda = nuevaCelda->sig;
        }
        printf("\n");
    }
}

int contarFilas(tipoLista lista) {

    celdaLista *aux;
    aux = lista.ini;
    int contador = 0;
    while(aux != NULL){

        contador++;
        aux = aux->sig;
    }
    return(contador);
}