#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include "secuenciaEnteros.h"

void nuevaSecuencia(tipoSecuencia* s){
    s->pilaIzq = NULL;
    s->pilaDcha = NULL;
}

void insertarDelantePunto(tipoSecuencia* s, tipoElementoPila e){
    apilar(&(s->pilaIzq),e);
}

void insertarEnPunto(tipoSecuencia* s, tipoElementoPila e){
    apilar(&(s->pilaDcha),e);
}

void eliminarEnPunto(tipoSecuencia* s){
    desapilar(&(s->pilaDcha));
}

tipoElementoPila consultarEnPunto(tipoSecuencia s){
    return cima(s.pilaDcha);
}

void avanzarPunto (tipoSecuencia* s){
    tipoElementoPila aux;
    aux = cima(s->pilaDcha);
    desapilar(&(s->pilaDcha));
    apilar(&(s->pilaIzq),aux);
}

void moverPuntoAlPrincipio (tipoSecuencia* s){
    tipoElementoPila aux;
    while(!(esNulaPila(s->pilaIzq))){
        aux = cima(s->pilaIzq);
        desapilar(&(s->pilaIzq));
        apilar(&(s->pilaDcha),aux);
    }
}

bool esPuntoUltimo(tipoSecuencia s){
    desapilar(&s.pilaDcha);
    return (esNulaPila(s.pilaDcha));
}

bool esVaciaSecuencia(tipoSecuencia s){
    return (esNulaPila(s.pilaIzq) && esNulaPila(s.pilaIzq));
}
