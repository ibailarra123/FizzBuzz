/*
  FICHERO: pilaEnterosDinamica.h
  VERSION: 1.0.0
  HISTORICO:
  Creado por Aránzazu Jurío Munárriz el 09/09/19.
  
  Este fichero se crea sólo con intenciones de coordinación docente y como
  ayuda a sus alumnos y alumnas. La autora desautoriza expresamente su difusión, copia
  o exhibición pública (salvo entre los alumnos de las asignaturas 240301 y 250301 del
  grado en Ingeniería Informática de la UPNA).
*/

#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include "pilaEnterosDinamica.h"

void nuevaPila(tipoPila *p){
    *p = NULL;
}

void apilar(tipoPila *p, tipoElementoPila e){
    celdaPila *aux;
    aux = (celdaPila*)malloc(sizeof(celdaPila));
    aux->elem = e;
    aux->sig = (*p);
    (*p) = aux;
}

void desapilar(tipoPila *p){
    if (esNulaPila(*p))
        printf("No se puede desapilar una pila vacía\n");
    else{
        celdaPila *aux;
        aux = (*p);
        (*p) = (*p)->sig;
        free(aux);
    }
}

int cima(tipoPila p){
    if (esNulaPila(p))
        printf("La pila está vacía \n");
    else return p->elem;
}

bool esNulaPila(tipoPila p){
    return (p == NULL);
}
