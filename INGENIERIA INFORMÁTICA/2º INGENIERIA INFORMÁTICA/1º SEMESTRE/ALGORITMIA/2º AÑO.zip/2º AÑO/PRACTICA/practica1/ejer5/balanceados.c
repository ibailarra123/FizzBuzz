#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include "pilaEnterosDinamica.h"


int main(void){
    char quiereSalir,aux;
    char frase[100];
    tipoPila p;

    do{
        nuevaPila(&p);
        printf("Introduce la frase: \n");
        scanf("%s",frase);

        for(int i=0; i < sizeof(frase); i++){
            if (frase[i] == '(' || frase[i] == '[' || frase[i] == '{'){
                apilar(&p, frase[i]);
            }
            else if (frase[i] == ')' || frase[i] == ']' || frase[i] == '}'){
                if (esNulaPila(p)){
                    printf("La frase está mal balanceada. \n");
                    exit(0);
                }
                else{
                    aux = cima(p);
                    desapilar(&p);
                    if (frase[i] == ')'){
                        if(aux != '('){
                            printf("La frase está mal balanceada. \n");
                            exit(0);
                        }
                    }
                    else if (frase[i] == '}'){
                        if(aux != '{'){
                            printf("La frase está mal balanceada. \n");
                            exit(0);
                        }
                    }
                    else{
                        if(aux != '['){
                            printf("La frase está mal balanceada. \n");
                            exit(0);
                        }
                    }
                }
            }
        }

        if (!esNulaPila(p)){
            printf("La frase está mal balanceada. \n");
            exit(0);
        }
    
        printf("Si desea salir pulse s, para repetir la ejecucion cualquier otra cosa.");
		scanf("\n%c", &quiereSalir);
	} while (quiereSalir != 's');
	return 0;
}