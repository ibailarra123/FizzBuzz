#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include "colaEnteros.h"


int main(void){
    char quiereSalir,aux;
    tipoCola c;
    int i,e,n, intervalo;

    do{
        nuevaCola(&c);
        printf("Introduce el número de soldados: \n");
        scanf("%d",&n);
        printf("Introduce el intervalo de muerte: \n");
        scanf("%d",&intervalo);

        for(i = 1; i<=n; i++){
            encolar(&c,i);
        }
        i=1;
        while(!esNulaCola(c)){
            e = frente(c);
            desencolar(&c);
            if(i % intervalo != 0)
                encolar(&c,e);
            i = i+1;
        }
        printf("La posición adecuada para salvarse es la: %i\n",e);
        printf("Si desea salir pulse s, para repetir la ejecucion cualquier otra cosa.");
		scanf("\n%c", &quiereSalir);
	} while (quiereSalir != 's');
	return 0;
}