#include "pilaEnterosDinamica.h"
#include <stdio.h>
#include <stdlib.h>

typedef desastres tabla[100];

int main(void){
    char quiereSalir;
    tabla desastres1;
    int n;
    tipoPila p;
    tipoElementoPila desastres;
    
    do{
        nuevaPila(&p);
        printf("Introduce el número de desastres(máx 100): \n");
        scanf("%d",&n);
        
        for(int i=0;i<n;i++){
            
            printf("Introduce la fecha del accidente %d:\n",i+1);
            scanf("%d",&(desastres1[i].fecha));
            printf("Introduce el número de víctimas del accidente %d:\n",i+1);
            scanf("%d",&(desastres1[i].victimas));

            if((!esNulaPila(p)) && ((cima(p)).victimas < desastres1[i].victimas)){
                
                while((!esNulaPila(p)) && ((cima(p)).victimas < desastres1[i].victimas)){
                    desapilar(&p);
			    }
			
                if(esNulaPila(p))
                    desastres1[i].mas = 0;
			    else
				    desastres1[i].mas = (cima(p)).fecha;
            }

            else if((!esNulaPila(p)) && ((cima(p)).victimas > desastres1[i].victimas))
                desastres1[i].mas = (cima(p)).fecha;
		
            else if(esNulaPila(p))
			    desastres1[i].mas = 0;
		
		    apilar(&p, desastres1[i]);
        }


        for(int j=0;j<n;j++){
            printf("%d\n",desastres1[j].mas);
        }
    
        printf("Si desea salir pulse s, para repetir la ejecucion cualquier otra cosa.");
		scanf("\n%c", &quiereSalir);
	} while (quiereSalir != 's');
	return 0;
}