#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include "colaEnteros.h"

void nuevaCola(tipoCola *c){
    c->ini = NULL;
    c->fin = NULL;
}

void encolar(tipoCola *c, tipoElementoCola e){
    celdaCola *aux;
    aux = (celdaCola*)malloc(sizeof(celdaCola));
    aux->elem = e;
    aux->sig = NULL;
    if (c->fin == NULL)
        c->ini = aux;
    else
        c->fin->sig = aux;
    c->fin = aux;
}

void desencolar(tipoCola *c){
    celdaCola *aux;
    aux = c->ini;
    c->ini = c->ini->sig;
    if (c->ini == NULL)
        c->fin = NULL;
    free(aux);
}

bool esNulaCola(tipoCola c){
    return (c.ini == NULL);
}

tipoElementoCola frente(tipoCola c){
	if (esNulaCola(c))
		printf("No se puede obtener el frente en una cola vacia.");
	else
		return c.ini->elem;
}