#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include "colaDobleCaracteres.h"


void nuevaColaDoble(tipoColaDoble *c){
    c->ini = NULL;
    c->fin = NULL;
}

void encolarPrimero(tipoColaDoble *c, tipoElementoColaDoble e){
    celdaColaDoble *aux;
    aux = (celdaColaDoble*)malloc(sizeof(celdaColaDoble));
    aux->elem = e;
    aux->ant = NULL;
    if (esNulaColaDoble((*c))){
        aux->sig = NULL;
        c->fin = aux;
    }
    else{
        aux->sig = c->ini;
        c->ini->ant = aux; 
    }
    c->ini = aux;
}

void encolarUltimo(tipoColaDoble *c, tipoElementoColaDoble e){
    celdaColaDoble *aux;
    aux = (celdaColaDoble*)malloc(sizeof(celdaColaDoble));
    aux->elem = e;
    aux->sig = NULL;
    if (esNulaColaDoble((*c))){
        aux->ant = NULL;
        c->ini = aux;
    }
    else{
        aux->ant = c->fin;
        c->fin->sig = aux; 
    }
    c->fin = aux;
}

void desencolarPrimero(tipoColaDoble *c){
    celdaColaDoble *aux;
    aux = c->ini;
    c->ini = c->ini->sig;
    if (c->ini == NULL)
        c->fin = NULL;
    else
        c->ini->ant = NULL;
    free(aux);

}

void desencolarUltimo(tipoColaDoble *c){
    celdaColaDoble *aux;
    aux = c->fin;
    c->fin = c->fin->ant;
    if (c->fin == NULL)
        c->ini = NULL;
    else
        c->fin->sig = NULL;
    free(aux);
}

tipoElementoColaDoble elemPrimero(tipoColaDoble c){
    if (esNulaColaDoble(c)){
        printf("La cola está vacía\n");
        return(0);
    }
    else
        return(c.ini->elem);

}

tipoElementoColaDoble elemUltimo(tipoColaDoble c){
    if (esNulaColaDoble(c)){
        printf("La cola está vacía\n");
        return(0);
    }
    else
        return(c.fin->elem);
}

bool esNulaColaDoble(tipoColaDoble c){
    return (c.ini == NULL && c.fin == NULL);
}