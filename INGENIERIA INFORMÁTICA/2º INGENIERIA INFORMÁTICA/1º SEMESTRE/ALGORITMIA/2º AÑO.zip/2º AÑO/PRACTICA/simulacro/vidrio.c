#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include "colaPrioridades.h"

int main(){
	tipoCola cola;
	int opcion;
	bool prioridad;
	int i=1;
	int j=1;
	nuevaCola(&cola);
	do
    {
		printf("Introduce pedido %d\n",i);
		printf("Pulsa 0 para pedido de plata\n");
		printf("Pulsa 1 para pedido de oro\n");
		printf("Pulsa 2 para no admitir más pedidos hoy\n");
		printf("Opción: ");
		scanf("%d",&opcion);
        if (opcion == 0){
            if (cola.n_secundarios > 6)
				prioridad = true;
			else
            	prioridad =false;
            encolar(&cola,i, prioridad);    
		}
		else if(opcion == 1){
			prioridad = true;
			encolar(&cola,i, prioridad);
		}
		i++;
		if (cola.n_prioritarios == 3){
			printf("Se ha producido el lote %d. Los pedidos producidos han sido:\n",j);
			j++;
			while(!esNulaCola(cola)){
				printf("Pedido %d\n",cola.ini->elem);
				desencolar(&cola);
			}
		}
	}while(opcion<2);
}
