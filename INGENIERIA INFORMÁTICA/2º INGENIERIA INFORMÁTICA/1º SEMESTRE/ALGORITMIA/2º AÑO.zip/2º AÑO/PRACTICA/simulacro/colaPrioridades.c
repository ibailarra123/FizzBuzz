#include <stdbool.h>
#include <stdlib.h>
#include <stdio.h>
#include "colaPrioridades.h"

void nuevaCola(tipoCola *c){
    c->ini = NULL;
    c->fin = NULL;
    c->ultimo_prioritario = NULL;
    c->n_prioritarios = 0;
    c->n_secundarios = 0;
}
    
bool hayPrioritarios(tipoCola c){
    return (c.n_prioritarios>0);
}

bool haySecundarios(tipoCola c){
    return(c.n_secundarios>0);
}

bool esNulaCola(tipoCola c){
    return(c.ini == NULL);
}

void encolar(tipoCola *c, tipoValorElemento e, tipoPrioridadElemento bol){
    celdaCola *aux;
    aux = (celdaCola*)malloc(sizeof(celdaCola));
    aux->elem = e;
    aux->prioridad = bol;
    if (esNulaCola(*c)){
        aux->sig = NULL;
        c->ini = aux;
        c->fin = aux;
        if (bol){
            c->n_prioritarios++;
            c->ultimo_prioritario = aux;
        }
        else{
            c->n_secundarios++;
        }
        
    }
    else{
        if(bol){
            c->n_prioritarios++;
            if (c->ultimo_prioritario == NULL){
                aux->sig = c->ini;
                c->ini = aux;
                c->ultimo_prioritario = aux;
            }
            else{
                if(c->ultimo_prioritario->sig == NULL){
                    c->fin = aux;
                    aux->sig = NULL;
                    c->ultimo_prioritario->sig = aux;
                    c->ultimo_prioritario=aux;
                }
                else{
                    aux->sig = c->ultimo_prioritario->sig;
                    c->ultimo_prioritario->sig = aux;
                    c->ultimo_prioritario = aux;
                }
            }
        }
        else{
            c->n_secundarios++;
            aux->sig = NULL;
            c->fin->sig = aux;
            c->fin = aux;
        }
    }
}

void desencolar(tipoCola *c){
    if (esNulaCola(*c))
        printf("La cola está vacía\n");
    else{
        celdaCola *aux;
        aux = c->ini;
        if (aux->prioridad){
            c->n_prioritarios--;
            if (c->n_prioritarios == 0)
                c->ultimo_prioritario = NULL;
        }
        else
            c->n_secundarios--;
        c->ini = c->ini->sig;
        free(aux);
    }
}

tipoValorElemento frente(tipoCola c){
    if (esNulaCola(c))
        printf("La cola está vacía\n");
    else
        return (c.ini->elem);
}

int nPrioritarios(tipoCola c){
    return (c.n_prioritarios);
}

int nSecundarios(tipoCola c){
    return (c.n_secundarios);
}
