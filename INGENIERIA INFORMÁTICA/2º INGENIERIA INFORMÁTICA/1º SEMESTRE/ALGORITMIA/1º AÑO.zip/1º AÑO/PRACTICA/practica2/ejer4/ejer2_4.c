#include "arbolBinarioBusqueda.h"
#include <stdio.h>
#include <stdlib.h>



int main(void){
    tipoElementoArbolBusqueda num;
	tipoArbolBB arbol;
    char quiereSalir;
	
	nuevoArbolBB(&arbol);
    
    do{
        printf("Introduce elementos para ordenar. 0 para terminar. \n");
        scanf("%d",&num);
        while (num != 0){
            insertar(&arbol,num);
            scanf("%d",&num);
        }
        printf("\n");
        printf("Los elementos ordenados son: ");
        mostrarInorden(arbol);
        printf("\n");

        printf("Si desea salir pulse s, para repetir la ejecucion cualquier otra cosa.");
        scanf("\n%c", &quiereSalir);
	} while (quiereSalir != 's');
	return 0;
}
