#include "arbolBin.h"
#include <stdio.h>
#include <stdlib.h>

void nuevoArbolBin(tipoArbolBin *a){
    *a=NULL;
}

void errorArbolBin(char s[]){
	printf("\n\n\nERROR en el modulo arbolBin: %s \n", s);
}

tipoArbolBin construir(tipoElementoArbolBin e, tipoArbolBin a, tipoArbolBin b ){
    celdaArbolBin *nuevo;
    nuevo = (celdaArbolBin*)malloc(sizeof(celdaArbolBin));
    nuevo->elem = e;
    nuevo->dcha = b;
    nuevo->izda = a;
}

tipoElementoArbolBin devolverRaiz(tipoArbolBin a){  
    if(esVacio(a)){
        errorArbolBin("El arbol esta vacio");
    }
    else return (a->elem);
}

void preorden(tipoArbolBin a){
    if(!(esVacio(a))){      
        printf("%d",a->elem);
        preorden(a->izda);
        preorden(a->dcha);
    }
}

void inorden(tipoArbolBin a){
    if(!(esVacio(a))){      
        inorden(a->izda);
        printf("%d",a->elem);
        inorden(a->dcha);
    }
}

void postorden(tipoArbolBin a){
    if(!(esVacio(a))){  
        postorden(a->izda);
        postorden(a->dcha);
        printf("%d",a->elem);
    }
}

bool esVacio(tipoArbolBin a){
    return (a==NULL);
}
