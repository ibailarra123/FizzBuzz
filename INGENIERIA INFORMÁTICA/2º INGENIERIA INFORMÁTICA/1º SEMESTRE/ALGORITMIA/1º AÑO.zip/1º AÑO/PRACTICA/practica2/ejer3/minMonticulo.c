#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#include"minMonticulo.h"
int mayor(int a,int b){
    if(a<b)
        return b;
    else
        return a;
}
void nuevoMinMonticulo(tipoMinMonticulo *min, int a){
    min->pos=-1;
    min->array=(int *)malloc(a*sizeof(int));
    min->numEl=a;
}
void insertarMinMonticulo(tipoMinMonticulo * min, tipoElementoMinMonticulo a){
    if(estaLleno(*min)){
        printf("error.");
    }
    else{
        int aux,intercambio;
        min->pos++;
        min->array[min->pos] = a;
        aux=min->pos;
        while(aux != 0 && min->array[aux]<min->array[(aux-1)/2]){
            intercambio=min->array[aux];
            min->array[aux]=min->array[(aux-1)/2];
            min->array[(aux-1)/2]=intercambio;
            aux=(aux-1)/2;
        }
    }
}
void eliminarElemento(tipoMinMonticulo *min, tipoElementoMinMonticulo a){
    if(esVacio(*min)){
        printf("error. \n");
    }
    else{
        bool fin;
        fin = true;
        int intercambio;
        int i=0;
        while( i != min->pos){
            if (min->array[i] == a){
                min->array[i]=min->array[min->pos];
                min->pos--;
                if(2*(i+1) <= min->pos){
                    while(fin && ((min->array[i] > min->array[(i+1)*2]) || (min->array[i] > min->array[2*(i+1)+1]))){
                        if(min->array[2*(i+1)] <= min->array[2*(i+1)+1]){
                            intercambio = min->array[i];
                            min->array[i]=min->array[2*(i+1)];
                            min->array[2*(i+1)]=intercambio;
                            i=(i+1)*2;
                            if(2*(i+1)>min->pos)
                                fin = false;
                        }
                        else{ 
                           intercambio = min->array[i];
                            min->array[i]=min->array[2*(i+1)+1];
                            min->array[2*(i+1)+1]=intercambio;
                            i=2*(i+1)+1;
                            if(2*(i+1)+1 > min->pos)
                                fin = false;
                    }
                    }
                }
            }
            i++;
        }
    }
}
tipoElementoMinMonticulo devolverRaiz(tipoMinMonticulo min){
    return(min.array[0]);
}
void mostrarAnchura(tipoMinMonticulo min){
    for(int i=0;i<=min.pos;i++){
        printf("%d ",min.array[i]);
    }
}
bool esVacio(tipoMinMonticulo min){
    return (min.pos == -1);
}

bool estaLleno(tipoMinMonticulo min){
    return (min.pos==min.numEl);
}
