#include "arbolBinarioBusqueda.h"
#include <stdio.h>
#include <stdlib.h>

void nuevoArbolBB(tipoArbolBB *a){
    *a=NULL;
}

void errorArbolBB(char s[]){
	printf("\n\n\nERROR en el modulo arbolBin: %s \n", s);
}

void insertar(tipoArbolBB *a, tipoElementoArbolBusqueda e){
    if (esVacio(*a)){
        celdaArbolBusqueda *nuevo;
        nuevo = (celdaArbolBusqueda*)malloc(sizeof(celdaArbolBusqueda));
        nuevo->elem = e;
        nuevo->dcha = NULL;
        nuevo->izda = NULL;
        *a=nuevo;
    }
    else{
        if (((*a)->elem)>e)
            insertar(&(*a)->izda,e);
        else if (((*a)->elem)<e)
            insertar(&(*a)->dcha,e);
    }
        
}

void borrar(tipoArbolBB *a, tipoElementoArbolBusqueda e){                
    if (((*a)->elem)>e)
        borrar(&((*a)->izda), e);

    else if (((*a)->elem)<e)
        borrar(&(*a)->dcha, e);
    
    else {
        if (esVacio((*a)->izda) && esVacio((*a)->dcha)) {
            celdaArbolBusqueda *nuevo;
            nuevo = *a;
            *a=NULL;
            free(nuevo);
        }
        else if (esVacio((*a)->izda) && (!esVacio((*a)->dcha))) {
            celdaArbolBusqueda *nuevo;
            nuevo = *a;
            *a = ((*a)->dcha);
            free(nuevo);
        }
        else if ((!esVacio((*a)->izda)) && esVacio((*a)->dcha)) {
            celdaArbolBusqueda *nuevo;
            nuevo = *a;
            *a = ((*a)->izda);
            free(nuevo);
        }
        else{
            celdaArbolBusqueda *nuev;
            nuev=((*a)->izda);
            while((nuev->dcha)!= NULL)
                nuev=nuev->dcha;
            (*a)->elem = nuev->elem;
            borrar(&(*a)->izda, (*a)->elem);
        }
    }
}


void mostrarPreorden(tipoArbolBB a){
    if(!(esVacio(a))){      
        printf("%d",a->elem);
        mostrarPreorden(a->izda);
        mostrarPreorden(a->dcha);
    }
}

void mostrarInorden(tipoArbolBB a){
    if(!(esVacio(a))){      
        mostrarInorden(a->izda);
        printf("%d",a->elem);
        mostrarInorden(a->dcha);
    }
}

void mostrarPostorden(tipoArbolBB a){
    if(!(esVacio(a))){  
        mostrarPostorden(a->izda);
        mostrarPostorden(a->dcha);
        printf("%d",a->elem);
    }
}

bool esVacio(tipoArbolBB a){
    return ( a == NULL );
}
