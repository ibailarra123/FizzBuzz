monticulo


nuevo monticulo:
pos = -1
numer = el entero k se pasa
reservar posiciones para el array
monticulo->array =


insertar:
padre=(i-1)/2
izda=(i*2)+1
dcha=(i*2)+2

mientras mi punto interes!=0
comparar con mi padre y cambiar
punto de interes= [puno]
