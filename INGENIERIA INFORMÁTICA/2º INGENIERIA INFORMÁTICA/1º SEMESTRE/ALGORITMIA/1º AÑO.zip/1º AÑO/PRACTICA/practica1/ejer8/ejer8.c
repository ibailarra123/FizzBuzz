#include "colaEnteros.h"
#include <stdio.h>
#include <stdlib.h>



int main(void){
    char quiereSalir;
    tipoCola c;
    do{
        int cont;
        nuevaCola(&c);
        printf("Introduce el numero de resistentes: ");
        scanf("%d",&n);
        printf("Introduce el paso (cada cuanto se muere uno: ");
        scanf("%d",&m);
        for (cont = 1; cont <= n; ++cont)
            encolar(&c,cont);
        josephus (&c);
        mostrar_vencedor (c);
        printf("Si desea salir pulse s, para repetir la ejecucion cualquier otra cosa.");
        scanf("\n%c", &quiereSalir);
	} while (quiereSalir != 's');
	return 0;
}

void josephus(tipoCola *c) {
    if (*c != NULL) {
        while (c != (**c).sig) {
            encontrar (c);
            elimina (p);

		}

	}

}
