#include "colaEnteros.h"
#include <stdio.h>
#include <stdlib.h>

void nuevaCola(tipoCola *c){
    c->ini = NULL;
    c->fin = NULL;
}

void encolar(tipoCola *c, tipoElementoCola elemento){
    celdaCola *nueva;
    nueva=(celdaCola*)malloc(sizeof(celdaCola));
    nueva->elem=elemento;
    nueva->sig = NULL;
    if(c->fin==NULL)
        c->ini=nueva;
    else
        c->fin->sig=nueva;
    c->fin = nueva;
}

void desencolar(tipoCola *c){
    celdaCola *nueva;
    nueva=c->ini;
    c->ini = c->ini->sig;
    if (c->ini == NULL)
        c->fin = NULL;
    free(nueva);
}

tipoElementoCola frente(tipoCola c){
	if (esNulaCola(c))
		printf("No se puede obtener el frente en una cola vacia.");
	else
		return c.ini->elem;
}

bool esNulaCola(tipoCola c){
    return(c.ini==NULL);
}
