    /**
 *	MODULO: Cola Doble de Caracteres
 *	FICHERO: colaDobleCaracteres.c
 *	VERSION: 1.0.0
 *	HISTORICO:
 *		Creado por Carlos Ruiz Oyarzun el 28/9/21
 */
#include "colaDobleCaracteres.h"
#include <stdio.h>
#include <stdlib.h>

void nuevaColaDoble(tipoColaDoble *c){
    c->ini = NULL;
    c->fin = NULL;
}

void encolarPrimero(tipoColaDoble *c, tipoElementoColaDoble elemento){
    celdaColaDoble *q;
    q=(celdaColaDoble*)malloc(sizeof(celdaColaDoble));
    q->elem = elemento;
    q->ant = NULL;
    q->sig = c->ini;
    if (c->fin == NULL)
        c->fin = q;
    else
        q->sig->ant = q;
    c->ini = q;
}

void encolarUltimo(tipoColaDoble *c, tipoElementoColaDoble elemento){
    celdaColaDoble *q;
    q=(celdaColaDoble*)malloc(sizeof(celdaColaDoble));
    q->elem = elemento;
    q->sig = NULL;
    q->ant = c->fin;
    if (c->ini == NULL)
        c->ini = q;
    else
        q->ant->sig = q;
    c->fin = q;
}

void desencolarPrimero(tipoColaDoble *c){
    celdaColaDoble *q;
    q = c->ini;
    c->ini = c->ini->sig;
    if (c->ini == NULL)
        c->fin = NULL;
    else
        c->ini->ant = NULL;
    free(q);
}

void desencolarUltimo(tipoColaDoble *c){
    celdaColaDoble *q;
    q = c->fin;
    c->fin = c->fin->ant;
    if (c->fin == NULL)
        c->ini = NULL;
    else
        c->fin->sig = NULL;
    free(q);
}

tipoElementoColaDoble elemPrimero(tipoColaDoble c){
    if (esNulaColaDoble(c))
        printf("primero en cola nula");
    return (c.ini->elem);
}

tipoElementoColaDoble elemUltimo(tipoColaDoble c){
    if (esNulaColaDoble(c))
        printf("último en cola nula");
    return (c.fin->elem);
}

bool esNulaColaDoble(tipoColaDoble c){
    return (c.ini == NULL && c.fin == NULL);
}
