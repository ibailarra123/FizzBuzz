
#include "secuenciaEnteros.h"
#include <stdio.h>
#include <stdlib.h>


void nuevaSecuencia(tipoSecuencia *s){
    &s->pilaIzq == NULL;
    &s->pilaDcha == NULL;
}

void insertarDelantePunto(tipoSecuencia*s, tipoElementoPila e){
    apilar(&s->pilaIzq,e);
}

void insertarEnPunto(tipoSecuencia*s, tipoElementoPila e){
    apilar(&s->pilaDcha,e);
}

void eliminarEnPunto(tipoSecuencia *s){
    desapilar(&s->pilaDcha);
}

tipoElementoPila consultarEnPunto(tipoSecuencia s){
    int e;
    e = cima(s.pilaDcha);
    return e;
}

void avanzarPunto (tipoSecuencia*s){
    int e;
    e = cima(s->pilaDcha);
    desapilar(&s->pilaDcha);
    apilar(&s->pilaIzq,e);
}

void moverPuntoAlPrincipio (tipoSecuencia*s){
    int e;
    while (esNulaPila(s->pilaIzq)==0){
        e = cima(s->pilaIzq);
        desapilar(&s->pilaIzq);
        apilar(&s->pilaDcha,e);
    }
}

bool esPuntoUltimo(tipoSecuencia s){
}

bool esVaciaSecuencia(tipoSecuencia s){
    return (esNulaPila(s.pilaIzq)!=0) && (esNulaPila(s.pilaDcha)!=0);
}
