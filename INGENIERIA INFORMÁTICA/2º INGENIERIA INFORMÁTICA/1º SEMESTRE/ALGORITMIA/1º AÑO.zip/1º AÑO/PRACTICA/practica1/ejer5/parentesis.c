#include "pilaCaracteres.h"
#include <stdio.h>
#include <stdlib.h>



int main(void){
    tipoPila p;
    nuevaPila(&p);
    char quiereSalir;
    char texto[100];
    int i;
    do{
        printf( "Introduzca un texto (100 caracteres máximo): " );
        scanf( "%s", texto );
        for (i=0;i<sizeof(texto);i++){
            
            if (texto[i]=='(') 
                apilar(&p,texto[i]);
            else if(texto[i]=='[')
                apilar(&p,texto[i]);
            else if(texto[i]=='{')
                apilar(&p,texto[i]);
           
            else if (texto[i]==')'){
                char e = cima(p);
                desapilar(&p);
                if (e!='('){
                    printf("El texto no está bien balanceado\n");
                    exit(0);
                }
            }
            else if (texto[i]==']'){
                char e = cima(p);
                desapilar(&p);
                if (e!='['){
                    printf("El texto no está bien balanceado\n");
                    exit(0);
                }
            }
            else if (texto[i]=='}'){
                char e = cima(p);
                desapilar(&p);
                if (e!='{'){
                    printf("El texto no está bien balanceado\n");
                    exit(0);
                }
            }
        }
        printf("El texto está correctamente balanceado\n");
        printf("Si desea salir pulse s, para repetir la ejecucion cualquier otra cosa.");
        scanf("\n%c", &quiereSalir);
	} while (quiereSalir != 's');
	return 0;
}
