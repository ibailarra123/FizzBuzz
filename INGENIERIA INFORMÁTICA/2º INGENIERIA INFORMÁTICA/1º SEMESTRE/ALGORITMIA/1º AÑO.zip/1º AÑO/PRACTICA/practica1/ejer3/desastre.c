#include "pilaEnterosDinamica.h"
#include <stdio.h>
#include <stdlib.h>

typedef struct desastres{
	int fecha; 
	int victimas;
	int mas;
} desastres;

typedef desastres tabla[100];

int main(void){
    tipoPila pila;
    nuevaPila(&pila);
    tipoPila pila2;
    nuevaPila(&pila2);
    int i,n;
    char quiereSalir;
    tabla vector;
    do{
        printf("Introduce el número de desastres: \n");
        scanf("%d",&n);
        for(i=0;i<n;i++){
            printf("Introduce la fecha del desastre %d : \n",i+1);
            scanf("%d",&(vector[i].fecha));
            printf("Introduce el número de víctimas del desastre %d : \n",i+1);
            scanf("%d",&(vector[i].victimas));
            apilar(&pila,(vector[i].victimas));
        }
        while(!(esNula(pila))){
        }
    
        printf("Si desea salir pulse s, para repetir la ejecucion cualquier otra cosa.");
		scanf("\n%c", &quiereSalir);
	} while (quiereSalir != 's');
	return 0;
}
