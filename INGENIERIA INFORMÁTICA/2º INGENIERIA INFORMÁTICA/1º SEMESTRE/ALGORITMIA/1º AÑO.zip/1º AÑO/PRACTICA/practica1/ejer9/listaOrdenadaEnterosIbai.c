#include <stdio.h>
#include <stdlib.h>
#include "listaOrdenadaEnteros.h"
void errorLista(char motivo[]){
    printf("Error en el módulo lista ordenada: %s", motivo);
}
void nuevaLista(tipoLista *l){
    l -> ini = NULL;
    l -> fin = NULL;
}
void insertar(tipoLista *l, tipoElementoLista e){
    celdaLista *aux;
    aux = (celdaLista*) malloc(sizeof(celdaLista));
    aux -> elem = e;
    if (esNulaLista(*l)){
        aux->sig = NULL;
        aux->ant = NULL;
        l->ini = aux;
        l->fin = aux;
    }else{
        celdaLista *auxBusqueda;
        auxBusqueda = l -> ini;
        while (auxBusqueda -> elem <= aux -> elem && auxBusqueda -> sig != NULL){
            auxBusqueda = auxBusqueda -> sig;
        }
        if (auxBusqueda -> sig == NULL){
            aux -> sig = NULL;
            aux -> ant = l -> fin;
            l -> fin -> sig = aux;
            l -> fin = aux;
        }else{
            aux -> sig = auxBusqueda;
            aux -> ant = auxBusqueda -> ant;
            auxBusqueda -> ant -> sig = aux;
            auxBusqueda -> ant = aux;
        }
    }
}
void eliminarMenor(tipoLista *l){
    if (!esNulaLista (*l)){
        celdaLista *aux;
        aux = l -> ini;
        l -> ini = l -> ini -> sig;
        free(aux);
    }else{
        errorLista("Eliminar en una lista vacía");
    }
}

void eliminarMayor(tipoLista *l){
    if (!esNulaLista(*l)){
        celdaLista *aux;
        aux = l -> fin;
        l -> fin = l -> fin -> ant;
        free(aux);
    }else{
        errorLista("Eliminar en una lista vacía");
    }
}
tipoElementoLista consultarMenor(tipoLista l){
    return l.ini -> elem;
}

tipoElementoLista consultarMayor(tipoLista l){
    return l.fin -> elem;
}

bool estaElemento(tipoLista l, tipoElementoLista e){
    if (!esNulaLista(l)){
        celdaLista *aux;
        aux = l.ini;
        while (aux -> elem < e && aux -> sig != NULL){
            aux = aux -> sig;
        }
        return (aux -> elem == e);
    }else{
        return 0;
    }
}

bool esNulaLista(tipoLista l){
    return (l.ini == NULL);
}

void concatenar (tipoLista *l1, tipoLista *l2){
    celdaLista *aux;
    aux = l2 -> ini;
    while (aux != NULL){
        insertar(l1, aux -> elem);
        aux = aux -> sig;
    }

}

void imprimirLista (tipoLista l){
    celdaLista *aux;
    aux = (&l)->ini;
    while (aux != NULL){
        printf("%d ", aux -> elem);
        aux = aux -> sig;
    }
    printf("\n");
}
