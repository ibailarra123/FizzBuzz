/*
  FICHERO: pilaAtributosDinamica.h
  VERSION: 1.0.0
  HISTORICO:
  Creado por Aránzazu Raúl Itoiz García el 9/11/21.
*/

#include "listaOrdenadaAtributos.h"
#include <stdbool.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#define NUM_FLOATS 30

/**
 * cambiamos la estructura de datos de la pila para que pueda almacenar un struct como el
 * que necesitamos par el proyecto
 */

typedef float tep;
typedef struct celdaP{

  int id;
  enum r diagnosis;
  tep atributo[NUM_FLOATS];

  struct celdaP *sig;

} celdaPila;
typedef celdaPila* tipoPila;

void nuevaPila(tipoPila *);

void apilar(tipoPila *p, int id, enum r d,tep,tep,tep,tep,tep,tep,tep,tep,tep,tep,tep,tep,tep,tep,tep,tep,tep,tep,tep,tep,tep,tep,tep,tep,tep,tep,tep,tep,tep,tep);

void desapilar(tipoPila *);

void mostrarCima(tipoPila);

void escribirEnFichero(tipoPila , FILE *);

void normalizar(tipoPila *, int);

void mostrarPila(tipoPila, int);

void mostrarFicheroNormalizado(tipoPila, int fila, FILE *);

//void predecirK1(tipoPila *, int);

//void predecirK1ConLista(tipoPila *, int);

void predecirUsuarioKConLista(tipoPila *, int, int);

void calcularPrecision(tipoPila *, int, int);

void intercambioPosicionesPila(tipoPila *, tipoPila *, tipoPila *);

void wilson(tipoPila *, int *, int);

void informarDeResultado(tipoPila *);

bool esNulaPila(tipoPila);


