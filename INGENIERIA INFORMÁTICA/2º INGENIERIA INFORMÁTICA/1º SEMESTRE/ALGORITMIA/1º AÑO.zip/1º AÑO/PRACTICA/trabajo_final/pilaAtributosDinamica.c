/*
  FICHERO: pilaAtributosDinamica.c
  VERSION: 1.0.0
  HISTORICO:
  Creado por Raúl Itoiz García el 9/11/21.
*/

#include "pilaAtributosDinamica.h"


void nuevaPila(tipoPila *p){
	*p=NULL;
}

void errorPila(char s[]){
	printf("\n\n\nERROR en el modulo pilas: %s \n", s);
}

void apilar(tipoPila *p, int id, enum r d, tep radius_mean,tep texture_mean,tep perimeter_mean,tep area_mean,
			tep smoothness_mean,tep compactness_mean,tep concavity_mean,tep concave_points_mean,tep symmetry_mean,
   			tep fractal_dimension_mean,tep radius_se,tep texture_se,tep perimeter_se,tep area_se,tep smoothness_se,
			tep compactness_se,tep concavity_se,tep concave_points_se,tep symmetry_se,tep fractal_dimension_se,
   			tep radius_worst,tep texture_worst,tep perimeter_worst,tep area_worst,tep smoothness_worst,tep compactness_worst,
   			tep concavity_worst,tep concave_points_worst,tep symmetry_worst,tep fractal_dimension_worst) {

	tep nuevoDato[30];
	celdaPila *nuevo;
	nuevo=(celdaPila*)malloc(sizeof(celdaPila));
	nuevo->id = id;
	nuevo->diagnosis = d;
	nuevo->atributo[0] = radius_mean;
	nuevo->atributo[1] = texture_mean;
	nuevo->atributo[2] = perimeter_mean;
	nuevo->atributo[3] = area_mean;
	nuevo->atributo[4] = smoothness_mean;
	nuevo->atributo[5] = compactness_mean;
	nuevo->atributo[6] = concavity_mean;
	nuevo->atributo[7] = concave_points_mean;
	nuevo->atributo[8] = symmetry_mean;
	nuevo->atributo[9] = fractal_dimension_mean;

	nuevo->atributo[10] = radius_se;
	nuevo->atributo[11] = texture_se;
	nuevo->atributo[12] = perimeter_se;
	nuevo->atributo[13] = area_se;
	nuevo->atributo[14] = smoothness_se;
	nuevo->atributo[15] = compactness_se;
	nuevo->atributo[16] = concavity_se;
	nuevo->atributo[17] = concave_points_se;
	nuevo->atributo[18] = symmetry_se;
	nuevo->atributo[19] = fractal_dimension_se;

	nuevo->atributo[20] = radius_worst;
	nuevo->atributo[21] = texture_worst;
	nuevo->atributo[22] = perimeter_worst;
	nuevo->atributo[23] = area_worst;
	nuevo->atributo[24] = smoothness_worst;
	nuevo->atributo[25] = compactness_worst;
	nuevo->atributo[26] = concavity_worst;
	nuevo->atributo[27] = concave_points_worst;
	nuevo->atributo[28] = symmetry_worst;
	nuevo->atributo[29] = fractal_dimension_worst;
	nuevo->sig=*p;
	*p=nuevo;
}

void desapilar(tipoPila *p){
	if (esNulaPila(*p))
		errorPila("No se puede desapilar en una pila vacia.");
	else{
		celdaPila *aux;
		aux=*p;
		*p=(*p)->sig;
		free(aux);
	}
}

void mostrarCima(tipoPila p){

	printf("%d,",p->id);
	if(p->diagnosis == 0) printf("B,");
	else printf("M,");

	for(int i = 0; i < NUM_FLOATS; i++) {

		printf("%f,",p->atributo[i]);
	}
	printf("\n");
}

void escribirEnFichero(tipoPila p, FILE *f) {

	fprintf(f,"%d,",p->id);
	if(p->diagnosis == 0) fprintf(f,"B,");
	else fprintf(f,"M,");

	for(int i = 0; i < NUM_FLOATS; i++) {

		fprintf(f,"%f,",p->atributo[i]);
	}
	fprintf(f,"\n");
}

void normalizar(tipoPila *p, int fila) {

	celdaPila *pAux1, *pAux2;
	pAux1 = pAux2 = *p;
	float mayor[NUM_FLOATS],menor[NUM_FLOATS];

	for(int i = 0; i<NUM_FLOATS; i++) {

		mayor[i] = menor[i] = pAux1->atributo[i];
	}
	pAux1 = pAux1->sig;

	for(int i = 0; i<(fila-1); i++) {

		for(int j = 0; j<NUM_FLOATS; j++){

			if(pAux1->atributo[j] > mayor[j]) mayor[j] = pAux1->atributo[j];
			if(pAux1->atributo[j] < menor[j]) menor[j] = pAux1->atributo[j];
		}
		pAux1 = pAux1->sig;
	}

	for(int j = 0; j<fila; j++) {

		for(int i =0; i<NUM_FLOATS; i++){

			pAux2->atributo[i] = (pAux2->atributo[i] - menor[i]) / (mayor[i] - menor[i]);
		}
		pAux2 = pAux2->sig;
	}
}

void mostrarPila(tipoPila p, int fila){

	celdaPila *pAux;
	pAux = p;
	for(int i = 0; i<fila; i++){

		mostrarCima(pAux);
		pAux = pAux->sig;
	}
}

void mostrarFicheroNormalizado(tipoPila p, int fila, FILE *f) {

	celdaPila *pAux;
	pAux = p;
	for(int i = 0; i<fila; i++){

		escribirEnFichero(pAux,f);
		pAux = pAux->sig;
	}
}

void predecirUsuarioKConLista(tipoPila *p, int fila, int numVecinos){

	celdaPila *pAux1;
	tipoLista listaAtributos;
	nuevaLista(&listaAtributos);

	pAux1 = *p;
	pAux1 = pAux1->sig;
	float d = 0.0;
	float dist[NUM_FLOATS];
	float distanciaTotal = 0.0;

	for(int i = 0; i<fila-1; i++) {

		for(int k = 0; k<NUM_FLOATS; k++) {

			dist[k] = pAux1->atributo[k] - (*p)->atributo[k];
			distanciaTotal = distanciaTotal + powf(dist[k],2);
		}
		distanciaTotal = sqrtf(distanciaTotal);
		insertar(&listaAtributos,pAux1->id,pAux1->diagnosis,distanciaTotal);
		pAux1 = pAux1->sig;
		distanciaTotal = 0.0;
	}
	int contador_M = 0;
	int contador_B = 0;
	int empate = consultarMenorDiagnosis(listaAtributos);

	for(int i=0; i<numVecinos; i++) {

		if(consultarMenorDiagnosis(listaAtributos) == 0) contador_B++;
		if(consultarMenorDiagnosis(listaAtributos) == 1) contador_M++;
		eliminarMenor(&listaAtributos);
	}
	if(contador_B == contador_M) (*p)->diagnosis = empate;
	if(contador_B > contador_M) (*p)->diagnosis = 0;
	if(contador_B < contador_M) (*p)->diagnosis = 1;
}

void calcularPrecision(tipoPila *p, int fila, int numVecinos){

	tipoPila pAux2;
    nuevaPila(&pAux2);
	celdaPila *pAux;
	pAux = *p;
	int diagnosticoAnt = 0, diagnosticoPost = 0, aciertos = 0, fallos = 0;
	for(int i = 0; i<fila; i++){

		diagnosticoAnt = (*p)->diagnosis;
		predecirUsuarioKConLista(p,fila,numVecinos);
		diagnosticoPost = (*p)->diagnosis;
		pAux = pAux->sig;
		apilar(&pAux2,(*p)->id,(*p)->diagnosis,(*p)->atributo[0],(*p)->atributo[1],(*p)->atributo[2],(*p)->atributo[3],(*p)->atributo[4],(*p)->atributo[5],(*p)->atributo[6],(*p)->atributo[7],(*p)->atributo[8],(*p)->atributo[9],
                (*p)->atributo[10],(*p)->atributo[11],(*p)->atributo[12],(*p)->atributo[13],(*p)->atributo[14],(*p)->atributo[15],(*p)->atributo[16],(*p)->atributo[17],(*p)->atributo[18],(*p)->atributo[19],
                (*p)->atributo[20],(*p)->atributo[21],(*p)->atributo[22],(*p)->atributo[23],(*p)->atributo[24],(*p)->atributo[25],(*p)->atributo[26],(*p)->atributo[27],(*p)->atributo[28],(*p)->atributo[29]);

		intercambioPosicionesPila(&pAux,p,&pAux2);
		if(diagnosticoAnt == diagnosticoPost) aciertos++;
		else fallos++;
		while(!esNulaPila(pAux2)) {

			desapilar(&pAux2);
		}
	}
	free(pAux2);
	float precision = ((float)aciertos/(float)fila)*100;
	printf("la precison es de %f \n",precision);
}

void intercambioPosicionesPila(tipoPila *p1, tipoPila *p2, tipoPila *pAux) {

	(*p2)->id = (*p1)->id;
	(*p2)->diagnosis = (*p1)->diagnosis;
	for(int i = 0; i<NUM_FLOATS; i++) {

		(*p2)->atributo[i] = (*p1)->atributo[i];
	}
	(*p1)->id = (*pAux)->id;
	(*p1)->diagnosis = (*pAux)->diagnosis;
	for(int i = 0; i<NUM_FLOATS; i++) {

		(*p1)->atributo[i] = (*pAux)->atributo[i];
	}
}
void wilson(tipoPila *p, int *fila, int numVecinos) {

	tipoPila pAux2;
    nuevaPila(&pAux2);
	celdaPila *pAux;
	pAux = *p;
	int diagnosticoAnt = 0, diagnosticoPost = 0;
	for(int i = 0; i<(*fila); i++){

		diagnosticoAnt = (*p)->diagnosis;
		predecirUsuarioKConLista(p,(*fila),numVecinos);
		diagnosticoPost = (*p)->diagnosis;
		pAux = pAux->sig;
		apilar(&pAux2,(*p)->id,(*p)->diagnosis,(*p)->atributo[0],(*p)->atributo[1],(*p)->atributo[2],(*p)->atributo[3],(*p)->atributo[4],(*p)->atributo[5],(*p)->atributo[6],(*p)->atributo[7],(*p)->atributo[8],(*p)->atributo[9],
                (*p)->atributo[10],(*p)->atributo[11],(*p)->atributo[12],(*p)->atributo[13],(*p)->atributo[14],(*p)->atributo[15],(*p)->atributo[16],(*p)->atributo[17],(*p)->atributo[18],(*p)->atributo[19],
                (*p)->atributo[20],(*p)->atributo[21],(*p)->atributo[22],(*p)->atributo[23],(*p)->atributo[24],(*p)->atributo[25],(*p)->atributo[26],(*p)->atributo[27],(*p)->atributo[28],(*p)->atributo[29]);

		intercambioPosicionesPila(&pAux,p,&pAux2);
		if(diagnosticoAnt != diagnosticoPost) {

			desapilar(p);
			(*fila)--;
		}
		while(!esNulaPila(pAux2)) {

			desapilar(&pAux2);
		}
	}
}

void informarDeResultado(tipoPila *p) {

	int informe = (*p)->diagnosis;
	if(informe == 0) {

		printf("\n\n ________________________________________________\n");
		printf("|                                                |\n");
		printf("| El diagnostico informa que el tumor es BENIGNO |\n");
		printf("| Id del paciente: %d                      |\n",(*p)->id);
		printf("|________________________________________________|\n\n");
	}
	if(informe == 1) {

		printf("\n\n ______________________________________________________\n");
		printf("|                                                      |\n");
		printf("| El diagnostico informa que el tumor es MALIGNO       |\n");
		printf("| Id del paciente: %d                            |\n",(*p)->id);
		printf("|                                                      |\n");
		printf("| Nº Asociacion Española Contra el Cancer: 900 100 036 |\n");
		printf("|______________________________________________________|\n\n");
	}
}

bool esNulaPila(tipoPila p){
	return p==NULL;
}
