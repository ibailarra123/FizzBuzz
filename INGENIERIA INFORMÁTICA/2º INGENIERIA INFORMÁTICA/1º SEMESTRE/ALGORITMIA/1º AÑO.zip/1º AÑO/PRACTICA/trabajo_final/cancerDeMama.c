#include "pilaAtributosDinamica.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <string.h>
#include <unistd.h>

int main(void){

    FILE *fp = fopen("data.csv","r");
    FILE *f_normalizado = fopen("CSV_normalizado.csv","w");

    if(fp == NULL) {

        perror("Error al abrir el fichero");
        exit(1);
    }

    char *line = NULL;          /* pointer to use with getline ()   */
    ssize_t read = 0;           /* characters read by getline ()    */
    size_t n = 0;               /* number of bytes to allocate      */
    char *sp = NULL;            /* start pointer for parsing line   */
    char *p = NULL;             /* end pointer to use parsing line  */
    int atributo = -2;           /* counter for field in line        */
    int fila = 0;               /* contador de numero de filas      */
    char res;
    int numVecinos = 0, accion = 0;

    int id;
    enum r diagnosis;
    tep atrib[NUM_FLOATS];

    tipoPila pilaAtributos;
    nuevaPila(&pilaAtributos);

    char buf[500];
    fgets(buf, sizeof(buf), fp); //skip the first line

    int i = 0;
    while(buf[i] != '\n' && i <= 500) {

        fprintf(f_normalizado,"%c",buf[i]);
        i++;
    }

    while ((read = getline (&line, &n, fp)) != -1){ /* lee cada linea del archvio*/

        sp = p = line;  /* pones el puntero de inicio y el puntero de recorrido al principio*/
        atributo = -2;

        while(*p) {

            if(*p == ','){      /*final de atributo*/

                *p = 0;         /*indicamos el inicio de la siguiente palabra*/

                if(atributo == -2) id = atoi(sp);
                if(atributo == -1) {

                    if (*sp == 'B') {

                        diagnosis = 0;
                    }
                    else {

                        diagnosis = 1;
                    }
                }
                atrib[atributo] = atof(sp);
                *p = ',';   /* reemplaza con el original */
                sp = p+1;   /* asignar al puntero de inicio una nueva posición de inicio*/
                atributo++; /* actualizar el contador de atributos*/
            }
            p++;            /* incrementamos el puntero p*/
        }
        atrib[29] = atof(sp);

        apilar(&pilaAtributos,id,diagnosis,atrib[0],atrib[1],atrib[2],atrib[3],atrib[4],atrib[5],atrib[6],atrib[7],atrib[8],atrib[9],
                atrib[10],atrib[11],atrib[12],atrib[13],atrib[14],atrib[15],atrib[16],atrib[17],atrib[18],atrib[19],
                atrib[20],atrib[21],atrib[22],atrib[23],atrib[24],atrib[25],atrib[26],atrib[27],atrib[28],atrib[29]);

        fila ++;
    }
    printf("\n\tMMMMMMMMMMMMMMMMMMMMMMMMMMMMMWWWWWWWWMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM\n");
    printf("\tMMMMMMMMMMMMMMMMMMMMMMMMWNK0OkxxxxxxkkO0XWMMMMMMMMMMMMMMMMMMMMMMMMMMMM\n");
    printf("\tMMMMMMMMMMMMMMMMMMMMMMWKkolcccllllcccccclx0NMMMMMMMMMMMMMMMMMMMMMMMMMM\n");
    printf("\tMMMMMMMMMMMMMMMMMMMMMNOdlcccccclllccccccccokXWMMMMMMMMMMMMMMMMMMMMMMMM\n");
    printf("\tMMMMMMMMMMMMMMMMMMMWKkdolcccccclllcccccccllld0NMMMMMMMMMMMMMMMMMMMMMMM\n");
    printf("\tMMMMMMMMMMMMMMMMMMWKxdoolcccccclllcccccccllllokNWMMMMMMMMMMMMMMMMMMMMM\n");
    printf("\tMMMMMMMMMMMMMMMMMW0xooooolcccccllcclccccloooolokXMMMMMMMMMMMMMMMMMMMMM\n");
    printf("\tMMMMMMMMMMMMMMMMWKxooooooodxxkkkkkkkkOkxdoooooooOWMMMMMMMMMMMMMMMMMMMM\n");
    printf("\tMMMMMMMMMMMMMMMMNOdooooood0NWWWMMMMMMMNOdoooooookXMMMMMMMMMMMMMMMMMMMM\n");
    printf("\tMMMMMMMMMMMMMMMMNkooooooodx0WMMMMMMMMW0dooooooookXMMMMMMMMMMMMMMMMMMMM\n");
    printf("\tMMMMMMMMMMMMMMMMNOdoooooooox0WMMMMMMWKxoooooooookNMMMMMMMMMMMMMMMMMMMM\n");
    printf("\tMMMMMMMMMMMMMMMMW0doooooooood0NMMMWNKxdooooooood0WMMMMMMMMMMMMMMMMMMMM\n");
    printf("\tMMMMMMMMMMMMMMMMMNkdooooooooodkXWW0kxooooooooooxXWMMMMMMMMMMMMMMMMMMMM\n");
    printf("\tMMMMMMMMMMMMMMMMMWKxooooooooooox0Oxdooooooooddd0WMMMMMMMMMMMMMMMMMMMMM\n");
    printf("\tMMMMMMMMMMMMMMMMMMWKxoooooooolllododooooooooodONMMMMMMMMMMMMMMMMMMMMMM\n");
    printf("\tMMMMMMMMMMMMMMMMMMMW0dooooollllooooooooooooodkXMMMMMMMMMMMMMMMMMMMMMMM\n");
    printf("\tMMMMMMMMMMMMMMMMMMMMW0dollllllooooooooooooodkXWMMMMMMMMMMMMMMMMMMMMMMM\n");
    printf("\tMMMMMMMMMMMMMMMMMMMMMW0dlllclooooooooooooodxKWMMMMMMMMMMMMMMMMMMMMMMMM\n");
    printf("\tMMMMMMMMMMMMMMMMMMMMMMW0dcclooooooooooooodxKWMMMMMMMMMMMMMMMMMMMMMMMMM\n");
    printf("\tMMMMMMMMMMMMMMMMMMMMMMMWKdlooooooooooooooxKWMMMMMMMMMMMMMMMMMMMMMMMMMM\n");
    printf("\tMMMMMMMMMMMMMMMMMMMMMMMMN0doooooooooooooooONMMMMMMMMMMMMMMMMMMMMMMMMMM\n");
    printf("\tMMMMMMMMMMMMMMMMMMMMMMMW0xdooooooooooooolclONMMMMMMMMMMMMMMMMMMMMMMMMM\n");
    printf("\tMMMMMMMMMMMMMMMMMMMMMMW0xoooooooooooooolcccoONMMMMMMMMMMMMMMMMMMMMMMMM\n");
    printf("\tMMMMMMMMMMMMMMMMMMMMMW0xoooooooooooooollcllloONMMMMMMMMMMMMMMMMMMMMMMM\n");
    printf("\tMMMMMMMMMMMMMMMMMMMMW0xoooooooooooooollllllllokNMMMMMMMMMMMMMMMMMMMMMM\n");
    printf("\tMMMMMMMMMMMMMMMMMMMW0xoooooooooooooolllllllloookXWMMMMMMMMMMMMMMMMMMMM\n");
    printf("\tMMMMMMMMMMMMMMMMMMW0xoooooooooooddolllllllooooodkXWMMMMMMMMMMMMMMMMMMM\n");
    printf("\tMMMMMMMMMMMMMMMMMW0xooooooooooodx0OxdllooooooooodxKWMMMMMMMMMMMMMMMMMM\n");
    printf("\tMMMMMMMMMMMMMMMMWKxooooooooooooxKWWNKxoooooooooooox0WMMMMMMMMMMMMMMMMM\n");
    printf("\tMMMMMMMMMMMMMMMWKxoodoooooooodxKWMMMWXkooooooooooood0NMMMMMMMMMMMMMMMM\n");
    printf("\tMMMMMMMMMMMMMMW0xdoooooooodooxKWMMMMMMXOdooooooooooodONWMMMMMMMMMMMMMM\n");
    printf("\tMMMMMMMMMMMMMWKxooooooooooooxKWMMMMMMMMNOdooooooooooodkXWMMMMMMMMMMMMM\n");
    printf("\tMMMMMMMMMMMMWKxddddddddddddxKWMMMMMMMMMMN0xddddddddddddkKWMMMMMMMMMMMM\n");
    printf("\tMMMMMMMMMMMMWXKKKKKKKKKKKKKXWMMMMMMMMMMMMWXKKKKKKKKKKKKKNWMMMMMMMMMMMM\n");
    printf("\tMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM\n");
    
    printf("\nPREDICCION EN LA NATURALEZA DE UN TUMOR MAMARIO\n");
    printf("-----------------------------------------------\n\n");
    printf("Introduce el numero de vecinos con los que comparar: ");
    scanf("%d",&numVecinos);
    getchar();
    printf("\n\t¿Desea introducir los datos de un paciente [s/n]?: ");
    scanf(" %c",&res);
    printf("\n");

    if(res == 's' || res == 'S') {
        printf("\n ____________________________________________________________________________________\n");
        printf("|                                                                                   |\n");
        printf("| A continuación deberá de introducir los 31 datos del paciente que desea consultar |\n");
        printf("|___________________________________________________________________________________|\n\n");
        printf("Los datos entre corchetes [] son solo de referencia\n");
        printf("Tenga paciencia, es por su salud\n");
        printf("\n-------------------------------------------------------------------------------------\n\n");

        printf("\tId del paciente [sugerencia: 389]: ");
        scanf("%d",&id);
        printf("\tradius_mean [8.0 - 23.0 (mm)]: ");
        scanf("%f",&atrib[0]);
        printf("\ttexture_mean [10.0 - 25.0]: ");
        scanf("%f",&atrib[1]);
        printf("\tperimeter_mean [50.0 - 140.0 (mm)]: ");
        scanf("%f",&atrib[2]);
        printf("\tarea_mean [180.0 - 1500.0 (mm)]: ");
        scanf("%f",&atrib[3]);
        printf("\tsmoothness_mean [0.08 - 0.15]: ");
        scanf("%f",&atrib[4]);
        printf("\tcompactness_mean [0.05 - 0.3]: ");
        scanf("%f",&atrib[5]);
        printf("\tconcavity_mean [0.01 - 0.4]: ");
        scanf("%f",&atrib[6]);
        printf("\tconcave_points_mean [0.01 - 0.15]: ");
        scanf("%f",&atrib[7]);
        printf("\tsymmetry_mean [0.1 - 0.3]: ");
        scanf("%f",&atrib[8]);
        printf("\tfractal_dimension_mean [0.05 - 0.08]: ");
        scanf("%f",&atrib[9]);

        printf("\tradius_se [0.1 - 1.3 (mm)]: ");
        scanf("%f",&atrib[10]);
        printf("\ttexture_se [0.6 - 3]: ");
        scanf("%f",&atrib[11]);
        printf("\tperimeter_se [1.0 - 6.0 (mm)]: ");
        scanf("%f",&atrib[12]);
        printf("\tarea_se [15.0 - 130.0 (mm)]: ");
        scanf("%f",&atrib[13]);
        printf("\tsmoothness_se [0.04 - 0.2]: ");
        scanf("%f",&atrib[14]);
        printf("\tcompactness_se [0.01 - 0.1]: ");
        scanf("%f",&atrib[15]);
        printf("\tconcavity_se [0.01 - 0.1]: ");
        scanf("%f",&atrib[16]);
        printf("\tconcave_points_se [0.005 - 0.03]: ");
        scanf("%f",&atrib[17]);
        printf("\tsymmetry_se [0.01 - 0.05]: ");
        scanf("%f",&atrib[18]);
        printf("\tfractal_dimension_se [0.001 - 0.01]: ");
        scanf("%f",&atrib[19]);

        printf("\tradius_worst [10.0 - 30.0 (mm)]: ");
        scanf("%f",&atrib[20]);
        printf("\ttexture_worst [15.0 - 40.0]: ");
        scanf("%f",&atrib[21]);
        printf("\tperimeter_worst [30.0 - 220.0 (mm)]: ");
        scanf("%f",&atrib[22]);
        printf("\tarea_worst [400.0 - 2000.0 (mm)]: ");
        scanf("%f",&atrib[23]);
        printf("\tsmoothness_worst [0.1 - 0.20]: ");
        scanf("%f",&atrib[24]);
        printf("\tcompactness_worst [0.05 - 0.6]: ");
        scanf("%f",&atrib[25]);
        printf("\tconcavity_worst [0.1 - 0.6]: ");
        scanf("%f",&atrib[26]);
        printf("\tconcave_points_worst [0.05 - 0.25]: ");
        scanf("%f",&atrib[27]);
        printf("\tsymmetry_worst [0.2 - 0.5]: ");
        scanf("%f",&atrib[28]);
        printf("\tfractal_dimension_worst [0.07 - 0.15]: ");
        scanf("%f",&atrib[29]);
        printf("\nGracias por aportar los datos\n");

        diagnosis = 0;

        apilar(&pilaAtributos,id,diagnosis,atrib[0],atrib[1],atrib[2],atrib[3],atrib[4],atrib[5],atrib[6],atrib[7],atrib[8],atrib[9],
                atrib[10],atrib[11],atrib[12],atrib[13],atrib[14],atrib[15],atrib[16],atrib[17],atrib[18],atrib[19],
                atrib[20],atrib[21],atrib[22],atrib[23],atrib[24],atrib[25],atrib[26],atrib[27],atrib[28],atrib[29]);

        fila ++;
    }

    printf("Procediendo al analisis. . .\n\n");

    fclose(fp);
    if(line)
        free(line);

    fila--;
    normalizar(&pilaAtributos,fila);
    mostrarFicheroNormalizado(pilaAtributos,fila,f_normalizado);

    printf("Que dese hacer ahora?:\n");
    printf("\t1: wilson y calcular la precisión\n");
    printf("\t2: calcular la precision sin wilson\n");
    printf("\t3: predecir el resultado del paciente introducido o en su defecto del primero de la pila\n");
    printf("\t4: salir\n");
    printf("\n\t respuesta: ");
    scanf("%d",&accion);
    switch (accion)
    {
    case 1:

        wilson(&pilaAtributos,&fila,numVecinos);
        calcularPrecision(&pilaAtributos,fila,numVecinos);
        break;

    case 2:

        calcularPrecision(&pilaAtributos,fila,numVecinos);
        break;

    case 3:

        predecirUsuarioKConLista(&pilaAtributos,fila,numVecinos);
        informarDeResultado(&pilaAtributos);
        break;

    default:
        break;
    }

    return 0;
}