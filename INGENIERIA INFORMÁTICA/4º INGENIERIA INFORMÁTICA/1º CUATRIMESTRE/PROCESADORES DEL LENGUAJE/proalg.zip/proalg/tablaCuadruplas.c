#include <stdlib.h>
#include <stdio.h>
#include "tablaCuadruplas.h"
#include "tablaSimbolos.h"

TablaCuadruplas tablaCuadruplas;
const char * nombres_tiposCuadruplas[] =    {"SUMA_ENTEROS", "SUMA_REALES", "RESTA_ENTEROS", "RESTA_REALES", "MULTIPLICACION_ENTEROS", "MULTIPLICACION_REALES", "DIVISION_ENTEROS", "DIVISION_REALES", "OP_MODULO", "DIV_ENTEROS", "ENTERO_A_REAL", "OPERANDO_NULO", "=", ">", "<", ">=", "<=", "!=", "GOTO", "= VERDADERO","= FALSO", ":=", "VERDADERO", "FALSO"};

void inicializarTablaCuadruplas(){
    tablaCuadruplas.siguientePosicion=0;
}

int gen(int resultado, int operando1, int operador, int operando2){
    int siguientePosicion = tablaCuadruplas.siguientePosicion;
    tablaCuadruplas.tabla[siguientePosicion].operando1 = operando1;
    tablaCuadruplas.tabla[siguientePosicion].operando2 = operando2;
    tablaCuadruplas.tabla[siguientePosicion].operador = operador;
    tablaCuadruplas.tabla[siguientePosicion].resultado = resultado;
    tablaCuadruplas.siguientePosicion++;
    return siguientePosicion;

}

int makelist(int posicion){
    return posicion;
}

void backpatch(int* tabla_booleanos, int siguientePosicion, int m_quad){
    for(int i = 0; i < siguientePosicion; i++){
        if(tablaCuadruplas.tabla[tabla_booleanos[i]].resultado == -1){
            tablaCuadruplas.tabla[tabla_booleanos[i]].resultado = m_quad;
        }
    }
}

void merge(int* tabla_booleanos_1, int siguientePosicion_1, int* tabla_booleanos_2, int siguientePosicion_2, int* tabla_resultado){
    for (int i = 0; i < siguientePosicion_1; i++) {
        tabla_resultado[i] = tabla_booleanos_1[i]; 
    }
    for(int i = siguientePosicion_1; i < siguientePosicion_1 + siguientePosicion_2; i++){
        tabla_resultado[i] = tabla_booleanos_2[i - siguientePosicion_1];
    }
}


const char* obtenerNombreOperando(int indice) {
    if (indice == OPERANDO_NULO) {
        return "Nulo";
    } else {
        return tabla_Simbolos.tabla[indice].nombre;
    }
}

// Función principal para imprimir la tabla de cuádruplas
void imprimairTablaCuadruplas() {
    FILE* archivo = fopen("tablaCuadruplas.txt", "w");

    if (archivo == NULL) {
        printf("No se pudo abrir el archivo.");
        return;
    }

    // Imprimir encabezado
    fprintf(archivo, "sigPos\t\tOperando1\tOperador\tOperando2\tResultado\n");

    for (int i = 0; i < tablaCuadruplas.siguientePosicion; ++i) {
        const char* op1 = obtenerNombreOperando(tablaCuadruplas.tabla[i].operando1);
        const char* op2 = obtenerNombreOperando(tablaCuadruplas.tabla[i].operando2);
        const char* operador = nombres_tiposCuadruplas[tablaCuadruplas.tabla[i].operador];

        fprintf(archivo, "%d\t\t%s\t\t%s\t\t%s\t\t%d\n", i, op1, operador, op2, tablaCuadruplas.tabla[i].resultado);
    }

    fclose(archivo); // Cerrar el archivo después de escribir
}
