#ifndef TABLA_SIMBOLOS_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define TABLA_SIZE 100

#define TABLA_SIMBOLOS_H

typedef enum TipoConstantes{
    ENTERO,
    REAL,
    STRING,
    CARACTER,
    BOOLEANO
}TipoConstantes;

typedef struct Simbolo{
    int id;
    char nombre[50];
    int tipo;
}Simbolo;

typedef struct TablaSimbolos{
    Simbolo tabla[TABLA_SIZE];
    int siguientePosicion;
    int siguienteId;
    int siguienteTemporal;
}TablaSimbolos;

extern TablaSimbolos tabla_Simbolos;

void inicializarTablaSimbolos();
int nueva_variable(char nombreNuevaVariable[50]);
void cambia_tipo_variable(int id, int tipo);
char* extraer_nombre_variable(int id);
int extraer_posicion_variable(char* nombre);
int extraer_tipo_variable(char* nombre);
void imprimirTablaSimbolos();
int nueva_variable_temporal();
int nueva_variable_temporal_booleana();
int nueva_variableLiteral();

#endif
