#ifndef TABLA_CUADRUPLAS_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "tablaSimbolos.h"

#define TABLA_CUADRUPLAS_H

typedef struct Cuadrupla{
    int operando1;
    int operando2;
    int operador;
    int resultado;
}Cuadrupla;

typedef struct TablaCuadruplas{
    Cuadrupla tabla[TABLA_SIZE];
    int siguientePosicion;
    int siguienteId;
}TablaCuadruplas;
extern TablaCuadruplas tablaCuadruplas;

typedef enum operacion{
    SUMA_ENTEROS,
    SUMA_REALES,
    RESTA_ENTEROS,
    RESTA_REALES,
    MULTIPLICACION_ENTEROS,
    MULTIPLICACION_REALES,
    DIVISION_ENTEROS,
    DIVISION_REALES,
    OP_MODULO,
    DIV_ENTEROS,
    ENTERO_A_REAL,
    OPERANDO_NULO,
    IGUAL_BOOLEANO,
    MAYOR_BOOLEANO,
    MENOR_BOOLEANO,
    MAYOR_IGUAL_BOOLEANO,
    MENOR_IGUAL_BOOLEANO,
    DISTINTO_BOOLEANO,
    GOTO,
    IGUAL_VERDADERO,
    IGUAL_FALSO,
    ASIGNACION_A,
    EVERDADERO,
    EFALSO
}operacion;

void inicializarTablaCuadruplas();
int gen(int resultado, int operando1, int operador, int operando2);
void backpatch(int* tabla_booleanos, int siguientePosicion, int m_quad);
void merge(int* tabla_booleanos_1, int siguientePosicion_1, int* tabla_booleanos_2, int siguientePosicion_2, int* tabla_resultado);
void imprimairTablaCuadruplas();
int makelist(int posicion);
const char *obtenerNombreOperando(int indice);

#endif
