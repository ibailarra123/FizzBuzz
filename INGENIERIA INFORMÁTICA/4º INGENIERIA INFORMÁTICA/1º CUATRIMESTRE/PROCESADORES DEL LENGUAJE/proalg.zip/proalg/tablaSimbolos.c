#include "tablaSimbolos.h"
#include <string.h>

TablaSimbolos tabla_Simbolos;
const char * nombres_tipos[] = {"ENTERO", "REAL", "STRING", "CARACTER", "BOOLEANO", "OPREL"};

void inicializarTablaSimbolos(){
    for(int i = 0; i < 100; i++){
        strcpy(tabla_Simbolos.tabla[i].nombre, "");
    }
    tabla_Simbolos.siguienteId = 0;
    tabla_Simbolos.siguientePosicion=0;
}

int nueva_variable(char nombreNuevaVariable[50]){
    int posicion = tabla_Simbolos.siguientePosicion;
    tabla_Simbolos.tabla[posicion].id = tabla_Simbolos.siguienteId;
    strcpy(tabla_Simbolos.tabla[posicion].nombre,nombreNuevaVariable);
    tabla_Simbolos.siguienteId++;
    tabla_Simbolos.siguientePosicion++;
    return tabla_Simbolos.tabla[posicion].id;
}

int nueva_variableLiteral(){
    char nombreNuevaVariable[50];
    int posicion = tabla_Simbolos.siguientePosicion;
    sprintf(nombreNuevaVariable,"L.R.%d",posicion);
    tabla_Simbolos.tabla[posicion].id = tabla_Simbolos.siguienteId;
    strcpy(tabla_Simbolos.tabla[posicion].nombre,nombreNuevaVariable);
    tabla_Simbolos.siguienteId++;
    tabla_Simbolos.siguientePosicion++;
    return tabla_Simbolos.tabla[posicion].id;
}

int nueva_variable_temporal(){
    char nombreNuevaVariableTemporal[50];
    sprintf(nombreNuevaVariableTemporal,"Temporal%d", tabla_Simbolos.siguientePosicion);
    tabla_Simbolos.siguienteTemporal++;
    return nueva_variable(nombreNuevaVariableTemporal);
}

int nueva_variable_temporal_booleana(){
    char nombreNuevaVariableBooleanaTemporal[50];
    sprintf(nombreNuevaVariableBooleanaTemporal,"TemporalBooleana%d", tabla_Simbolos.siguienteTemporal);
    tabla_Simbolos.siguienteTemporal++;
    return nueva_variable(nombreNuevaVariableBooleanaTemporal);
}

void cambia_tipo_variable(int id, int tipo){
    tabla_Simbolos.tabla[id].tipo = tipo;
}

char* extraer_nombre_variable(int id){
    return tabla_Simbolos.tabla[id].nombre;
}

int extraer_tipo_variable(char* nombre){
    for (int i = 0; i < 100; ++i) {
        if(strcmp(nombre, tabla_Simbolos.tabla[i].nombre)==0){
            return tabla_Simbolos.tabla[i].tipo;
        }
    }
}

int extraer_posicion_variable(char* nombre){
    for (int i = 0; i <100; ++i) {
        if(strcmp(nombre,tabla_Simbolos.tabla[i].nombre)==0){
            return i;
        }
    }
} 

void imprimirTablaSimbolos() {
    FILE *archivo = fopen("tablaSimbolos.txt", "w"); // Abre el archivo en modo escritura

    if (archivo == NULL) {
        printf("No se pudo abrir el archivo.");
        return;
    }

    fprintf(archivo, "Tabla de símbolos:\n");
    fprintf(archivo, "ID\tNombre\t\tTipo\n");

    for (int i = 0; i < tabla_Simbolos.siguientePosicion; ++i) {
        fprintf(archivo, "%d\t%s\t\t%s\n", tabla_Simbolos.tabla[i].id, tabla_Simbolos.tabla[i].nombre, nombres_tipos[tabla_Simbolos.tabla[i].tipo]);
    }

    fclose(archivo); // Cierra el archivo después de escribir
}
