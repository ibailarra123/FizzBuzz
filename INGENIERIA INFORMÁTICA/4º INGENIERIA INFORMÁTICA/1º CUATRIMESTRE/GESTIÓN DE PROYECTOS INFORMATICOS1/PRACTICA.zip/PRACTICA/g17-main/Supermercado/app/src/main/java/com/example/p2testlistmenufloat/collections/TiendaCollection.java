package com.example.p2testlistmenufloat.collections;

import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.annotation.NonNull;

import com.example.p2testlistmenufloat.R;
import com.example.p2testlistmenufloat.modelo.Categoria;
import com.example.p2testlistmenufloat.modelo.Producto;
import com.example.p2testlistmenufloat.modelo.Tienda;
import com.example.p2testlistmenufloat.modelo.Usuario;
import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CountDownLatch;

public class TiendaCollection {


    private List<Tienda> local_tiendalist = new ArrayList<>();
    Set<String> nombresUnicos = new HashSet<>();
    public TiendaCollection(){
    }
    public void getTiendaServerUpdate()  {
        ParseQuery<Tienda> query = ParseQuery.getQuery("tiendas");
        query.findInBackground((objects, e) -> {
            if (e == null) {
                local_tiendalist.addAll(objects);
                Log.d("object query server OK:", "getUsuariosServerUpdate()");
            } else {
                Log.d("error query, reason: " + e.getMessage(), "getUsuariosServerUpdate()");
            }
        });
    }
    public void getTiendaServerUpdate(ListView lista)  {
        local_tiendalist.clear();
        ParseQuery<Tienda> query = ParseQuery.getQuery("tiendas");
        query.findInBackground((objects, e) -> {
            if (e == null) {
                local_tiendalist.addAll(objects);
                Comparator<Tienda> comparadorPorNombre = Comparator.comparing(Tienda::getNombre);
                local_tiendalist.sort(comparadorPorNombre);
                ArrayAdapter<Tienda> pointItemsAdapter =
                        new ArrayAdapter<>(lista.getContext(), R.layout.row_layout3,
                                R.id.listText2,local_tiendalist);
                lista.setAdapter(pointItemsAdapter);
                pointItemsAdapter.notifyDataSetChanged();
                Log.d("object query server OK:", "getUsuariosServerUpdate()");
            } else {
                Log.d("error query, reason: " + e.getMessage(), "getUsuariosServerUpdate()");
            }
        });
    }


    public void addTiendaUpdate(@NonNull Tienda aTienda, boolean modificado){
        aTienda.saveInBackground(e -> {
            if (e == null){
                if (!modificado)
                    local_tiendalist.add(aTienda);
                Log.d("object saved in server:", "addObjectUpdate()");
            } else {
                Log.d("save failed, reason: "+ e.getMessage(), "addObjectUpdate()");
            }

        });

    }
    public List<Tienda> getLocal_tiendalist() {
        return local_tiendalist;
    }

    public void eliminarTienda(Tienda tienda) {
        local_tiendalist.remove(tienda);
        ParseObject.createWithoutData("user", tienda.getObjectId()).deleteInBackground(e -> {
            if (e == null) {
                Log.d("Tienda eliminada", "eliminarTienda()");
            } else {
                Log.d("Error" + e.getMessage(), "eliminarTienda()");
            }
        });
    }

    public void modificaTienda(Tienda tienda, Tienda tienda1){

        ParseQuery<ParseObject> query = ParseQuery.getQuery("tiendas");
        query.whereEqualTo("nombreTienda", tienda.getNombre());
        tienda.setNombre(tienda1.getNombre());
        tienda.setMapa(tienda1.getMapa());
        tienda.setCodigoPostal(tienda1.getCodigoPostal());

        query.getFirstInBackground((object, e) -> {
            if (e == null) {
                object.put("nombreTienda",tienda1.getNombre());
                object.put("codigoPostal",tienda1.getCodigoPostal());
                object.put("geoPoint",tienda1.getMapa());
                // Guardar el objeto actualizado en la base de datos
                object.saveInBackground(e1 -> {
                    if (e1 == null) {
                        Log.d("", "cambiarValorBooleanoContrario()");
                    } else {
                        Log.d("Error" + e1.getMessage(), "cambiarValorBooleanoContrario()");
                    }
                });
            } else {
                Log.d("Error" + e.getMessage(), "cambiarValorBooleanoContrario()");
            }
        });
    }

}
