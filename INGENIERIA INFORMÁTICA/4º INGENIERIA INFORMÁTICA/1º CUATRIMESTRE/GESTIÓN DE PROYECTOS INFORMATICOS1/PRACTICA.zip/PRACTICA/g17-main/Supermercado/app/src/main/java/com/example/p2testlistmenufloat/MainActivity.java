package com.example.p2testlistmenufloat;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.p2testlistmenufloat.databinding.ActivityMainBinding;
import com.example.p2testlistmenufloat.modelo.Pedido;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;
    ListView listView;
    ArrayAdapter<Pedido> todoItemsAdapter;
    private static final int SHOW_INICIO = 4;
    private static final int SHOW_MAP_ACTIVITY = 3;
    private static final int SHOW_ADDACTIVITY = 2;
    FloatingActionButton fab;
    PedidoProductoApp ppa;

    Integer posicionUsuario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Cosas que hacen falta
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        fab = binding.fab;
        // OBTENEMOS EL INTENT Y POR TANTO LA POSICIÓN
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        posicionUsuario = bundle.getInt ( "posicionUsuario" );

        //GET APLICATION CONTEXT
        ppa = (PedidoProductoApp) getApplicationContext();

        TextView textViewPrecioTotal = findViewById(R.id.precioTotal);
        textViewPrecioTotal.setText("0 €");

        //Muestro la textview de acuerdo al diseño del row_layout
        ListView listView = (ListView) findViewById(R.id.list);
        todoItemsAdapter = new ArrayAdapter<Pedido>(this, R.layout.row_layout, R.id.listText2, ppa.getConsumicionesList());
        listView.setAdapter(todoItemsAdapter);

        //Función a la que llama el botón flotante
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle bundle = new Bundle();
                bundle.putInt("noMostrarNueva",1);
                Intent intent = new Intent(getBaseContext() , AddConsumptionActivity.class);
                intent.putExtras(bundle);
                startActivityForResult(intent, SHOW_ADDACTIVITY);
            }
        });

    }


    public void productos(View view){ //Llamo a la lista de productos
        Intent intent = new Intent(this, ListProductCreateUpdate.class);
        startActivityForResult(intent, SHOW_ADDACTIVITY);
    }

    public void tiendas(View view){
        Intent intent = new Intent(this,ListaMapasActivity.class);
        startActivityForResult(intent,SHOW_MAP_ACTIVITY);
    }

    //Programo qué ocurre cuando se ha cerrado otra actividad
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        todoItemsAdapter.notifyDataSetChanged(); //Actualizo la lista
        Double precioTotal = ppa.getPrecioTotal();
        TextView textViewPrecioTotal = findViewById(R.id.precioTotal);
        textViewPrecioTotal.setText(Double.toString(precioTotal)+"€");
    }

    public void finalizar(View view){
        // Supongamos que ppa es tu objeto que contiene la lista de consumiciones
        ppa.getConsumicionesList().clear();

        // Notifica al ArrayAdapter que los datos han cambiado
        todoItemsAdapter.notifyDataSetChanged();
        showAlertDialog("El pedido se ha realizado con éxito");

        Double precioTotal = ppa.getPrecioTotal();
        TextView textViewPrecioTotal = findViewById(R.id.precioTotal);
        textViewPrecioTotal.setText(Double.toString(precioTotal)+"€");

    }

    public void showAlertDialog(String mensaje) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);

        // Configura el mensaje.
        alertDialogBuilder
                .setMessage(mensaje)
                .setCancelable(false)
                .setNeutralButton ("ACEPTAR",new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,int id) {
                        dialog.cancel();
                    }
                }).create().show();
    }
}
