package com.example.p2testlistmenufloat;

import androidx.fragment.app.FragmentActivity;

import android.content.Intent;
import android.os.Bundle;

import com.example.p2testlistmenufloat.modelo.Tienda;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.example.p2testlistmenufloat.databinding.ActivityMapaBinding;
import com.parse.ParseGeoPoint;

import java.util.ArrayList;
import java.util.List;

public class MapaActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMapaBinding binding;
    PedidoProductoApp ppa;
    List<Tienda> tiendasList ;
    Tienda tienda;
    int todas;
    int position;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        position = bundle.getInt("position");
        todas = bundle.getInt("todas");
        binding = ActivityMapaBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        ppa = (PedidoProductoApp) getApplicationContext();
        if(todas == 1)
            tiendasList = ppa.getTiendasCollection().getLocal_tiendalist();
        else
            tienda = ppa.getTiendasCollection().getLocal_tiendalist().get(position);
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        if (todas == 1) {
            for (Tienda tienda : tiendasList) {
                ParseGeoPoint mapa = tienda.getMapa();
                if (mapa != null) {
                    LatLng tiendaLocation = new LatLng(mapa.getLatitude(), mapa.getLongitude());
                    mMap.addMarker(new MarkerOptions().position(tiendaLocation).title(tienda.getNombre()));
                }
            }
            if (!tiendasList.isEmpty()) {
                LatLngBounds.Builder builder = new LatLngBounds.Builder();
                for (Tienda tienda : tiendasList) {
                    ParseGeoPoint mapa = tienda.getMapa();
                    if (mapa != null) {
                        LatLng tiendaLocation = new LatLng(mapa.getLatitude(), mapa.getLongitude());
                        builder.include(tiendaLocation);
                    }
                }
                LatLngBounds bounds = builder.build();
                int padding;

                padding = 100; // Padding en píxeles alrededor de los marcadore
                CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(bounds, padding);
                mMap.moveCamera(cu);
            }
        } else{
            ParseGeoPoint punto = tienda.getMapa();
            LatLng mapa = new LatLng(punto.getLatitude(), punto.getLongitude());
            mMap.addMarker(new MarkerOptions().position(mapa).title(tienda.getNombre()));
            mMap.moveCamera(CameraUpdateFactory.newLatLng(mapa));
            LatLngBounds.Builder builder = new LatLngBounds.Builder();
            builder.include(mapa);

            LatLngBounds bounds = builder.build();
            int padding = 5000; // Padding en píxeles alrededor de los marcadores
            CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(bounds, padding);
            mMap.moveCamera(cu);

        }
        // Ajustar la cámara para mostrar todos los marcadores

    }




}