package com.example.p2testlistmenufloat.modelo;

import com.parse.ParseClassName;
import com.parse.ParseFile;
import com.parse.ParseObject;

import java.io.File;


@ParseClassName("productos")
public class Producto extends ParseObject {
    String nombre;
    Double precio;

    Integer cantidadDisponible;

    ParseFile imagen;

    public Producto() {
    }

    public String getCategoria() {return getString("category");}

    public void setCategoria(String categoria){put("category", categoria);}
    public String getNombre() {
        return getString("name");
    }

    public Double getPrecio() {
        return getDouble("price");
    }

    public void setNombre(String nombre) {
        put("name", nombre);
    }

    public void setPrecio(Double precio) {
        put("price", precio);
    }

    public Integer getCantidadDisponible() {
        return getInt("cantidadDisponible");
    }

    public void setCantidadDisponible(Integer cantidadDisponible) {
        put("cantidadDisponible", cantidadDisponible);
    }

    public ParseFile getImagen() {
        return getParseFile("imagen");
    }

    public void setImagen(ParseFile parseFileImagen) {
        this.imagen = parseFileImagen;
    }
    @Override
    public String toString() {
        return this.getNombre () + "\nPrecio: " + this.getPrecio () + "€\nCantidad Disponible: "+ this.getCantidadDisponible();
    }
}
