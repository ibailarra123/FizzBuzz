package com.example.p2testlistmenufloat;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.p2testlistmenufloat.modelo.Producto;
import com.example.p2testlistmenufloat.modelo.Usuario;
import com.parse.ParseGeoPoint;

import java.util.ArrayList;
import java.util.List;

public class ListProductCreateUpdate extends AppCompatActivity {
    private ListView listView;
    String nombre;
    PedidoProductoApp ppa;
    private static final int SHOW_SUBACTIVITY = 1;
    ArrayAdapter<Producto> todoItemsAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_product_create_update);
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        nombre= bundle.getString("nombre");

        //Obtengo la referencia al controlador
        ppa = (PedidoProductoApp) getApplicationContext();

        listView = (ListView) findViewById(R.id.list);

        ppa.getProductosCollection().getProductoServerUpdate(listView, nombre);
        //Programo qué ocurre cuando pulso uno de los elementos de la lista
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Producto item = (Producto) listView.getItemAtPosition(position);
                Bundle bundle = new Bundle();
                bundle.putInt("position", position); //Mando la posición del elemento pulsado
                bundle.putString("nombre", item.getNombre());
                bundle.putDouble("precio", item.getPrecio());
                bundle.putInt("cantidadDisponible", item.getCantidadDisponible());
                bundle.putString("nombreCategoria",nombre);
                Intent intent = new Intent(getApplicationContext(), CreateUpdateProduct.class);
                intent.putExtras(bundle);
                startActivityForResult(intent, SHOW_SUBACTIVITY);
            }
        });
    }

    public void nuevoProducto(View view){ //Llamo a la actividad para crear o editar productos
        Bundle bundle = new Bundle();
        bundle.putInt("position", -1);
        bundle.putString("nombreCategoria",nombre);//Si llego desde aquí, mando un -1 para hacer ver que creo un producto nuevo
        Intent intent = new Intent(getApplicationContext(), CreateUpdateProduct.class);
        intent.putExtras(bundle);
        startActivityForResult(intent, 1);

    }

    public void volverAtras(View view){
        Intent intent = new Intent();
        setResult(4, intent);
        finish();
    }

    //Programo qué ocurre cuando se termina la actividad a la que he llamado
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == 1) {
            Bundle bundle = data.getExtras();
            int cantidadDisponible = bundle.getInt("cantidadDisponible");
            String nombre1 = bundle.getString("name");
            Double precio = bundle.getDouble("price");
            String categoria = bundle.getString("categoria");
            Producto aProducto = new Producto();
            aProducto.setNombre(nombre1);
            aProducto.setPrecio(precio);
            aProducto.setCantidadDisponible(cantidadDisponible);
            aProducto.setCategoria(categoria);
            ppa.getProductosCollection().addProductoUpdate(aProducto,listView,false);
            ppa.getProductosCollection().getProductoServerUpdate(listView, nombre);
        }else if(resultCode == 2){
            List<Producto> productos = ppa.getProductosCollection().getProductos();
            Bundle bundle = data.getExtras();
            int cantidadDisponible = bundle.getInt("cantidadDisponible");
            String nombre1 = bundle.getString("name");
            Double precio = bundle.getDouble("price");
            String categoria = bundle.getString("categoria");
            int position = bundle.getInt("position");
            Producto aProducto1 = productos.get(position);
            Producto aProducto = new Producto();
            aProducto.setPrecio(precio);
            aProducto.setNombre(nombre1);
            aProducto.setCantidadDisponible(cantidadDisponible);
            aProducto.setCategoria(categoria);

            ppa.getProductosCollection().modificaProducto(aProducto1,aProducto);

            ppa.getProductosCollection().getProductoServerUpdate(listView, nombre);
        }
    }
}