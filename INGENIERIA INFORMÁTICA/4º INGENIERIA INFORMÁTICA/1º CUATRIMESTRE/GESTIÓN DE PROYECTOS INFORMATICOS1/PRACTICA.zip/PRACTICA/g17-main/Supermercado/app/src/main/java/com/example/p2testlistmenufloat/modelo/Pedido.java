package com.example.p2testlistmenufloat.modelo;


import androidx.navigation.Navigator;

import com.parse.ParseClassName;
import com.parse.ParseObject;
@ParseClassName("pedido")
public class Pedido extends ParseObject {

    Producto producto;
    //
    int cantidad;

    public Pedido() {
    }

    public Producto getProducto() {
        return producto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    @Override
    public String toString() {
        return "\n"+cantidad+ " x " + producto.getNombre() + "(" + producto.getPrecio()+"€)";
    }
}