package com.example.p2testlistmenufloat.collections;

import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.annotation.NonNull;

import com.example.p2testlistmenufloat.R;
import com.example.p2testlistmenufloat.modelo.Tienda;
import com.example.p2testlistmenufloat.modelo.Usuario;
import com.parse.ParseObject;
import com.parse.ParseQuery;

import java.util.ArrayList;
import java.util.List;

public class UsuarioCollection {
    private List<Usuario> local_usuariolist = new ArrayList<> ();

    public List<Usuario> getLocal_usuariolist() {
        return local_usuariolist;
    }

    public void getUsuariosServerUpdate(){
        ParseQuery<Usuario> query = ParseQuery.getQuery("user");
        query.findInBackground((objects, e) -> {
            if (e == null) {
                this.local_usuariolist.addAll (  objects );
                Log.d("object query server OK:", "getUsuariosServerUpdate()");
            } else {
                Log.d("error query, reason: " + e.getMessage(), "getUsuariosServerUpdate()");
            }
        });
    }

    public boolean getUsuario_Name(String nombre){
        ParseQuery<Usuario> query = ParseQuery.getQuery("user");
        query.whereEqualTo("nombreUsuario", nombre);

        /*query.findInBackground((objects, e) -> {
            if (e == null) {
                System.out.println(objects);
                local_usuariolist = objects;

                Log.d("object query server OK:", "getUsuariosServerUpdate()");

                return true;
            } else {
                Log.d("error query, reason: " + e.getMessage(), "getUsuariosServerUpdate()");

                return false;
            }
        });*/
        return false;
    }

    public void addUsuarioUpdate(@NonNull Usuario aUsuario) {

        aUsuario.saveInBackground(e -> {
            if (e == null) {
                local_usuariolist.add(aUsuario);
                Log.d("object saved in server:", "addUsuarioUpdate()");
            } else {
                Log.d("save failed, reason: "+ e.getMessage(), "addUsuarioUpdate()");
            }
        });
    }
    public void modificaUsuario(@NonNull Usuario aUsuario,ListView listview){
        aUsuario.saveInBackground(e -> {
            if (e == null) {
                ArrayAdapter<Usuario> pointItemsAdapter;
                pointItemsAdapter = (ArrayAdapter<Usuario>) listview.getAdapter();
                pointItemsAdapter.notifyDataSetChanged();
                Log.d("object saved in server:", "addCommentUpdate()");
            } else {
                Log.d("save failed, reason: "+ e.getMessage(), "addCommentUpdate()");
            }
        });
    }

    public void eliminarUsuario(Usuario usuario) {
        local_usuariolist.remove(usuario);
        ParseObject.createWithoutData("user", usuario.getObjectId()).deleteInBackground(e -> {
            if (e == null) {
                Log.d("Usuario eliminado", "eliminarUsuario()");
            } else {
                Log.d("Error" + e.getMessage(), "eliminarUsuario()");
            }
        });
    }
    public void cambiaPrivilegios(Usuario usuario){
        usuario.setEsAdmin(!usuario.getEsAdmin());
        ParseQuery<ParseObject> query = ParseQuery.getQuery("user");
        query.whereEqualTo("objectId", usuario.getObjectId());

        query.getFirstInBackground((object, e) -> {
            if (e == null) {
                // Modificar el campo booleano en el objeto ParseObject
                object.put("esAdmin", usuario.getEsAdmin());

                // Guardar el objeto actualizado en la base de datos
                object.saveInBackground(e1 -> {
                    if (e1 == null) {
                        Log.d("", "cambiarValorBooleanoContrario()");
                    } else {
                        Log.d("Error" + e1.getMessage(), "cambiarValorBooleanoContrario()");
                    }
                });
            } else {
                Log.d("Error" + e.getMessage(), "cambiarValorBooleanoContrario()");
            }
        });


    }

}
