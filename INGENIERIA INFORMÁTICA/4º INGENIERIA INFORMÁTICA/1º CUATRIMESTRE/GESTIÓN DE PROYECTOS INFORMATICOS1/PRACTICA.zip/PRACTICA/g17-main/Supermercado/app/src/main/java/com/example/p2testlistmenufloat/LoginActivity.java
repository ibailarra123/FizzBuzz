package com.example.p2testlistmenufloat;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;

import com.example.p2testlistmenufloat.databinding.ActivityMainBinding;
import com.example.p2testlistmenufloat.modelo.Usuario;

import java.util.ArrayList;
import java.util.List;

public class LoginActivity extends AppCompatActivity {

    private static final int SHOW_SUBACTIVITY = 1;
    PedidoProductoApp ppa;
    private ListView listView;
    private ActivityMainBinding binding;

    private List<Usuario> usuarioList = new ArrayList<> ();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        ppa = (PedidoProductoApp)getApplicationContext();
        usuarioList = ppa.getUsuarioCollection().getLocal_usuariolist();
        setContentView ( R.layout.activity_login );
    }

    public void abrirRegistarActivity(View view){
        Intent intent = new Intent(this,RegistrarActivity.class);
        startActivityForResult(intent,SHOW_SUBACTIVITY);
    }

    public void iniciarSesion(View view) {
        // OBTENEMOS LOS EDIT TEXT
        EditText editTextNombre = findViewById(R.id.editTextUsername);
        EditText editTextPassword = findViewById(R.id.editTextPassword);
        String nombre = editTextNombre.getText ().toString ();
        String passwd = editTextPassword.getText ().toString ();


        Usuario aUsuario = null;
        aUsuario = existeUsuario (nombre, passwd);
        System.out.println("Hola");
        if(aUsuario == null){
            System.out.println ("NO EXISTE USUARIO O LA CONTRASEÑA NO ES CORRECTA");
            showAlertDialog ( "No existe el usuario o la contraseña no es correcta" );
        }else {
            System.out.println (aUsuario.toString ());
            boolean esAdmin = esAdmin(nombre);
            if (esAdmin){
                System.out.println("Es ADMIN");
                Intent intent = new Intent(this,MainAdminActivity.class);
                Bundle bundle = new Bundle ();
                System.out.println ("hola el index es: "+ usuarioList.indexOf ( aUsuario ));
                bundle.putInt ("posicionUsuario",usuarioList.indexOf ( aUsuario ));
                intent.putExtras ( bundle );
                startActivity (intent);
            }else{
                System.out.println("NO es ADMIN");
                Intent intent = new Intent(this,MainActivity.class);
                Bundle bundle = new Bundle ();
                System.out.println ("hola el index es: "+ usuarioList.indexOf ( aUsuario ));
                bundle.putInt ("posicionUsuario",usuarioList.indexOf ( aUsuario ));
                intent.putExtras ( bundle );
                startActivity (intent);
            }
        }
    }

    private Usuario existeUsuario(String nombre, String contraseña) {
        System.out.println(usuarioList);
        for (Usuario u:usuarioList) {
            System.out.println (u.toString ());
            if(((u.getNombre ().equals ( nombre )) ||(u.getEmail ().equals ( nombre ))) && u.getContrasenia ().equals ( contraseña )){
                return u;
            }
        }
        return null;
    }

    private boolean esAdmin(String nombre){
        for (Usuario u:usuarioList) {
            if(((u.getNombre ().equals ( nombre )) ||(u.getEmail ().equals ( nombre )))){
                if(u.getEsAdmin() == true) {
                    return true;
                }else{
                    return false;
                }
            }
        }
        return false;
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        System.out.println (data);
        System.out.println ("hola");
        Bundle bundle = data.getExtras();
        Usuario aUsuario = new Usuario ();
        aUsuario.setNombre ( bundle.getString ("nombreUsuario"));
        aUsuario.setApellidos (bundle.getString ("apellidosUsuario"));
        aUsuario.setTelefono (bundle.getInt ("telefonoUsuario"));
        aUsuario.setEmail (bundle.getString ("emailUsuario"));
        aUsuario.setContrasenia (bundle.getString ("contraseniaUsuario"));
        aUsuario.setEsAdmin (false);
        ppa.getUsuarioCollection ().addUsuarioUpdate (aUsuario);
    }
    public void showAlertDialog(String mensaje) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);

        // Configura el mensaje.
        alertDialogBuilder
                .setMessage(mensaje)
                .setCancelable(false)
                .setNeutralButton ("ACEPTAR",new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,int id) {
                        dialog.cancel();
                    }
                }).create().show();
    }
}