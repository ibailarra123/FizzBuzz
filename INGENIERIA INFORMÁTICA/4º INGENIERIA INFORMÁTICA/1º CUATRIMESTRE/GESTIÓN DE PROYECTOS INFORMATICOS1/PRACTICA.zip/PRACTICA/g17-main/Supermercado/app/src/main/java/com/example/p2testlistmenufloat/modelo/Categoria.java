package com.example.p2testlistmenufloat.modelo;

import com.parse.ParseClassName;
import com.parse.ParseFile;
import com.parse.ParseObject;

@ParseClassName("categoria")
public class Categoria extends ParseObject {
    String nombre;


    public Categoria() {
    }

    public String getNombre() {
        return getString("name");
    }


    public void setNombre(String nombre) {
        put("name", nombre);
    }

    @Override
    public String toString() {
        return this.getNombre ().toUpperCase();
    }
}
