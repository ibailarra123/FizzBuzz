package com.example.p2testlistmenufloat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.p2testlistmenufloat.modelo.Tienda;

public class EditarMapaActivity extends AppCompatActivity {

    private int posicion;
    private Tienda tienda;
    private PedidoProductoApp ppa;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar_mapa);
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        posicion = bundle.getInt("posicion");
        ppa = (PedidoProductoApp)getApplicationContext();
        System.out.println(posicion);
        tienda = ppa.getTiendasCollection().getLocal_tiendalist().get(posicion);

        TextView textView = findViewById(R.id.textView9);
        textView.setText(tienda.toString());
    }

    public void eliminar2(View view){
        ppa.getTiendasCollection().eliminarTienda(tienda);
        Intent intent = new Intent();
        setResult(RESULT_OK, intent);
        finish();
    }
}