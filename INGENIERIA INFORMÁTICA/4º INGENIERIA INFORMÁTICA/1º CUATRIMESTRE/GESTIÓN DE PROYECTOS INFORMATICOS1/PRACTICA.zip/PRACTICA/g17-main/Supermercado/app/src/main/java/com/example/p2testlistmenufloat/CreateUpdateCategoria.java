package com.example.p2testlistmenufloat;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.example.p2testlistmenufloat.modelo.Categoria;
import com.example.p2testlistmenufloat.modelo.Producto;

import java.util.List;

public class CreateUpdateCategoria extends AppCompatActivity {
    int position;
    Boolean debemosCrearNuevoProducto = Boolean.TRUE;
    PedidoProductoApp ppa;

    EditText editTextNombre;
    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_update_categoria);

        //Obtengo la referencia al controlador
        ppa = (PedidoProductoApp) getApplicationContext();

        //Cojo los datos del bundle
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        position = bundle.getInt("position");

        // OBTENEMOS LOS EDIT TEXT
        editTextNombre = findViewById(R.id.nombre);
        //Booleano que compueba si creo o si edito
        debemosCrearNuevoProducto = (position==-1);

        String nombre= bundle.getString("nombre");

        editTextNombre.setText(nombre);

        position= bundle.getInt("position");


    }
    public void guardar(View view){
        //Cojemos los datos guardados en los editText

        String nombre = editTextNombre.getText().toString();


        if (debemosCrearNuevoProducto){ //Caso de crear un nuevo producto
            Bundle bundle = new Bundle();
            bundle.putString("name", nombre);

            Intent intent = new Intent();
            intent.putExtras(bundle);
            setResult(RESULT_OK, intent);
            finish();
        }else{ //Caso de editar un producto existente
            List<Categoria> productos = ppa.getCategoriasList();
            productos.get(position).setNombre(nombre);
        }
        //Terminamos la ejecución de este intent
        Intent intent = new Intent();
        setResult(RESULT_OK, intent);
        finish();
    }
}
