package com.example.p2testlistmenufloat;

import android.app.AlertDialog;
import android.app.Application;
import android.content.Context;

import com.example.p2testlistmenufloat.collections.CategoriaCollection;
import com.example.p2testlistmenufloat.collections.PedidoCollection;
import com.example.p2testlistmenufloat.collections.ProductoCollection;
import com.example.p2testlistmenufloat.collections.TiendaCollection;
import com.example.p2testlistmenufloat.collections.UsuarioCollection;
import com.example.p2testlistmenufloat.modelo.*;
import com.parse.Parse;
import com.parse.ParseGeoPoint;
import com.parse.ParseObject;

import java.util.ArrayList;
import java.util.List;

public class PedidoProductoApp extends Application {
    //Tantas listas como modelos
    private List<Pedido> pedidos = new ArrayList<>();
    private List<Producto> productos = new ArrayList<>();
    private List<Categoria> categorias = new ArrayList<>();
    private List<Tienda> tiendas = new ArrayList<>();
    private ProductoCollection productosCollection;
    private TiendaCollection tiendasCollection;
    private UsuarioCollection usuarioCollection;
    private CategoriaCollection categoriasCollection;

    @Override
    public void onCreate() {
        super.onCreate();
        ParseObject.registerSubclass(Tienda.class);
        ParseObject.registerSubclass(Pedido.class);
        ParseObject.registerSubclass(Producto.class);
        ParseObject.registerSubclass(Usuario.class);
        ParseObject.registerSubclass(Categoria.class);
        //Cuando creo la lista, solo inicializo los productos
        //initializeListProducto();
        //initializeListTienda();
        tiendasCollection = new TiendaCollection();
        usuarioCollection = new UsuarioCollection ();
        productosCollection = new ProductoCollection();
        categoriasCollection = new CategoriaCollection();

        Parse.initialize(new Parse.Configuration.Builder(getApplicationContext())
                .applicationId(getString(R.string.back4app_app_id))
                .clientKey(getString(R.string.back4app_client_key))
                .server(getString(R.string.back4app_server_url))
                .build());
        usuarioCollection.getUsuariosServerUpdate();
        System.out.println(usuarioCollection.getLocal_usuariolist());
        tiendasCollection.getTiendaServerUpdate();
    }
    //Getters de las listas de los modelos
    public List<Pedido> getConsumicionesList() {return pedidos;}
    public List<Producto> getProductosList() {
        return productos;
    }

    public List<Categoria> getCategoriasList() {return categorias;}

    public List<Tienda> getTiendasList() {return tiendas;}


    public Double getPrecioTotal(){ //Método que calcula el precio total
        Double precioTotal = 0.0;
        for (int i = 0; i < pedidos.size(); i++){
            precioTotal += pedidos.get(i).getProducto().getPrecio()*pedidos.get(i).getCantidad();
        }
        return precioTotal;
    }

    public TiendaCollection getTiendasCollection(){return tiendasCollection;}

    public UsuarioCollection getUsuarioCollection(){return usuarioCollection;}

    public ProductoCollection getProductosCollection(){return productosCollection;}

    public CategoriaCollection getCategoriasCollection(){return categoriasCollection;}


}
