package com.example.p2testlistmenufloat;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.p2testlistmenufloat.modelo.Producto;
import com.example.p2testlistmenufloat.modelo.Tienda;
import com.parse.ParseGeoPoint;
import com.parse.ParseObject;

import java.util.List;

public class GestionMapasActivity extends AppCompatActivity {

    private static final int SHOW_SUBACTIVITY = 1;
    PedidoProductoApp ppa;
    private ListView listView2;
    private List<Tienda> tiendas2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gestion_mapas);
        ppa = (PedidoProductoApp) getApplicationContext();

        listView2 = (ListView) findViewById(R.id.list2);

        tiendas2 = ppa.getTiendasCollection().getLocal_tiendalist();

        ppa.getTiendasCollection().getTiendaServerUpdate(listView2);
        //Programo qué ocurre cuando pulso uno de los elementos de la lista
        listView2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String nombreTienda = (String) listView2.getItemAtPosition(position).toString();
                Tienda item = (Tienda) tiendas2.get(position);
                Bundle bundle = new Bundle();
                bundle.putInt("position", position); //Mando la posición del elemento pulsado
                bundle.putString("nombre", item.getNombre());
                bundle.putInt("codigo", item.getCodigoPostal());
                bundle.putDouble("latitud", item.getMapa().getLatitude());
                bundle.putDouble("longitud",item.getMapa().getLongitude());
                Intent intent = new Intent(getApplicationContext(), CreateUpdateTienda.class);
                intent.putExtras(bundle);
                startActivityForResult(intent, SHOW_SUBACTIVITY);
            }
        });
    }

    public void todas(View view){
        Bundle bundle = new Bundle();
        bundle.putInt("todas",1);//Meto un uno para decir que quiero mostrar todas las tiendas
        Intent intent = new Intent(getApplicationContext(), MapaActivity.class);
        intent.putExtras(bundle);
        startActivityForResult(intent, SHOW_SUBACTIVITY);
    }

    public void anadirTienda(View view){
        Bundle bundle = new Bundle();
        bundle.putInt("position", -1);
        Intent intent = new Intent(getApplicationContext(), CreateUpdateTienda.class);
        intent.putExtras(bundle);
        startActivityForResult(intent, 1);
    }

    public void nuevoProducto(View view){ //Llamo a la actividad para crear o editar productos
        Bundle bundle = new Bundle();
        bundle.putInt("position", -1);//Si llego desde aquí, mando un -1 para hacer ver que creo un producto nuevo
        Intent intent = new Intent(getApplicationContext(), CreateUpdateTienda.class);
        intent.putExtras(bundle);
        startActivityForResult(intent, 1);

    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
            if (resultCode == 1) {//Creo una tienda que funciona bien
                Bundle bundle = data.getExtras();
                String nombre = bundle.getString("name");
                int codigo = bundle.getInt("codigo");
                Double latitud = bundle.getDouble("latitud");
                Double longitud = bundle.getDouble("longitud");
                Tienda aTienda = new Tienda();
                aTienda.setNombre(nombre);
                aTienda.setCodigoPostal(codigo);
                ParseGeoPoint mapa = new ParseGeoPoint();
                mapa.setLatitude(latitud);
                mapa.setLongitude(longitud);
                aTienda.setMapa(mapa);
                ppa.getTiendasCollection().addTiendaUpdate(aTienda, false);
                ppa.getTiendasCollection().getTiendaServerUpdate();
            }else if(resultCode == 2){//Edito la tienda
                List<Tienda> tiendas = ppa.getTiendasCollection().getLocal_tiendalist();
                Bundle bundle = data.getExtras();
                String nombre = bundle.getString("name");
                int codigo = bundle.getInt("codigo");
                Double latitud = bundle.getDouble("latitud");
                Double longitud = bundle.getDouble("longitud");
                int position = bundle.getInt("position");
                ParseGeoPoint mapa = new ParseGeoPoint();
                mapa.setLatitude(latitud);
                mapa.setLongitude(longitud);
                Tienda aTienda = new Tienda();
                Tienda aTienda1 = tiendas.get(position);
                aTienda.setMapa(mapa);
                aTienda.setNombre(nombre);
                aTienda.setCodigoPostal(codigo);
                System.out.println("HOLAAAAAAAAA\n\n\n");
                ppa.getTiendasCollection().modificaTienda(aTienda1,aTienda);
                ppa.getTiendasCollection().getTiendaServerUpdate(listView2);
            }


    }
}