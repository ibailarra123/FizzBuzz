package com.example.p2testlistmenufloat.collections;

import android.util.Log;
import android.widget.ListView;

import androidx.annotation.NonNull;

import com.example.p2testlistmenufloat.modelo.Pedido;
import com.parse.ParseQuery;

import java.util.ArrayList;
import java.util.List;

public class PedidoCollection {
    private List<Pedido> local_pedidolist = new ArrayList<>();

    public List<Pedido> getPedidoServerUpdate(ListView listView){
        ParseQuery<Pedido> query = ParseQuery.getQuery("pedido");
        query.findInBackground((objects, e) -> {
            if (e == null) {
                local_pedidolist = objects;

                Log.d("object query server OK:", "getPedidoServerUpdate()");
            } else {
                Log.d("error query, reason: " + e.getMessage(), "getPedidoServerUpdate()");
            }
        });
        return local_pedidolist;
    }

    public void addPedidoUpdate(@NonNull Pedido aPedido/*, ListView listView*/) {

        aPedido.saveInBackground(e -> {
            if (e == null) {
                local_pedidolist.add(aPedido);
                /*ArrayAdapter<Pedido> pointItemsAdapter;
                pointItemsAdapter = (ArrayAdapter<Pedido>) listView.getAdapter();
                pointItemsAdapter.notifyDataSetChanged();*/
                Log.d("object saved in server:", "addPedidoUpdate()");
            } else {
                Log.d("save failed, reason: "+ e.getMessage(), "addPedidoUpdate()");
            }
        });
    }
}
