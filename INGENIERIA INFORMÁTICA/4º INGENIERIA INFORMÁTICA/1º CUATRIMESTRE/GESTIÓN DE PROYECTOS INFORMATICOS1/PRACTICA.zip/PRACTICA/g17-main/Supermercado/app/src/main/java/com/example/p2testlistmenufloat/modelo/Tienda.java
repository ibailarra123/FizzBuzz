package com.example.p2testlistmenufloat.modelo;
import com.parse.Parse;
import com.parse.ParseClassName;
import com.parse.ParseGeoPoint;
import com.parse.ParseObject;

@ParseClassName("tiendas")
public class Tienda extends ParseObject {

    public Tienda() {
    }

    public ParseGeoPoint getMapa() {
        return (ParseGeoPoint) get("geoPoint");
    }

    public void setMapa(ParseGeoPoint mapa) {
        put("geoPoint", mapa);
    }

    public String getNombre() {
        return getString("nombreTienda");
    }

    public void setNombre(String nombre) {
        put("nombreTienda", nombre);
    }

    public Integer getCodigoPostal() {
        return getInt("codigoPostal");
    }

    public void setCodigoPostal(Integer codigoPostal) {
        put("codigoPostal", codigoPostal);
    }

    public String toString() {
        return  this.getNombre ();
    }

}