package com.example.p2testlistmenufloat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class AnadirProductoActivity extends AppCompatActivity {
    int position;
    PedidoProductoApp ppa;
    int cantidadDisponible;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anadir_producto);
        //Obtengo la referencia al controlador
        ppa = (PedidoProductoApp) getApplicationContext();

        //Cojo los datos del bundle
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        position = bundle.getInt("position");
        cantidadDisponible = bundle.getInt("cantidadDisponible");
        TextView nombreProductoTextView = findViewById(R.id.nombreEditable);
        TextView cantidadDisponibleTextView = findViewById(R.id.disponibleEditable);
        TextView precioProductoTextView = findViewById(R.id.precioUnitarioEditable);
        TextView categoriaTextView = findViewById(R.id.cartegoriaEditable);
        TextView precioTotal = findViewById ( R.id.precioTotal );

        nombreProductoTextView.setText(bundle.getString("nombre"));
        cantidadDisponibleTextView.setText(String.valueOf(bundle.getInt("cantidadDisponible")));
        precioProductoTextView.setText(String.valueOf(bundle.getDouble("precio")));
        categoriaTextView.setText(bundle.getString("nombreCategoria"));
        precioTotal.setText(String.valueOf(bundle.getDouble("precio")));
    }
    public void volver(View view){
        Intent intent = new Intent();
        setResult(2, intent);
        finish();
    }
    public void guardarPedido(View view){
        Bundle bundle= new Bundle();
        TextView cantidad = findViewById(R.id.cantidadProducto);
        if(Integer.parseInt(cantidad.getText().toString()) <= cantidadDisponible) {
            bundle.putInt("cantidad", Integer.parseInt(cantidad.getText().toString()));
            bundle.putInt("posicion",position);
            Intent intent = new Intent();
            intent.putExtras(bundle);
            setResult(1, intent);
            finish();
        }
    }

    public void restaUno(View view) {
        TextView cantidadProducto = (TextView) findViewById ( R.id.cantidadProducto );
        TextView precioUnitario = (TextView) findViewById ( R.id.precioUnitarioEditable );
        TextView precioTotal= (TextView) findViewById ( R.id.precioTotal );
        int cantidad = Integer.parseInt (cantidadProducto.getText ().toString ());

        if(cantidad>1) {
            cantidadProducto.setText ( Integer.toString ( cantidad -1 ) );
            float precio = Float.parseFloat (precioUnitario.getText ().toString ())*cantidad;
            precioTotal.setText ( Float.toString ( precio ));
        }
    }

    public void sumaUno(View view) {
        TextView cantidadProducto = (TextView) findViewById ( R.id.cantidadProducto );
        TextView precioUnitario = (TextView) findViewById ( R.id.precioUnitarioEditable );
        TextView precioTotal= (TextView) findViewById ( R.id.precioTotal );
        int cantidad = Integer.parseInt (cantidadProducto.getText ().toString ())+1;
        cantidadProducto.setText ( Integer.toString ( cantidad ));
        float precio = Float.parseFloat (precioUnitario.getText ().toString ())*cantidad;
        precioTotal.setText ( Float.toString ( precio ));
    }

}