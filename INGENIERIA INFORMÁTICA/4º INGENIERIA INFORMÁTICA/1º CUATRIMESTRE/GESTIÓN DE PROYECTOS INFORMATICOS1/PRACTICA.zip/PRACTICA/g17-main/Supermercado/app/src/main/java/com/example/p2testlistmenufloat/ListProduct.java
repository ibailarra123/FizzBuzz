package com.example.p2testlistmenufloat;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.p2testlistmenufloat.modelo.Pedido;
import com.example.p2testlistmenufloat.modelo.Producto;

public class ListProduct extends AppCompatActivity {
    private ListView listView;
    PedidoProductoApp ppa;
    private static final int SHOW_SUBACTIVITY = 1;
    ArrayAdapter<Producto> todoItemsAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_product);
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        String nombre= bundle.getString("nombre");

        //Obtengo la referencia al controlador
        ppa = (PedidoProductoApp) getApplicationContext();

        listView = (ListView) findViewById(R.id.list);

        ppa.getProductosCollection().getProductoServerUpdate(listView, nombre);
        //Programo qué ocurre cuando pulso uno de los elementos de la lista
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Producto item = (Producto) listView.getItemAtPosition(position);
                Bundle bundle = new Bundle();
                bundle.putString("nombreCategoria",nombre);
                bundle.putInt("position", position); //Mando la posición del elemento pulsado
                bundle.putString("nombre", item.getNombre());
                bundle.putDouble("precio", item.getPrecio());
                bundle.putInt("cantidadDisponible", item.getCantidadDisponible());
                Intent intent = new Intent(getApplicationContext(), AnadirProductoActivity.class);
                intent.putExtras(bundle);
                startActivityForResult(intent, SHOW_SUBACTIVITY);

            }
        });



    }

    public void volverAtras(View view){
        Intent intent = new Intent();
        setResult(4, intent);
        finish();
    }

    //Programo qué ocurre cuando se termina la actividad a la que he llamado
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == 1) {
            Bundle bundle = data.getExtras();
            int cantidad = bundle.getInt("cantidad");
            int position = bundle.getInt("posicion");
            Pedido aPedido = new Pedido();
            aPedido.setCantidad(cantidad);
            Producto item = (Producto) listView.getItemAtPosition(position);
            aPedido.setProducto(item);
            ppa.getConsumicionesList().add(aPedido);
            ppa.getProductosCollection().cambiaCantidad(item,cantidad);
            Intent intent = new Intent();
            setResult(1,intent);
            finish();
        }
    }
}
