package com.example.p2testlistmenufloat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.p2testlistmenufloat.modelo.Usuario;

import java.util.List;

public class ListaUsuariosActivity extends AppCompatActivity {

    PedidoProductoApp ppa;
    private ListView listView;
    private List<Usuario> usuarios;
    private static int SHOW_GESTION_USUARIOS_AVTIVITY = 1;
    private ArrayAdapter<String> adaptador;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_usuarios);
        ppa = (PedidoProductoApp) getApplicationContext();

        listView = (ListView) findViewById(R.id.list);
        //ppa.getUsuarioCollection().getUsuariosServerUpdate();
        usuarios = ppa.getUsuarioCollection().getLocal_usuariolist();

        adaptador = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1);
        for (Usuario usuario : usuarios) {
            adaptador.add(usuario.toString());
        }
        listView.setAdapter(adaptador);
        //Programo qué ocurre cuando pulso uno de los elementos de la lista
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(), GestionUsuarioActivity.class);
                Bundle bundle = new Bundle();
                bundle.putInt("posicion",position);
                System.out.println(position);
                intent.putExtras(bundle);
                startActivityForResult(intent,SHOW_GESTION_USUARIOS_AVTIVITY);
            }
        });
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        usuarios = ppa.getUsuarioCollection().getLocal_usuariolist();
        adaptador = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1);
        for (Usuario usuario : usuarios) {
            adaptador.add(usuario.toString());
        }
        listView.setAdapter(adaptador);
    }
}