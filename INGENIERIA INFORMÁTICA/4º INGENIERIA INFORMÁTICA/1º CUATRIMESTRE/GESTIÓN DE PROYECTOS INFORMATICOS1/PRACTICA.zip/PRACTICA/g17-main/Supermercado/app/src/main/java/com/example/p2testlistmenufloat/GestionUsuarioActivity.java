package com.example.p2testlistmenufloat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.p2testlistmenufloat.modelo.Usuario;

public class GestionUsuarioActivity extends AppCompatActivity {
    private int posicion;
    private Usuario usuario;
    private PedidoProductoApp ppa;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gsetion_usuario);
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        posicion = bundle.getInt("posicion");
        ppa = (PedidoProductoApp)getApplicationContext();
        System.out.println(posicion);
        usuario = ppa.getUsuarioCollection().getLocal_usuariolist().get(posicion);

        TextView textView = findViewById(R.id.textView8);
        textView.setText(usuario.toString());
    }

    public void eliminar(View view){
        ppa.getUsuarioCollection().eliminarUsuario(usuario);
        Intent intent = new Intent();
        setResult(RESULT_OK, intent);
        finish();
    }
    public void privilegios(View view){
        ppa.getUsuarioCollection().cambiaPrivilegios(usuario);
        Intent intent = new Intent();
        setResult(RESULT_OK, intent);
        finish();

    }
}