package com.example.p2testlistmenufloat.collections;

import android.os.Build;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

import com.example.p2testlistmenufloat.R;
import com.example.p2testlistmenufloat.modelo.Categoria;
import com.example.p2testlistmenufloat.modelo.Producto;
import com.example.p2testlistmenufloat.modelo.Tienda;
import com.example.p2testlistmenufloat.modelo.Usuario;
import com.google.android.gms.common.internal.BaseGmsClient;
import com.parse.ParseFile;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class CategoriaCollection {
    public CategoriaCollection(){
    }
    Set<String> nombresUnicos = new HashSet<>();
    List<Categoria> local_categorialist = new ArrayList<>();
    @RequiresApi(api = Build.VERSION_CODES.N)
    public void getCategoriaServerUpdate(ListView listView)  {
        ParseQuery<Categoria> query = ParseQuery.getQuery("categoria");
        query.findInBackground((objects, e) -> {
            if (e == null) {
                for (ParseObject parseObject : objects) {
                    String nombreCategoria = parseObject.getString("name");

                    if (!nombresUnicos.contains(nombreCategoria)) {
                        // Agregar el nombre a la lista de nombres únicos
                        nombresUnicos.add(nombreCategoria);

                        // Crear una nueva instancia de Categoria y establecer el nombre
                        Categoria categoria = new Categoria();
                        categoria.setNombre(nombreCategoria);

                        // Agregar la instancia de Categoria a la lista final
                        local_categorialist.add(categoria);
                    }
                }
                Comparator<Categoria> comparadorPorNombre = Comparator.comparing(Categoria::getNombre);
                local_categorialist.sort(comparadorPorNombre);
                ArrayAdapter<Categoria> pointItemsAdapter =
                        new ArrayAdapter<>(listView.getContext(),R.layout.row_layout3,
                                R.id.listText2,local_categorialist);
                listView.setAdapter(pointItemsAdapter);
                pointItemsAdapter.notifyDataSetChanged();

                Log.d("object query server OK:", "getProductoServerUpdate()");
            } else {
                Log.d("error query, reason: " + e.getMessage(), "getCategoriaServerUpdate()");
                e.printStackTrace();
            }
        });
    }


    public void addCategoriaUpdate(@NonNull Categoria aCategoria, ListView listView) {

        aCategoria.saveInBackground(e -> {
            if (e == null) {
                local_categorialist.add(aCategoria);
                ArrayAdapter<Categoria> pointItemsAdapter;
                pointItemsAdapter = (ArrayAdapter<Categoria>) listView.getAdapter();
                pointItemsAdapter.notifyDataSetChanged();
                Log.d("object saved in server:", "addProductoUpdate()");
            } else {
                Log.d("save failed, reason: "+ e.getMessage(), "addProductoUpdate()");
            }
        });
    }
    public List<Categoria> getLocal_categorialist() {
        return local_categorialist;
    }
}
