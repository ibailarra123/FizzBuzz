package com.example.p2testlistmenufloat;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.example.p2testlistmenufloat.modelo.Producto;

import java.util.List;

public class CreateUpdateProduct extends AppCompatActivity {

    int position;
    String nombreCategoria;
    Boolean debemosCrearNuevoProducto = Boolean.TRUE;
    PedidoProductoApp ppa;

    EditText editTextNombre, editTextPrecio,editTextCantidad;
    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_update_product);

        //Obtengo la referencia al controlador
        ppa = (PedidoProductoApp) getApplicationContext();

        //Cojo los datos del bundle
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        position = bundle.getInt("position");
        nombreCategoria = bundle.getString("nombreCategoria");


        // OBTENEMOS LOS EDIT TEXT
        editTextNombre = findViewById(R.id.nombre);
        editTextPrecio = findViewById(R.id.precio);
        editTextCantidad =  findViewById(R.id.cantidad);
        //Booleano que compueba si creo o si edito
        debemosCrearNuevoProducto = (position==-1);

        String nombre= bundle.getString("nombre");
        Double precio= bundle.getDouble("precio");
        Integer cantidadDisponible= bundle.getInt("cantidadDisponible");

        editTextNombre.setText(nombre);
        editTextPrecio.setText(precio.toString());
        editTextCantidad.setText(cantidadDisponible.toString());
        position= bundle.getInt("position");


    }
    public void guardar(View view){
        //Cojemos los datos guardados en los editText

        String nombre = editTextNombre.getText().toString();
        Double precio = Double.parseDouble(editTextPrecio.getText().toString());
        int cantidad = Integer.parseInt(editTextCantidad.getText().toString());

        if (debemosCrearNuevoProducto){ //Caso de crear un nuevo producto
            Bundle bundle = new Bundle();
            bundle.putString("name", nombre);
            bundle.putDouble("price", precio);
            bundle.putInt("cantidadDisponible",cantidad);
            bundle.putString("categoria", nombreCategoria);
            Intent intent = new Intent();
            intent.putExtras(bundle);
            setResult(1, intent);
            finish();
        }else{ //Caso de editar un producto existente
            Bundle bundle = new Bundle();
            bundle.putString("name", nombre);
            bundle.putDouble("price", precio);
            bundle.putInt("cantidadDisponible",cantidad);
            bundle.putString("categoria", nombreCategoria);
            bundle.putInt("position",position);
            Intent intent = new Intent();
            intent.putExtras(bundle);
            //Terminamos la ejecución de este intent
            setResult(2,intent);
            finish();

        }

    }
}