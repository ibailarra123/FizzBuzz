package com.example.p2testlistmenufloat.modelo;

import com.parse.ParseClassName;
import com.parse.ParseObject;

@ParseClassName("user")
public class Usuario extends ParseObject {
    public Usuario() {
    }


    public String getNombre() {
        return getString ( "nombreUsuario" );
    }

    public void setNombre(String nombre) {
        put ( "nombreUsuario",nombre );
    }

    public String getApellidos() {
        return getString("apellidosUsuario");
    }

    public void setApellidos(String apellidos) {
        put("apellidosUsuario", apellidos );
    }

    public String getEmail() {
        return getString("emailUsuario");
    }

    public void setEmail(String email) {
        put("emailUsuario", email);
    }

    public String getContrasenia() {
        return getString("contraseniaUsario");
    }

    public void setContrasenia(String contrasenia) {
        put("contraseniaUsario", contrasenia);
    }

    public Boolean getEsAdmin() {
        return getBoolean ("esAdmin");
    }

    public void setEsAdmin(Boolean esAdmin) {
        put("esAdmin", esAdmin);
    }

    public Integer getTelefono() {
        return getInt ("telefonoUsuario");
    }

    public void setTelefono(Integer telefono) {
        put("telefonoUsuario", telefono);
    }

    @Override
    public String toString() {
        return "Nombre='" + this.getNombre () + '\'' +
                ", Administrador=" + (this.getEsAdmin() ? "Si":"No");
    }
}
