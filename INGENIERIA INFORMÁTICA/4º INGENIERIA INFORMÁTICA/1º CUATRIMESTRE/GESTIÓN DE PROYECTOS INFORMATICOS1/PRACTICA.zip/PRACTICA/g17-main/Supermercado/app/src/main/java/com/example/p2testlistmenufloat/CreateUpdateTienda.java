package com.example.p2testlistmenufloat;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.example.p2testlistmenufloat.modelo.Tienda;
import com.parse.ParseGeoPoint;

import java.util.List;

public class CreateUpdateTienda extends AppCompatActivity {

    int position;
    Boolean debemosCrearNuevaTienda = Boolean.TRUE;
    PedidoProductoApp ppa;

    EditText editTextNombre, editTextCodigo, editTextLatitud, editTextLongitud;
    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_update_tienda);

        //Obtengo la referencia al controlador
        ppa = (PedidoProductoApp) getApplicationContext();

        //Cojo los datos del bundle
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        position = bundle.getInt("position");


        // OBTENEMOS LOS EDIT TEXT
        editTextNombre = findViewById(R.id.nombre2);
        editTextCodigo = findViewById(R.id.codigo);
        editTextLatitud =  findViewById(R.id.latitud);
        editTextLongitud =  findViewById(R.id.longitud);
        //Booleano que compueba si creo o si edito
        debemosCrearNuevaTienda = (position==-1);
        if(debemosCrearNuevaTienda){
            editTextNombre.setText("EROSKI ");
            editTextCodigo.setText("31002");
            editTextLatitud.setText("42.8306750");
            editTextLongitud.setText("-1.6665500");
        }else {
            String nombre = bundle.getString("nombre");
            Double codigo = (double) bundle.getInt("codigo");
            Double latitud = bundle.getDouble("latitud");
            Double longitud = bundle.getDouble("longitud");

            editTextNombre.setText(nombre);
            editTextCodigo.setText(codigo.toString());
            editTextLatitud.setText(latitud.toString());
            editTextLongitud.setText(longitud.toString());
        }


    }
    public void guardar2(View view){
        //Cojemos los datos guardados en los editText
        String nombre = editTextNombre.getText().toString();
        Double codigo = Double.parseDouble(editTextCodigo.getText().toString());
        Double latitud = Double.parseDouble(editTextLatitud.getText().toString());
        Double longitud = Double.parseDouble(editTextLongitud.getText().toString());

        if (debemosCrearNuevaTienda){ //Caso de crear un nuevo producto
            Bundle bundle = new Bundle();
            bundle.putString("name", nombre);
            bundle.putInt("codigo", codigo.intValue());
            bundle.putDouble("latitud",latitud);
            bundle.putDouble("longitud",longitud);
            Intent intent = new Intent();
            intent.putExtras(bundle);
            setResult(1, intent);
            finish();
        }else{ //Caso de editar un producto existente
            Bundle bundle = new Bundle();
            bundle.putString("name", nombre);
            bundle.putInt("codigo", codigo.intValue());
            bundle.putDouble("latitud",latitud);
            bundle.putDouble("longitud",longitud);
            bundle.putInt("position",position);
            Intent intent = new Intent();
            intent.putExtras(bundle);
            setResult(2, intent);
            finish();
        }
        //Terminamos la ejecución de este intent

    }
}