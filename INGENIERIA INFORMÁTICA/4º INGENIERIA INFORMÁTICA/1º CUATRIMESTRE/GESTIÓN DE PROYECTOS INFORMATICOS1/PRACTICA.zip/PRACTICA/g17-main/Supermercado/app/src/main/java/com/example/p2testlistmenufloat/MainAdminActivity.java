package com.example.p2testlistmenufloat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.example.p2testlistmenufloat.R;
import com.example.p2testlistmenufloat.databinding.ActivityMainAdminBinding;
import com.example.p2testlistmenufloat.modelo.Pedido;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainAdminActivity extends AppCompatActivity {

    private ActivityMainAdminBinding binding;
    ListView listView;
    ArrayAdapter<Pedido> todoItemsAdapter;
    private static final int SHOW_INICIO = 4;
    private static final int SHOW_MAP_ACTIVITY = 3;
    private static final int SHOW_ADDACTIVITY = 2;
    private static final int SHOW_USER_ACTIVITY = 5;
    FloatingActionButton fab;
    PedidoProductoApp ppa;

    Integer posicionUsuario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Cosas que hacen falta
        super.onCreate(savedInstanceState);
        binding = ActivityMainAdminBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        // OBTENEMOS EL INTENT Y POR TANTO LA POSICIÓN
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        posicionUsuario = bundle.getInt ( "posicionUsuario" );

        //GET APLICATION CONTEXT
        ppa = (PedidoProductoApp) getApplicationContext();

        System.out.println (ppa.getUsuarioCollection ().getLocal_usuariolist());

        //Obtengo la referencia al controlador
        ppa = (PedidoProductoApp) getApplicationContext();

    }

    public void productos(View view){ //Llamo a la lista de productos
        Intent intent = new Intent(this, DisplayActivity.class);
        startActivityForResult(intent, SHOW_ADDACTIVITY);
    }

    public void tiendas(View view){
        Bundle bundle = new Bundle();
        bundle.putInt("todas",1);
        Intent intent = new Intent(this,GestionMapasActivity.class);
        intent.putExtras(bundle);
        startActivityForResult(intent,SHOW_MAP_ACTIVITY);
    }

    public void usuarios(View view){
        Intent intent = new Intent(this,ListaUsuariosActivity.class);
        startActivityForResult(intent,SHOW_USER_ACTIVITY);
    }

    //Programo qué ocurre cuando se ha cerrado otra actividad
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }
}