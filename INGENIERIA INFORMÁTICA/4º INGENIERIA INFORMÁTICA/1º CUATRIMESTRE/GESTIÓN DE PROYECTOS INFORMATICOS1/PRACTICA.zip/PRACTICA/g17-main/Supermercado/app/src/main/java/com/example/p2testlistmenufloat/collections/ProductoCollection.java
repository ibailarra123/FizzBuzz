package com.example.p2testlistmenufloat.collections;

import static java.util.Collections.*;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PorterDuff;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

import com.example.p2testlistmenufloat.R;
import com.example.p2testlistmenufloat.modelo.Categoria;
import com.example.p2testlistmenufloat.modelo.Producto;
import com.example.p2testlistmenufloat.modelo.Usuario;
import com.parse.ParseException;
import com.parse.ParseFile;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ProductoCollection {
    private List<Producto> local_productolist = new ArrayList<>();

    @RequiresApi(api = Build.VERSION_CODES.N)
    public void getProductoServerUpdate(ListView listView, String categoriaSeleccionada) {
        local_productolist.clear();
        ParseQuery<Producto> query = ParseQuery.getQuery("productos");
        query.whereEqualTo("category", categoriaSeleccionada);
        query.findInBackground((objects, e) -> {
            if (e == null) {
                //List<Producto> local_productolist = new ArrayList<>();

                for (ParseObject parseObject : objects) {
                    //No entra aqui
                    Producto producto = new Producto();
                    producto.setNombre(parseObject.getString("name"));
                    producto.setPrecio(parseObject.getDouble("price"));
                    parseObject.getParseFile("imagen");
                    producto.setCantidadDisponible(parseObject.getInt("cantidadDisponible"));
                    local_productolist.add(producto);
                }

                Comparator<Producto> comparadorPorNombre = Comparator.comparing(Producto::getNombre);
                local_productolist.sort(comparadorPorNombre);

                ArrayAdapter<Producto> pointItemsAdapter =
                        new ArrayAdapter<Producto>(listView.getContext(), R.layout.row_layout2,
                                R.id.listText, local_productolist) {
                            @NonNull
                            @Override
                            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                                View row = super.getView(position, convertView, parent);

                                ImageView productImage = row.findViewById(R.id.image_view); // Assuming you have an ImageView for the product image
                                Producto producto = local_productolist.get(position);
                                ParseFile parseFile = producto.getImagen();

                                /*if (parseFile != null) {
                                    String imageUrl = parseFile.getUrl();
                                    Picasso.get().load(imageUrl).into(productImage);
                                }*/

                                return row;
                            }
                        };

                listView.setAdapter(pointItemsAdapter);
                pointItemsAdapter.notifyDataSetChanged();

                Log.d("object query server OK:", "getProductoServerUpdate()");
            } else {
                Log.d("error query, reason: " + e.getMessage(), "getProductoServerUpdate()");
            }
        });
    }




    public void addProductoUpdate(@NonNull Producto aProducto, ListView listView,boolean modificacion) {
        System.out.println(aProducto);
        aProducto.saveInBackground(e -> {
            if (e == null) {
                local_productolist.add(aProducto);
                ArrayAdapter<Producto> pointItemsAdapter;
                pointItemsAdapter = (ArrayAdapter<Producto>) listView.getAdapter();
                pointItemsAdapter.notifyDataSetChanged();
                Log.d("object saved in server:", "addProductoUpdate()");
            } else {
                Log.d("save failed, reason: "+ e.getMessage(), "addProductoUpdate()");
            }
        });
    }

    public void modificaProducto(Producto producto,Producto producto1){
        System.out.println(producto);
        System.out.println(producto1);
        ParseQuery<ParseObject> query = ParseQuery.getQuery("productos");
        query.whereEqualTo("name", producto.getNombre());
        producto.setNombre(producto1.getNombre());
        producto.setCategoria(producto1.getCategoria());
        producto.setCantidadDisponible(producto1.getCantidadDisponible());
        producto.setPrecio(producto1.getPrecio());

        query.getFirstInBackground((object, e) -> {
            if (e == null) {
                object.put("price",producto1.getPrecio());
                object.put("name",producto1.getNombre());
                object.put("category",producto1.getCategoria());
                object.put("cantidadDisponible",producto1.getCantidadDisponible());
                // Guardar el objeto actualizado en la base de datos
                object.saveInBackground(e1 -> {
                    if (e1 == null) {
                        Log.d("", "cambiarValorBooleanoContrario()");
                    } else {
                        Log.d("Error" + e1.getMessage(), "cambiarValorBooleanoContrario()");
                    }
                });
            } else {
                Log.d("Error" + e.getMessage(), "cambiarValorBooleanoContrario()");
            }
        });
    }
    public void cambiaCantidad(Producto producto,int cantidad){
        producto.setCantidadDisponible(producto.getCantidadDisponible()-cantidad);
        ParseQuery<ParseObject> query = ParseQuery.getQuery("productos");
        query.whereEqualTo("name", producto.getNombre());
        query.getFirstInBackground((object, e) -> {
            if (e == null) {
                // Modificar el campo booleano en el objeto ParseObject
                object.put("cantidadDisponible", producto.getCantidadDisponible());

                // Guardar el objeto actualizado en la base de datos
                object.saveInBackground(e1 -> {
                    if (e1 == null) {
                        Log.d("", "cambiarValorBooleanoContrario()");
                    } else {
                        Log.d("Error" + e1.getMessage(), "cambiarValorBooleanoContrario()");
                    }
                });
            } else {
                Log.d("Error" + e.getMessage(), "cambiarValorBooleanoContrario()");
            }
        });


    }

    public void eliminarProducto(Producto producto) {
        System.out.println(local_productolist);
        local_productolist.remove(producto);
        System.out.println(local_productolist);
        System.out.println(producto);
        System.out.println(producto.getObjectId());
        producto.deleteInBackground(e -> {
            if (e == null) {
                Log.d("Usuario eliminado", "eliminarUsuario()");

            } else {
                Log.d("Error" + e.getMessage(), "eliminarUsuario()");
            }
        });

    }
    /*public Producto getProducto(int posicion){
        return local_productolist;
    }*/

    public List<Producto> getProductos(){
        return local_productolist;
    }
}
