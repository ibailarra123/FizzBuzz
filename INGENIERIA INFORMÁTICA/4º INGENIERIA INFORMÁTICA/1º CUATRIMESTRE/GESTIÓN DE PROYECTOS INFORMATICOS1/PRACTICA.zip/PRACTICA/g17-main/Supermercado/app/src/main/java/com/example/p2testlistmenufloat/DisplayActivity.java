package com.example.p2testlistmenufloat;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.p2testlistmenufloat.modelo.Categoria;
import com.example.p2testlistmenufloat.modelo.Producto;

public class DisplayActivity extends AppCompatActivity {
    private ListView listView;
    PedidoProductoApp ppa;
    private static final int SHOW_SUBACTIVITY = 1;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);



        //Obtengo la referencia al controlador
        ppa = (PedidoProductoApp) getApplicationContext();

        listView = (ListView) findViewById(R.id.list);
        button = (Button) findViewById(R.id.button4);


        //ppa.getProductosCollection().getProductoServerUpdate(listView);
        ppa.getCategoriasCollection().getCategoriaServerUpdate(listView);

        //Programo qué ocurre cuando pulso uno de los elementos de la lista
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Categoria item = (Categoria) listView.getItemAtPosition(position);
                Bundle bundle = new Bundle();
                bundle.putInt("position", position); //Mando la posición del elemento pulsado
                bundle.putString("nombre", item.getNombre());
                Intent intent = new Intent(getApplicationContext(), ListProductCreateUpdate.class);
                intent.putExtras(bundle);
                startActivityForResult(intent, SHOW_SUBACTIVITY);

            }
        });



    }

    public void nuevaCategoria(View view){ //Llamo a la actividad para crear o editar productos
        Bundle bundle = new Bundle();
        bundle.putInt("position", -1); //Si llego desde aquí, mando un -1 para hacer ver que creo un producto nuevo
        Intent intent = new Intent(getApplicationContext(), CreateUpdateCategoria.class);
        intent.putExtras(bundle);
        startActivityForResult(intent, 1);
    }

    public void volverAtras(View view){
        Intent intent = new Intent();
        setResult(4, intent);
        finish();
    }

    //Programo qué ocurre cuando se termina la actividad a la que he llamado
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == 1) {
                Bundle bundle = data.getExtras();
                String nombre = bundle.getString("name");
                Categoria aCategoria = new Categoria();
                aCategoria.setNombre(nombre);

                ppa.getCategoriasCollection().addCategoriaUpdate(aCategoria,listView);

            }

        }
    }
}
