package com.example.p2testlistmenufloat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.p2testlistmenufloat.modelo.Producto;
import com.example.p2testlistmenufloat.modelo.Tienda;

import java.util.List;

public class ListaMapasActivity extends AppCompatActivity {
    int SHOW_MAP_ACTIVITY = 1;
    PedidoProductoApp ppa;
    private ListView listView;
    private List<Tienda> tiendas;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_mapas);
        ppa = (PedidoProductoApp) getApplicationContext();

        listView = (ListView) findViewById(R.id.list);

        tiendas = ppa.getTiendasCollection().getLocal_tiendalist();

        ppa.getTiendasCollection().getTiendaServerUpdate(listView);
        //Programo qué ocurre cuando pulso uno de los elementos de la lista
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Bundle bundle = new Bundle();
                bundle.putInt("position", position); //Mando la posición del elemento pulsado
                bundle.putInt("todas",0);
                Intent intent = new Intent(getApplicationContext(), MapaActivity.class);
                intent.putExtras(bundle);
                startActivityForResult(intent, SHOW_MAP_ACTIVITY);
            }
        });
    }

    public void todas(View view){
        Bundle bundle = new Bundle();
        bundle.putInt("todas",1);//Meto un uno para decir que quiero mostrar todas las tiendas
        Intent intent = new Intent(getApplicationContext(), MapaActivity.class);
        intent.putExtras(bundle);
        startActivityForResult(intent, SHOW_MAP_ACTIVITY);
    }
}