package com.example.p2testlistmenufloat;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;

import com.example.p2testlistmenufloat.modelo.Tienda;

import java.util.ArrayList;
import java.util.List;

import com.example.p2testlistmenufloat.databinding.ActivityMainBinding;
import com.example.p2testlistmenufloat.modelo.Usuario;

public class RegistrarActivity extends AppCompatActivity {
    PedidoProductoApp ppa;
    private ListView listView;
    private ActivityMainBinding binding;
    private List<Usuario> usuarioList = new ArrayList<> ();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate ( savedInstanceState );
        setContentView ( R.layout.activity_registrar );
        binding = ActivityMainBinding.inflate(getLayoutInflater());


        ppa = (PedidoProductoApp) getApplicationContext();
        usuarioList = ppa.getUsuarioCollection ().getLocal_usuariolist ();

    }

    public void registrar(View view) {
        if(!checkEmptyEditTexts ()){
            registrarUsuario ( view );
        }else {
            showAlertDialog ("Por favor, rellene los campos requeridos" );
        }
    }
    public void registrarUsuario(View view){
        // OBTENEMOS LOS EDIT TEXT
        EditText editTextNombre = findViewById(R.id.editTextNombre);
        EditText editTextApellidos = findViewById(R.id.editTextApellidos);
        EditText editTextTelefono = findViewById(R.id.editTextTelefono);
        EditText editTextEmail = findViewById(R.id.editTextEmail);
        EditText editTextPassword = findViewById(R.id.editTextTextPassword);
        EditText editTextPassword2 = findViewById(R.id.editTextTextPassword2);
        //HABRIA QUE COMPROBAR AQUI LA CONTRASEÑA QUE SEA LA MISMA


        Usuario aUsuario = new Usuario ();
        aUsuario.setNombre ( editTextNombre.getText ().toString () );
        aUsuario.setApellidos ( editTextApellidos.getText ().toString () );
        if(!TextUtils.isDigitsOnly(editTextTelefono.getText().toString())){
            showAlertDialog("Debes introducir un valor valido para el numero de telefono");
            editTextTelefono.setText("Telefono");
        }else {
            aUsuario.setTelefono(Integer.parseInt(editTextTelefono.getText().toString()));
        }
        aUsuario.setEmail ( editTextEmail.getText ().toString () );
        aUsuario.setContrasenia (editTextPassword.getText ().toString ()  );
        aUsuario.setEsAdmin ( false );

        Bundle bundle = new Bundle();

        if(existeUsuario ( editTextNombre.getText ().toString (), editTextEmail.getText ().toString () ) != null){
            //mostrariamos mensaje del usuario esta registrado
            showAlertDialog ( "El usuario/email ya esta registrado" );

        }else {
            if(TextUtils.isDigitsOnly(editTextTelefono.getText().toString())) {
                if (sonContraseniasIguales(editTextPassword.getText().toString(), editTextPassword2.getText().toString())) {
                    bundle.putString("nombreUsuario", editTextNombre.getText().toString());
                    bundle.putString("apellidosUsuario", editTextApellidos.getText().toString());
                    bundle.putInt("telefonoUsuario", Integer.parseInt(editTextTelefono.getText().toString()));
                    bundle.putString("emailUsuario", editTextEmail.getText().toString());
                    bundle.putString("contraseniaUsuario", editTextPassword.getText().toString());

                    Intent intent = new Intent();
                    intent.putExtras(bundle);
                    setResult(RESULT_OK, intent);
                    finish();

                } else {
                    showAlertDialog("Las contraseñas introducidas no coinciden");
                }
            }
        };
    }
    private Boolean checkEmptyEditTexts() {
        Boolean estanVacios = false;
        List<EditText>listaEditText = new ArrayList<> ();

        // Obtén referencias a tus EditText y los almacenamos en una lista
        EditText editTextNombre = findViewById(R.id.editTextNombre);
        listaEditText.add ( editTextNombre );

        EditText editTextApellidos = findViewById(R.id.editTextApellidos);
        listaEditText.add ( editTextApellidos );

        EditText editTextTelefono = findViewById(R.id.editTextTelefono);
        listaEditText.add ( editTextTelefono );

        EditText editTextEmail = findViewById(R.id.editTextEmail);
        listaEditText.add ( editTextEmail );

        EditText editTextPassword = findViewById(R.id.editTextTextPassword);
        listaEditText.add ( editTextPassword );

        EditText editTextPassword2 = findViewById(R.id.editTextTextPassword2);
        listaEditText.add ( editTextPassword2 );
        // VERIFICAMOS QUE NO HAYA NINGUNO VACIO
        for (EditText editText:listaEditText) {
            // Verifica si están vacíos
            if (TextUtils.isEmpty(editText.getText())) {
                // Marca en rojo el EditText 1
                editText.setHintTextColor (Color.RED);
                editText.setHint ( editText.getHint ()+" * " );
                estanVacios = true;
            } else {
                // Restaura el color por defecto
                editText.setHintTextColor (Color.TRANSPARENT);
            }
        }
        return estanVacios;
    }

    public void showAlertDialog(String mensaje) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);

        // Configura el mensaje.
        alertDialogBuilder
                .setMessage(mensaje)
                .setCancelable(false)
                .setNeutralButton ("ACEPTAR",new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,int id) {
                        dialog.cancel();
                    }
                }).create().show();
    }

    private boolean sonContraseniasIguales(String contrasenia1, String contrasenia2){
        return contrasenia1.equals ( contrasenia2 );
    }

    private Usuario existeUsuario(String nombre, String email) {
        for (Usuario u:usuarioList) {
            if(((u.getNombre ().equals ( nombre )) ||(u.getEmail ().equals ( email ))) ){
                return u;
            }
        }
        return null;
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

}