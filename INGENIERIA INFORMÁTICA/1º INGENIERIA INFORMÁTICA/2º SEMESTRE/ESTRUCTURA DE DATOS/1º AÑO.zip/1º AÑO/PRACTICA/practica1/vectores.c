/*
 *  Programa: vectores
 *  Histrico:
 *    Creado por Ibai Larralde Baldanta el 09/02/2021.
 *      versin 1.0.0
 *  Copyright © 2016 Ibai Larralde Baldanta. All rights reserved.
 */

#include <stdio.h>
#include <math.h>
#define N 10
typedef float vector[N];

/*
 * FUNCION: productoEscalar
 * ENTRADA: v1 un vector de N reales con valores V1i = Ai y V2i = Bi 
 * REQUISITOS: Ninguno
 * SALIDA: un real prod = Σ 1 ≤ i ≤ N (Ai * Bi)
 */
int productoEscalar(vector v1, vector v2);

/*
 * FUNCION: ordenaVector
 * ENTRADA: v1 un vector de N reales con valores v1i = V1i
 * REQUISITOS: Ninguno
 * SALIDA: v1 contiene todos los valores iniciales pero ordenados de menor a mayor
 */
void ordenaVector(vector v1);

/*
 * FUNCION: intercambio
 * ENTRADA: a = A, b = B dos valores reales
 * REQUISITOS: Ninguno
 * MODIFICA: las variables a y b pasan a valer a = B y b = A
 */
void intercambio(float *a, float *b);

/*
 * FUNCION: posicionMaximoEnPrefijo
 * ENTRADA: a un vector de N reales con valores ai = Aiy m = M un entero
 * REQUISITOS: 0 < M ≤ N
 * SALIDA: el entero pos verificando que pos = I significa que ∀k ≤ M se verifica aI ≥ ak
 */
int posicionMaximoEnPrefijo(vector a, int m);

/*
 * PROGRAMA PRINCIPAL
 * ENTRADA: Por teclado, dos vectores v1 y v3 de valores reales
 * REQUISITOS:
 * SALIDA: Este programa saca por pantalla el producto escalar del primer vector v1 por él mismo, ordena el   
 * vector v1 de menor a mayor, a continuación realiza el producto escalar del vector, ahora ordenado por un 
 * vector nuevo pedido al usuario v3, y finalmente realiza la diferencia en valor absoluto de los dos productos
 * escalares.
 */
int main(void) {
    char quiereSalir;
    int i;
    float pe1, pe2, dif;
    vector v1, v2;
	printf("\tPrograma vectores\n");
	printf("\tCreado por Ibai Larralde Baldanta\n");
	printf("\tversion 1.0 (09/02/2021)\n\n");
	printf("Este programa pide al usuario 10 números reales y los guarda en un vector, \n");
	printf("para despúes hacer el producto escalar del vector por él mismo, ordena el \n");
	printf("vector de menor a mayor, a continuación realiza el producto escalar del vector, ahora ordenado, \n");
    printf("por un vector nuevo pedido al usuario, y finalmente realiza la diferencia en \n");
    printf("valor absoluto de los dos productos escalares.\n\n");
    do {
        for (i = 0; i < N; i++){
            printf("Introduce un numero entero real v1[%d]: \n",i+1);
            scanf( " %f", &v1[i]);
        }
        
        printf("El vector v1 : [");
        for (i = 0; i < N; i++){
            printf(" %f", v1[i]);
        }
        printf ("] \n");
        
        for (i = 0; i < N; i++){
            v2[i] = v1[i]; 
        }
        
        pe1 = productoEscalar(v1, v2);
        printf("El producto escalar del vector por el mismo es: %f\n",pe1);
        
        ordenaVector(v1);
        printf("El vector ordenado : [");
        for (i = 0; i < N; i++){
            printf(" %f", v1[i]);
        }
        printf ("] \n");
        
        pe2 = productoEscalar(v1, v2);
        printf("El producto escalar del primer vector por el nuevo vector ordenado es: %f\n",pe2);
        
        dif = fabs(pe1 - pe2);
        printf("Por tanto la diferencia, en valor absoluto, de los dos productos escalares es: %f\n",dif);
        
        printf("Si desea salir pulse s, para repetir la ejecucion cualquier otra cosa.");
		scanf("\n%c", &quiereSalir);
	} while (quiereSalir != 's');
	return 0;
}

int productoEscalar(vector v1, vector v2){
    int i;
    float prod;
    prod = 0;
    for (i = 0; i < N; i++){
        prod = prod + (v1[i] * v2[i]);
    }
    return prod;
}
    
void ordenaVector(vector v1){
    int i,max;
    for (i = 1; i < N; i++){
        max = posicionMaximoEnPrefijo(v1, N-i);
        intercambio(&v1[N-i], &v1[max]);
    }
}
        
void intercambio(float *a, float *b){
    float aux;
    aux = *a;
    *a = *b;
    *b = aux;
}

int posicionMaximoEnPrefijo(vector a, int m){
    int i,pos;
    pos = 0;
    for (i = 1; i <= m; i++){
        if (a[i] > a[pos]){
            pos = i;
        }
    }
    return pos;
}    
