/*
 *  Programa: capicuas1
 *  Histrico:
 *    Creado por Ibai Larralde Baldanta el 10/02/2021.
 *      versin 1.0.0
 *  Copyright © 2016 Ibai Larralde Baldanta. All rights reserved.
 */

#include <stdio.h>
#include <math.h>
typedef enum{FAlSE = 0, TRUE = 1}boolean;

/*
 * FUNCION: esCapicua
 * ENTRADA: n, un número entero
 * REQUISITOS: n >= 0
 * SALIDA: el booleando b será verdadero si n era capicua
 */
boolean esCapicua(int n);

/*
 * FUNCION: reverso
 * ENTRADA: el entero n = n1,n2,...,nl
 * REQUISITOS: n >= 0
 * SALIDA: m contiene los d ́ıgitos de n invertidos (m = nl,...,n2,n1)
 */
int reverso(int n);

/*
 * PROGRAMA PRINCIPAL
 * ENTRADA: Por teclado un número menor que 100.000
 * REQUISITOS: El número ha de ser mayor que 0
 * SALIDA: Este programa saca por pantalla si el número introducido es capicúa o no
 */
int main(void) {
    char quiereSalir;
    int n;
    boolean b;
	printf("\tPrograma capicua\n");
	printf("\tCreado por Ibai Larralde Baldanta\n");
	printf("\tversion 1.0 (10/02/2021)\n\n");
    printf("Este programa pide al usuario un número mayor que 0 y menor que 100.000 y saca por pantalla si el número introducido es capicúa o no.\n\n");
    do {
        printf("Introduce un número mayor que 0 y menor que 100.000: \n");
        scanf( " %d", &n);
        b = esCapicua(n);
        if (b){
            printf("El número %d es capicúa \n",n);
        }
        else{
            printf("El número %d no es capicúa \n",n);
        }
        printf("Si desea salir pulse s, para repetir la ejecucion cualquier otra cosa.");
		scanf("\n%c", &quiereSalir);
	} while (quiereSalir != 's');
	return 0;
}

int reverso(int n){
    int m;
    m = 0;
    while (n > 0){
        m = (10 * m) + (n % 10);
        n = n / 10;
    }
    return m;
}

boolean esCapicua(int n){
    boolean b;
    b = (n == reverso(n));
    return b;
}
