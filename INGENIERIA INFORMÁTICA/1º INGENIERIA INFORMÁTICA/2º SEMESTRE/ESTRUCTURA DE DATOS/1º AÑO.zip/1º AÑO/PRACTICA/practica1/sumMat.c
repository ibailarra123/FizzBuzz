/*
 *  Programa: sumMat
 *  Histrico:
 *    Creado por Ibai Larralde Baldanta el 11/02/2021.
 *      versin 1.0.0
 *  Copyright © 2016 Ibai Larralde Baldanta. All rights reserved.
 */

#include <stdio.h>
#include <math.h>
#define N 3
typedef float matriz[N][N];

/*
 * FUNCION: sumaMatrices
 * ENTRADA: m y n, dos tablas de N x N reales con valores mij = Mij, nij = Nij
 * REQUISITOS: Ninguno
 * SALIDA: una tabla de N × N reales con valores lij = Mij + Nij
 */
void sumaMatrices(matriz m, matriz n, matriz l);

/*
 * FUNCION: matrizTraspuesta
 * ENTRADA: m, una tabla de N × N reales con valores mij = Mij
 * REQUISITOS: Ninguno
 * SALIDA: m de modo que mij pase a contener Mji
 */
void matrizTraspuesta(matriz m);

/*
 * FUNCION: intercambio
 * ENTRADA: a = A, b = B dos valores reales
 * REQUISITOS: Ninguno
 * MODIFICA: las variables a y b pasan a valer a = B y b = A
 */
void intercambio(float *a, float *b);

/*
 * PROGRAMA PRINCIPAL
 * ENTRADA: Por teclado, elementos de dos matrices 3 x 3 de reales
 * REQUISITOS:
 * SALIDA: Este programa saca por pantalla la suma de las dos matrices introducidas y sus respectivas traspuestas
 */
int main(void) {
    char quiereSalir;
    matriz m, n, l;
    int i,j;
	printf("\tPrograma sumMat\n");
	printf("\tCreado por Ibai Larralde Baldanta\n");
	printf("\tversion 1.0 (11/02/2021)\n\n");
    printf("Este programa solicita elementos para crear dos matrices 3 x 3 saca por pantalla la suma de \n");  printf("estas y sus respectivas traspuestas.\n\n");
    do {
        printf("Introduce los valores de la primera matriz: \n");
        for (i = 1; i <= N; i++){
            for (j = 1; j <= N; j++){
                printf("Introduzca el valor [%d][%d] de la primera matriz: \n",i,j);
                scanf("%f",&m[i][j]);
            }
        }
        printf("Introduce los valores de la segunda matriz: \n");
        for (i = 1; i <= N; i++){
            for (j = 1; j <= N; j++){
                printf("Introduzca el valor [%d][%d] de la segunda matriz: \n",i,j);
                scanf("%f",&n[i][j]);
            }
        }
        
        sumaMatrices(m, n, l);
        printf("La suma de las dos matrices es: \n");
        for (i = 1; i <= N; i++){
            for (j = 1; j <= N; j++){
                printf("%f ",l[i][j]);
            }
            printf(" \n");
        }
        
        matrizTraspuesta(m);
        printf("La primera matriz traspuesta es: \n");
        for (i = 1; i <= N; i++){
            for (j = 1; j <= N; j++){
                printf("%f ",m[i][j]);
            }
            printf(" \n");
        }
        
        matrizTraspuesta(n);
        printf("La segunda matriz traspuesta es: \n");
        for (i = 1; i <= N; i++){
            for (j = 1; j <= N; j++){
                printf("%f ",n[i][j]);
            }
            printf(" \n");
        }
        printf("Si desea salir pulse s, para repetir la ejecucion cualquier otra cosa.");
		scanf("\n%c", &quiereSalir);
	} while (quiereSalir != 's');
	return 0;
}

void sumaMatrices(matriz m, matriz n, matriz l){
    int i, j;
    for (i = 1; i <= N; i++){
        for (j = 1; j <= N; j++){
            l[i][j] = m[i][j] + n[i][j];
        }
    }
}

void intercambio(float *a, float *b){
    float aux;
    aux = *a;
    *a = *b;
    *b = aux;
}

void matrizTraspuesta(matriz m){
    int i, j;
    for (i = 2; i <= N; i++){
        for (j = 1; j <= i-1; j++){
            intercambio(&m[i][j], &m[j][i]);
        }
    }
}
