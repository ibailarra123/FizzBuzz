/**
 *	MODULO: ruleta
 *	FICHERO: ruleta.h
 *	VERSION: 1.1.0
 *	HISTORICO:
 *		Creado por Ibai Larralde Baldanta el 04/05/21.
 * DESCRIPCION: Este módulo contiene una serie de operaciones que permiten generar números aleatorios
 */

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>


/**
 * ACCION: iniciarRuleta
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
 */
void iniciarRuleta(){
    srand(time(NULL));
}

/**
 * FUNCION: distribucionExponencial
 * ENTRADA: entero media
 * SALIDA: implementa una distribucion exponencial de media tmedio
 */
int distribucionExponencial(int media){
    float x;
    int t;
    x = (float)rand() / RAND_MAX;
    t = (int)(-log(1-x)*media);
    while ( t = 0 ){
        x = rand() % RAND_MAX;
        t = (int)(-log(1-x)*media);
    }
return t;
}

/**
 * FUNCION: distribucionLineal
 * ENTRADA: dos enteros min y max
 * SALIDA: implementa una distribucion lineal entre min y max
 */
int distribucionLineal(int min,int max){
    float x;
    int t;
    x = rand() % RAND_MAX;
    t = (int)((max - min)*x) + min;
    return t;
}

/**
 * FUNCION: eleccionCon3Probabilidades
 * ENTRADA: tres reales maxp, medp y minp
 * SALIDA: elige entre tres opciones con prob.  dadas
 */
int eleccionCon3Probabilidades(float maxp, float medp, float minp){
    float x;
    int n;
    float elec[3];
    elec[1] = maxp;
    elec[2] = medp + maxp;
    elec[3] = 1;
    x = rand() % RAND_MAX;
    n = 1;
    while ((elec[n] < x) && (n < 3)){
        n = n + 1;
    }
    return n;
}
