/**
 *	MODULO: peajes
 *	FICHERO: peajes.h
 *	VERSION: 1.1.0
 *	HISTORICO:
 *		Creado por Ibai Larralde Baldanta el 11/05/21.
 * DESCRIPCION: Este módulo simula el funcionamientode un peaje de autopista conNCABcabinas.
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "peajes.h"
/**
 * ACCION: 
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
 */
int posicionMaximoEnPrefijo(taux t, int m){
    int i,pos;
    pos = 1;
    for(i=2; i<=m;i=i+1){
        if ((t[i].can) > (t[pos].can))
            pos = i;
    }
    return pos;
}

/**
 * ACCION: 
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
*/
void intercambio(int *t1,int *t2){
    int t3;
    t3 = *t1;
    *t1 = *t2;
    *t2 = t3;
}

/**
 * ACCION: 
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
 */    

void ordenar(taux t){
    int i,max;
    for(i=1;i <= NCAB; i=i+1){
        max = posicionMaximoEnPrefijo(t, (NCAB - i));
        intercambio(&t[NCAB-i].can,&t[max].can);
    }
}

 
/**
 * ACCION: 
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
 */
void guardaCola(Peaje *p, int ncab, Reloj r){
    encolarCoche(p[ncab],r);
}

/**
 * ACCION: 
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
 */
void iniciarPeaje(Peaje *p){
    int i;
    for (i = 1; i <= NCAB; i = i+1)
        iniciarCab(p[i], tipoCobro[i].min, tipoCobro[i].max);
}

/**
 * ACCION: 
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
 */
void rondaCabinas(Peaje *p, Reloj r){
    int i;
    for (i = 1; i <= NCAB; i = i+1)
        servCabina(p[i],r);
}


/**
 * ACCION: 
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
 */
int eligeCabina(Peaje p){
    int x,i,n;
    taux t;
    for (i = 1; i <= NCAB; i = i+1){
        t[i].can = cuantosCoches(p[i]);
        t[i].cab = i;
    }
    ordenar(t);
    x = eleccionCon3Probabilidades(PROB_MAX, PROB_MEDIA, PROB_MIN);
    n=t[x].cab;
    return n;
}
