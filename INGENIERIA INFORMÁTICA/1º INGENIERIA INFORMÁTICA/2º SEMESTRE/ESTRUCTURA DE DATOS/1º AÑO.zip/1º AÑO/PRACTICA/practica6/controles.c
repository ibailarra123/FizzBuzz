/**
 *	MODULO: controles
 *	FICHERO: controles.h
 *	VERSION: 1.1.0
 *	HISTORICO:
 *		Creado por Ibai Larralde Baldanta el 11/05/21.
 * DESCRIPCION: Este módulo
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "controles.h"
/**
 * ACCION: 
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
 */

/**
 * ACCION: 
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
 */    
void iniciarControl(Control *c ){
    c->trafico.tLlegada = distribucionExponencial(c->trafico.tMedio);
    iniciarPeaje(&c->peaje);
}

/**
 * ACCION: 
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
 */
void llegaCoche(Control *c, Reloj r){
    int n;
    if(instante(r) == c->trafico.tLlegada){
        n = eligeCabina(c->peaje);
        guardaCola(&c->peaje,n,r);
        c->trafico.tLlegada = instante(r) + distribucionExponencial(c->trafico.tMedio);
    }
}


/**
 * ACCION: 
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
 */
void marchaCoche(Control *c, Reloj r){
    rondaCabinas(&c->peaje,r);
}
