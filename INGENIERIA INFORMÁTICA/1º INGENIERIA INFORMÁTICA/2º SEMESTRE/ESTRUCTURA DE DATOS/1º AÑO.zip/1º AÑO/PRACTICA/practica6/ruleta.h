/**
 *	MODULO: ruleta
 *	FICHERO: ruleta.h
 *	VERSION: 1.1.0
 *	HISTORICO:
 *		Creado por Ibai Larralde Baldanta el 04/05/21.
 * DESCRIPCION: Este módulo contiene una serie de operaciones que permiten generar números aleatorios
 */
#ifndef ILB_RULETA_H
#define ILB_RULETA_H

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>


/**
 * ACCION: iniciarRuleta
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
 */
void iniciarRuleta();

/**
 * FUNCION: distribucionExponencial
 * ENTRADA: entero media
 * SALIDA: implementa una distribucion exponencial de media tmedio
 */
int distribucionExponencial(int );

/**
 * FUNCION: distribucionLineal
 * ENTRADA: dos enteros min y max
 * SALIDA: implementa una distribucion lineal entre min y max
 */
int distribucionLineal(int ,int );

/**
 * FUNCION: eleccionCon3Probabilidades
 * ENTRADA: tres reales maxp, medp y minp
 * SALIDA: elige entre tres opciones con prob.  dadas
 */
int eleccionCon3Probabilidades(float, float, float );

#endif // ILB_RULETA_H
