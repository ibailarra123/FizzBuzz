/**
 *	MODULO: controles
 *	FICHERO: controles.h
 *	VERSION: 1.1.0
 *	HISTORICO:
 *		Creado por Ibai Larralde Baldanta el 11/05/21.
 * DESCRIPCION: Este módulo 
 */
#ifndef ILB_CONTROLES_H
#define ILB_CONTROLES_H

#include <stdio.h>
#include <stdbool.h>
#include "reloj.h"
#include "colaDeEnteros.h"
#include "ruleta.h"
#include "cabinas.h"
#include "peajes.h"


typedef struct frecuencia{
    int tLlegada;
    int tMedio;
}Frecuencia;
typedef struct control{
    Peaje peaje;
    Frecuencia trafico;
}Control;

/**
 * ACCION: 
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
 */    
void iniciarControl(Control * );

/**
 * ACCION: 
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
 */
void llegaCoche(Control *, Reloj);

/**
 * ACCION: 
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
 */
void marchaCoche(Control *, Reloj);

#endif // ILB_CONTROLES_H
