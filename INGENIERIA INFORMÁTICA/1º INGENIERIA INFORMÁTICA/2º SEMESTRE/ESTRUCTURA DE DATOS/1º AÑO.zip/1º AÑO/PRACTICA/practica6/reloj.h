/**
 *	MODULO: reloj
 *	FICHERO: reloj.h
 *	VERSION: 1.1.0
 *	HISTORICO:
 *		Creado por Ibai Larralde Baldanta el 04/05/21.
 * DESCRIPCION: Este módulo crea el concepto de rloj. Un reloj permite
 *		contar segundos
 */
#ifndef ILB_RELOJ_H
#define ILB_RELOJ_H

#include <stdbool.h>
#include <stdio.h>

typedef int Reloj;

/**
 * ACCION: aCero
 * ENTRADA: Nada
 * SALIDA:  Pone a cero la cuenta del reloj r
 */
void aCero(Reloj *);

/**
 * ACCION: tic
 * ENTRADA: reloj r
 * SALIDA: Incrementa en uno la cuenta del reloj r 
 */
void tic(Reloj *);

/**
 * FUNCION: instante
 * ENTRADA: reloj r
 * SALIDA: Devuelve el operando almacenado en el símbolo
 */
int instante(Reloj);

#endif // ILB_RELOJ_H
