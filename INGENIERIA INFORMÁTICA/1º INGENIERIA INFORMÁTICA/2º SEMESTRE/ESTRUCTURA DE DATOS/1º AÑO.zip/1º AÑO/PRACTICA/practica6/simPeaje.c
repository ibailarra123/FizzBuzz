/**
 *	FICHERO: simPeaje.c
 *	VERSION: 1.1.0
 *	HISTORICO:
 *		Creado por Ibai Larralde Baldanta el 11/05/21.
 * DESCRIPCION: Este algoritmo
 */

#define TSIM 10800

#include <stdio.h>
#include <stdbool.h>
#include "reloj.h"
#include "colaDeEnteros.h"
#include "ruleta.h"
#include "cabinas.h"
#include "peajes.h"
#include "controles.h"


void iniciarSimulacion(Control *c);
/*
 * Entrada : 
 * Requisitos: 
 * Modifica: 
 * Salida: 
 */

void siguienteIteracion(Control *c, Reloj r);
/* Entrada: 
 * Requisitos: 
 * Modifica: 
 * Salida:
 */


/*
 * PROGRAMA PRINCIPAL
 * ENTRADA: Un fichero f de caracteres
 * REQUISITOS: Fichero no vacío
 * SALIDA: Variable que cuenta el número de veces que la primera palabra aparece a lo largo del fichero
 */
int main(void) {
    Reloj r;
    Control c;
    char quiereSalir;
	printf("\tPrograma simpPeaje\n");
	printf("\tCreado por Ibai Larralde Baldanta\n");
	printf("\tversion 1.0 01/05/2021)\n\n");
    printf("\n\n");
    do {
        aCero(&r);
        iniciarSimulacion(&c);
        while (instante(r) != TSIM){
            tic(&r);
            siguienteIteracion(&c,r);
        }
        printf("Si desea salir pulse s, para repetir la ejecucion cualquier otra cosa.");
		scanf("\n%c", &quiereSalir);
	} while (quiereSalir != 's');
	return 0;
}

void iniciarSimulacion(Control *c){
    iniciarRuleta();
    iniciarControl(&*c);
}

void siguienteIteracion(Control *c, Reloj r){
    llegaCoche(&*c,r);
    marchaCoche(&*c,r);
}

