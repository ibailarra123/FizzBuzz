/**
 *	MODULO: colaDeEnteros
 *	FICHERO: colaDeEnteros.h
 *	VERSION: 1.1.0
 *	HISTORICO:
 *		Creado por Ibai Larralde Baldanta el 04/05/21.
 * DESCRIPCION: Este módulo es una cola de elementos tipo entero
 */
#ifndef ILB_COLA_DE_ENTEROS_H
#define ILB_COLA_DE_ENTEROS_H

#include <stdbool.h>


typedef struct nodoDeColaDeEnteros{
    int e;
    struct nodoDeColaDeEnteros *s;
}NodoDeColaDeEnteros;
    
typedef struct colaDeEnteros{
    NodoDeColaDeEnteros *i;
    NodoDeColaDeEnteros *f;
}ColaDeEnteros;
    
/**
 * ACCION: 
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
 */    
void nuevaColaDeEnteros(ColaDeEnteros *);

/**
 * ACCION: 
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
 */
void pideTurnoColaDeEnteros(ColaDeEnteros *, int);

/**
 * ACCION: 
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
 */
void avanceColaDeEnteros(ColaDeEnteros *);

/**
 * ACCION: 
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
 */
void primeroColaDeEnteros(ColaDeEnteros, int *);


/**
 * ACCION: 
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
 */
bool esNulaColaDeEnteros(ColaDeEnteros);



#endif // ILB_COLA_DE_ENTEROS_H
