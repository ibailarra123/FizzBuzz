
/**
 *	MODULO: cabinas
 *	FICHERO: cabinas.h
 *	VERSION: 1.1.0
 *	HISTORICO:
 *		Creado por Ibai Larralde Baldanta el 04/05/21.
 * DESCRIPCION: Este modulo simula el funciona-miento de una cabina del peaje
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "cabinas.h"
#include "ruleta.h"
/**
 * ACCION: 
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
 */    
void iniciarCab(Cabina *cab , int tmin, int tmax){
    cab->nCoches = 0; 
    cab->maxCoches = 0; 
    cab->servidos = 0;
    cab->totalEsperado = 0; 
    cab->proxServ = 0;
    cab->minServ = tmin; 
    cab->maxServ = tmax;
    nuevaColaDeEnteros(&cab->colaCoches);
}

/**
 * ACCION: 
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
 */
void contarCoche(Cabina *cab, Reloj r){
    if (cab->nCoches == 0)
        cab->proxServ = instante(r) + distribucionLineal(cab->minServ, cab->maxServ);
    cab->nCoches = cab->nCoches + 1;
    if (cab->nCoches > cab->maxCoches)
        cab->maxCoches = cab->nCoches;
}

/**
 * ACCION: 
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
 */
void encolarCoche(Cabina *cab, Reloj r){
    contarCoche(cab, r);
    pideTurnoColaDeEnteros(&cab->colaCoches, instante(r));
}

/**
 * ACCION: 
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
 */
void servCabina(Cabina *cab, Reloj r){
    int x;
    if (cab->proxServ == instante(r)){
        cab->servidos = cab->servidos + 1;
        primeroColaDeEnteros(cab->colaCoches,&x);
        avanceColaDeEnteros(&(cab->colaCoches));
        cab->totalEsperado = cab->totalEsperado + (instante(r) - x);
        cab->nCoches = cab->nCoches - 1;
        if (cab->nCoches == 0)
            cab->proxServ = 0;
        else
            cab->proxServ = instante(r) + distribucionLineal(cab->minServ,cab->maxServ);
    }
}


/**
 * ACCION: 
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
 */
int cuantosCoches(Cabina cab){
    int n;
    n = cab.nCoches;
    return n;
}
