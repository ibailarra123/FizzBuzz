/**
 *	MODULO: reloj
 *	FICHERO: reloj.h
 *	VERSION: 1.1.0
 *	HISTORICO:
 *		Creado por Ibai Larralde Baldanta el 04/05/21.
 * DESCRIPCION: Este módulo crea el concepto de rloj. Un reloj permite
 *		contar segundos
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "reloj.h"

typedef int Reloj;

/**
 * ACCION: aCero
 * ENTRADA: Nada
 * SALIDA:  Pone a cero la cuenta del reloj r
 */
void aCero(Reloj *r){
    *r = 0;
}

/**
 * ACCION: tic
 * ENTRADA: reloj r
 * SALIDA: Incrementa en uno la cuenta del reloj r 
 */
void tic(Reloj *r){
    *r = *r + 1;
}

/**
 * FUNCION: instante
 * ENTRADA: reloj r
 * SALIDA: Devuelve el operando almacenado en el símbolo
 */
int instante(Reloj r){
    int i;
    i = r;
    return i;
}
