
/**
 *	MODULO: cabinas
 *	FICHERO: cabinas.h
 *	VERSION: 1.1.0
 *	HISTORICO:
 *		Creado por Ibai Larralde Baldanta el 04/05/21.
 * DESCRIPCION: Este modulo simula el funciona-miento de una cabina del peaje
 */
#ifndef ILB_CABINAS_H
#define ILB_CABINAS_H

#include <stdio.h>
#include <stdbool.h>
#include "reloj.h"
#include "colaDeEnteros.h"


typedef struct cabina{
    int nCoches;
    int maxCoches;
    int servidos;
    int totalEsperado;
    int proxServ;
    int minServ;
    int maxServ;
    ColaDeEnteros colaCoches;
}Cabina;
    

    
/**
 * ACCION: 
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
 */    
void iniciarCab(Cabina * , int , int );

/**
 * ACCION: 
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
 */
void encolarCoche(Cabina *, Reloj );

/**
 * ACCION: 
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
 */
void servCabina(Cabina * , Reloj );


/**
 * ACCION: 
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
 */
int cuantosCoches(Cabina );



#endif // ILB_CABINAS_H
