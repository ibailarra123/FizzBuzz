/**
 *	MODULO: peajes
 *	FICHERO: peajes.h
 *	VERSION: 1.1.0
 *	HISTORICO:
 *		Creado por Ibai Larralde Baldanta el 11/05/21.
 * DESCRIPCION: Este módulo simula el funcionamientode un peaje de autopista conNCABcabinas.
 */
#ifndef ILB_PEAJES_H
#define ILB_PEAJES_H
#define NCAB 5
#define PROB_MAX 0.6
#define PROB_MEDIA 0.3
#define PROB_MIN 0.1

#include <stdio.h>
#include <stdbool.h>
#include "reloj.h"
#include "colaDeEnteros.h"
#include "ruleta.h"
#include "cabinas.h"


typedef Cabina Peaje[NCAB];
typedef struct pareja{
    int can;
    int cab;
}Pareja;
typedef Pareja taux[NCAB];
typedef struct intervalo{
    int min;
    int max;
}Intervalo;
Intervalo tipoCobro[]= {{15,30},{15,30},{15,45},{15,45},{30,60}};

/**
 * ACCION: 
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
 */    
void ordenar(taux );

/**
 * ACCION: 
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
 */
void guardaCola(Peaje *, int, Reloj);

/**
 * ACCION: 
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
 */
void iniciarPeaje(Peaje *);

/**
 * ACCION: 
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
 */
void rondaCabinas(Peaje *, Reloj);


/**
 * ACCION: 
 * ENTRADA: Nada
 * SALIDA:  Inicia la generacion de numeros aleatorios
 */
int eligeCabina(Peaje);

#endif // ILB_PEAJES_H
