/*
 *  Programa: Decascii
 *  Histrico:
 *    Creado por Ibai Larralde Baldanta el 23/03/2021.
 *      versin 1.0.0
 *  Copyright © 2016 Ibai Larralde Baldanta. All rights reserved.
 */

#include <stdio.h>
#define N 8

void ascii(FILE * f, int *n);
/* ENTRADA: Un fichero f de caracteres que tan solo pueden ser "0" o "1"
 * REQUISITOS: Fichero f no vacío
 * SALIDA: Un entero con el numero del conjunto de 8 caracteres
 */

/*
 * PROGRAMA PRINCIPAL
 * ENTRADA: Un fichero f de caracteres que tan solo pueden ser "0" o "1"
 * REQUISITOS: Fichero f no vacío
 * SALIDA: Numero entero correspondiente a cada conjunto de 8 caracteres
 */
int main(void) {
    FILE * f;
    char quiereSalir,c[100];
    int n;
	printf("\tPrograma Decascii\n");
	printf("\tCreado por Ibai Larralde Baldanta\n");
	printf("\tversion 1.0 23/03/2021)\n\n");
    printf("Programa que obtiene un numero entero correspondiente a cada conjunto de 8 caracteres\n");
    do {
        printf("Por favor, introduzca el nombre del fichero de caracteres\n");
        scanf("%s",c);
        while((f = fopen(c,"r")) == NULL){
            printf("Nombre incorrecto, introduce el nombre del fichero de caracteres\n");
            scanf("%s",c);
        }
        printf("Estos son los números obtenidos del fichero intoducido: \n");
        ascii(f,&n);
        while(!feof(f)){
            printf("%d ", n);
            ascii(f,&n);
        }
        printf("\n");
        fclose(f);
        printf("Si desea salir pulse s, para repetir la ejecucion cualquier otra cosa.");
		scanf("\n%c", &quiereSalir);
	} while (quiereSalir != 's');
	return 0;
}

void ascii(FILE * f, int *n){
    char c;
    int x;
    *n = 0;
    for (x = 1; x <= N; x = x+1){
        c = fgetc(f);
        if (c == '0')
            *n = *n * 2;
        else
            *n = (*n * 2) + 1;
    }
}
