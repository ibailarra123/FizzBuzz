/*
 *  Programa: Cuenta
 *  Histrico:
 *    Creado por Ibai Larralde Baldanta el 09/03/2021.
 *      versin 1.0.0
 *  Copyright © 2016 Ibai Larralde Baldanta. All rights reserved.
 */

#include <stdio.h>
#define M 20
typedef enum{FALSE = 0, TRUE = 1}boolean;
typedef char tabla[M];
typedef struct tupla{
    int longitud; 
    tabla letra;
}palabra;

void leerPalabra(FILE * f, palabra *p);
/*
 * Entrada f: fichero de caracter
 * Requisitos: El fichero no esta vacio y pd(f) = aM y a != e
 * Modifica: f avanzando el elemento distinguido hasta el principio de la siguiente palabra
 * Salida: p (entero) contiene la primera palabra de a
 */

void saltarBlancos(FILE * f, char *c);
/* Entrada: f un fichero de caracter
 * Requisitos: pd(f) = aM con a != e
 * Modifica: f, a la salida el elemento distinguido de f es el primer caracter no blanco de a
 * Salida: c, un caracter que coincide con el elemento distinguido de f
 */

void copiarLetras(FILE * f, palabra *p, char c);
/*
 * Entrada f: fichero de caracter pd(f) = BM y c, un caracter
 * Requisitos: c coincide con el elemento distinguido de f
 * Modifica: f avanzando el elemento distinguido hasta el principio de la siguiente palabra
 * Salida: p (entero) contiene la primera palabra de B
 */
 
boolean sonPalabrasIguales(palabra p1, palabra p2);
/*
 * Entrada: p1 = P y p2 = Q, dos palabras
 * Requisitos: p1 y p2 están inicializadas
 * Salida: el booleano b será verdadero si y sólo si P = Q 
 */

/*
 * PROGRAMA PRINCIPAL
 * ENTRADA: Un fichero f de caracteres
 * REQUISITOS: Fichero no vacío
 * SALIDA: Variable que cuenta el número de veces que la primera palabra aparece a lo largo del fichero
 */
int main(void) {
    FILE * f;
    char gp[100],quiereSalir;
    int contador;
    palabra p1,p2;
    boolean b;
	printf("\tPrograma cuenta\n");
	printf("\tCreado por Ibai Larralde Baldanta\n");
	printf("\tversion 1.0 09/03/2021)\n\n");
    printf("Dado un fichero de caracteres cuéntese el número de veces que la primera palabra aparece\n"); 
    printf("a lo largo del mismo\n\n");
    do {
        printf("¿Qué fichero quiere abrir?\n");
        scanf("%s",gp);
        while ((f=fopen(gp,"r"))==NULL){
            printf("Nombre incorrecto, ¿Qúe fichero quiere abrir?\n");
            scanf("%s",gp);
        }
        contador = 1;
        leerPalabra(f,&p1);
        while(!feof(f)){
            leerPalabra(f,&p2);
            b = sonPalabrasIguales(p1,p2);
            if (b)
                contador = contador + 1;
            }
        fclose(f);
        printf("La primera palabra se repite %d veces\n",contador);
        printf("Si desea salir pulse s, para repetir la ejecucion cualquier otra cosa.");
		scanf("\n%c", &quiereSalir);
	} while (quiereSalir != 's');
	return 0;
}

void leerPalabra(FILE *f, palabra *p){
    char c;
    saltarBlancos(f, &c);
    copiarLetras(f, p, c);
}

void saltarBlancos(FILE *f, char *c){
    *c=getc(f);
    while(!feof(f) && (*c ==' ')){
        *c=getc(f);
    }
}

void copiarLetras(FILE *f, palabra *p, char c){
    p -> longitud = 0;
    while(!feof(f) && (c !=' ')){
        p->longitud = p->longitud + 1;
        p->letra[p->longitud] = c;    
        c = getc(f);
    }
    if (c !=' '){
        p->longitud = p->longitud + 1;
        p->letra[p->longitud] = c;
    }
}

boolean sonPalabrasIguales(palabra p1, palabra p2){
    int i;
    boolean b;
    if (p1.longitud == p2.longitud){
        i = 1;
        while ((i < p1.longitud) && (p1.letra[i] == p2.letra[i]))
            i = i + 1;
        b = (p1.letra[i] == p2.letra[i]);
    }
    else 
        b = FALSE;
    return b;
}
