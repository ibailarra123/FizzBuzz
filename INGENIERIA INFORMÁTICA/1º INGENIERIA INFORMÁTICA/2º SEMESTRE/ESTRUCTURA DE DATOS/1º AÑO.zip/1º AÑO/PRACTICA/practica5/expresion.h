#ifndef FFF_EXPRESION_H
#define FFF_EXPRESION_H
/**
 *	MODULO: Expresion
 *	FICHERO: Expresion.h
 *	VERSION: 1.0.0
 *	HISTORICO:
 *		Creado por Ibai Larralde el 13/04/21.
 * DESCRIPCION: Este módulo gestiona el almacén de la expresión postfija como
 * una cola de un  ́unico uso
 */

#include <stdio.h>
#include <stdbool.h>
#include "simbolos.h"

#define N_EXPRESION 100

typedef struct expresion{
	Simbolo valores[N_EXPRESION];
    int inicio;
    int fin;
} Expresion;

/**
 * ACCION: 
 * ENTRADA: 
 *	REQUISITOS: 
 * SALIDA: 
 */
void expresionNula(Expresion *);
/**
 * ACCION: 
 * ENTRADA: 
 *	REQUISITOS: 
 * MODIFICA: 
 */
void aniadeSimbolo(Expresion *, Simbolo);
/**
 * ACCION: 
 * ENTRADA: 
 *	REQUISITOS: 
 * MODIFICA: 
 */
void eliminaSimbolo(Expresion *);
/**
 * ACCION: 
 * ENTRADA: 
 *	REQUISITOS: 
 * MODIFICA: 
 */
void primerSimbolo(Expresion, Simbolo *);
/**
 * FUNCION : 
 * ENTRADA: 
 *	REQUISITOS: 
 * SALIDA: 
 */
bool expresionVacia(Expresion);
#endif //FFF_PILA_DE_SIMBOLOS_H
