/**
 *	MODULO: Expresion
 *	FICHERO: Expresion.h
 *	VERSION: 1.0.0
 *	HISTORICO:
 *		Creado por Ibai Larralde el 13/04/21.
 * DESCRIPCION: Este módulo gestiona el almacén de la expresión postfija como
 * una cola de un  ́unico uso
 */

#include <stdio.h>
#include <stdlib.h>
#include "expresion.h"

/**
 * ACCION: 
 * ENTRADA: 
 *	REQUISITOS: 
 * SALIDA: 
 */
void errorExpresion(char s[]){
    printf("\n\n\nERROR EN EL MODULO PILAS: %s \n",s);
    while(true)
        exit(-1);
}

/**
 * ACCION: 
 * ENTRADA: 
 *	REQUISITOS: E
 * SALIDA: 
 */
bool llenaExpresion(Expresion e){
    return(e.fin == N_EXPRESION-1);
}

    /**
 * ACCION: 
 * ENTRADA: 
 *	REQUISITOS: 
 * SALIDA: 
 */
void expresionNula(Expresion *e){
    e->inicio=0;
    e->fin=0;
    Simbolo valores[N_EXPRESION];
}
/**
 * ACCION: 
 * ENTRADA: 
 *	REQUISITOS: 
 * MODIFICA: 
 */
void aniadeSimbolo(Expresion *e, Simbolo s){
    if(llenaExpresion(*e))
        errorExpresion("error");
    e->fin++;
    e->valores[e->fin]=s;
}
/**
 * ACCION: 
 * ENTRADA: 
 *	REQUISITOS: 
 * MODIFICA: 
 */
void eliminaSimbolo(Expresion *e){
    if(expresionVacia(*e))
        errorExpresion("VACIA");
    e->fin--;
}
/**
 * ACCION: 
 * ENTRADA: 
 *	REQUISITOS: 
 * MODIFICA: 
 */
void primerSimbolo(Expresion e, Simbolo *s){
    if(expresionVacia(e))
        errorExpresion("VACÍA");
    *s =  e.valores[e.fin];
}
/**
 * FUNCION : 
 * ENTRADA: 
 *	REQUISITOS: 
 * SALIDA: 
 */
bool expresionVacia(Expresion e){
    return(e.fin==e.inicio);
}
