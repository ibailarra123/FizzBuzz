#ifndef FFF_CONVERSOR_H
#define FFF_CONVERSOR_H
/**
 *	MODULO: conversor
 *	FICHERO: conversor.h
 *	VERSION: 1.0.0
 *	HISTORICO:
 *		Creado por Ibai Larralde el 14/04/21.
 * DESCRIPCION: Añade la funcionalidad de conversión de una expresión denotación infija a notación postfija.
 */

#include <stdio.h>
#include <stdbool.h>
#include "operadores.h"
#include "expresion.h"
#include "pilaDeSimbolos.h"
#include "simbolos.h"

#define N 100
typedef char cadena[N];

/**
 * ACCION: decbin
 * ENTRADA: 
 *	REQUISITOS: 
 * SALIDA: 
 */
void decbin(cadena,int *, int *);
/**
 * ACCION: colocaSimbolo
 * ENTRADA:
 *	REQUISITOS: 
 * MODIFICA: 
 */
void colocaSimbolo(Simbolo, Expresion *,PilaDeSimbolos *);
/**
 * ACCION: transfPolonesa
 * ENTRADA:
 *	REQUISITOS: 
 * MODIFICA: 
 */
void transfPolonesa(cadena, Expresion *);

#endif //FFF_PILA_DE_ENTEROS_H
