#ifndef FFF_PILA_DE_SIMBOLOS_H
#define FFF_PILA_DE_SIMBOLOS_H
/**
 *	MODULO: pilaSimbolos
 *	FICHERO: pilaDeSimbolos.h
 *	VERSION: 1.0.0
 *	HISTORICO:
 *		Creado por Ibai Larralde el 13/04/21.
 * DESCRIPCION: Este módulo exporta la funcionalidad necesaria para implementar
 * 	una pila de simbolos. Utiliza una implementacion estática contigua. El tipo es
 * 	asignable
 */

#include <stdbool.h>
#include "simbolos.h"

#define TAMANIO_PILA_DE_SIMBOLOS 100

typedef struct pilaDeSimbolos{
	int cima; 
	Simbolo valores[TAMANIO_PILA_DE_SIMBOLOS];
} PilaDeSimbolos;

/**
 * ACCION: nuevaPilaDeSimbolos
 * ENTRADA: una pila de simbolos
 *	REQUISITOS: la pila no está inicializada
 * SALIDA: Inicializa la pila como una pila de simbolos sin elementos
 */
void nuevaPilaDeSimbolos(PilaDeSimbolos *);
/**
 * ACCION: apilarPilaDeSimbolos
 * ENTRADA: una pila de simbolos y un simbolo
 *	REQUISITOS: la pila está inicializada y no está llena
 * MODIFICA: Añade el simbolo como la cima de la pila
 */
void apilarPilaDeSimbolos(PilaDeSimbolos *, Simbolo);
/**
 * ACCION: desapilarPilaDeSimbolos
 * ENTRADA: una pila de simbolos
 *	REQUISITOS: la pila está inicializada y no está vacía
 * MODIFICA: Elimina el elemento más nuevo de la pila
 */
void desapilarPilaDeSimbolos(PilaDeSimbolos *);
/**
 * ACCION: cimaPilaDeSimbolos
 * ENTRADA: una pila de simbolos y un simbolo
 *	REQUISITOS: la pila está inicializada y no está vacía
 * MODIFICA: Copia en elentero el elemento más nuevo de la pila
 */
void cimaPilaDeSimbolos(PilaDeSimbolos, Simbolo *);
/**
 * ACCION: esNulaPilaDeSimbolos
 * ENTRADA: una pila de simbolos
 *	REQUISITOS: la pila está inicializada
 * SALIDA: Devuelve true si la pila está vacía
 */
bool esNulaPilaDeSimbolos(PilaDeSimbolos);
#endif //FFF_PILA_DE_SIMBOLOS_H
