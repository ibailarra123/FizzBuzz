#ifndef FFF_EVALUADOR_H
#define FFF_EVALUADOR_H
/**
 *	MODULO: evaluador
 *	FICHERO: avaluador.h
 *	VERSION: 1.0.0
 *	HISTORICO:
 *		Creado por Ibai Larralde el 14/04/21.
 * DESCRIPCION: Este módulo evalua la expresion en notación postfija dada en e
 */

#include <stdio.h>
#include <stdbool.h>
#include "operadores.h"
#include "expresion.h"
#include "pilaDeEnteros.h"
#include "simbolos.h"


/**
 * ACCION: eval
 * ENTRADA: 
 *	REQUISITOS: 
 * SALIDA: 
 */
void eval(PilaDeEnteros *, Operador);
/**
 * FUNCION: evaluaPolonesa
 * ENTRADA:
 *	REQUISITOS: 
 * MODIFICA: 
 */
int evaluaPolonesa(Expresion);
#endif //FFF_PILA_DE_ENTEROS_H
