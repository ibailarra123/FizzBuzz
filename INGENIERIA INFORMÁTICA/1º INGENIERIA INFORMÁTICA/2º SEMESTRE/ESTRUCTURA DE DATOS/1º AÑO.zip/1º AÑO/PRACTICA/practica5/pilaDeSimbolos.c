/**
 *	MODULO: pilaDeSimbolos
 *	FICHERO: pilaDeSimbolos.h
 *	VERSION: 1.0.0
 *	HISTORICO:
 *		Creado por Ibai Larralde el 13/04/21.
 * DESCRIPCION: Este módulo exporta la funcionalidad necesaria para implementar
 * 	una pila simbolos. Utiliza una implementacion estática contigua. El tipo es
 * 	asignable
 */
#include "pilaDeSimbolos.h"
#include <stdio.h>
#include <stdlib.h>
/**
 * ACCION: nuevaPilaDeSimbolos
 * ENTRADA: una pila de simbolos
 *	REQUISITOS: la pila no está inicializada
 * SALIDA: Inicializa la pila como una pila de simbolos sin elementos
 */
void nuevaPilaDeSimbolos(PilaDeSimbolos *p){
	p->cima=-1;
}
/**
 * ACCION: error
 *	REQUISITOS:
 * SALIDA: Para la ejecución tras informar de un error
 */
void errorPilaDeSimbolos(char s[]){
	printf("\n\n\nERROR en el módulo pilas: %s \n", s);
	while (true)
		exit(-1);
}
/**
 * ACCION: llena
 *	REQUISITOS:
 * SALIDA: Devuelve verdadero si la pila está llena
 */
bool llenaPilaDeSimbolos(PilaDeSimbolos p){
	return (p.cima == TAMANIO_PILA_DE_SIMBOLOS -1);
}
/**
 * ACCION: apilarPilaDeSimbolos
 * ENTRADA: una pila de simbolos y un simbolo
 *	REQUISITOS: la pila está inicializada y no está llena
 * MODIFICA: Añade el simbolo como la cima de la pila
 */
void apilarPilaDeSimbolos(PilaDeSimbolos *p, Simbolo x){
	if (llenaPilaDeSimbolos(*p))
		errorPilaDeSimbolos("Apilando en una pila de simbolos llena.");
	p->cima++;
	p->valores[p->cima]=x;
}
/**
 * ACCION: desapilarPilaDeSimbolos
 * ENTRADA: una pila de simbolos
 *	REQUISITOS: la pila está inicializada y no está vacía
 * MODIFICA: Elimina el elemento más nuevo de la pila
 */
void desapilarPilaDeSimbolos(PilaDeSimbolos *p){
	if (esNulaPilaDeSimbolos(*p))
		errorPilaDeSimbolos("Desapilando en una pila de simbolos vacia.");
	p->cima--;
}
/**
 * ACCION: cimaPilaDeSimbolos
 * ENTRADA: una pila de simbolos y un simbolo
 *	REQUISITOS: la pila está inicializada y no está vacía
 * MODIFICA: Copia en elentero el elemento más nuevo de la pila
 */
void cimaPilaDeSimbolos (PilaDeSimbolos p, Simbolo *x){
	if (esNulaPilaDeSimbolos(p))
		errorPilaDeSimbolos("Cima en una pila de simbolos vacia.");
	*x = p.valores[p.cima];
}
/**
 * ACCION: esNulaPilaDeSimbolos
 * ENTRADA: una pila de simbolos
 *	REQUISITOS: la pila está inicializada
 * SALIDA: Devuelve true si la pila está vacía
 */
bool esNulaPilaDeSimbolos (PilaDeSimbolos p){
	return (p.cima == -1);
}
