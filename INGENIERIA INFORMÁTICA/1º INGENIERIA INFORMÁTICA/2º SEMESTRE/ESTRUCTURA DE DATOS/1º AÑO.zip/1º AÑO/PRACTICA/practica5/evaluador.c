
/**
 *	MODULO: evaluador
 *	FICHERO: avaluador.h
 *	VERSION: 1.0.0
 *	HISTORICO:
 *		Creado por Ibai Larralde el 14/04/21.
 * DESCRIPCION: Este módulo evalua la expresion en notación postfija dada en e
 */

#include <stdio.h>
#include <stdlib.h>
#include "evaluador.h"

/**
 * ACCION: eval
 * ENTRADA: 
 *	REQUISITOS: 
 * SALIDA: 
 */
void eval(PilaDeEnteros *p, Operador op){
    int v1,v2;
    cimaPilaDeEnteros(*p,&v1);
    desapilarPilaDeEnteros(*&p);
    cimaPilaDeEnteros(*p,&v2);
    desapilarPilaDeEnteros(*&p);
    if (op == suma)
        v1 = v2 + v1;
    else if (op == resta)
        v1 = v2 - v1;
    else if (op == producto)
        v1 = v2 * v1;
    else if (op == division)
        v1 = v2 / v1;
    apilarPilaDeEnteros(*&p,v1);
}

/**
 * FUNCION: evaluaPolonesa
 * ENTRADA:
 *	REQUISITOS: 
 * MODIFICA: 
 */
int evaluaPolonesa(Expresion e){
    int v;
    PilaDeEnteros p;
    Simbolo x;
    nuevaPilaDeEnteros(&p);
    while (!expresionVacia(e)){
        primerSimbolo(e,&x);
        if (esOperador(x))
            eval(&p,operador(x));
        else
            apilarPilaDeEnteros(&p,valor(x));
        eliminaSimbolo(&e);
    }
    cimaPilaDeEnteros(p,&v);
    return v;
}

