/**
 *	MODULO: conversor
 *	FICHERO: conversor.h
 *	VERSION: 1.0.0
 *	HISTORICO:
 *		Creado por Ibai Larralde el 15/04/21.
 * DESCRIPCION: Este módulo Añade la funcionalidad de conversión de una expresión denotación infija a notación 
 * postfija
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "conversor.h"

/**
 * ACCION: decbin
 * ENTRADA: 
 *	REQUISITOS: 
 * SALIDA: 
 */
void decbin(cadena s,int *i, int *n){
    *n = 0;
    while (s[*i] >= '0' && s[*i] <= '9' && *i <= strlen(s)){
        *n = *n * 10 + (s[*i] - ('0'));
        *i = *i+1;
    }
}
/**
 * ACCION: colocaSimbolo
 * ENTRADA:
 *	REQUISITOS: 
 * MODIFICA: 
 */
void colocaSimbolo(Simbolo y, Expresion *e ,PilaDeSimbolos *p){
    Simbolo x;
    Operador a,b;
    if (esOperador(y)){
        cimaPilaDeSimbolos(*p,&x);
        a = operador(x);
        b = operador(y);
        if (a != dolar || b != dolar){
            if (precedenciaIzquierda(a) < precedenciaDerecha(b))
                apilarPilaDeSimbolos(*&p,y);
            else{
                while (precedenciaIzquierda(a) > precedenciaDerecha(b)){
                    aniadeSimbolo(*&e,x);
                    desapilarPilaDeSimbolos(*&p);
                    cimaPilaDeSimbolos(*p,&x);
                    a = operador(x);
                }
                if(precedenciaIzquierda(a) = precedenciaDerecha(b))
                    desapilarPilaDeSimbolos(*&p);
                else
                    apilarPilaDeSimbolos(*&p,y);
            }
        }
        else if(a == dolar && b == dolar)
            desapilarPilaDeSimbolos(*&p);
    }
    else
        aniadeSimbolo(*&e,y);
}
/**
 * ACCION: transfPolonesa
 * ENTRADA:
 *	REQUISITOS: 
 * MODIFICA: 
 */
void transfPolonesa(cadena ein, Expresion *eout){
    PilaDeSimbolos p;
    Simbolo a;
    int i,x;
    expresionNula(*&eout);
    nuevaPilaDeSimbolos(&p);
    hazOperador(dolar,&a);
    apilarPilaDeSimbolos(&p,a);
    i = 1;
    while (i <= strlen(ein)){
        if (ein[i] = ' ')
            i = i+1;
        else if(ein[i] = '+'){
            hazOperador(suma,&a);
            colocaSimbolo(a,*&eout,&p);
            i = i+1;
        }
        else if(ein[i] = '-'){
            hazOperador(resta,&a);
            colocaSimbolo(a,*&eout,&p);
            i = i+1;
        }
        else if(ein[i] = '*'){
            hazOperador(producto,&a);
            colocaSimbolo(a,*&eout,&p);
            i = i+1;
        }
        else if(ein[i] = '/'){
            hazOperador(division,&a);
            colocaSimbolo(a,*&eout,&p);
            i = i+1;
        }
        else if(ein[i] = '('){
            hazOperador(parizqdo,&a);
            colocaSimbolo(a,*&eout,&p);
            i = i+1;
        }
        else if(ein[i] = ')'){
            hazOperador(pardcho,&a);
            colocaSimbolo(a,*&eout,&p);
            i = i+1;
        }
        else if(ein[i] >= '0' && ein[i] <= '9'){
            decbin(ein,&i,&x);
            hazOperando(x,&a);
            colocaSimbolo(a,*&eout,&p);
        }
        else
            i = i+1;
    }
    hazOperador(dolar,&a);
    colocaSimbolo(a,*&eout,&p);
            
}
