/*
 *  Programa: Palabras
 *  Histrico:
 *    Creado por Ibai Larralde Baldanta el 24/03/2021.
 *      versin 1.0.0
 *  Copyright © 2016 Ibai Larralde Baldanta. All rights reserved.
 */

typedef enum{FALSE = 0, TRUE = 1}boolean;
typedef char tabla[20];
typedef struct tupla{
    int longitud; 
    tabla letra;
}palabra;


void leerPalabra(FILE * f, palabra *p);
/*
 * Entrada f: fichero de caracter
 * Requisitos: El fichero no esta vacio y pd(f) = aM y a != e
 * Modifica: f avanzando el elemento distinguido hasta el principio de la siguiente palabra
 * Salida: p (entero) contiene la primera palabra de a
 */

void saltarBlancos(FILE * f, char *c);
/* Entrada: f un fichero de caracter
 * Requisitos: pd(f) = aM con a != e
 * Modifica: f, a la salida el elemento distinguido de f es el primer caracter no blanco de a
 * Salida: c, un caracter que coincide con el elemento distinguido de f
 */

void copiarLetras(FILE * f, palabra *p, char c);
/*
 * Entrada f: fichero de caracter pd(f) = BM y c, un caracter
 * Requisitos: c coincide con el elemento distinguido de f
 * Modifica: f avanzando el elemento distinguido hasta el principio de la siguiente palabra
 * Salida: p (entero) contiene la primera palabra de B
 */
 
boolean sonPalabrasIguales(palabra p1, palabra p2);
/*
 * Entrada: p1 = P y p2 = Q, dos palabras
 * Requisitos: p1 y p2 están inicializadas
 * Salida: el booleano b será verdadero si y sólo si P = Q 
 */
