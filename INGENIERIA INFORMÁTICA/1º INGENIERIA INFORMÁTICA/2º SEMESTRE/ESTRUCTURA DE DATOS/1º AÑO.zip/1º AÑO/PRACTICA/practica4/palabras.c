/*
 *  Programa: Palabras
 *  Histrico:
 *    Creado por Ibai Larralde Baldanta el 24/03/2021.
 *      versin 1.0.0
 *  Copyright © 2016 Ibai Larralde Baldanta. All rights reserved.
 */

#include <stdio.h>
#include "palabras.h"

void leerPalabra(FILE *f, palabra *p){
    char c;
    saltarBlancos(f, &c);
    copiarLetras(f, p, c);
}

void saltarBlancos(FILE *f, char *c){
    *c=getc(f);
    while(!feof(f) && (*c ==' ')){
        *c=getc(f);
    }
}

void copiarLetras(FILE *f, palabra *p, char c){
    p -> longitud = 0;
    while(!feof(f) && (c !=' ')){
        p->longitud = p->longitud + 1;
        p->letra[p->longitud] = c;    
        c = getc(f);
    }
    if (c !=' '){
        p->longitud = p->longitud + 1;
        p->letra[p->longitud] = c;
    }
}

boolean sonPalabrasIguales(palabra p1, palabra p2){
    int i;
    boolean b;
    if (p1.longitud == p2.longitud){
        i = 1;
        while ((i < p1.longitud) && (p1.letra[i] == p2.letra[i]))
            i = i + 1;
        b = (p1.letra[i] == p2.letra[i]);
    }
    else 
        b = FALSE;
    return b;
}
