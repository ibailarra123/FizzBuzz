/*
 *  Programa: Cuenta2
 *  Histrico:
 *    Creado por Ibai Larralde Baldanta el 24/03/2021.
 *      versin 1.0.0
 *  Copyright © 2016 Ibai Larralde Baldanta. All rights reserved.
 */
 
#include <stdio.h>
#include "palabras.h"

/*
 * PROGRAMA PRINCIPAL
 * ENTRADA: Un fichero f de caracteres
 * REQUISITOS: Fichero no vacío
 * SALIDA: Variable que cuenta el número de veces que la primera palabra aparece a lo largo del fichero
 */

int main(void) {
    FILE * f;
    char gp[100],quiereSalir;
    int contador;
    palabra p1,p2;
    boolean b;
	printf("\tPrograma cuenta\n");
	printf("\tCreado por Ibai Larralde Baldanta\n");
	printf("\tversion 1.0 09/03/2021)\n\n");
    printf("Dado un fichero de caracteres cuéntese el número de veces que la primera palabra aparece\n"); 
    printf("a lo largo del mismo\n\n");
    do {
        printf("¿Qué fichero quiere abrir?\n");
        scanf("%s",gp);
        while ((f=fopen(gp,"r"))==NULL){
            printf("Nombre incorrecto, ¿Qúe fichero quiere abrir?\n");
            scanf("%s",gp);
        }
        contador = 1;
        leerPalabra(f,&p1);
        while(!feof(f)){
            leerPalabra(f,&p2);
            b = sonPalabrasIguales(p1,p2);
            if (b)
                contador = contador + 1;
            }
        fclose(f);
        printf("La primera palabra se repite %d veces\n",contador);
        printf("Si desea salir pulse s, para repetir la ejecucion cualquier otra cosa.");
		scanf("\n%c", &quiereSalir);
	} while (quiereSalir != 's');
	return 0;
}
