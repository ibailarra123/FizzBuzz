/*
 * PROGRAMA:Visor de archivos
 * FICHERO:visor.c
 * HISTORICO:
 *      Creado por Ibai Larralde el 23/02/2021
 *          version 1.0.0
 */
#include <stdio.h>

int main (void)
{
    FILE * f;
    char fichero[50];
    int x;
    printf("Introduzca el nombre del fichero a tratar\n");
    scanf("%s", fichero);
    while ((f=fopen(fichero,"rb"))==NULL) 
    {
        printf("Nombre incorrecto. Introduzca oto nombre\n");
        scanf("%s", fichero);
    }
    fread(&x, sizeof(int), 1, f);

    while(!feof(f))
    {
        printf("%d ", x);
        fread(&x, sizeof(int), 1, f);
    }
    fclose(f);
}
