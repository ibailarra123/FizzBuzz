/*
 *  Programa: Intersecion
 *  Histrico:
 *    Creado por Ibai Larralde Baldanta el 02/03/2021.
 *      versin 1.0.0
 *  Copyright © 2016 Ibai Larralde Baldanta. All rights reserved.
 */

#include <stdio.h>
typedef enum {False = 0, True = 1} booleano;

/*
 * PROGRAMA PRINCIPAL
 * ENTRADA: las rutas de dos ficheros bi-narios de enteros ordenados de menor a mayor (orden estrictamente 
 * creciente)
 * REQUISITOS: Ninguno
 * SALIDA: Un nuevo fichero binario de enteros ordenados con los valores que aparezcanen ambos ficheros
 */
int main(void) {
    FILE *capicuas;
    FILE *primos;
    FILE *priycap;
    char quiereSalir,c[50],p[50];
    int xp,xc;
	printf("\tPrograma Interseccion\n");
	printf("\tCreado por Ibai Larralde Baldanta\n");
	printf("\tversion 1.0 02/03/2021)\n\n");
    printf("Programa que construye un fichero binario priycap.int, el cual es un fichero de enteros ordenados ");
    printf("con los valores que aparezcan en dos ficheros dados\n\n");
    do {
        priycap = fopen("priycap.int","wb");
        printf("Por favor, introduzca el nombre del fichero de números primos que desea introducir\n");
        scanf("%s",p);
        while((primos=fopen(p,"rb"))==NULL){
            printf("Nombre incorrecto, introduce el nombre del fichero de números primos que desea introducir\n");
            scanf("%s",p);
        }
        printf("Por favor, introduzca el nombre del fichero de números capicuas que desea introducir\n");
        scanf("%s",c);
        while((capicuas=fopen(c,"rb"))==NULL){
            printf("Nombre incorrecto, introduce el nombre del fichero de números capicuas que desea\n"); printf("introducir\n");
            scanf("%s",c);
        }
        fread(&xp,sizeof(int),1,primos);
        fread(&xc,sizeof(int),1,capicuas);
        while(!feof(primos) && !feof(capicuas)){
            if (xp > xc)
                fread(&xc,sizeof(int),1,capicuas);
            else if (xp < xc)
                fread(&xp,sizeof(int),1,primos);
            else{
                fwrite(&xp,sizeof(int),1,priycap);
                fread(&xc,sizeof(int),1,capicuas);
                fread(&xp,sizeof(int),1,primos);
            }
        }
        fclose(capicuas);
        fclose(primos);
        fclose(priycap);
        printf("Si desea salir pulse s, para repetir la ejecucion cualquier otra cosa.");
		scanf("\n%c", &quiereSalir);
	} while (quiereSalir != 's');
	return 0;
}
