/*
 *  Programa: capicuas
 *  Histrico:
 *    Creado por Ibai Larralde Baldanta el 23/02/2021.
 *      versin 1.0.0
 *  Copyright © 2016 Ibai Larralde Baldanta. All rights reserved.
 */

#include <stdio.h>
#include <math.h>
typedef enum{FAlSE = 0, TRUE = 1}boolean;

/*
 * FUNCION: esCapicua
 * ENTRADA: n, un número entero
 * REQUISITOS: n >= 0
 * SALIDA: el booleando b será verdadero si n era capicua
 */
boolean esCapicua(int n);

/*
 * FUNCION: reverso
 * ENTRADA: el entero n = n1,n2,...,nl
 * REQUISITOS: n >= 0
 * SALIDA: m contiene los d ́ıgitos de n invertidos (m = nl,...,n2,n1)
 */
int reverso(int n);

/*
 * PROGRAMA PRINCIPAL
 * ENTRADA: Ninguno
 * REQUISITOS: Ninguno
 * SALIDA: Construye un fichero binario capicuas.int de valores de tipo entero con todods los números capicúas
 * menores que 1.008.002
 */
int main(void) {
    FILE *capicuas;
    char quiereSalir;
    int x;
    boolean b;
	printf("\tPrograma capicuas\n");
	printf("\tCreado por Ibai Larralde Baldanta\n");
	printf("\tversion 1.0 23/02/2021)\n\n");
    printf("Construye un fichero binario capicuas.int de valores de tipo entero con todods los números capicúas");
    printf("menores que 1.008.002\n\n");
    do {
        capicuas = fopen("capicuas.int","wb");
            for(x = 1; x < 1008002 ; x++){
                b = esCapicua(x);
                if (b)
                    fwrite(&x, sizeof(int),1,capicuas);
            }
        fclose(capicuas);
        printf("Si desea salir pulse s, para repetir la ejecucion cualquier otra cosa.");
		scanf("\n%c", &quiereSalir);
	} while (quiereSalir != 's');
	return 0;
}

int reverso(int n){
    int m;
    m = 0;
    while (n > 0){
        m = (10 * m) + (n % 10);
        n = n / 10;
    }
    return m;
}

boolean esCapicua(int n){
    boolean b;
    b = (n == reverso(n));
    return b;
}
