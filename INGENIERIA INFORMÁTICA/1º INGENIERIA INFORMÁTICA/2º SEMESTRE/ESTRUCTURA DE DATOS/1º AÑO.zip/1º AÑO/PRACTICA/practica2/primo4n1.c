/*
 *  Programa: primo4n1
 *  Histrico:
 *    Creado por Ibai Larralde Baldanta el 24/02/2021.
 *      versin 1.0.0
 *  Copyright © 2016 Ibai Larralde Baldanta. All rights reserved.
 */

#include <stdio.h>
#include <math.h>

/*
 * PROGRAMA PRINCIPAL
 * ENTRADA: Ninguno
 * REQUISITOS: Ninguno
 * SALIDA: Construye un fichero primo4n1.int de valores de tipo entero con todods los números primos de la forma
 * 4n+1 menores que 1.008.002
 */
int main(void) {
    FILE *primo4n1;
    FILE *primos;
    char quiereSalir;
    int x;
	printf("\tPrograma primo4n1\n");
	printf("\tCreado por Ibai Larralde Baldanta\n");
	printf("\tversion 1.0 24/02/2021)\n\n");
    printf("Construye un fichero binario primos.int de valores de tipo entero con todods los números primos ");
    printf("de la forma 4n + 1 menores que 1.008.002\n\n");
    do {
        primo4n1 = fopen("primo4n1.int","wb");
        primos = fopen("primos.int","rb");
        fread(&x, sizeof(int),1,primos);
        while(!feof(primos)){
            if ((x-1)%4 == 0)
                fwrite(&x, sizeof(int),1,primo4n1);
            fread(&x, sizeof(int),1,primos);  
            }
        
        fclose(primo4n1);
        fclose(primos);
        printf("Si desea salir pulse s, para repetir la ejecucion cualquier otra cosa.");
		scanf("\n%c", &quiereSalir);
	} while (quiereSalir != 's');
	return 0;
}
