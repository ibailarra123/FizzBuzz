/*
 *  Programa: Primos
 *  Histrico:
 *    Creado por Ibai Larralde Baldanta el 24/02/2021.
 *      versin 1.0.0
 *  Copyright © 2016 Ibai Larralde Baldanta. All rights reserved.
 */

#include <stdio.h>
#include <math.h>
typedef enum{FALSE = 0, TRUE = 1}boolean;

/*
 * FUNCION: esPrimo
 * ENTRADA: n, un número entero
 * REQUISITOS: n >1
 * SALIDA: el booleando b será verdadero si n es primo
 */
boolean esPrimo(int n);

/*
 * PROGRAMA PRINCIPAL
 * ENTRADA: Ninguno
 * REQUISITOS: Ninguno
 * SALIDA: Construye un fichero primos.int de valores de tipo entero con todods los números primos
 * menores que 1.008.002
 */
int main(void) {
    FILE *primos;
    char quiereSalir;
    int x;
    boolean b;
	printf("\tPrograma primos\n");
	printf("\tCreado por Ibai Larralde Baldanta\n");
	printf("\tversion 1.0 24/02/2021)\n\n");
    printf("Construye un fichero binario primos.int de valores de tipo entero con todods los números primos");
    printf("menores que 1.008.002\n\n");
    do {
        primos = fopen("primos.int","wb");
            for(x = 1; x < 1008002 ; x++){
                b = esPrimo(x);
                if (b)
                    fwrite(&x, sizeof(int),1,primos);
            }
        fclose(primos);
        printf("Si desea salir pulse s, para repetir la ejecucion cualquier otra cosa.");
		scanf("\n%c", &quiereSalir);
	} while (quiereSalir != 's');
	return 0;
}

boolean esPrimo(int n){
    boolean b;
    int k;
    if (n == 2)
        b = TRUE;
    else if (n == 3)
        b = TRUE;
    else if (n > 3){
        if (n % 2 == 0)
            b = FALSE;
        else if (n % 2 != 0){
            k = 3;
            while ((n > k*k) && (n % k != 0))
                k = k + 2;
            b = (n % k != 0);
        }
    }
    return b;
}
