/*
 *  Programa: capicuas
 *  Histrico:
 *    Creado por Ibai Larralde Baldanta el 18/02/2022.
 *      versin 1.0.0
 *  Copyright Ibai Larralde Baldanta. All rights reserved.
 */

#include <stdio.h>
#include <stdbool.h>
#include <math.h>
#define N 1008002


/*
 * FUNCION: esCapicua
 * ENTRADA: n un número entero
 * REQUISITOS: n >=0
 * SALIDA: el booleano b será verdadero si n era capicua
 */
int esCapicua(int n);



/*
 * FUNCION: reverso
 * ENTRADA: el entero n = n1n2....nl
 * REQUISITOS: n >=0
 * SALIDA: m contiene los dígitos de n invertidos (m= nl....n2n1)
 */
int reverso(int n);



/*
 * PROGRAMA PRINCIPAL
 * ENTRADA: Ninguna
 * REQUISITOS: Ninguno
 * SALIDA: Un fichero con todos los numeros capicúas menores que 1.008.002
 */
int main(void) {
    char quiereSalir;
    char nombre[50];
    int i;
    FILE *capicuas;
	printf("\tPrograma capicuas1\n");
	printf("\tCreado por Ibai Larralde Baldanta\n");
	printf("\tversion 1.0 (18/02/2022)\n\n");
	printf("Introduce en un fichero todos los numeros capicúas menores que 1.008.002  \n");
    
    do {
        printf("Introduzca el nombre del fichero a tratar: ");
        scanf("%s", nombre);
        printf("\n");
        while ((capicuas=fopen(nombre,"wb"))==NULL) {
            printf("Nombre incorrecto. Introduzca oto nombre\n");
            scanf("%s", nombre);
        }

        for(i=0;i<N;i++){
            if (esCapicua(i))
                fwrite(&i, sizeof(int), 1, capicuas);
        }
        fclose(capicuas);
        printf("Si desea salir pulse s, para repetir la ejecucion cualquier otra cosa: ");
		scanf("\n%c", &quiereSalir);
	} while (quiereSalir != 's');
	return 0;
}

int esCapicua(int n){
    bool b;
    b=(n==reverso(n));
    return b;
}

int reverso(int n){
    int m;
    m =0;
    while (n > 0){
        m = (10 * m) + (n % 10);
        n = n/10;
    }
    return m;
}




