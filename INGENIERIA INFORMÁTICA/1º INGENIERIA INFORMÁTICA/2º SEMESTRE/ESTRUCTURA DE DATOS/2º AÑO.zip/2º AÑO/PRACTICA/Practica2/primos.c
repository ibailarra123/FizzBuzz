/*
 *  Programa: primos
 *  Histrico:
 *    Creado por Ibai Larralde Baldanta el 18/02/2022.
 *      versin 1.0.0
 *  Copyright Ibai Larralde Baldanta. All rights reserved.
 */

#include <stdio.h>
#include <stdbool.h>
#include <math.h>
#define N 1008002


/*
 * FUNCION: esPrimo
 * ENTRADA: n un número entero
 * REQUISITOS: n >=0
//  * SALIDA: el booleano b será verdadero si n es primo
 */
int esPrimo(int n);


/*
 * PROGRAMA PRINCIPAL
 * ENTRADA: Ninguna
 * REQUISITOS: Ninguno
 * SALIDA: Un fichero con todos los numeros primos menores que 1.008.002
 */
int main(void) {
    char quiereSalir;
    char nombre[50];
    int i;
    FILE *primos;
	printf("\tPrograma primos\n");
	printf("\tCreado por Ibai Larralde Baldanta\n");
	printf("\tversion 1.0 (18/02/2022)\n\n");
	printf("Introduce en un fichero todos los numeros primos menores que 1.008.002  \n");
    
    do {
        printf("Introduzca el nombre del fichero a tratar: ");
        scanf("%s", nombre);
        printf("\n");
        while ((primos=fopen(nombre,"wb"))==NULL) {
            printf("Nombre incorrecto. Introduzca oto nombre\n");
            scanf("%s", nombre);
        }

        for(i=0;i<N;i++){
            if (esPrimo(i))
                fwrite(&i, sizeof(int), 1, primos);
        }
        fclose(primos);
        printf("Si desea salir pulse s, para repetir la ejecucion cualquier otra cosa: ");
		scanf("\n%c", &quiereSalir);
	} while (quiereSalir != 's');
	return 0;
}


int esPrimo(int n){
    int k;
    bool b;
    if (n == 2)
        b = true;
    else if (n==3)
        b = true;
    else if (n>3){
        if(n % 2 == 0)
            b = false;
        else{
            k = 3;
            while((n > (k*k)) && (n % k != 0)){
                k = k+2;
            }
            b = (n % k !=0);
        }
    }
    return b;
}

