/*
 *  Programa: primo4n+1
 *  Histrico:
 *    Creado por Ibai Larralde Baldanta el 18/02/2022.
 *      versin 1.0.0
 *  Copyright Ibai Larralde Baldanta. All rights reserved.
 */

#include <stdio.h>
#include <stdbool.h>
#include <math.h>



/*
 * PROGRAMA PRINCIPAL
 * ENTRADA: Un fichero con todos los numeros primos menores que 1.008.002
 * REQUISITOS: Ninguno
 * SALIDA: Un fichero con todos los numeros primos de la forma 4n+1 menores que 1.008.002
 */
int main(void) {
    char quiereSalir;
    char nombre[50];
    int i;
    FILE *primos;
    FILE *primos4n;
	printf("\tPrograma primos\n");
	printf("\tCreado por Ibai Larralde Baldanta\n");
	printf("\tversion 1.0 (18/02/2022)\n\n");
	printf("Este programa introduce en un fichero todos los numeros primos de la forma 4n+1 menores que 1.008.002  \n");
    
    do {
        printf("Introduzca el nombre del fichero a tratar: ");
        scanf("%s", nombre);
        printf("\n");

        while ((primos4n=fopen(nombre,"wb"))==NULL) {
            printf("Nombre incorrecto. Introduzca oto nombre\n");
            scanf("%s", nombre);
        }

        primos = fopen("primos.int","rb");

        while(fread(&i, sizeof(int), 1, primos) == 1) {
            if((i-1)%4 == 0)
                fwrite(&i, sizeof(int), 1, primos4n);
        }

        fclose(primos);
        fclose(primos4n);

        printf("Si desea salir pulse s, para repetir la ejecucion cualquier otra cosa: ");
		scanf("\n%c", &quiereSalir);
	} while (quiereSalir != 's');
	return 0;
}

