/*
 *  Programa: cuenta
 *  Histrico:
 *    Creado por Ibai Larralde Baldanta el 4/03/2022.
 *      versin 1.0.0
 *  Copyright Ibai Larralde Baldanta. All rights reserved.
 */

#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>

typedef struct palabra{
    int longitud;
    char letras[20];
}palabra1;


/*
 * FUNCION: sonPalabrasIguales
 * ENTRADA: Dos palabras
 * REQUISITOS: Ninguno
 * SALIDA: Un booleano b indicando si las palabras son iguales
 */
int sonPalabrasIguales(palabra1 p1, palabra1 p2);


/*
 * ACCION: leerPalabra
 * ENTRADA: Fichero f de caracteres
 * REQUISITOS: Ninguno
 * SALIDA: Una palabra
 */
void leerPalabra(FILE *f,palabra1 *p);


/*
 * ACCION: saltarBlancos
 * ENTRADA: Fichero f de caracteres
 * REQUISITOS: Ninguno
 * SALIDA: Fichero f sin los blancos inciales
 */
void saltarBlancos(FILE *f,char *c);


/*
 * ACCION: copiarLetras
 * ENTRADA: Fichero f de caracteres
 * REQUISITOS: Ninguno
 * SALIDA: Una palabra con sus letras
 */
void copiarLetras(FILE *f, palabra1 *p,char c);


/*
 * PROGRAMA PRINCIPAL
 * ENTRADA: Un fichero de caracteres
 * REQUISITOS: Ninguno
 * SALIDA: contador una variable que cuenta el número de veces que la primera palabra aparece a lo largo del fichero
 */


int main(void) {
    FILE *f;
    char quiereSalir,fichero[50];
    palabra1 p,p2;
    int contador;
	printf("\tPrograma Cuenta\n");
	printf("\tCreado por Ibai Larralde Baldanta\n");
	printf("\tversion 1.0 04/03/2021)\n\n");
    printf("Programa que cuenta el número de veces que la primera palabra aparece a lo largo del fichero\n");
    do {
        printf("Por favor, introduzca el nombre del fichero de palabras que desea introducir: ");
        scanf("%s",fichero);
        while ((f=fopen(fichero,"r"))==NULL){
            printf("Nombre incorrecto, ¿Qúe fichero quiere abrir?\n");
            scanf("%s",fichero);
        }
        leerPalabra(f,&p);
        contador=1;
        while (!feof(f)){
            leerPalabra(f,&p2);
            if(sonPalabrasIguales(p,p2)){
                contador++;
            }
        }
        printf("El número de veces que aparece la primera palabra a lo largo del texto es: %d\n",contador);
        fclose(f);
        printf("Si desea salir pulse s, para repetir la ejecucion cualquier otra cosa: ");
		scanf("\n%c", &quiereSalir);
	} while (quiereSalir != 's');
	return 0;
}

int sonPalabrasIguales(palabra1 p1, palabra1 p2){
    int i;
    bool b;
    if (p1.longitud == p2.longitud){
        i = 1;
        while((i < p1.longitud) && (p1.letras[i] == p2.letras[i]))
            i++;
        b = (p1.letras[i] == p2.letras[i]);
    }
    else
        b = false;
    return b;
}

void leerPalabra(FILE *f,palabra1 *p){
    char c;
    saltarBlancos(f,&c);
    copiarLetras(f,p,c);
}

void saltarBlancos(FILE *f,char *c){
    *c=fgetc(f);
    while(!feof(f) && (*c ==' ')){
        *c=fgetc(f);
    }
}

void copiarLetras(FILE *f, palabra1 *p,char c){
    p->longitud=0;
    while((!feof(f)) && (c != ' ')){
        p->longitud++;
        p->letras[p->longitud]= c;
        c=fgetc(f);
    }
    if (c != ' '){
        p->longitud++;
        p->letras[p->longitud]=c;
    }
}
