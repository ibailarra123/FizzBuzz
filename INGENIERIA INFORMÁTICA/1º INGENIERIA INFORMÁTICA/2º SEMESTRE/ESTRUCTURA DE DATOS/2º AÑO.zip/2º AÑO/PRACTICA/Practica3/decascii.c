/*
 *  Programa: decascii
 *  Histrico:
 *    Creado por Ibai Larralde Baldanta el 9/03/2022.
 *      versin 1.0.0
 *  Copyright Ibai Larralde Baldanta. All rights reserved.
 */

#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>



/*
 * ACCION: ascii
 * ENTRADA: Fichero f con unos y ceros
 * REQUISITOS: ninguno
 * SALIDA: n un número entero representado en ascii por uno binario de 8 bits
 */
void ascii(FILE *f,int *n,char *c);



/*
 * PROGRAMA PRINCIPAL
 * ENTRADA: Un fichero de caracteres que solo contiene ceros y unos
 * REQUISITOS: El número de unos y ceros tiene que ser un número múltiplo de 8
 * SALIDA: Secuencia de elementos del código ASCII formada por los caracteres que corresponden a los códigos númericos obtenidos del fichero
 */


int main(void) {
    FILE *f;
    char quiereSalir,fichero[50];
    int n;
    char letra,c;
	printf("\tPrograma Decascii\n");
	printf("\tCreado por Ibai Larralde Baldanta\n");
	printf("\tversion 1.0 09/03/2021)\n\n");
    printf("Programa que construye Secuencia de elementos del código ASCII formada por los caracteres que corresponden a los códigos númericos obtenidos del fichero.\n");
    do {
        printf("Por favor, introduzca el nombre del fichero de palabras que desea introducir: ");
        scanf("%s",fichero);
        while ((f=fopen(fichero,"r"))==NULL){
            printf("Nombre incorrecto, ¿Qúe fichero quiere abrir?\n");
            scanf("%s",fichero);
        }

        printf("La secuencia de elementos del fichero es: \n");
        while(!feof(f)){
            ascii(f,&n,&c);
            letra = n;
		    printf("%c", letra);
        }

        printf("\n");
        fclose(f);
        printf("Si desea salir pulse s, para repetir la ejecucion cualquier otra cosa: ");
		scanf("\n%c", &quiereSalir);
	} while (quiereSalir != 's');
	return 0;
}

void ascii(FILE *f, int *n,char *c){
    int i;
    *n=0;
    for(i=0; i<=7; i++){
        *c = fgetc(f);
        if(*c == '0')
            *n= (*n *2) +0;
        else
            *n= (*n *2) +1;
    }
}


