/*
 *  Programa: capicuas1
 *  Histrico:
 *    Creado por Ibai Larralde Baldanta el 04/02/2022.
 *      versin 1.0.0
 *  Copyright Ibai Larralde Baldanta. All rights reserved.
 */

#include <stdio.h>
#include <stdbool.h>
#include <math.h>
#define N 100000


/*
 * FUNCION: esCapicua
 * ENTRADA: n un número entero
 * REQUISITOS: n >=0
 * SALIDA: el booleano b será verdadero si n era capicua
 */
int esCapicua(int n);



/*
 * FUNCION: reverso
 * ENTRADA: el entero n = n1n2....nl
 * REQUISITOS: n >=0
 * SALIDA: m contiene los dígitos de n invertidos (m= nl....n2n1)
 */
int reverso(int n);



/*
 * PROGRAMA PRINCIPAL
 * ENTRADA: Por teclado, un número entero num 
 * REQUISITOS: num < 100000
 * SALIDA: Este programa saca por pantalla si el número introducido es un
 * numero capicúa o no.
 */
int main(void) {
    char quiereSalir;
    int num;
    bool b;
    
	printf("\tPrograma capicuas1\n");
	printf("\tCreado por Ibai Larralde Baldanta\n");
	printf("\tversion 1.0 (04/02/2022)\n\n");
	printf("Este programa saca por pantalla si el número introducido  \n");
    printf("es un número capicua o no.\n\n");
    do {
        printf("Introduce un número mayor que 0 y menor que 100.000: ");
        scanf( " %d", &num);
        printf("\n");
        while (num>N){
            printf("El número introducido es mayor que 100.000\n");
            printf("Introduce un número menor que 100.000: ");
            scanf( " %d", &num);
            printf("\n");
        }
        b = esCapicua(num);
        if (b)
            printf("El numero intorducido %d es un número capicua\n",num);
        else
            printf("El numero intorducido %d no es un número capicua\n",num);

        printf("Si desea salir pulse s, para repetir la ejecucion cualquier otra cosa: ");
		scanf("\n%c", &quiereSalir);
	} while (quiereSalir != 's');
	return 0;
}

int esCapicua(int n){
    bool b;
    b=(n==reverso(n));
    return b;
}

int reverso(int n){
    int m;
    m =0;
    while (n > 0){
        m = (10 * m) + (n % 10);
        n = n/10;
    }
    return m;
}