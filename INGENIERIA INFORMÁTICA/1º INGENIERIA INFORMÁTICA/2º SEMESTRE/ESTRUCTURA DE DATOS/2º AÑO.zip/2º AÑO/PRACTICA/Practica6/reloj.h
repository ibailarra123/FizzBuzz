#ifndef ILB_COLA_DE_TELEMS_H
#define ILB_COLA_DE_TELEMS_H
#include <stdbool.h> 

typedef struct reloj{
    int segundos;
}Reloj;

// Salida: Pone a cero la cuenta del reloj r
void aCero(Reloj *);

// Incrementa en uno la cuenta del reloj r
void tic(Reloj *);

///Devuelve el valor en segundos de la cuenta del reloj r
int instante(Reloj);

#endif