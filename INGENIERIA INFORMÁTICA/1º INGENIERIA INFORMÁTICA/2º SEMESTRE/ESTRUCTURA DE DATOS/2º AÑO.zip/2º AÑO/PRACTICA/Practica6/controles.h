#ifndef ILB_CONTROLES_H
#define ILB_CONTROLES_H

#include "reloj.h"
#include "peajes.h"

typedef struct frecuencia{
    int tLlegada;
    int tMedio;
}Frecuencia;

typedef struct control{
    Peaje peaje;
    Frecuencia trafico;
}Control;

void iniciarControl(Control *);
void llegaCoche(Control *, Reloj);
void marchaCoche(Control *, Reloj);

#endif //ILB_CONTROLES_H