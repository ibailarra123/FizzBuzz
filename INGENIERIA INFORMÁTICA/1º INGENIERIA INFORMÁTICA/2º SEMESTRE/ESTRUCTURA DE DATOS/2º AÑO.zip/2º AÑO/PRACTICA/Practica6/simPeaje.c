#define TSIM 10800
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include "reloj.h"
#include "controles.h"
#include "mostrarResultados.h"

void siguienteIteracion(Control *c, Reloj r){
    llegaCoche(c,r);
    marchaCoche(c,r);
}

void iniciarSimulacion(Control *c){
    iniciarRuleta();
    iniciarControl(c);
}

int main(void){
    char quiereSalir;
    do{
        Control c;
        Reloj r;
        aCero(&r);
        iniciarSimulacion(&c);
        while (instante(r) != TSIM){
            tic(&r);
            siguienteIteracion(&c,r);
        }
        mostrarResultados(c);

        printf("Si desea salir pulse s, para repetir la ejecucion cualquier otra cosa: ");
		scanf("\n%c", &quiereSalir);

    } while (quiereSalir != 's');
    return 0;
}
