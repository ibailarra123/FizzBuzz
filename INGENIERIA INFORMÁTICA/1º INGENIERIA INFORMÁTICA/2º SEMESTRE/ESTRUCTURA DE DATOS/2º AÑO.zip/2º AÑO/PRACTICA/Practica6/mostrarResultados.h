#ifndef ILB_MOSTRAR_RESULTADOS_H
#define ILB_MOSTRAR_RESULTADOS_H

#include "colaDeEnteros.h"
#include "reloj.h"
#include "controles.h"
#include "ruleta.h"
#include "cabinas.h"
#include "peajes.h"

void mostrarResultados(Control );

#endif //ILB_MOSTRAR_RESULTADOS_H