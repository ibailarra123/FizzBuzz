#include <stdio.h>
#include <stdlib.h>
#include "controles.h"

void iniciarControl(Control *c){
    printf("Introduzca el tiempo medio entre llegadas: ");
    scanf("%d",&c->trafico.tMedio);
    c->trafico.tLlegada = distribucionExponencial(c->trafico.tMedio);
    iniciarPeaje(c->peaje);
}

void llegaCoche(Control *c, Reloj r){
    int n;
    if (instante(r) == c->trafico.tLlegada){
        n = eligeCabina(c->peaje);
        guardaCola(c->peaje,n,r);
        c->trafico.tLlegada = instante(r) + distribucionExponencial(c->trafico.tMedio);
    }
}

void marchaCoche(Control *c, Reloj r){
    rondaCabinas(c->peaje,r);
}
