#ifndef ILB_CABINAS_H
#define ILB_CABINAS_H
#include <stdbool.h> 
#include "colaDeEnteros.h"
#include "reloj.h"
#include "ruleta.h"


typedef struct cabina{
    int nCoches;
    int maxCoches;
    int servidos;
    int totalEsperado;
    int proxServ;
    int minServ;
    int maxServ;
    ColaDeEnteros colaCoches;
}Cabina;

// Inicia la cabina sin coches esperando
void iniciarCab(Cabina *, int ,int );

// Pone en el instante r un coche en espera en la cabina
void encolarCoche(Cabina *, Reloj);

// Da el numero de coches esperando en la cabina
int cuantosCoches(Cabina );

// Simula el servicio de un coche en la cola de la cabina en el instante r
void servCabina(Cabina *,Reloj);

#endif