#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include "reloj.h"


// Salida: Pone a cero la cuenta del reloj r
void aCero(Reloj *r){
    r->segundos = 0;
}

// Incrementa en uno la cuenta del reloj r
void tic(Reloj *r){
    r->segundos += 1;
}

///Devuelve el valor en segundos de la cuenta del reloj r
int instante(Reloj r){
    return (r.segundos);
}