#include "peajes.h"
#include <stdio.h>
#include <stdlib.h>


typedef struct pareja{
	int can;
	int cab;
}Pareja;

typedef Pareja taux[NCAB];

typedef struct intervalo{
	int min;
	int max;
}Intervalo;


int tipoCobro[NCAB][2] = {{15,30},{15,30},{15,45},{15,45},{30,60}};

void intercambiar(Pareja *x, Pareja *y){
	Pareja aux;
	aux = *x;
	*x = *y;
	*y = aux;
}

void ordenar(taux t){
	for (int i = 0; i < NCAB - 1 ; i++)
	{	
		for (int j = i+1; j < NCAB ; j++)
		{
			if (t[i].can > t[j].can)
				intercambiar(&t[i],&t[j]);
		}
	}
}

void guardaCola(Peaje p, int nCab, Reloj r){
	encolarCoche(&p[nCab],r);
}

void iniciarPeaje(Peaje p)
{
	int i;
	for (i = 0; i < NCAB ; i++)
	{
		iniciarCab(&p[i], tipoCobro[i][0], tipoCobro[i][1]);
	}
}
int eligeCabina(Peaje p)
{
	int x,i,n;
	taux t;
	for (i = 0; i < NCAB ; i++)
	{
		t[i].can = cuantosCoches(p[i]);
		t[i].cab = i;
	}
	ordenar(t);
	x = eleccionCon3Probabilidades(PROB_MAX,PROB_MEDIA,PROB_MIN);
	n = t[x].cab;
	return(n);

}
void rondaCabinas(Peaje p, Reloj r)
{
	int i;
	for (i = 0; i < NCAB ; i++)
	{
		servCabina(&p[i],r);
	}
}
