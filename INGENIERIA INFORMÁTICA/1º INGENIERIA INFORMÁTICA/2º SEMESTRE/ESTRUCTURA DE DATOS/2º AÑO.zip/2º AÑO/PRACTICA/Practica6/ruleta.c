#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include "ruleta.h"

typedef float tabla[4];

void iniciarRuleta(){
    srand(time(NULL));
}

int distribucionExponencial(int media){
    float x;
    double t,y;
    x = (double)rand()/RAND_MAX; // numero aleatorio en [0, 1)
    y = modf((-log(1-x) * media),&t);

    while (t == 0){
        x = (double)rand()/RAND_MAX;
        y = modf((-log(1-x) * media),&t); 
    }
    return t;
}

int distribucionLineal(int min, int max){
    float x;
    double t,y;
    x = (double)rand()/RAND_MAX;
    y = modf(((max - min) * x) + min,&t);
    return t;
}

int eleccionCon3Probabilidades (float maxp, float medp, float minp){
    float x;
    int n;
    tabla elec;

    elec[0]=maxp;
    elec[1] =medp+maxp;
    elec[2] = 1;
    x = (double)rand()/RAND_MAX;

    n= 0;
    while ((elec[n] < x) && (n < 3)){
        n= n+1;
    }
    return n;
}
