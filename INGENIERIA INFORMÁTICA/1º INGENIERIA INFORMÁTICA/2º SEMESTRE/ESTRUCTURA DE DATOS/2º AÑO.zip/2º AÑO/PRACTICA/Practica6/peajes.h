#ifndef ILB_PEAJES_H
#define ILB_PEAJES_H

#include "reloj.h"
#include "cabinas.h"

#define NCAB 5
#define PROB_MAX 0.6
#define PROB_MEDIA 0.3
#define PROB_MIN 0.1

typedef Cabina Peaje[NCAB];


void iniciarPeaje(Peaje );
void guardaCola(Peaje , int , Reloj );
int eligeCabina(Peaje );
void rondaCabinas(Peaje , Reloj );


#endif //ILB_PEAJES_H
