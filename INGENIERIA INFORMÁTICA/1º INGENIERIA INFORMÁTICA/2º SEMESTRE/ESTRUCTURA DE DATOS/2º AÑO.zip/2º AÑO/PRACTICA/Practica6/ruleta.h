#ifndef ILB_RULETA_H
#define ILB_RULETA_H
#include <stdbool.h> 

// Inicia la generacion de numeros aleatorios
void iniciarRuleta();

//implementa una distribucion exponencial de media tmedio
int distribucionExponencial(int );

// implementa una distribucion lineal entre min y max
int distribucionLineal(int ,int );

// elige entre tres opciones con prob. dadas
int eleccionCon3Probabilidades(float ,float ,float );

#endif