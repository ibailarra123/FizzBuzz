#ifndef ILB_COLA_DE_ENTEROS_H
#define ILB_COLA_DE_ENTEROS_H
#include <stdbool.h> 


typedef struct nodoDeColaDeEnteros {
    int e;
    struct nodoDeColaDeEnteros *s;
} NodoDeColaDeEnteros;

typedef struct colaDeEnteros{
    NodoDeColaDeEnteros *i;
    NodoDeColaDeEnteros *f;
} ColaDeEnteros;

void nuevaColaDeEnteros(ColaDeEnteros *);
void pideTurnoColaDeEnteros(ColaDeEnteros *, int);
void avanceColaDeEnteros(ColaDeEnteros *);
void primeroColaDeEnteros(ColaDeEnteros, int *);
bool esNulaColaDeEnteros(ColaDeEnteros);
#endif