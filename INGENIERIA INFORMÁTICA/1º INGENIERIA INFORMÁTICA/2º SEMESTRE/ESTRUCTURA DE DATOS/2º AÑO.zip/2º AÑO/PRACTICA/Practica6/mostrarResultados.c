#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include "mostrarResultados.h"

void mostrarResultados(Control c){
    int i, nCoches;
    float nEspera;
    nCoches = 0;
    nEspera = 0;
    for (i = 0; i < NCAB; i++){
        if(c.peaje[i].servidos == 0){
            printf("El tiempo medio de espera de la cabina %d es de 0 segundos\n",i+1);
            printf("El máximo de choches que han estado en la cabina %d han sido %d coches\n" ,i+1, c.peaje[i].maxCoches);
        }
        else{
            printf("El tiempo medio de espera de la cabina %d es de %f segundos\n",i+1,((float)c.peaje[i].totalEsperado/c.peaje[i].servidos));
            printf("El máximo de choches que han estado en la cabina %d han sido %d coches\n" ,i+1, c.peaje[i].maxCoches);
            nEspera = nEspera+c.peaje[i].totalEsperado;
        }
        nCoches = nCoches+c.peaje[i].servidos;
        printf("\n");
    }
    printf("%d coches han sido servidos con una espera media de %f segundos\n",nCoches,nEspera/nCoches);

}
