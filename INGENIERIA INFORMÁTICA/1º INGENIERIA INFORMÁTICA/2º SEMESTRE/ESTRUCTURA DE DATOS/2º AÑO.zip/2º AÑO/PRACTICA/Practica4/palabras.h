/**
 *	MODULO: Palabras
 *	FICHERO: Palabras.h
 *	VERSION: 1.0.0
 *	HISTORICO:
 *		Creado por Ibai Larralde Baldanta el 18/03/22.
 * DESCRIPCION: Este modulo proporciona el comportamiento teórico de palabras partir del interface para ficheros de texto
 * que proporciona C. Gracias a él se pueden implementar los algoritmos
 * habituales sobre palabras.
 *
 *  Este fichero se crea sólo con intenciones de coordinación
 *  docente. El autor desautoriza expresamente su difusión, copia
 *  o exhibición pública.
 */
// Headers necesarios para la compilación
#ifndef ILB_PALABRAS_H
#define ILB_PALABRAS_H

#include <stdio.h> 
#include <stdbool.h> 
#define MAX 20

typedef struct tupla{
    int longitud;
    char letras[MAX];
}palabra;


/**
 * ACCION: agregarCaracter
 * ENTRADA: p una palabra y c un caracter
 * REQUISITOS: 
 * MODIFICA: p, incorpora c como último caracter de p
 */
void agregarCaracter(char c,palabra *p);


/**
 * ACCION: modificarCaracter
 * ENTRADA: p una palabra, el entero i y c un caracter
 * REQUISITOS: i es menor o igual que la longitud de p
 * SALIDA: Devuelve el caracter i-ésimmo de p
 */
void modificarCaracter(palabra *p,int i,char c);


/**
 * FUNCION: consultarCaracter
 * ENTRADA: p una palabra y el entero i
 * REQUISITOS: i es menor o igual que la longitud de p
 * SALIDA: Devuelve el caracter i-ésimo de p
 */
int consultarCaracter(palabra p,int i);


/**
 * FUNCION: longitudPalabra
 * ENTRADA: p , una palabra
 * REQUISITOS:
 * SALIDA: long la longitud de p
 */
int longitudPalabra(palabra p);


/**
 * FUNCION: esPalabraVacia
 * ENTRADA: p una palabra
 * REQUISITOS:
 * SALIDA: el booleano b es verdadero si y solo si p no tiene letras
 */
int esPalabraVacia(palabra p);


/**
 * FUNCION: sonPalabrasIguales
 * ENTRADA: Dos palabras
 * REQUISITOS: Ninguno
 * SALIDA: Un booleano b indicando si las palabras son iguales
 */
int sonPalabrasIguales(palabra p1, palabra p2);


/**
 * ACCION: leerPalabra
 * ENTRADA: Fichero f de caracteres
 * REQUISITOS: Ninguno
 * SALIDA: Una palabra
 */
void leerPalabra(FILE *f,palabra *p);

/**
 * ACCION: saltarBlancos
 * ENTRADA: Fichero f de caracteres
 * REQUISITOS: Ninguno
 * SALIDA: Fichero f sin los blancos inciales
 */
void saltarBlancos(FILE *f,char *c);


/**
 * ACCION: copiarLetras
 * ENTRADA: Fichero f de caracteres
 * REQUISITOS: Ninguno
 * SALIDA: Una palabra con sus letras
 */
void copiarLetras(FILE *f, palabra *p,char c);

#endif // ILB_PALABRAS_H
