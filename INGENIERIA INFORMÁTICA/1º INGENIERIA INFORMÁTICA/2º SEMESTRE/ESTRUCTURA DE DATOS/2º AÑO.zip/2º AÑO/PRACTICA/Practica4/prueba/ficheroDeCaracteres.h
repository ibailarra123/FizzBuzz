/**
 *	MODULO: FicheroDeCaracteres
 *	FICHERO: FicheroDeCaracteres.h
 *	VERSION: 1.0.0
 *	HISTORICO:
 *		Creado por Federico Fariña Figueredo el 20/02/19.
 * DESCRIPCION: Este modulo proporciona el comportamiento teórico del
 * fichero de caracteres a partir del interface para ficheros de texto
 * que proporciona C. Gracias a él se pueden implementar los algoritmos
 * habituales sobre ficheros de caracteres. Ademas proporciona funciones
 * para leer desde stdin y escribir en stdout un fichero de caracteres.
 *
 *  Este fichero se crea sólo con intenciones de coordinación
 *  docente. El autor desautoriza expresamente su difusión, copia
 *  o exhibición pública.
 */
// Headers necesarios para la compilación
#ifndef FFF_FICHERO_DE_CARACTERES_H
#define FFF_FICHERO_DE_CARACTERES_H
#include <stdio.h> //necesario porque exporta el tipo FILE
#include <stdbool.h> //necesario porque exporta el tipo bool
// Definición de tipos
/**
 * La idea del tipo es mantener una lectura adelantada para haceer casar el modo
 *	de trabajo de ficheros en C con el algoritmico
 */
typedef struct FicheroDeCaracteres {
	FILE * fichero;
	char cabezaLectura;
	char nombre[100];
} FicheroDeCaracteres;
//Prototipos de las funciones
/**
 * FUNCION: asociarConArchivoFichCar
 *	ENTRADA: n, una cadena de caracteres que se interpreta como una
 * 	en el sistema de archivos y f, un FicheroDeCaracteres
 * REQUISITOS: el tama\~no del nombre no puede exceder de 99
 *		caracteres
 * MODIFICA: f pasa a estar asociado con el archivo de ruta n
 */
void asociarConArchivoFichCar(FicheroDeCaracteres *, char []);
/**
 *	FUNCION: abrirLecFichCar
 *	ENTRADA: f, un FicheroDeCaracteres *
 * REQUISITOS: f acaba en EOF y no esta abierto
 * MODIFICA: f pasa a apuntar a un fichero dispuesto para la primera
 *		lectura. Si el fichero no tiene nombre, se le pide al usuario. Si
 * 	el fichero tiene nombre pero no puede abrirse, se le pide al usuario
 * 	un nuevo nombre
 */
void abrirLecFichCar(FicheroDeCaracteres *);
/**
 * FUNCION: leerFichCar
 *	ENTRADA: f, un FicheroDeCaracteres *
 * REQUISITOS: f está abierto en lectura y quedan cosas por leer, es decir,
 * 	la cabeza de lectura no es EOF.
 * SALIDA: la variable x pasa a contener lo que era la cabeza de lectura
 * MODIFICA: se modifica la cabeza de lectura pues se avanza en la lectura
 *		del fichero.
 */
void leerFichCar(FicheroDeCaracteres * f, char * x);
/**
 * FUNCION: fdfFichCar
 *	ENTRADA: f, un FicheroDeCaracteres *
 * REQUISITOS: f está abierto en lectura.
 * SALIDA: devuelve verdadero si y solo si la cabeza de lectura es EOF
 */
bool fdfFichCar(FicheroDeCaracteres f);
/**
 * FUNCION: cerrarFichCar
 *	ENTRADA: f, un FicheroDeCaracteres *
 * REQUISITOS: f está abierto en lectura o en escritura.
 * MODIFICA: cierra el fichero (poniendo EOF al final si esta
 *		abierto en escritura
 */
void cerrarFichCar(FicheroDeCaracteres * f);
/**
 *	FUNCION: abrirEscFichCar
 *	ENTRADA: f, un FicheroDeCaracteres *
 * REQUISITOS:
 * MODIFICA: f pasa a apuntar a un fichero dispuesto para empezar a escribir
 *		lectura. Si el fichero no tiene nombre, se le pide al usuario. Si
 * 	el fichero tiene nombre pero no puede abrirse, se le pide al usuario
 * 	un nuevo nombre
 */
void abrirEscFichCar(FicheroDeCaracteres *);
/**
 * FUNCION: escribirFichCar
 *	ENTRADA: f, un FicheroDeCaracteres * y x, un caracter
 * REQUISITOS: f está abierto en escritura.
 * MODIFICA: el valor de x se ha escrito al final del fichero.
 */
void escribirFichCar(FicheroDeCaracteres * f, char x);
/**
 * FUNCION: stdin2FichCar
 *	ENTRADA: f, un FicheroDeCaracteres * y fin, un caracter
 * REQUISITOS: f está abierto en escritura.
 * MODIFICA: Lee caracteres de la entrada hasta encontrar la marca indicada por
 *		fin y los vuelca en un fichero de caracteres.
 */
void stdin2FichCar(FicheroDeCaracteres *, char);
/**
 * FUNCION: FichCar2stdout
 *	ENTRADA: f, un FicheroDeCaracteres *
 * REQUISITOS: f está abierto en lectura.
 * MODIFICA: Escribe en la salida estandard el contenido del fichero.
 */
void fichCar2stdout(FicheroDeCaracteres *);
#endif // FFF_FICHERO_DE_CARACTERES_H
