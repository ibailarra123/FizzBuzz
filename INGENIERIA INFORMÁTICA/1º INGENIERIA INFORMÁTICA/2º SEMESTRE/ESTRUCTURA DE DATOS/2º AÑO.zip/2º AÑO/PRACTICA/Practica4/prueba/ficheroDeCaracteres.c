/**
 *	MODULO: FicheroDeCaracteres
 *	FICHERO: FicheroDeCaracteres.c
 *	VERSION: 1.0.0
 *	HISTORICO:
 *		Creado por Federico Fariña Figueredo el 20/02/19.
 * DESCRIPCION: Implementación de las funciones declaradas en
 * 	ficheroDeCaracteres.h
 *
 *  Este fichero se crea sólo con intenciones de coordinación
 *  docente y como ejemplo para los alumnos. El autor desautoriza expresamente
 *  su difusión, copia o exhibición pública.
 */
#include "ficheroDeCaracteres.h"
#include <string.h>
#include <stdlib.h>
//
// A continuación aparece el código de las funciones que exporta el módulo
// su especificación más completa aparece en el header ficheroDeCaracteres.h
//
/*
 * FUNCION: asociarConArchivoFichCar
 *	ENTRADA: n, una cadena de caracteres que se interpreta como una
 * 	en el sistema de archivos y f, un FicheroDeCaracteres
 * REQUISITOS: el tama\~no del nombre no puede exceder de 99
 *		caracteres
 * MODIFICA: f pasa a estar asociado con el archivo de ruta n
 */
void asociarConArchivoFichCar(FicheroDeCaracteres * f, char nombre[]) {
	if ((nombre == NULL) || (strlen(nombre) < 1) || strlen(nombre) > 99) {
		printf("\tERROR: El nombre del fichero que desea utilizar ");
		printf("no es válido\n\tSe procede a cancelar la ejecución\n");
		exit(-1);
	} else {
		strcpy(f->nombre, nombre);
	}
}
/*
*	FUNCION: abrirLecFichCar
*	ENTRADA: f, un FicheroDeCaracteres *
* REQUISITOS: f acaba en EOF y no esta abierto
* MODIFICA: f pasa a apuntar a un fichero dispuesto para la primera
*		lectura. Si el fichero no tiene nombre, se le pide al usuario. Si
* 	el fichero tiene nombre pero no puede abrirse, se le pide al usuario
* 	un nuevo nombre
*/
void abrirLecFichCar(FicheroDeCaracteres * f) {
	while ((f->fichero = fopen(f->nombre, "r"))==NULL) {
		printf("El fichero que indica no puede abrirse en lectura.\n\t");
		printf("Escriba un nuevo nombre: ");
		scanf("%s", (f->nombre));
	}
	f->cabezaLectura = getc(f->fichero);
}
/*
 * FUNCION: leerFichCar
 *	ENTRADA: f, un FicheroDeCaracteres *
 * REQUISITOS: f está abierto en lectura y quedan cosas por leer, es decir,
 * 	la cabeza de lectura no es EOF.
 * SALIDA: la variable x pasa a contener lo que era la cabeza de lectura
 * MODIFICA: se modifica la cabeza de lectura pues se avanza en la lectura
 *		del fichero.
 */
void leerFichCar(FicheroDeCaracteres * f, char * x) {
	if (f->cabezaLectura == EOF) {
		printf("\tERROR: Intento de lectura en un fichero totalmente leído\n");
		printf("\tSe procede a cancelar la ejecución\n");
		exit(-1);
	} else {
		*x = f->cabezaLectura;
		f->cabezaLectura = getc(f->fichero);
	}
}
/*
 * FUNCION: fdfFichCar
 *	ENTRADA: f, un FicheroDeCaracteres *
 * REQUISITOS: f está abierto en lectura.
 * SALIDA: devuelve verdadero si y solo si la cabeza de lectura es EOF
 */
bool fdfFichCar(FicheroDeCaracteres f){
	return (f.cabezaLectura == EOF);
}
/*
 * FUNCION: cerrarFichCar
 *	ENTRADA: f, un FicheroDeCaracteres *
 * REQUISITOS: f está abierto en lectura o en escritura.
 * MODIFICA: cierra el fichero (poniendo EOF al final si esta
 *		abierto en escritura
 */
void cerrarFichCar(FicheroDeCaracteres * f){
	fclose(f->fichero);
}
/*
 *	FUNCION: abrirEscFichCar
 *	ENTRADA: f, un FicheroDeCaracteres *
 * REQUISITOS:
 * MODIFICA: f pasa a apuntar a un fichero dispuesto para empezar a escribir
 *		lectura. Si el fichero no tiene nombre, se le pide al usuario. Si
 * 	el fichero tiene nombre pero no puede abrirse, se le pide al usuario
 * 	un nuevo nombre
 */
void abrirEscFichCar(FicheroDeCaracteres *f) {
	while ((f->fichero = fopen(f->nombre, "w"))==NULL) {
		printf("El fichero que indica no puede abrirse en escritura.\n\t");
		printf("Escriba un nuevo nombre:");
		scanf("%s", (f->nombre));
	}
}
/*
 * FUNCION: escribirFichCar
 *	ENTRADA: f, un FicheroDeCaracteres * y x, un caracter
 * REQUISITOS: f está abierto en escritura.
 * MODIFICA: el valor de x se ha escrito al final del fichero.
 */
void escribirFichCar(FicheroDeCaracteres * f, char x){
	putc(x, f->fichero);
}
/*
 * FUNCION: stdin2FichCar
 *	ENTRADA: f, un FicheroDeCaracteres * y fin, un caracter
 * REQUISITOS: f está abierto en escritura.
 * MODIFICA: Lee caracteres de la entrada hasta encontrar la marca indicada por
 *		fin y los vuelca en un fichero de caracteres.
 * NOTA1: Se utiliza el bucle con el comentario para eliminar caracteres
 * 	que pudiesen estar en stdin. Puede ser el salto de línea del último
 *		valor leido o incluso alguna frase porque se ha metido espacios a la
 * 	hora de dar la última entrada. fflush(stdin) no es C estandard. Solo
 *		es valida en algunos compiladores
 */
void stdin2FichCar(FicheroDeCaracteres * f, char fin) {
	int x;
	printf("Escriba los caracteres que desee escribir en el fichero.\n");
	printf("Para finalizar escribael caracter \"%c\"\n\tValores:", fin);
	while(getchar()!='\n'); //SEE: NOTA1
	while ((x = getchar())!=fin)
		escribirFichCar(f, x);
}
/**
 * FUNCION: FichCar2stdout
 *	ENTRADA: f, un FicheroDeCaracteres *
 * REQUISITOS: f está abierto en lectura.
 * MODIFICA: Escribe en la salida estandard el contenido del fichero.
 */
void fichCar2stdout(FicheroDeCaracteres * f) {
	char x;
	printf("El contenido del fichero es el que aparece a partir de la ");
	printf("siguiente línea:\n");
	while (!fdfFichCar(*f)){
		leerFichCar(f, &x);
		putchar(x);
	}
}
//
// A continuación aparece el código de las funciones que no se exportan
// junto con su especificación completa
//
