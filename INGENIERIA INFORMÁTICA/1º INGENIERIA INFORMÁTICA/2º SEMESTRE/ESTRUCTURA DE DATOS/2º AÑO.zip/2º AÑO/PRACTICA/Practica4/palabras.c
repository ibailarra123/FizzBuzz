/**
 *	MODULO: Palabras
 *	FICHERO: Palabras.c
 *	VERSION: 1.0.0
 *	HISTORICO:
 *		Creado por Ibai Larralde Baldanta el 18/03/22.
 * DESCRIPCION: Implementación de las funciones declaradas en
 * 	palabras.h
 */
#include "palabras.h"
#include <string.h>
#include <stdlib.h>



/**
 * ACCION: agregarCaracter
 * ENTRADA: p una palabra y c un caracter
 * REQUISITOS: 
 * MODIFICA: p, incorpora c como último caracter de p
 */
void agregarCaracter(char c,palabra *p){
	if (longitudPalabra(*p) < MAX){
		p->longitud = p->longitud +1;
		p->letras[p->longitud]= c;
    }
}


/**
 * ACCION: modificarCaracter
 * ENTRADA: p una palabra, el entero i y c un caracter
 * REQUISITOS: i es menor o igual que la longitud de p
 * SALIDA: Devuelve el caracter i-ésimmo de p
 */
void modificarCaracter(palabra *p,int i,char c){
    p->letras[i]=c;
}

/**
 * FUNCION: consultarCaracter
 * ENTRADA: p una palabra y el entero i
 * REQUISITOS: i es menor o igual que la longitud de p
 * SALIDA: Devuelve el caracter i-ésimo de p
 */
int consultarCaracter(palabra p,int i){
	char c;
	c = p.letras[i];
	return c;
}


/**
 * FUNCION: longitudPalabra
 * ENTRADA: p , una palabra
 * REQUISITOS:
 * SALIDA: long la longitud de p
 */
int longitudPalabra(palabra p){
    int longi;
    longi = p.longitud;
    return longi;
}


/**
 * FUNCION: esPalabraVacia
 * ENTRADA: p una palabra
 * REQUISITOS:
 * SALIDA: el booleano b es verdadero si y solo si p no tiene letras
 */
int esPalabraVacia(palabra p){
    bool b;
    b = (longitudPalabra(p) == 0);
    return b;
}


/**
 * FUNCION: sonPalabrasIguales
 * ENTRADA: Dos palabras
 * REQUISITOS: Ninguno
 * SALIDA: Un booleano b indicando si las palabras son iguales
 */
int sonPalabrasIguales(palabra p1, palabra p2){
    int i;
    bool b;
    if (longitudPalabra(p1) == longitudPalabra(p2)){
        i= 1;
        while((i<longitudPalabra(p1)) && (p1.letras[i] == p2.letras[i])){
            i= i + 1;
        }
        b = (p1.letras[i] == p2.letras[i]);
    }
    else
        b = false;
    return b;
}


/**
 * ACCION: leerPalabra
 * ENTRADA: Fichero f de caracteres
 * REQUISITOS: Ninguno
 * SALIDA: Una palabra
 */
void leerPalabra(FILE *f,palabra *p){
    char c;
    saltarBlancos(f,&c);
    copiarLetras(f,p,c);
}

/**
 * ACCION: saltarBlancos
 * ENTRADA: Fichero f de caracteres
 * REQUISITOS: Ninguno
 * SALIDA: Fichero f sin los blancos inciales
 */
void saltarBlancos(FILE *f,char *c){
    *c=fgetc(f);
    while(!feof(f) && (*c ==' ')){
        *c=fgetc(f);
    }
}


/**
 * ACCION: copiarLetras
 * ENTRADA: Fichero f de caracteres
 * REQUISITOS: Ninguno
 * SALIDA: Una palabra con sus letras
 */
void copiarLetras(FILE *f, palabra *p,char c){
    p -> longitud = 0;
    while(!feof(f) && (c !=' ')){
        p->longitud = p->longitud + 1;
        p->letras[p->longitud] = c;    
        c = getc(f);
    }
    if (c !=' '){
        p->longitud = p->longitud + 1;
        p->letras[p->longitud] = c;
    }
}
