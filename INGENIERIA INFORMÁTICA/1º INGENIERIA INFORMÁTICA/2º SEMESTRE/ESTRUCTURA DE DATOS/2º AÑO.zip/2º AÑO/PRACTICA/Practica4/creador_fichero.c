#include <stdio.h>
int main (void){
    FILE * f;
    char res, nombre[50];
    do{
        printf("Introduce el nombre del fichero en el que va a guardar el contenido\n");
        scanf(" %s", nombre);
        f = fopen(nombre, "w");
        fputs("hola peter hola peter hola peter hola peter hola peter hola ",f);
        fclose(f);
        printf("Si quiere salir del programa introduzca la letra s");
        scanf(" %c",&res);
    }while(res != 's');
    return 0;
}
