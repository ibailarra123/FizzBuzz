/*
 *  Programa: cuenta
 *  Histrico:
 *    Creado por Ibai Larralde Baldanta el 18/03/2022.
 *      versin 1.0.0
 *  Copyright Ibai Larralde Baldanta. All rights reserved.
 */

#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>

#include "palabras.h"


/*
 * PROGRAMA PRINCIPAL
 * ENTRADA: Un fichero de caracteres
 * REQUISITOS: Ninguno
 * SALIDA: contador una variable que cuenta el número de veces que la primera palabra aparece a lo largo del fichero
 */


int main(void) {
    FILE *f;
    char quiereSalir,fichero[50];
    palabra p,p2;
    int contador;
	printf("\tPrograma Cuenta\n");
	printf("\tCreado por Ibai Larralde Baldanta\n");
	printf("\tversion 1.0 04/03/2021)\n\n");
    printf("Programa que cuenta el número de veces que la primera palabra aparece a lo largo del fichero\n");
    do {
        printf("Por favor, introduzca el nombre del fichero de palabras que desea introducir: ");
        scanf("%s",fichero);
        while ((f=fopen(fichero,"r"))==NULL){
            printf("Nombre incorrecto, ¿Qúe fichero quiere abrir?\n");
            scanf("%s",fichero);
        }
        leerPalabra(f,&p);
        contador=1;
        while (!feof(f)){
            leerPalabra(f,&p2);
            if(sonPalabrasIguales(p,p2)){
                contador++;
            }
        }
        fclose(f);
        printf("El número de veces que aparece la primera palabra a lo largo del texto es: %d\n",contador);
        printf("Si desea salir pulse s, para repetir la ejecucion cualquier otra cosa: ");
		scanf("\n%c", &quiereSalir);
	} while (quiereSalir != 's');
	return 0;
}