/**
 *	MODULO: evaluador
 *	FICHERO: evaluador.h
 *	VERSION: 1.0.0
 *	HISTORICO:
 *		Creado por Ibai Larralde Baldanta el 01/04/22.
 * DESCRIPCION: Este módulo exporta la funcionalidad necesaria para implementar la evaluación de una expresion en notacion postfija.
 */

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include "evaluador.h"

void eval(PilaDeEnteros *p, Operador op){
    int v1,v2;
    cimaPilaDeEnteros(*p,&v1);
    desapilarPilaDeEnteros(&(*p));
    cimaPilaDeEnteros(*p,&v2);
    desapilarPilaDeEnteros(&(*p));
    if (op == suma) {
        v1 = v2 + v1;
    }
    else if(op == resta) {
        v1 = v2 - v1;
    }
    else if (op == producto) {
        v1 = v2 * v1;
    }
    else if (op == division) {
        v1 = v2 / v1;
    }
    apilarPilaDeEnteros(&(*p),v1);
}


int evaluaPolonesa (Expresion e){
    PilaDeEnteros p;
    Simbolo x;
    int v;
    nuevaPilaDeEnteros(&p);
    while (!expresionVacia(e)){
        primerSimbolo(e,&x);
        if (esOperador(x))
            eval(&p, operador(x));
        else
            apilarPilaDeEnteros(&p, valor(x));
        eliminaSimbolo(&e);
    }
    cimaPilaDeEnteros(p,&v);
    return v;
}