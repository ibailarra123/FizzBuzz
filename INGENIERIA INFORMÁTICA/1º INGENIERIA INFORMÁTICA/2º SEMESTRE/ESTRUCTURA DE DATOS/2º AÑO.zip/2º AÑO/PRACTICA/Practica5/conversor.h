#ifndef ILB_CONVERSOR_H
#define ILB_CONVERSOR_H

/**
 *	MODULO: conversor
 *	FICHERO: conversor.h
 *	VERSION: 1.0.0
 *	HISTORICO:
 *		Creado por Ibai Larralde Baldanta el 01/04/22.
 * DESCRIPCION: Este módulo exporta la funcionalidad necesaria para laconversión de una expresión de
 *              notación infija a notación postfija.
 */

#include <stdbool.h>
#include "simbolos.h"
#include "expresion.h"
#include "operadores.h"
#include "pilaDeSimbolos.h"


/**
 * ACCION: evaluaPolonesa
 * ENTRADA: una expresion
 *	REQUISITOS: la expresion en e debe estar bien escrita y no ser nula
 * SALIDA: v valor de la expresión
 */

void transformaPolonesa(char[] , Expresion *);

#endif //ILB_CONVERSOR_H