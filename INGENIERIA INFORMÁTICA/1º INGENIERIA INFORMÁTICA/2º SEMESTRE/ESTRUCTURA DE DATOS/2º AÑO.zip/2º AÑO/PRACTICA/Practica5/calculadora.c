/*
 *  Programa: cuenta
 *  Histrico:
 *    Creado por Ibai Larralde Baldanta el 18/03/2022.
 *      versin 1.0.0
 *  Copyright Ibai Larralde Baldanta. All rights reserved.
 */

#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include "conversor.h"
#include "evaluador.h"



/*
 * PROGRAMA PRINCIPAL
 * ENTRADA: Una operacion
 * REQUISITOS: Ninguno
 * SALIDA: un entero resultado de la operación introducida
 */


int main(void) {
    char quiereSalir,operacion[100];
    Expresion expresion;
    int resultado;
	printf("\tPrograma Calculadora\n");
	printf("\tCreado por Ibai Larralde Baldanta\n");
	printf("\tversion 1.0 08/04/2021)\n\n");
    printf("Programa que obtine el resultado de una operación\n");
    do {
        printf("Por favor, introduzca la operación: ");
        scanf("%s", operacion);

        transformaPolonesa(operacion,&expresion);
        resultado = evaluaPolonesa(expresion);

        printf("El resultado es: %d\n",resultado);

        printf("Si desea salir pulse s, para repetir la ejecucion cualquier otra cosa: ");
		scanf("\n%c", &quiereSalir);
	} while (quiereSalir != 's');
	return 0;
}