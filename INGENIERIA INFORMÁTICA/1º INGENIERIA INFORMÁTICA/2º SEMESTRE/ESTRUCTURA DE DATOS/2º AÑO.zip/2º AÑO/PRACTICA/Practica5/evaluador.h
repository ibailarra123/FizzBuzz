#ifndef ILB_EVALUADOR_H
#define ILB_EVALUADOR_H

/**
 *	MODULO: evaluador
 *	FICHERO: evaluador.h
 *	VERSION: 1.0.0
 *	HISTORICO:
 *		Creado por Ibai Larralde Baldanta el 01/04/22.
 * DESCRIPCION: Este módulo exporta la funcionalidad necesaria para implementar la evaluación de una expresion en notacion postfija.
 */

#include <stdbool.h>
#include "simbolos.h"
#include "expresion.h"
#include "operadores.h"
#include "pilaDeEnteros.h"


/**
 * ACCION: evaluaPolonesa
 * ENTRADA: una expresion
 *	REQUISITOS: la expresion en e debe estar bien escrita y no ser nula
 * SALIDA: v valor de la expresión
 */

int evaluaPolonesa (Expresion);

#endif //ILB_EVALUADOR_H