/**
 *	MODULO: expresion
 *	FICHERO: expresion.c
 *	VERSION: 1.0.0
 *	HISTORICO:
 *		Creado por Ibai Larralde Baldanta el 01/04/22.
 * DESCRIPCION: Este módulo exporta la funcionalidad necesaria para implementar
 * 	una expresion.
 */

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include "expresion.h"


/**
 * ACCION: expresionNula
 * ENTRADA: una expresion
 *	REQUISITOS: la expresion no está inicializada
 * SALIDA: Inicializa la expresion sin elementos
 */
void expresionNula (Expresion *e){
	e->inicio = 0;
	e->primero = -1;
}

/**
 * ACCION: expresionVacia
 * ENTRADA: una expresion
 *	REQUISITOS: Ninguno
 * SALIDA: Devuelve true si la expresión está vacía
 */
bool expresionVacia (Expresion e){
	return(e.inicio==e.primero+1);
}

/**
 * ACCION: expresionLlena
 * ENTRADA: una expresion
 *	REQUISITOS: Ninguno
 * SALIDA: Devuelve true si la expresión está Llena
 */
bool expresionLlena (Expresion e){
	return(e.primero==TAMANIO_EXPRESION-1);
}


/**
 * ACCION: error
 *	REQUISITOS:
 * SALIDA: Para la ejecución tras informar de un error
 */
void errorExpresion(char s[]){
	printf("\n\n\nERROR en el módulo expresion: %s \n", s);
	while (true)
		exit(-1);
}

/**
 * ACCION: aniadeSimbolo
 * ENTRADA: una expresion y un simbolo
 *	REQUISITOS: Ninguno
 * SALIDA: Se ha introducido el simbolo al final de la expresión
 */
void aniadeSimbolo (Expresion *e, Simbolo x){
	if(expresionLlena(*e)){
		errorExpresion("No puedes introducir un símbolo en una expresión llena");
	}
	e->primero++;
	e->valores[e->primero]=x;
}


/**
 * ACCION: eliminaSimbolo
 * ENTRADA: una expresion
 *	REQUISITOS: No está vacía
 * SALIDA: Se elimina el primer elemento de la expresión
 */
void eliminaSimbolo (Expresion *e){
	if(expresionVacia(*e)){
		errorExpresion("No puedes eliminar un símbolo en una expresión vacía");
	}
	e->inicio++;
}


/**
 * ACCION: primerSimbolo
 * ENTRADA: una expresion y un símbolo x
 *	REQUISITOS: No está vacía
 * SALIDA: El valor del primer símbolo de de la expresión en x
 */
void primerSimbolo (Expresion e, Simbolo *x){
	if(expresionVacia(e)){
		errorExpresion("No puedes obtener el primer símbolo de una expresion vacía");
	}
	*x=e.valores[e.inicio];
}
