#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include "conversor.h"
#include "evaluador.h"
#include "pilaDeSimbolos.h"
#include "simbolos.h"


/*
 * PROGRAMA PRINCIPAL
 * ENTRADA: Una operacion
 * REQUISITOS: Ninguno
 * SALIDA: un entero resultado de la operación introducida
 */


int main(void) {
    char quiereSalir,operacion[100];
    Expresion expresion, aux;
    PilaDeSimbolos p;
    int resultado;
    Simbolo s;
    do {
        printf("Escriba una expresión aritmética en postorden: ");
        scanf("%s", operacion);
        printf("\n");
        transformaPolonesa(operacion,&expresion);
        
        expresionNula(&aux);
        nuevaPilaDeSimbolos(&p);
        printf("La expresión en postorden es: ");
        while(!expresionVacia(expresion)){
            primerSimbolo(expresion,&s);
            eliminaSimbolo(&expresion);
            aniadeSimbolo(&aux,s);
            apilarPilaDeSimbolos(&p,s);
            if (!esOperador(s)){
                printf("%c",operador(s));
            }
            else{
                printf("%d",s.valor);
            }
        }
        printf("\n");
        
        printf("Obviamente su inversa es: ");
        while(!esNulaPilaDeSimbolos(p)){
            cimaPilaDeSimbolos(p,&s);
            desapilarPilaDeSimbolos(&p);
            printf("%d",s.valor);
        }
        printf("\n");
        resultado = evaluaPolonesa(aux);

        printf("El resultado es: %d\n",resultado);

        printf("Si desea salir pulse s, para repetir la ejecucion cualquier otra cosa: ");
		scanf("\n%c", &quiereSalir);
	} while (quiereSalir != 's');
	return 0;
}
