#ifndef ILB_EXPRESION_H
#define ILB_EXPRESION_H
/**
 *	MODULO: expresion
 *	FICHERO: expresion.h
 *	VERSION: 1.0.0
 *	HISTORICO:
 *		Creado por Ibai Larralde Baldanta el 01/04/22.
 * DESCRIPCION: Este módulo exporta la funcionalidad necesaria para implementar
 * 	una expresion.
 */

#include <stdbool.h>
#include "simbolos.h"
#define TAMANIO_EXPRESION 100

typedef struct expresion{
	int primero;
	int inicio;
	Simbolo valores[TAMANIO_EXPRESION];
} Expresion;


/**
 * ACCION: expresionNula
 * ENTRADA: una expresion
 *	REQUISITOS: la expresion no está inicializada
 * SALIDA: Inicializa la expresion sin elementos
 */
void expresionNula (Expresion *);

/**
 * ACCION: aniadeSimbolo
 * ENTRADA: una expresion y un simbolo
 *	REQUISITOS: Ninguno
 * SALIDA: Se ha introducido el simbolo al final de la expresión
 */
void aniadeSimbolo (Expresion *, Simbolo);


/**
 * ACCION: eliminaSimbolo
 * ENTRADA: una expresion
 *	REQUISITOS: No está vacía
 * SALIDA: Se elimina el primer elemento de la expresión
 */
void eliminaSimbolo (Expresion *);


/**
 * ACCION: primerSimbolo
 * ENTRADA: una expresion y un símbolo x
 *	REQUISITOS: No está vacía
 * SALIDA: El valor del primer símbolo de de la expresión en x
 */
void primerSimbolo (Expresion, Simbolo *);


/**
 * ACCION: expresionVacia
 * ENTRADA: una expresion
 *	REQUISITOS: Ninguno
 * SALIDA: Devuelve true si la expresión está vacía
 */
bool expresionVacia (Expresion);

#endif //ILB_EXPRESION_H