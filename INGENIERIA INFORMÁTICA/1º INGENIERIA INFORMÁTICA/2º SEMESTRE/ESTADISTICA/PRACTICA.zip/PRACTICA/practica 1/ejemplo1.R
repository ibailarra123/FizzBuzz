(7*3)+12/2-7^2+sqrt(4)

log(3)+sqrt(2)*sin(pi/4)-exp(3)

3+2+log(5)+exp(3)/4+sqrt(6)

x <- 0.28354
round(x,2)
round(x,3)

x<-7
rm(x)
x

x<-2
y<-5
z<- (x*y)
z
rm(z)

x<- c(1,5,2,3)
y<- x^2
y
which(y==4)
class(y)

y<-c("A","table","book")
y

x<-c(2,3,4,1)
y<-c(1,1,3,7)
x+y

cbind(x,y)
rbind(x,y)
class(.Last.value)
z<-data.frame(x,y)
z

seq(0,1,0.2)
seq(0,8)
seq(8,1,-1)
rep(1,5)

c(rep(1,3),rep(2,3), rep(3,3))
rep(1:3, each=3)

library(PASWR2)
BODYFAT<-read.table("Bodyfat.txt",header=TRUE)
head(BODYFAT)

summary(BODYFAT)

str(BODYFAT)

BODYFAT$fat

o<-order(BODYFAT$age)
BODYFAT[o,]

o<-order(BODYFAT$age, decreasing=TRUE)
BODYFAT2<-BODYFAT[o,]
BODYFAT2

with(BODYFAT, table(sex))
table(BODYFAT$sex)

low.fat<-with(BODYFAT, fat[fat<25])
low.fat

subset(BODYFAT, fat<25 & fat!=7.8)

min(BODYFAT$fat)
max(BODYFAT$fat)
range(BODYFAT$fat)

BODYFAT2<-BODYFAT[,-2]
BODYFAT2<-BODYFAT2[-c(7,9,15),]
with(BODYFAT, eda(fat))
hist(BODYFAT$fat)
boxplot(BODYFAT$fat)

o<-order(BODYFAT$age)
plot(BODYFAT$age[o], BODYFAT$fat[o],type="l",xlab="age",ylab="fat")
