//Programa:Hanoi
//Ibai Larralde Baldanta
//12/11/2020
//Programa que calcula una secuencia de movimientos que conducen las n piezas de la barra A a la barra B
#include <stdio.h>
void colocar (int n, char i, char j, char k);
int main (void)
{
    int n;
    char res, i, j, k;
    printf("Programa: Hanoi\n");  
    printf("Ibai Larralde Baldanta\n");   
    printf("12/11/2020\n");
    printf("Este programa calcula una secuencia de movimientos que conducen");
    printf("las n piezas de la barra A a la barra B.\n");
    do
    {
        printf("Por favor, introduce un número entero positivo mayor que 0: \n");
        scanf("%d", &n);
        i = 'A';
        j = 'C';
        k = 'B';
        colocar(n, i, j, k);
        printf("Deseas continuar? s/n: ");
        scanf(" %c", &res);        
    } while(res == 's' || res == 'S');
    return 0;
}
void colocar(int n, char i, char j, char k)
{
    if (n == 1)
    {
        printf("Mover disco %d del poste %c al %c\n", n, i, j);
    }
    else if (n > 1)
    {
        colocar(n-1, i, k, j);
        printf("Mover disco %d del poste %c al %c\n", n, i, j);
        colocar(n-1, k, j, i);
    }
}
