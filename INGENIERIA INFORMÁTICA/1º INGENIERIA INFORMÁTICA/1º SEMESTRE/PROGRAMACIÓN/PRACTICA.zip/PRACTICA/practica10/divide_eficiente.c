//Programa:Divide eficiente
//Ibai Larralde Baldanta
//12/11/2020
//Programa que calcula el cociente y el resto de dos números enteros positivos
#include <stdio.h>
void division (int a, int b, int *q, int *r , int *contador);
int main (void)
{
    int a, b, q, r, contador;
    char res;
    printf("Programa: Divide eficiente\n");  
    printf("Ibai Larralde Baldanta\n");   
    printf("12/11/2020\n");
    printf("Este programa calcula el cociente y el resto");
    printf("de dos números enteros positivos.\n");
    q = 0;
    r = 0;
    contador = 0;
    do
    {
        printf("Por favor, introduce un número entero positivo mayor o igual que 0: \n");
        scanf("%d", &a);
        printf("Por favor, introduce un número entero positivo mayor que 0: \n");
        scanf("%d", &b);
        division(a, b, &q, &r, &contador);    
        printf("El cociente entre %d y %d es %d\n", a, b, q);
        printf("El resto es %d\n",r);
        printf("El numero de vueltas que da es %d\n", contador);
        printf("Deseas continuar? s/n: ");
        scanf(" %c", &res);        
    } while(res == 's' || res == 'S');
    return 0;
}
void division(int a, int b, int *q, int *r, int *contador)
{
    int q2, r2;
    *contador = *contador + 1;
    if (a < b)
    {
        *q = 0;
        *r = a;
    }
    else
    {
        division(a, 2*b, &q2, &r2, &contador);
        if (r2 >= b)
        {
            *q = 2 * q2 + 1;
            *r = r2 - b;
        }
        else
        {
            *q = 2 * q2;
            *r = r2;
        }
    }
}

