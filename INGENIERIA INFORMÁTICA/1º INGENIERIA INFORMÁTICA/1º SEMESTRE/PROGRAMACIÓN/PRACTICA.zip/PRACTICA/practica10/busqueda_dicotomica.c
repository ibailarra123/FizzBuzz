//Programa: Busqueda dicotomica
//Ibai Larralde Baldanta
//12\11\2020
//Este programa construye una tabla con valores ordenados de menor a mayor e indica si un número introducido está en ella
#include <stdio.h>
#define N 10
typedef int tabla [N+1];
int	buscar(tabla t, int i, int j, int x);
int main (void)
{
	tabla t;
	int i, y, j, x, p;
	char res;
    j = N + 1;
    i = 0;
    printf("Programa: Segmentos\n");
	printf("Ibai Larralde Baldanta\n");
	printf("12/11/2020\n");
	printf("Programa que construye una tabla con valores ordenados de menor a"); 
	printf("mayor e indica si un número introducido está en ella.\n");
    printf("Introduce una tabla de números enteros en orden creciente.\n");
	do
	{
		for (y = 1; y < N+1; y = y+1)
		{
			printf("Introduce un numero entero t[%d]: \n",y);
			scanf( "%d", &t[y]);
		}
		printf("La tabla t: [");
		for (y = 1; y < N+1; y = y+1)
		{
			printf("%d", t[y]);
		}
		printf ("] \n");
        printf("Introduce un numero entero %d: \n",x);
        scanf( "%d", &x);
        p = buscar(t, i, j, x);
        if (t[p]==x)
        {
            printf("El número %d está en la tabla t\n",x);
        }
        else
        {
            printf("El número %d no está en la tabla t\n",x);
            printf("Debería estar entre la posición %d y %d\n",p,(p+1));
        }
        printf("Deseas continuar? s/n: ");
        scanf(" %c", &res);        
    	} while(res == 's' || res == 'S');
    	printf (" \n");
    	return 0;
}
int	buscar(tabla t, int i, int j, int x)
{
    int m, p;
    if (j == i + 1)
    {
        p = i;
    }
    else
    {
        m = (i + j)/2;
        if (x >= t[m])
        {
            p = buscar(t, m, j, x);
        }
        else
        {
            p = buscar(t, i, m, x);
        }
    }
    return p;
}
