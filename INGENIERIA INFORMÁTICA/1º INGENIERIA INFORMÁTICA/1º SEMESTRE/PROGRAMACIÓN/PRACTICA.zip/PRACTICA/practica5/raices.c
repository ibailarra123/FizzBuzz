//Raices
//Ibai Larralde Baldanta
//08/10/20202
//Programa que calcula la parte entera de la raíz n-ésima de un número entero positivo
#include <stdio.h>
int potencia(int y, int i);
int raiz_n_esima(int x, int i);
int main (void)
{
    int i,n,x,y;
    char res;
    printf("Programa: Raices\n");  
    printf("Ibai Larralde Baldanta\n");   
    printf("08/10/2020\n");
    printf("Programa que clcula la parte entera de la raíz n-ésima de un número entero positivo\n");
    do
    {
        printf("Por favor, introduce un número entero mayor o igual que 1 con el que trabajar: \n");
        scanf(" %d", &x);
        printf("Por favor, introduce un número entero mayor que 1: \n");
        scanf(" %d", &n);
        for (i = 1; i < n+1; i = i+1 )
        {
            y = raiz_n_esima(x,i);
            printf("La %d parte entera de la raíz de %d es %d\n",i,x,y);
        }
        printf("Deseas continuar? s/n: ");
        scanf(" %c", &res);        
    } while(res == 's' || res == 'S');
    return 0;
}
int potencia (int y, int i)
{
    int ii,p;
    ii = i;
    p = 1;
    while (ii != 0)
    {
        p = p*(y+1);
        ii = ii-1;
    }
    return p;
}   
int raiz_n_esima (int x, int i)
{
    int y,z;
    y = 0;
    z = 1;
    while (x >= z)
    {
        z = potencia (y+1,i);
        y = y+1;
    }
    return y;
}
