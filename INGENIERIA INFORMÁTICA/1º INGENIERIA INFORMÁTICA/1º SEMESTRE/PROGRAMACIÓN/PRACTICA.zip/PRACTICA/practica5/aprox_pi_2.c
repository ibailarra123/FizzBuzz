//Programa: Aprox_pi_2
//Autor: Ibai Larralde
//Fecha: 18/10/2020
//Este programa realiza una serie de aproximaciones desde 0 hasta un núnmero introducido
#include <stdio.h>
int potencia(int x, int y);
float aprox_pi(int n);
int main(void)
{
    int n,i;
    float p;
    char res;
    printf("Programa: Aprox_pi_2\n");
    printf("Autor: Ibai Larralde\n");
    printf("Fecha: 18/10/2020\n");
    printf("Este programa realiza una serie de aproximaciones desde 0 hasta un núnmero introducido.\n");
    do
    {
        printf("Introduce un número entero y positivo:\n");
        scanf(" %d", &n);
        for ( i = 0; i <= n; i = i+1)
        {
            p = aprox_pi( i );
            printf("La aproximación %d es: %f\n", i,p);
        }
        printf("Deseas continuar? s/n: ");
        scanf(" %c", &res);
        }while(res == 's' || res == 'S');
        return 0;
}
int potencia(int x, int y)
{
    int yy,z;
    yy = y;
    z = 1;
    while (yy != 0)
    {
        z = z * x;
        yy = yy - 1;
    }
    return z;
}
float aprox_pi (int n)
{
    int k,aux;
    float p;
    k = 0;
    p = 4;
    aux = potencia(10,n);
    while (aux >= 2* k + 3)
    {
        if ((k + 1 ) % 2 == 0)
            p = p + (4.0/(2 * k + 3));
        else
            p = p - (4.0/(2 * k + 3));
        k = k + 1;
    }
    return p;
}
