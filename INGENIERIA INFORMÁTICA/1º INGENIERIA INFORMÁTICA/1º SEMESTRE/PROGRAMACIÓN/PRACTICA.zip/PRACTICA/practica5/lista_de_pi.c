//Programa:Lista_de_pi
//Ibai Larralde Baldanta
//14/10/20202
//Programa que calcula el valor de las primeras aproximación de pi de un numero entero positivo mayor o igual que 1
#include <stdio.h>
float aproximacion_de_pi(float n);
int main (void)
{
    int i,n;
    float p;
    char res;
    printf("Programa: Lista de pi\n");  
    printf("Ibai Larralde Baldanta\n");   
    printf("14/10/2020\n");
    printf("Programa que calcula el valor de las primeras aproximación de pi");
    printf("de un numero entero positivo mayor o igual que 0.\n");
    do
    {
        printf("El programa solo trabaja con números enteros positivos\n");
        printf("Por favor, introduce un número entero positivo mayor o igual que 0: \n");
        scanf("%d", &n);
        for (i = 0; i < n+1; i = i+1 )
        {
            p = aproximacion_de_pi(i);
            printf("Aproximación %d de pi es %f\n",i,p);
        }
        printf("Deseas continuar? s/n: ");
        scanf(" %c", &res);        
    } while(res == 's' || res == 'S');
    return 0;
}
float aproximacion_de_pi(float n)
{
    float p;
    int k;
    k = 0;
    p = 4.0;
    while (k != n)
    {
        p = p*(1-(1/((2.0*k+3)*(2.0*k+3))));
        k = k+1;
    }
    return p;
}
