//Programa:Fracciones
//Ibai Larralde Baldanta
//15/10/20202
//Programa que calcula el valor de la fraccion reiterada hasta un numero natural positivo
#include <stdio.h>
void fraccion_reiterada(int n, int* p, int* q);
int main (void)
{
    int n,i,p,q;
    float a;
    char res;
    printf("Programa: Fracciones\n");  
    printf("Ibai Larralde Baldanta\n");   
    printf("15/10/2020\n");
    printf("Programa que calcula el valor de las inversas de cantor");
    printf(" dese 1 hasta un numero natural positivo.\n");
    do
    {
        printf("El programa solo trabaja con números enteros positivos\n");
        printf("Por favor, introduce un número entero positivo mayor que 0: \n");
        scanf("%d", &n);
        for (i = 1; i < n+1; i = i+1 )
        {
            fraccion_reiterada(i,&p,&q);
            a = p/ (float)q;
            printf("La %d fracción reiterada es %f\n",i,a);
        }
        printf("Deseas continuar? s/n: ");
        scanf(" %c", &res);        
    } while(res == 's' || res == 'S');
    return 0;
}
void fraccion_reiterada(int n, int *p, int *q)
{
    int k,aux;
    k = 1;
    *p = n;
    *q = 1;
    while (k != n)
    {
        aux = *p;
        *p = *p*(n-k)+*q;
        *q = aux;
        k = k+1;
    }
 
}