//Programa: Particiones
//Ibai Larralde Baldanta
//28/10/20202
//Programa que parte en dos tablas una tabla introducida
#include <stdio.h>
#define N 9
typedef enum{FAlSE = 0, TRUE = 1}boolean;
typedef float tabla[N+1];
void particion_tabla(float x, tabla t, int *i, int *j);
int main (void)
{
    int i,j;
    float x;
    tabla t;
    char res;
    printf("Programa: Particiones\n");  
    printf("Ibai Larralde Baldanta\n");   
    printf("28/10/2020\n");
    printf("Programa que detecta si hay elementos repetidos");
    printf("en la tabla introducida.\n");
    do
    {
        printf("Introduce un número real : \n",x);
        scanf(" %f", &x);
	for (i = 1; i < N+1; i = i+1)
	{
		printf("Introduce un numero real t[%f]: \n",i);
		scanf( " %f", &t[i]);
        }
	printf("La tabla t: [");
	for (i = 1; i < N+1; i = i+1)
	{
		printf(" %d", t[i]);
	}
	printf ("] \n");        
	printf("La primera tabla es: [");
	for (i = 1; i < N+1; i = i+1)
	{
		particion_tabla(x,t,&i,&j);
            	printf(" %d", t[i]);
	}
	printf ("] \n");
        printf("La segunda tabla es: [");
	for (i = 1; i < N+1; i = i+1)
	{
		particion_tabla(x,t,&i,&j);
            	printf(" %d", t[j-1]);
	}
	printf ("] \n");
        printf("Deseas continuar? s/n: ");
        scanf(" %c", &res);        
    } while(res == 's' || res == 'S');
    printf (" \n");
    return 0;
}
void particion_tabla(float x, tabla t, int *i, int *j)
{
    int aux;
    *i = 0;
    *j = N+1;
    while (*i != j)
    {
        if (t[*i] < x && t[*j - 1] >= x)
        {
            *i = *i+1; 
            *j = *j-1;
        }
        else if (t[*i] < x && t[*j - 1] < x)
        {
            *i = *i+1;
        }
        else if (t[*i] <= x && t[*j - 1] >= x)
        {
            *j = *j-1;
        }
        else if (t[*i] <= x && t[*j - 1] < x)
        {
            aux = t[*i];
            t[*i] = t[*j-1];
            t[*j-1] = aux;
            *i = *i+1;
            *j = *j-1;
        }
    }
 
}
