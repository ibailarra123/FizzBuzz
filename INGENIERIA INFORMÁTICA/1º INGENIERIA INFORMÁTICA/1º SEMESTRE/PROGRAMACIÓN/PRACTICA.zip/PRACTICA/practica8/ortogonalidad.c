//Programa: Ortogonalidad
//Ibai Larralde Baldanta
//04\11\2020
//Este programa compara dos tablas para ver si son ortogonales o no.

#include <stdio.h>
#define N 5
typedef enum{FAlSE = 0, TRUE = 1}boolean;
typedef int tabla [N];
boolean son_ortogonales(tabla t, tabla h);
int main (void)
{
	tabla t,h;
	int i;
    boolean b;
	char res;
	printf("Programa: Ortogonalidad\n");
	printf("Ibai Larralde Baldanta\n");
	printf("Programa que compara dos tablas para ver si son ortogonales o no.\n");
	do
	{
		for (i = 1; i < N+1; i = i+1)
		{
			printf("Introduce un numero entero positivo t[%d]: \n",i);
			scanf( " %d", &t[i]);
		}
		printf("La tabla t: [");
		for (i = 1; i < N+1; i = i+1)
		{
			printf(" %d", t[i]);
		}
		printf ("] \n");
		for (i = 1; i < N+1; i = i+1)
		{
			printf("Introduce un numero entero positivo h[%d]: \n",i);
			scanf( " %d", &h[i]);
		}
		printf("La tabla h: [");
		for (i = 1; i < N+1; i = i+1)
		{
			printf(" %d", h[i]);
		}
		printf ("] \n");
        b = son_ortogonales(h,t);
        if (b)
        {
            printf("Las tablas son ortogonales\n");
        }
        else
        {
            printf("Las tablas NO son ortogonales\n");
        }
        printf("Deseas continuar? s/n: ");
        scanf(" %c", &res);        
    } while(res == 's' || res == 'S');
    printf (" \n");
    return 0;
}
boolean son_ortogonales(tabla h, tabla t)
{
	boolean b;
	int k,z;
	k = 1;
	z = 0;
	while (k != N+1)
	{
        z = z + (t[k]*h[k]);
		k = k+1;
	}
	b = (z == 0);
	return b;
}
	
