//Programa: Contador
//Ibai Larralde Baldanta
//05\11\2020
//Este programa calcula el número de parejas que hay en la tabla
#include <stdio.h>
#define N 10
typedef int tabla [N];
int cuenta_parejas(tabla t);
int main (void)
{
	tabla t;
	int r,i;
	char res;
	printf("Programa: Contador\n");
	printf("Ibai Larralde Baldanta\n");
	printf("Programa que calcula el número de"); 
	printf("parejas que hay en la tabla.\n");
	do
	{
		for (i = 1; i < N+1; i = i+1)
		{
			printf("Introduce un numero entero positivo t[%d]: \n",i);
			scanf( " %d", &t[i]);
		}
		printf("La tabla t: [");
		for (i = 1; i < N+1; i = i+1)
		{
			printf(" %d", t[i]);
		}
		printf ("] \n");
        r = cuenta_parejas(t);
        printf("El número de parejas encontradas en la tabla es: %d\n", r);
        printf("Deseas continuar? s/n: ");
        scanf(" %c", &res);        
    	} while(res == 's' || res == 'S');
    	printf (" \n");
    	return 0;
}
int cuenta_parejas(tabla t)
{
    int x,z,r;
    x = 1;
    r = 0;
    z = 0;
    while (x != N)
    {
        if (t[x] <= 0)
        {
            z = z+1;
        }
        if (t[x+1] >= 0)
        {
            r = r+z;
        }
        x = x+1;
    }
    return r;
}
