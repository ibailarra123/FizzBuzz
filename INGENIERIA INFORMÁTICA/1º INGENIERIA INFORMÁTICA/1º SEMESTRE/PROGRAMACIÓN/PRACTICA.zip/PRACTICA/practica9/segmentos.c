//Programa: Segmentos
//Ibai Larralde Baldanta
//05\11\2020
//Este programa calcula el máximo de las sumas de los segmentos de dos filas
#include <stdio.h>
#define N 7
typedef int tabla [N];
int segmento_maximo(tabla t);
int max(int a,int b);
int main (void)
{
	tabla h,t;
	int r1,r2,i;
	char res;
	printf("Programa: Segmentos\n");
	printf("Ibai Larralde Baldanta\n");
	printf("Programa que calcula el máximo de las sumas"); 
	printf("de los segmentos de dos filas.\n");
	do
	{
		for (i = 1; i < N+1; i = i+1)
		{
			printf("Introduce un numero entero h[%d]: \n",i);
			scanf( " %d", &h[i]);
		}
		printf("La tabla h: [");
		for (i = 1; i < N+1; i = i+1)
		{
			printf(" %d", h[i]);
		}
		printf ("] \n");
		for (i = 1; i < N+1; i = i+1)
		{
			printf("Introduce un numero entero t[%d]: \n",i);
			scanf( " %d", &t[i]);
		}
		printf("La tabla t: [");
		for (i = 1; i < N+1; i = i+1)
		{
			printf(" %d", t[i]);
		}
		printf ("] \n");
        r1 = segmento_maximo (t);
        printf("El máximo de las sumas de los segmentos de la tabla t es: %d\n",r1);
        r2 = segmento_maximo (h);
        printf("El máximo de las sumas de los segmentos de la tabla h es: %d\n",r2);
        if (r1 > r2)
        {
            printf("La tabla t es la que contiene la suma mayor");
        }
        else if (r1 = r2)
        {
            printf("Las tablas t y h contienen igual suma mayor");
        }
        else 
        {
            printf("La tabla h es la que contiene la suma mayor");
        }
        printf("Deseas continuar? s/n: ");
        scanf(" %c", &res);        
    	} while(res == 's' || res == 'S');
    	printf (" \n");
    	return 0;
}
int	segmento_maximo(tabla t)
{
    int r,z,x;
    x = 1;
    r = t[1];
    z = t[1];
    while (x != N)
    {
        z = max(z,0) + t[x+1];
        r = max(r,z);
        x = x+1;
    }
    return r;
}
int max(int a,int b)
{
    int may;
    if (a >= b)
    {
        may = a;
    }
    else 
    {
        may = b;
    }
    return may;
}
