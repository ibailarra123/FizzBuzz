//Programa: Repeticiones
//Ibai Larralde Baldanta
//28/10/20202
//Programa que detecta si hay elementos repetidos en la tabla introducida
#include <stdio.h>
#define N 6
typedef enum{FAlSE = 0, TRUE = 1}boolean;
typedef int Vector[N+1];
boolean calcula_A(Vector t, int x);
int elementos_no_repetidos(Vector t);
int main (void)
{
    int x;
    Vector t;
    boolean r;
    char res;
    printf("Programa: Repeticiones\n");  
    printf("Ibai Larralde Baldanta\n");   
    printf("28/10/2020\n");
    printf("Programa que detecta si hay elementos repetidos");
    printf("en la tabla introducida.\n");
    do
    {
        for(x = 0; x < N; x = x+1)
        {
            printf("Introduce un valor entero en t[ %d]:\n", x);
            scanf(" %d", &t[x]);
        }
        r = elementos_no_repetidos(t);
        if (r==0)
            printf("No existen elementos repetidos en la tabla t\n");
        else
            printf("Existe algun elemento repetido en la tabla t\n");
        printf("Deseas continuar? s/n: ");
        scanf(" %c", &res);        
    } while(res == 's' || res == 'S');
    printf (" \n");
    return 0;
}
boolean calcula_A(Vector t, int x)
{
    boolean z;
    int y;
    y = x+1;
    while ((y < N) && (t[x] != t[y]))
    {
        y = y+1;
    }
    z = (t[x] == t[y]);
    return z;
}
int elementos_no_repetidos(Vector t)
{
    int x;
    boolean r,z;
    x = 0;
    z = calcula_A(t,0);
    while ((!z) && x < (N-1))
    {
        z = calcula_A(t,x+1);
	x = x+1;
    }
    r != z;
    return z;
}

