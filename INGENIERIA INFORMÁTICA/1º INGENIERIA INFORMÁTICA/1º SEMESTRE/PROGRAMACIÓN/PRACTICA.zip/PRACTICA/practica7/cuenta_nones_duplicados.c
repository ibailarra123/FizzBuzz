//Programa: Cuenta_nones_duplicados
//Ibai Larralde Baldanta
//02/11/20202
//Programa que cuenta el número de veces que los valores nones de la tabla t se repiten en la tabla h
#include <stdio.h>
#define N 5
#define M 7
typedef enum{FAlSE = 0, TRUE = 1}boolean;
typedef int tabla1 [N+1];
typedef int tabla2 [M+1];
boolean esta_en(tabla1 t, int x);
int main (void)
{
	tabla2 t;
	tabla1 h;
	int i,r;
	boolean z;
	char res;
	printf("Programa: Cuenta_nones_duplicados\n");
	printf("Ibai Larralde Baldanta\n");
	printf("Programa que cuenta el número de veces que los valores"); 
	printf("nones de la tabla t se repiten en la tabla h.\n");
	do
	{
		r = 0;
		for (i = 1; i < N+1; i = i+1)
		{
			printf("Introduce un numero entero positivo h[%d]: \n",i);
			scanf( " %d", &t[i]);
		}
		printf("La tabla h: [");
		for (i = 1; i < N+1; i = i+1)
		{
			printf(" %d", t[i]);
		}
		printf ("] \n");
		for (i = 1; i < M+1; i = i+1)
		{
			printf("Introduce un numero entero positivo t[%d]: \n",i);
			scanf( " %d", &h[i]);
		}
		printf("La tabla t: [");
		for (i = 1; i < M+1; i = i+1)
		{
			printf(" %d", h[i]);
		}
		printf ("] \n");
		for (i = 1; i != N+1; i = i+1)
		{
			z = esta_en (h,t[i]);
			if ((t[i] % 2 == 1) && (z))
			{	
				r = r+1;
			}
		}
		printf("El número de valores nones que se repiten es: %d\n", r);
        	printf("Deseas continuar? s/n: ");
        	scanf(" %c", &res);        
    	} while(res == 's' || res == 'S');
    	printf (" \n");
    	return 0;
}
boolean esta_en(tabla1 t, int x)
{
	int y;
	boolean z;
	y = 1;
	while (y < M && (x != t[y]))
	{
		y = y+1;
	}
	z = (x == t[y]);
	return z;
}
