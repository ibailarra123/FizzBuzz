//Programa: Cuenta_divisores
//Ibai Larralde Baldanta
//01\11\2020
//Este programa cuenta el número de veces en la que una posición en la tabla es un divisor de un elemento de la tabla

#include <stdio.h>
#define N 6
typedef enum{FAlSE = 0, TRUE = 1}boolean;
typedef int tabla [N];
boolean calcula_B(tabla g, int z);
int cuenta_divisores(tabla g, tabla h);
int main (void)
{
	tabla h,g;
	int i,s;
	char res;
	printf("Programa: Cuenta_divisores\n");
	printf("Ibai Larralde Baldanta\n");
	printf("Programa que cuenta el número de veces en la que la"); 
	printf("posición en la tabla es un divisor de un elemento de la tabla.\n");
	do
	{
		for (i = 1; i < N+1; i = i+1)
		{
			printf("Introduce un numero entero positivo h[%d]: \n",i);
			scanf( " %d", &h[i]);
		}
		printf("La tabla h: [");
		for (i = 1; i < N+1; i = i+1)
		{
			printf(" %d", h[i]);
		}
		printf ("] \n");
		for (i = 1; i < N+1; i = i+1)
		{
			printf("Introduce un numero entero positivo g[%d]: \n",i);
			scanf( " %d", &g[i]);
		}
		printf("La tabla g: [");
		for (i = 1; i < N+1; i = i+1)
		{
			printf(" %d", g[i]);
		}
		printf ("] \n");
		s = cuenta_divisores (g,h);
		printf("El número de posiciones de divisores es: %d\n", s);
        	printf("Deseas continuar? s/n: ");
        	scanf(" %c", &res);        
    	} while(res == 's' || res == 'S');
    	printf (" \n");
    	return 0;
}
boolean calcula_B(tabla g, int z)
{
    int y;
    boolean b;
    y = 1;
    while (g[y] %z != 0 && y < N)
    {
        y = y+1;
    }
    b = (g[y]%z == 0);
    return b;
}
int cuenta_divisores(tabla g, tabla h)
{
	boolean b;
	int s, x;
	s = 0;
	x= 1;
	while (x != N+1)
	{
		b = calcula_B(g, h[x]);
		if (b)
		{
			s = s+1;
		}
		x = x+1;
	}
	return s;
}
		

