//Programa:Lista de Cantor
//Ibai Larralde Baldanta
//14/10/20202
//Programa que calcula el valor de las inversas de cantor dese 1 hasta un numero natural positivo
#include <stdio.h>
void inversa_de_Cantor(int r, int* m, int* n);
int main (void)
{
    int r,i,n,m;
    char res;
    printf("Programa: Lista de cantor\n");  
    printf("Ibai Larralde Baldanta\n");   
    printf("14/10/2020\n");
    printf("Programa que calcula el valor de las inversas de cantor");
    printf(" dese 1 hasta un numero natural positivo.\n");
    do
    {
        printf("El programa solo trabaja con números enteros positivos\n");
        printf("Por favor, introduce un número entero positivo mayor o igual que 1: \n");
        scanf("%d", &r);
        i = 1;
        while (i <= r)
        {
            inversa_de_Cantor(i,&m,&n);
            printf("Las inversa de cantor para %d es,m(%d)=%d y n(%d)=%d\n",i,i,m,i,n);
            i = i+1;
        }
        printf("Deseas continuar? s/n: ");
        scanf(" %c", &res);        
    } while(res == 's' || res == 'S');
    return 0;
}
void inversa_de_Cantor(int r, int *m, int *n)
{
    int s;
    s = 0;
    while (r >= (((s+1)*(s+2))/2))
    {
        s = s+1;
    }
    *m = r-(s*(s+1))/2;
    *n = s-*m;
}
