//Programa:Lista exponencial
//Ibai Larralde Baldanta
//08/10/20202
//Programa que calcula el valor de cada lista exponencial desde 0 hasta un numero introducido
#include <stdio.h>
int potencia(int a, int b);
int serie_exponencial(int n);
int main (void)
{
    int i,n,s;
    char res;
    printf("Programa: Lista exponencial\n");  
    printf("Ibai Larralde Baldanta\n");   
    printf("08/10/2020\n");
    printf("Programa que calcula el valor de cada lista");
    printf("exponencial desde 0 hasta un numero natural.\n");
    do
    {
        printf("El programa solo trabaja con números enteros positivos\n");
        printf("Por favor, introduce un número entero positivo: \n");
        scanf("%d", &n);
        i = 0;
        while (i <= n)
        {
            s = serie_exponencial(i);
            printf("La serie exponencial de %d es %d\n",i,s);
            i = i+1;
        }
        printf("Deseas continuar? s/n: ");
        scanf(" %c", &res);        
    } while(res == 's' || res == 'S');
    return 0;
}
int potencia (int a, int b)
{
    int bb,p;
    bb = b;
    p = 1;
    while (bb != 0)
    {
        p = p*a;
        bb = bb-1;
    }
    return p;
}   
int serie_exponencial (int n)
{
    int k,s,x;
    s = 0;
    k = 0;
    while (k != n)
    {
        x = potencia(k+1,k+1);
        s = s+x;
        k = k+1;
    }
    return s;
}
 
        
            

