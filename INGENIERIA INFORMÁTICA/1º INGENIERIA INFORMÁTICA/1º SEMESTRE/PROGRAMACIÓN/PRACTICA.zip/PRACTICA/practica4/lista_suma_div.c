//Programa:Lista suma de divisores
//Ibai Larralde Baldanta
//14/10/20202
//Programa que calcula el valor de una suma de divisores dese 1 hasta un numero natural positivo
#include <stdio.h>
int suma_divisores(int n);
int main (void)
{
    int i,n,s;
    char res;
    printf("Programa: Lista suma de divisores\n");  
    printf("Ibai Larralde Baldanta\n");   
    printf("14/10/2020\n");
    printf("Programa que calcula el valor de una suma de");
    printf("divisores dese 1 hasta un numero natural positivo.\n");
    do
    {
        printf("El programa solo trabaja con números enteros positivos\n");
        printf("Por favor, introduce un número entero positivo mayor o igual que 1: \n");
        scanf("%d", &n);
        i = 1;
        while (i <= n)
        {
            s = suma_divisores(i);
            printf("La serie de suma de divisores de %d es %d\n",i,s);
            i = i+1;
        }
        printf("Deseas continuar? s/n: ");
        scanf(" %c", &res);        
    } while(res == 's' || res == 'S');
    return 0;
}
int suma_divisores (int n)
{
    int k,s;
    k = n;
    s = n;
    while ( 1 < k)
    {
        if (n%(k-1) == 0)
        {
            s = s + (k-1);
        }
        k = k-1;
    }
    return s;
}   
