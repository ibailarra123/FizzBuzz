//Programa:Catalanes
//Ibai Larralde Baldanta
//17/10/20202
//Programa que calcula el valor de los n primeros numeros de catalán
#include <stdio.h>
int numero_catalan (int n);
int main (void)
{
    int c,n,i;
    char res;
    printf("Programa: Catalanes\n");  
    printf("Ibai Larralde Baldanta\n");   
    printf("17/10/2020\n");
    printf("Programa que calcula el valor de los n");
    printf("primeros numeros de catalán.\n");
    do
    {
        printf("El programa solo trabaja con números enteros positivos\n");
        printf("Por favor, introduce un número entero positivo mayor o igual que 0: \n");
        scanf("%d", &n);
        for (i = 0; i < n+1; i = i+1 )
        {
            c = numero_catalan(i);
            printf("Numero catalan %d de %d es %d\n",i,n,c);
        }
        printf("Deseas continuar? s/n: ");
        scanf(" %c", &res);        
    } while(res == 's' || res == 'S');
    return 0;
}
int numero_catalan (int n)
{
    int c,num,den;
    den = 1;
    num = 1;
    while (n != 0)
    {
        num = num*2*((2*n)-1);
        den = den*(n+1);
        n = n-1;
    }
    c = num/den;
    return c;
}
