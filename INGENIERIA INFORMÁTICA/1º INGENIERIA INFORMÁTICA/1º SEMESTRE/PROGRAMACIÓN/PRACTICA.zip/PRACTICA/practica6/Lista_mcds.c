//Programa: Lista_mcds
//Autor: Ibai Larralde
//Fecha: 18/10/2020
//Este programa calcula el mcd desde uno hasta el número introducido.
#include <stdio.h>
int accion_mcd(int x, int y);
int main(void)
{
    int x,t;
    char res;
    printf("Programa: Lista_mcds\n");
    printf("Autor: Ibai Larralde\n");
    printf("Fecha: 18/10/2020\n");
    printf("Este programa calcula el mcd desde uno hasta el número introducido.\n");
    do
    {
        printf("Introduce un número mayor que 0:\n");
        scanf(" %d", &x);
        for (int y = 1; y <= x; y = y+1)
        {
            t = accion_mcd(x,y);
            printf("El máximo comun divisor de %d y de %d es: %d\n",x,y,t);
        }
        printf("Deseas continuar? s/n: ");
        scanf(" %c", &res);
        }while(res == 's' || res == 'S');
        return 0;
}
int accion_mcd(int x, int y)
{
    int t,m,aux;
    m = 1;
    while (x != y)
    {
        if (x < y)
        {
            aux = x;
            x = y;
            y = aux;
        }
        if (x%2 == 0)
        {
            if (y%2 == 0)
            {
                x = x/2;
                y = y/2;
                m = m*2;
            }else
            {
                x = x/2;
            }
        }else
        {
            if(y%2 == 0)
            {
                y = y/2;
            }else
            {
                aux = x;
                x = (x+y)/2;
                y = (aux-y)/2;
            }
        }
    }
    t = x * m;
    return (t);
}

