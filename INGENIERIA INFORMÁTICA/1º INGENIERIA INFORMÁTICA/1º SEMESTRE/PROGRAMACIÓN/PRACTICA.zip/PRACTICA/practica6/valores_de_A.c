//Programa:Valores_de_A
//Ibai Larralde Baldanta
//17/10/20202
//Programa que calcula los valores de la función desde 0 hasta un número
#include <stdio.h>
int fun_A (int n);
int main (void)
{
    int n,i,f;
    char res;
    printf("Programa: Valores_de_A\n");  
    printf("Ibai Larralde Baldanta\n");   
    printf("17/10/2020\n");
    printf("Programa que calcula los valores de la");
    printf("función desde 0 hasta un número.\n");
    do
    {
        printf("El programa solo trabaja con números enteros positivos\n");
        printf("Por favor, introduce un número entero positivo mayor o igual que 0: \n");
        scanf("%d", &n);
        for (i = 0; i < n+1; i = i+1 )
        {
            f = fun_A(i);
            printf("El valor de A(%d) es %d\n",i,f);
        }
        printf("Deseas continuar? s/n: ");
        scanf(" %c", &res);        
    } while(res == 's' || res == 'S');
    return 0;
}
int fun_A (int n)
{
    int a,b,f;
    a = 0;
    b = 1;
    while (n != 0)
    {
        if (n%2 == 0)
        {
            b = 2*b;
            n = n/2;
        }
        else
        {
            a = a+b*(((n-1)/2));
            n = n-1;
        }
    }
    f = a + b;
    return f;
}
