//Programa: Premiesum
//Ibai Larralde
//24/11/2020
//Programa que dada un secuencia de números enteros distintos, realiza la suma de aquellos valores de la secuencia que no son primos
#include <stdio.h>
#define N 10
typedef int vector[N + 1];
void primos(vector t, int n, vector s, int *m);
int sumat(vector t, int n);
int main(void)
{
    vector t, s;
    int n, i, m, x;
    char res;
    do
    {
        printf("Programa: Premiesum\n");
        printf("Ibai Larralde\n");
        printf("24/11/2020\n");
        printf("Programa que dada una secuencia de números enteros distintos, realiza la");
        printf("suma de aquellos valores de la secuencia que no son primos.\n");
        printf("Introduce la longitud de la secuencia: \n");
        scanf("%d", &n);
        printf("Introduce valores enteros para la tabla t\n");
        for (i = 1; i < n + 1; i = i + 1)
        {
            printf("Elemento %d de la secuencia mayor que 1: \n", i);
            scanf("%d", &t[i]);
        }
        primos(t, n, s, &m);
        printf("Los números primos son: \n");
        for (i = 1; i < m + 1; i = i + 1)
        {
            printf(" %d", s[i]);
        }
        printf("\n");
        x = sumat(s, m);
        printf("La suma de los números primos es: %d\n", x);
        printf("Deseas continuar? (s/n): ");
        scanf(" %c", &res);
    }
    while(res == 's' || res == 'S');
    printf("\n");
    return 0;
}
void primos(vector t, int n, vector s, int *m)
{
    int i, j;
    *m = 0;
    i = 1;
    while (i <= n)
    {
        j = 2;
        while (((t[i] % j) != 0) && (j <= (t[i] / 2)))
        {
            j = j + 1;
        }
        if ((t[i] % j) != 0)
        {
            *m = *m + 1;
            s[*m] = t[i];
        }
        i = i + 1;
    }
}
int sumat(vector t, int n)
{
    int r, i;
    r = 0;
    i = 1;
    while (i <= n)
    {
        r = r + t[i];
        i = i + 1;
    }
    return r;
}
