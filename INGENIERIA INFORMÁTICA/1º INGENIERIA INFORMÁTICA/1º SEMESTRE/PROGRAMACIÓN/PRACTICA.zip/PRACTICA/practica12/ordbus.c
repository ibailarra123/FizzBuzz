//Programa: ordbus
//Ibai Larralde Baldanta
//23\11\2020
//Programa que lee una secuencia de valores enteros y en caso de que no este ordenada en orden ascendente, la ordena 
#include <stdio.h>
#define M 10
typedef int tablaM [M + 1];
typedef enum{FAlSE = 0, TRUE = 1}boolean;
boolean esta_ordenada (tablaM t, int n);
void insercion(tablaM t, int n);
int main(void)
{
    tablaM t;
    int i,n;
    boolean b;
    char res;
    do
    {
        printf("Programa: ordbus\n");
        printf("Ibai Larralde Baldanta\n");
        printf("23/11/2020\n");
        printf("Programa que lee una secuencia de valores enteros y en caso de que no este ordenada en orden"); printf("ascendente, la ordena.\n");
        printf("Introduce la longitud de la secuencia (1...10): \n");
        scanf("%d", &n);
        for (i = 1; i < n+1; i = i + 1)
        {
            printf("Introduce un número entero: \n");
            scanf("%d", &t[i]);
        }
        printf("La tabla t: [");
        for (i = 1; i < n+1; i = i + 1)
        {
            printf(" %d", t[i]);
        }
        printf("]\n");
        b = esta_ordenada(t, n);
        if (!b)
        {
            printf("La secuencia NO está ordenada\n");
            insercion(t, n);
            printf("Los valores en orden ascendente son: [ ");
            for (i =1; i < n + 1; i = i + 1)
            {
                printf(" %d", t[i]);
            }
            printf(" ]\n");
        }
        else
        {
            printf("La secuencia está ordenada\n");
        }
        printf("Deseas continuar? s/n: ");
        scanf(" %c", &res);        
    } while(res == 's' || res == 'S');
    printf (" \n");
    return 0;
}
boolean esta_ordenada(tablaM t, int n)
{
    boolean b;
    int i;
    i = 1;
    while ((i < n-1) && (t[i] <= t[i + 1]))
    {
        i = i+1;
    }
    b = (t[i] <= t[i + 1]);
    return b;
}
void insercion(tablaM t, int n)
{
    int x, i, j;
    i = 1;
    while (i < n)
    {
        j = i;
        x = t[i + 1];
        while ((j > 1) && (t[j] > x))
        {
            t[j + 1] = t[j];
            j = j - 1;
        }
        if (t[j] <= x) 
        {
            t[j + 1] = x;
        }
        else
        {
            t[2] = t[1];
            t[1] = x;
        }
        i = i + 1;
    }
    
}
    
