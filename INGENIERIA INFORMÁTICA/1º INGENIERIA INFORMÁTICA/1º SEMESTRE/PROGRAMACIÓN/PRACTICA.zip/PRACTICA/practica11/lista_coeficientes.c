//Programa:Lista coeficientes
//Ibai Larralde Baldanta
//19/11/2020
//Programa que calcula la lista de de los coeficientes binomiales entre un número introducido desde 0 hasta otro número introducido
#include <stdio.h>
int coeficientes_binomiales (int n, int m);
int main (void)
{
    int r,s,k,a;    
    char res;
    printf("Programa: Lista coeficientes\n");  
    printf("Ibai Larralde Baldanta\n");   
    printf("19/11/2020\n");
    printf("Programa que calcula la lista de de los coeficientes binomiales");
    printf("entre un número introducido desde 0 hasta otro número introducido.\n");
    do
    {
        printf("Por favor, introduce un número entero positivo mayor o igual que 0: \n");
        scanf("%d", &s);
        printf("Por favor, introduce un número entero positivo mayor o igual que el anterior: \n");
        scanf("%d", &r);
        if (r < s)
        {
            printf("Error, el segundo número introducido no es mayor que el primero\n");
        }
        else
        {
            for (k = 0; k <= s; k = k+1 )
            {
                a = coeficientes_binomiales(r,k);
                printf("El coeficiente binomial entre %d y %d es %d\n",k,r,a);
            }            
        }
        printf("Deseas continuar? s/n: ");
        scanf(" %c", &res);        
    } while(res == 's' || res == 'S');        
    return 0;
}
int coeficientes_binomiales (int n, int m)
{
    int q,q2;
    if (m == 0)
    {
        q = 1;
    }
    else if (m > 0)
    {
        q2 = coeficientes_binomiales(n,m - 1);
        q = (q2 * (n - m + 1)) / m;
    }
    return q;
}
