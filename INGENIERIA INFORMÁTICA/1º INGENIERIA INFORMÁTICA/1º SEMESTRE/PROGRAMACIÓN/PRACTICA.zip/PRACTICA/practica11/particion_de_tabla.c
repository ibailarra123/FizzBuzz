//Programa: Particición de tabla
//Ibai Larralde Baldanta
//21/11/2020
//Programa que parte en dos tablas una tabla introducida
#include <stdio.h>
#define N 10
typedef int vector [N + 1];
int particion(vector t, int x);
int i_particion(vector t, int x, int q, int z);
int main (void)
{
    int i,x,p;
    vector t;
    char res;
    printf("Programa: Particion de tabla\n");  
    printf("Ibai Larralde Baldanta\n");   
    printf("21/11/2020\n");
    printf("Programa que parte en dos tablas una tabla introducida\n");
    do
    {
        printf("Introduce un numero entero positivo: \n",x);
        scanf( " %d", &x);
        for (i = 0; i < N+1; i = i+1)
        {
            printf("Introduce un numero entero positivo t[%d]: \n",i);
            scanf( " %d", &t[i]);
        }
        printf("La tabla t: [");
        for (i = 0; i < N+1; i = i+1)
        {
            printf(" %d", t[i]);
        }
        printf ("] \n");  
        printf("La primera tabla es: [");
        p = particion(t,x);
        for (i = 0; i < t[p]; i = i+1)
        {
            printf(" %d", t[i]);
        }
        printf ("] \n");
        printf("La segunda tabla es: [");
        for (i = t[p]; i < N+1; i = i+1)
        {
            printf(" %d", t[i]);
        }
        printf ("] \n");
        printf("Deseas continuar? s/n: ");
        scanf(" %c", &res); 
    } while(res == 's' || res == 'S');
    printf (" \n");
    return 0;
}
int particion(vector t, int x)
{
    int p;
    p = i_particion(t, x, 0, 0);
    return p;
}
int i_particion(vector t, int x, int q, int z)
{
    int p;
    if (x < z + t[q + 1])
    {
        p = q;
    }
    else 
    {
        p = i_particion(t, x, q + 1, z + t[q]);
    }
    return p;
}
