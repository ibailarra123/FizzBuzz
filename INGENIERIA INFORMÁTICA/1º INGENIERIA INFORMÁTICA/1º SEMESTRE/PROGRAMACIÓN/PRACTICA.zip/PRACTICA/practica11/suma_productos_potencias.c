//Programa: Suma productos de potencias
//Ibai Larralde Baldanta
//21/11/2020
//Programa que calcula una suma de de productos de potencias
#include <stdio.h>
int sumaprod (int x, int y, int n);
void i_sumaprod(int x, int y, int n, int i, int z, int *s, int *r);
int main (void)
{
    int y,x,n,s;
    char res;
    printf("Programa: Suma productos de potencias\n");  
    printf("Ibai Larralde Baldanta\n");   
    printf("21/11/2020\n");
    printf("Programa que calcula una suma de de productos de potencias\n");
    do
    {
        printf("Por favor, introduce un número entero positivo mayor o igual que 0: \n");
        scanf("%d", &n);
        printf("Por favor, introduce un número para operar: \n");
        scanf("%d", &x);
        printf("Por favor, introduce otro número para operar: \n");
        scanf("%d", &y);
        s = sumaprod(x,y,n);
        printf("El sumatorio de los productos de potencias es: %d\n",s);
        printf("Deseas continuar? s/n: ");
        scanf(" %c", &res); 
    } while(res == 's' || res == 'S');
    printf (" \n");
    return 0;
}

int sumaprod(int x, int y, int n)
{
    int r,s;
    i_sumaprod(x, y, n, n, 1, &s, &r);
    return s;
}
void i_sumaprod(int x, int y, int n, int i, int z, int *s, int *r)
{
    int r2, s2;
    if (i == 0)
    {
        *s = z;
        *r = 1;
    }
    else if (i > 0)
    {
        i_sumaprod(x, y, n, (i - 1), (z * y), &s2, &r2);
        *r = r2 * x;
        *s = s2 + (*r * z);
    }
}
