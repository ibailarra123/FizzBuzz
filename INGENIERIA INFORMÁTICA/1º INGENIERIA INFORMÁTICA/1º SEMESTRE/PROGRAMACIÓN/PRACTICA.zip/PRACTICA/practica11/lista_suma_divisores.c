//Programa:Lista suma divisores
//Ibai Larralde Baldanta
//19/11/2020
//Programa que calcula la suma de divisores de un número natural
#include <stdio.h>
int suma_divisores(int n);
int i_suma_divisores(int n, int p, int k);
int main (void)
{
    int n,i,s;    
    char res;
    printf("Programa: Lista suma divisores\n");  
    printf("Ibai Larralde Baldanta\n");   
    printf("19/11/2020\n");
    printf("Programa que calcula la suma de divisores de un número natural.\n");
    do
    {
        printf("Por favor, introduce un número entero positivo mayor o igual que 1: \n");
        scanf("%d", &n);
        if (n < 1)
        {
            printf("Error, el número introducido es menor que 1\n");
        }
        else
        {
            for (i = 1; i <= n; i = i+1 )
            {
                s = suma_divisores(i);
                printf("La suma de divisores de %d es %d\n",i,s);
            }            
        }
        printf("Deseas continuar? s/n: ");
        scanf(" %c", &res);        
    } while(res == 's' || res == 'S');        
    return 0;
}
int suma_divisores(int n)
{
    int s;
    s = i_suma_divisores(n, 1, 1);
    return s;
}
int i_suma_divisores(int n, int p, int k)
{
    int s;
    if (k == n)
    {
        s = p;
    }
    else
    {
        if (n % (k + 1) == 0)
        {
            s = i_suma_divisores(n, p + (k + 1), (k + 1));
        }
        else
        {
            s = i_suma_divisores(n, p, (k + 1));
        }
    }
    return s;
}
