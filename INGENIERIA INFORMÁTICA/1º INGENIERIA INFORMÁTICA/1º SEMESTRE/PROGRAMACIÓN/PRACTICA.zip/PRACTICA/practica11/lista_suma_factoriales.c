//Programa:Lista suma factoriales
//Ibai Larralde Baldanta
//21/11/2020
//Programa que calcula la suma de los factoriales desde cero hasta un número introducido
#include <stdio.h>
int suma_de_factoriales (int n);
int i_suma_de_factoriales(int n, int p, int k, int z);
int main (void)
{
    int m,k,a;    
    char res;
    printf("Programa: Lista suma factoriales\n");  
    printf("Ibai Larralde Baldanta\n");   
    printf("19/11/2020\n");
    printf("Programa que calcula la suma de los factoriales desde cero");
    printf("hasta un número introducido.\n");
    do
    {
        printf("Por favor, introduce un número entero positivo mayor o igual que 0: \n");
        scanf("%d", &m);
        if (m < 0)
        {
            printf("Error, el número introducido es menor que 0\n");
        }
        else
        {
            for (k = 0; k <= m; k = k+1 )
            {
                a = suma_de_factoriales(k);
                printf("La suma de los factoriales de %d es %d\n",k,a);
            }            
        }
        printf("Deseas continuar? s/n: ");
        scanf(" %c", &res);        
    } while(res == 's' || res == 'S');        
    return 0;
}
int suma_de_factoriales(int n)
{
    int s;
    s = i_suma_de_factoriales(n, 1, 0, 1);
    return s;
}
int i_suma_de_factoriales(int n, int p, int k, int z)
{
    int s;
    if (k == n)
    {
        s = p;
    }
    else
    {
        s = i_suma_de_factoriales(n, ((k + 1) * z) + p, k + 1, (k + 1) * z);
    }
    return s;
}
