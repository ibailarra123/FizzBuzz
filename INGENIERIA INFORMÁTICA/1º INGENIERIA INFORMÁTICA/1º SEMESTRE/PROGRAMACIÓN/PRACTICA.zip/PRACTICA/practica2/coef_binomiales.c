//Programa:Coeficiente Binomial
//Ibai Larralde Baldanta
//01/10/20202
//Este programa calcula el coeficiente binomial entre dos numeros
#include <stdio.h>
int main (void)
{
    int n,m,q,i;
    char res;
    printf("Programa: Coeficiente binomial\n");  
    printf("Ibai Larralde Baldanta\n");   
    printf("01/10/2020\n");
    printf("Programa que realiza ...\n");
    printf(" ... el calculo de el coeficiente binomial entre dos numeros .\n");
    do
    {
        printf("Dame un entero positivo mayor o igual que 0: \n");
        scanf("%d", &m);
        printf("Dame un entero positivo mayor o igual que el anterior: \n");
        scanf("%d", &n);
        i=0;
        q=1;
        if (n<m<0)
        {
         printf("Introducción de datos incorrecta. ");
        }
        else if (n>=m>=0)
        {
            while ( i != m)
            {
                q=(q*(n-i))/(i+1);
                i=i+1;
            }
            printf("El coeficiente binominal es: %d\n",q);
        }
        printf("Deseas continuar? s/n: ");
        scanf(" %c",&res);
    } while(res == 's' || res == 'S');
    return 0;
}
