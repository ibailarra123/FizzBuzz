//Programa:Calculo multiplicidad
//Ibai Larralde Baldanta
//01/10/20202
//Este programa calcula la multiplicidad de un numero natural como factor de otro
#include <stdio.h>
int main (void)
{
    int n,p,s,q;
    char res;
    printf("Programa: Calculo multiplicidad\n");  
    printf("Ibai Larralde Baldanta\n");   
    printf("01/10/2020\n");
    printf("Programa que realiza ...\n");
    printf(" ... el calculo de una multiplicidad de un numero natural como factor de otro .\n");
    do
    {
        printf("Dame un entero mayor o igual que 0: \n");
        scanf("%d", &n);
        printf("Dame un entero primo mayor o igual que 0: \n");
        scanf("%d", &p);
        q=p;
        s=n/p;
        while (n>=q)
        {
         s=s+(n/(q*p));
         q=q*p;   
        }
        printf("El resultado de es: %d\n",s);
        printf("Deseas continuar? s/n: ");
        scanf(" %c",&res);
    } while(res == 's' || res == 'S');
    return 0;
}
