//Programa:Suma agujereada
//Ibai Larralde Baldanta
//01/10/20202
//Este programa calcula una suma agujereada
#include <stdio.h>
int main (void)
{
    int n,k;
    float x,s,q,p;
    char res;
    printf("Programa: Suma Agujereada\n");  
    printf("Ibai Larralde Baldanta\n");   
    printf("01/10/2020\n");
    printf("Programa que realiza ...\n");
    printf(" ... una suma agujereada.\n");
    do
    {
        printf("Dame un entero mayor o igual que : \n");
        scanf("%d", &n);
        printf("Dame un real mayor que 0: \n");
        scanf("%f", &x);
        k=0;
        s=1.0;
        p=1.0;
        q=1.0;
        while (k != n);
        {
            q = q * x;
            p = p * q;
            s = s + p;
            k = k + 1;
        }
        printf("El resultado de la suma agujereada es: %f\n",s);
        printf("Deseas continuar? s/n: ");
        scanf(" %c",&res);
    } while(res == 's' || res == 'S');
    return 0;
}
        
