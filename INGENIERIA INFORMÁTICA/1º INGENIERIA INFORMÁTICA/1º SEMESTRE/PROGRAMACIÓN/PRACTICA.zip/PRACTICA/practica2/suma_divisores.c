//Programa:Suma agujereada
//Ibai Larralde Baldanta
//01/10/20202
//Este programa calcula una suma de divisores de un numero natural
#include <stdio.h>
int main (void)
{
    int n,k,s;
    char res;
    printf("Programa: Suma Agujereada\n");  
    printf("Ibai Larralde Baldanta\n");   
    printf("01/10/2020\n");
    printf("Programa que realiza ...\n");
    printf(" ... una suma de los divisores de un número natural.\n");
    do
    {
        printf("Dame un entero mayor o igual que 1: \n");
        scanf("%d", &n);
        k=n;
        s=n;
        while ( 1 < k)
        {
           if (n%(k-1) == 0)
           {
               s = s + (k-1);
           }
           k = k-1;
        }
        printf("El resultado de la suma de divisores es: %d\n",s);
        printf("Deseas continuar? s/n: ");
        scanf(" %c",&res);
    } while(res == 's' || res == 'S');
    return 0;
}
