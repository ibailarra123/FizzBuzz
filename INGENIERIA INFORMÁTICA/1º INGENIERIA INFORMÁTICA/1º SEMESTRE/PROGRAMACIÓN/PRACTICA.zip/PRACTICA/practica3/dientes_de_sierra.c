//Programa: Dientes de sierra
//Ibai Larralde Baldanta
//05/10/20202
//Este programa realiza una función matemática llamada dientes de sierra.
#include <stdio.h>
int main (void)
{
    int x;
    float y;
    char res;
    printf("Programa: Dientes de sierra\n");  
    printf("Ibai Larralde Baldanta\n");   
    printf("05/10/2020\n");
    printf("Programa que realiza...\n");
    printf("...una función matemática llamada dientes de sierra.\n");
    do
    {
        printf("Introduce un número: ");
        scanf("%d", &x);
        int k;
        if (-5<=x)
        {
            k=0;
            while (x>=((10*k)+5))
            {
                k=k+1;
            }
        }
        else
        {
            k=-1;
            while (x<=(10*k))
            {
                k=k-1;
            }
        }
        y=(3.0/5.0)*(x-(10.0*k));
        printf("Resultado: %f \n",y);
        printf("Deseas continuar? s/n: ");
        scanf(" %c", &res);
    } while(res == 's' || res == 'S');
    return 0;
}
