//Programa: Inversa de Cantor
//Ibai Larralde Baldanta
//05/10/20202
//Este programa hace corresponer un número entero a un numero racional.
#include <stdio.h>
int main (void)
{
    int r,m,n,s,j;
    s=0;
    char res;
    printf("Programa: Inversa de Cantor\n");  
    printf("Ibai Larralde Baldanta\n");   
    printf("05/10/2020\n");
    printf("Programa que hace...\n");
    printf("...corresponer un número entero a un numero racional.\n");
    do
    {
        printf("Introduce un número entero mayor o igual que 0:");
        scanf("%d",&r);
        while (r>=(((s+1)*(s+2))/2))
        {
            s=s+1;
        }
        m=r-(s*(s+1))/2;
        n=s-m;
        j=(((m+n)*(m+n+1)/2)+m);
        printf("m = %d, n = %d, j = %d",m,n,j);
        printf("Deseas continuar? s/n: ");
        scanf(" %c", &res);
    } while(res == 's' || res == 'S');
    return 0;
}
