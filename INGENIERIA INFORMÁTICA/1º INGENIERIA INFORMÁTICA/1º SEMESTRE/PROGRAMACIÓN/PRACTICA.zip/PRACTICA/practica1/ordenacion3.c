//Programa: ordenación de tres números enteros
//Ibai Larralde
//24/09/2020
/*Este programa ordena tres números enteros
de menor a mayor*/
#include <stdio.h>
int main (void)
{
    int x,y,z;
    int p,s,t;
    char res;
    printf("Programa: ordenacion de tres números enteros");
    printf("Nombre del autor: Ibai Larralde");
    printf("24/09/2020");
    printf("Este programa ordena tres números enteros de menor a mayor");
    do
    {
        printf("El programa trabaja con números enteros");
        printf("Dame el primer número entero:");
        scanf("%d",&x);
        printf("Dame el segundo número entero:");
        scanf("%d",&y);
         printf("Dame el tercer número entero:");
        scanf("%d",&z);
        if (x<=y)
        {
            if (y<z)
            {
                p = x;
                s = y;
                t = z;

            }
            else if ((y>=z) && (z>=x))
            {
                p = x;
                s = z;
                t = y;
            }
            else
            {
                p = z;
                s = x;
                t = y;
            }
        }
        else
        {
            if (x<z)
            {
                p = y;
                s = x;
                t = z;
            }
            else if ((y<=z) && (z<=x))
            {
                p = y;
                s = z;
                t = x;
            }
            else
            {
                p = z;
                s = y;
                t = x;
            }
        }
       printf("Los números ordenados de mayor a mayor son:",p,s,t);
       printf("Deseas continuar? s/n: ");
       scanf(" %c",&res);
    } while(res == ’s’ || res == ’S’);
    return 0;
}            
            
